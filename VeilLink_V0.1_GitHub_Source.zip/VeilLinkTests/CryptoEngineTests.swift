import CryptoKit
import XCTest
@testable import VeilLink

final class CryptoEngineTests: XCTestCase {
    func testIdentityIDIsStable() {
        let key = CryptoEngine.newIdentityKey()
        let first = CryptoEngine.identityID(publicKey: key.publicKey.rawRepresentation)
        let second = CryptoEngine.identityID(publicKey: key.publicKey.rawRepresentation)
        XCTAssertEqual(first, second)
        XCTAssertFalse(first.isEmpty)
    }

    func testTwoPeersDeriveSameSessionKeyAndPairingCode() throws {
        let alice = Curve25519.KeyAgreement.PrivateKey()
        let bob = Curve25519.KeyAgreement.PrivateKey()
        let transcript = Data("test-transcript".utf8)

        let aliceKey = try CryptoEngine.deriveSessionKey(
            localPrivateKey: alice,
            remotePublicKey: bob.publicKey.rawRepresentation,
            transcript: transcript
        )
        let bobKey = try CryptoEngine.deriveSessionKey(
            localPrivateKey: bob,
            remotePublicKey: alice.publicKey.rawRepresentation,
            transcript: transcript
        )
        XCTAssertEqual(
            aliceKey.withUnsafeBytes { Data($0) },
            bobKey.withUnsafeBytes { Data($0) }
        )
        XCTAssertEqual(
            CryptoEngine.pairingCode(key: aliceKey, transcript: transcript),
            CryptoEngine.pairingCode(key: bobKey, transcript: transcript)
        )
    }

    func testAuthenticatedEncryptionRoundTrip() throws {
        let key = SymmetricKey(size: .bits256)
        let cleartext = Data("只在两台设备之间出现".utf8)
        let payload = try CryptoEngine.encrypt(cleartext, key: key, messageID: "m1", sequence: 1)
        XCTAssertEqual(try CryptoEngine.decrypt(payload, key: key), cleartext)
    }

    func testBLEFramingRoundTrip() {
        let original = Data((0..<3_000).map { UInt8($0 % 251) })
        let fragments = BLEFragment.split(original, maximumPacketSize: 180)
        let assembler = BLEFragmentAssembler()
        var recovered: Data?
        let source = UUID()
        for fragment in fragments {
            recovered = assembler.ingest(source: source, packet: fragment.encoded) ?? recovered
        }
        XCTAssertEqual(recovered, original)
    }
}
