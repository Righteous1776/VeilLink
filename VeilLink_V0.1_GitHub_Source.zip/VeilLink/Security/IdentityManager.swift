import Combine
import CryptoKit
import Foundation

enum IdentityError: LocalizedError {
    case profileLimitReached
    case passwordTooShort
    case missingIdentity

    var errorDescription: String? {
        switch self {
        case .profileLimitReached: return "本机最多保留 5 个身份。"
        case .passwordTooShort: return "账户密码至少需要 8 个字符。"
        case .missingIdentity: return "未找到本地身份。"
        }
    }
}

@MainActor
final class IdentityManager: ObservableObject {
    static let profileLimit = 5

    @Published private(set) var profiles: [LocalIdentity] = []
    @Published private(set) var activeIdentity: LocalIdentity?

    private let keychain: KeychainStore
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    private enum Key {
        static let profiles = "identity.profiles"
        static let activeID = "identity.active"
        static let deviceID = "device.id"
        static func secret(_ id: String) -> String { "identity.secret.\(id)" }
        static func password(_ id: String) -> String { "identity.password.\(id)" }
    }

    init(keychain: KeychainStore) {
        self.keychain = keychain
        load()
    }

    var deviceID: String {
        if let data = keychain.data(for: Key.deviceID),
           let value = String(data: data, encoding: .utf8) {
            return value
        }
        let value = UUID().uuidString
        try? keychain.set(Data(value.utf8), for: Key.deviceID)
        return value
    }

    @discardableResult
    func createProfile(displayName: String, password: String) throws -> LocalIdentity {
        guard profiles.count < Self.profileLimit else { throw IdentityError.profileLimitReached }
        guard password.count >= 8 else { throw IdentityError.passwordTooShort }

        let signingKey = CryptoEngine.newIdentityKey()
        let publicKey = signingKey.publicKey.rawRepresentation
        let id = CryptoEngine.identityID(publicKey: publicKey)
        let profile = LocalIdentity(
            id: id,
            displayName: displayName.trimmingCharacters(in: .whitespacesAndNewlines),
            publicKey: publicKey,
            createdAt: Date(),
            isPrimary: profiles.isEmpty
        )
        let verifier = PasswordKDF.makeVerifier(password, iterations: 100_000)

        try keychain.set(signingKey.rawRepresentation, for: Key.secret(id))
        try keychain.set(try encoder.encode(verifier), for: Key.password(id))
        profiles.append(profile)
        activeIdentity = profile
        try persist()
        return profile
    }

    func switchProfile(to id: String, password: String) -> Bool {
        guard verifyPassword(password, for: id),
              let profile = profiles.first(where: { $0.id == id }) else { return false }
        activeIdentity = profile
        try? keychain.set(Data(id.utf8), for: Key.activeID)
        return true
    }

    func verifyPassword(_ password: String, for identityID: String) -> Bool {
        guard let data = keychain.data(for: Key.password(identityID)),
              let verifier = try? decoder.decode(PasswordKDF.Verifier.self, from: data) else {
            return false
        }
        return PasswordKDF.verify(password, against: verifier)
    }

    func signingKey() throws -> Curve25519.Signing.PrivateKey {
        guard let id = activeIdentity?.id,
              let data = keychain.data(for: Key.secret(id)) else {
            throw IdentityError.missingIdentity
        }
        return try Curve25519.Signing.PrivateKey(rawRepresentation: data)
    }

    func encryptedIdentityBundle(password: String) throws -> Data {
        guard let identity = activeIdentity,
              verifyPassword(password, for: identity.id),
              let secret = keychain.data(for: Key.secret(identity.id)) else {
            throw IdentityError.missingIdentity
        }
        let salt = PasswordKDF.randomData(count: 16)
        let iterations = 210_000
        let derived = PasswordKDF.derive(
            password: password,
            salt: salt,
            iterations: iterations,
            outputByteCount: 32
        )
        let sealed = try ChaChaPoly.seal(secret, using: SymmetricKey(data: derived))
        let bundle = IdentityExport(
            profile: identity,
            salt: salt,
            iterations: iterations,
            combinedCiphertext: sealed.combined
        )
        return try encoder.encode(bundle)
    }

    func importIdentityBundle(_ data: Data, password: String) throws -> LocalIdentity {
        let bundle = try decoder.decode(IdentityExport.self, from: data)
        let derived = PasswordKDF.derive(
            password: password,
            salt: bundle.salt,
            iterations: bundle.iterations,
            outputByteCount: 32
        )
        let box = try ChaChaPoly.SealedBox(combined: bundle.combinedCiphertext)
        let secret = try ChaChaPoly.open(box, using: SymmetricKey(data: derived))
        let signingKey = try Curve25519.Signing.PrivateKey(rawRepresentation: secret)
        guard signingKey.publicKey.rawRepresentation == bundle.profile.publicKey else {
            throw IdentityError.missingIdentity
        }

        if !profiles.contains(where: { $0.id == bundle.profile.id }) {
            guard profiles.count < Self.profileLimit else { throw IdentityError.profileLimitReached }
            profiles.append(bundle.profile)
        }
        let verifier = PasswordKDF.makeVerifier(password, iterations: 100_000)
        try keychain.set(secret, for: Key.secret(bundle.profile.id))
        try keychain.set(try encoder.encode(verifier), for: Key.password(bundle.profile.id))
        activeIdentity = bundle.profile
        try persist()
        return bundle.profile
    }

    private func load() {
        guard let data = keychain.data(for: Key.profiles),
              let saved = try? decoder.decode([LocalIdentity].self, from: data) else { return }
        profiles = saved
        let activeID = keychain.data(for: Key.activeID).flatMap { String(data: $0, encoding: .utf8) }
        activeIdentity = saved.first(where: { $0.id == activeID }) ?? saved.first
    }

    private func persist() throws {
        try keychain.set(try encoder.encode(profiles), for: Key.profiles)
        if let id = activeIdentity?.id {
            try keychain.set(Data(id.utf8), for: Key.activeID)
        }
    }
}

private struct IdentityExport: Codable {
    let profile: LocalIdentity
    let salt: Data
    let iterations: Int
    let combinedCiphertext: Data
}
