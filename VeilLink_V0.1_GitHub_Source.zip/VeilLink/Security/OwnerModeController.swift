import Combine
import CryptoKit
import Foundation

@MainActor
final class OwnerModeController: ObservableObject {
    @Published private(set) var isUnlocked = false
    @Published private(set) var expiresAt: Date?
    @Published private(set) var capabilities: OwnerCapability = []
    @Published var lastError: String?

    // Replace before release with the public half of an offline owner signing key.
    // No universal decryption or user-content access is granted by this key.
    private let ownerPublicKeyData = Data(base64Encoded:
        "k7p4Oqgqkt4vRSeUDa4TBwYce8u8TSk8wsVeYp0iB2M="
    )!

    func authorizeLocal(password: String, identity: IdentityManager) -> Bool {
        guard let activeID = identity.activeIdentity?.id,
              identity.verifyPassword(password, for: activeID) else {
            lastError = "主身份账户密码不正确。"
            return false
        }
        capabilities = .safeDefault
        expiresAt = Date().addingTimeInterval(20 * 60)
        isUnlocked = true
        lastError = nil
        return true
    }

    func authorize(tokenText: String, deviceID: String) -> Bool {
        guard let data = Data(base64Encoded: tokenText),
              let token = try? JSONDecoder().decode(OwnerToken.self, from: data),
              token.deviceID == deviceID,
              token.expiresAt > Date(),
              let publicKey = try? Curve25519.Signing.PublicKey(rawRepresentation: ownerPublicKeyData),
              publicKey.isValidSignature(token.signature, for: token.signedPayload) else {
            lastError = "授权码无效、已过期或不属于本设备。"
            return false
        }
        capabilities = OwnerCapability(rawValue: token.capabilities)
        expiresAt = token.expiresAt
        isUnlocked = true
        lastError = nil
        return true
    }

    func lock() {
        capabilities = []
        expiresAt = nil
        isUnlocked = false
    }
}

private struct OwnerToken: Codable {
    let deviceID: String
    let capabilities: Int
    let issuedAt: Date
    let expiresAt: Date
    let nonce: String
    let signature: Data

    var signedPayload: Data {
        Data("\(deviceID)|\(capabilities)|\(issuedAt.timeIntervalSince1970)|\(expiresAt.timeIntervalSince1970)|\(nonce)".utf8)
    }
}
