import Combine
import CryptoKit
import Foundation

private enum WireKind: String, Codable {
    case hello
    case encryptedMessage
    case acknowledgement
}

private struct WireEnvelope: Codable {
    let kind: WireKind
    let payload: Data
}

private struct WireChatContent: Codable {
    enum Kind: String, Codable { case text, image }
    let kind: Kind
    let text: String?
    let attachment: Data?
    let mimeType: String?
}

private struct HelloPacket: Codable {
    let identityID: String
    let displayName: String
    let identityPublicKey: Data
    let agreementPublicKey: Data
    let nonce: Data
    let signature: Data

    var signedPayload: Data {
        var value = Data("VeilLink/Hello/v1|\(identityID)|\(displayName)|".utf8)
        value.append(identityPublicKey)
        value.append(agreementPublicKey)
        value.append(nonce)
        return value
    }
}

private struct SessionContext {
    let transportID: UUID
    let localEphemeral: Curve25519.KeyAgreement.PrivateKey
    let localHello: HelloPacket
    var remoteHello: HelloPacket?
    var sessionKey: SymmetricKey?
    var highestReceivedSequence: UInt64 = 0
    var nextSendSequence: UInt64 = 1
}

@MainActor
final class SessionCoordinator: ObservableObject {
    @Published private(set) var nearbyPeers: [NearbyPeer] = []
    @Published var lastError: String?
    @Published private(set) var securityEvents: [String] = []

    var transportSend: ((UUID, Data) -> Void)?
    var onMessagesChanged: (() -> Void)?

    private let identity: IdentityManager
    private let database: DatabaseStore
    private var sessions: [UUID: SessionContext] = [:]
    private var peerTransport: [String: UUID] = [:]
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init(identity: IdentityManager, database: DatabaseStore) {
        self.identity = identity
        self.database = database
    }

    func discovered(transportID: UUID, rssi: Int) {
        if let index = nearbyPeers.firstIndex(where: { $0.transportID == transportID }) {
            nearbyPeers[index].rssi = rssi
            nearbyPeers[index].lastSeen = Date()
        } else {
            nearbyPeers.append(NearbyPeer(
                id: transportID.uuidString,
                transportID: transportID,
                displayName: "未认证设备",
                rssi: rssi,
                trustState: .discovered,
                pairingCode: nil,
                lastSeen: Date()
            ))
        }
    }

    func connected(transportID: UUID) {
        do {
            try sendHello(to: transportID)
        } catch {
            lastError = "握手初始化失败：\(error.localizedDescription)"
        }
    }

    func receive(transportID: UUID, data: Data) {
        do {
            let envelope = try decoder.decode(WireEnvelope.self, from: data)
            switch envelope.kind {
            case .hello:
                try handleHello(transportID: transportID, data: envelope.payload)
            case .encryptedMessage:
                try handleEncryptedMessage(transportID: transportID, data: envelope.payload)
            case .acknowledgement:
                if let messageID = String(data: envelope.payload, encoding: .utf8) {
                    try database.updateDelivery(messageID: messageID, state: .delivered)
                    onMessagesChanged?()
                }
            }
        } catch {
            lastError = "收到无法验证的数据包。"
            securityEvents.insert("拒绝无效数据包 · \(Date().formatted())", at: 0)
        }
    }

    func confirmPairing(peerID: String) {
        guard let index = nearbyPeers.firstIndex(where: { $0.id == peerID }),
              let context = sessions[nearbyPeers[index].transportID],
              let remote = context.remoteHello else { return }
        do {
            try database.trustPeer(
                identityID: remote.identityID,
                displayName: remote.displayName,
                publicKey: remote.identityPublicKey
            )
            if database.conversationID(for: remote.identityID) == nil {
                _ = try database.createConversation(peerIdentityID: remote.identityID, title: remote.displayName)
            }
            nearbyPeers[index].trustState = .trusted
            nearbyPeers[index].pairingCode = nil
            securityEvents.insert("已信任 \(remote.displayName) · 身份指纹已固定", at: 0)
            onMessagesChanged?()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func rejectPairing(peerID: String) {
        guard let index = nearbyPeers.firstIndex(where: { $0.id == peerID }) else { return }
        sessions.removeValue(forKey: nearbyPeers[index].transportID)
        nearbyPeers[index].trustState = .blocked
        nearbyPeers[index].pairingCode = nil
    }

    func sendMessage(_ text: String, to peerIdentityID: String) throws {
        let content = WireChatContent(kind: .text, text: text, attachment: nil, mimeType: nil)
        try sendContent(content, preview: text, to: peerIdentityID)
    }

    func sendImage(_ imageData: Data, mimeType: String = "image/jpeg", to peerIdentityID: String) throws {
        guard imageData.count <= 800_000 else {
            throw NSError(domain: "VeilLink", code: 12, userInfo: [NSLocalizedDescriptionKey: "图片压缩后仍超过 800 KB。"])
        }
        let content = WireChatContent(kind: .image, text: nil, attachment: imageData, mimeType: mimeType)
        try sendContent(content, preview: "[图片]", to: peerIdentityID)
    }

    private func sendContent(_ content: WireChatContent, preview: String, to peerIdentityID: String) throws {
        guard let transportID = peerTransport[peerIdentityID],
              var context = sessions[transportID],
              let key = context.sessionKey,
              database.trustedContact(identityID: peerIdentityID) != nil,
              let sender = identity.activeIdentity,
              let conversationID = database.conversationID(for: peerIdentityID) else {
            throw NSError(domain: "VeilLink", code: 10, userInfo: [NSLocalizedDescriptionKey: "对方当前不在线或尚未完成安全配对。"])
        }
        let message = ChatMessage(
            id: UUID().uuidString,
            conversationID: conversationID,
            senderIdentityID: sender.id,
            body: preview,
            sentAt: Date(),
            isOutgoing: true,
            deliveryState: .sending
        )
        let encrypted = try CryptoEngine.encrypt(
            try encoder.encode(content),
            key: key,
            messageID: message.id,
            sequence: context.nextSendSequence
        )
        context.nextSendSequence += 1
        sessions[transportID] = context
        let envelope = WireEnvelope(kind: .encryptedMessage, payload: try encoder.encode(encrypted))
        transportSend?(transportID, try encoder.encode(envelope))
        try database.saveMessage(message)
        if let attachment = content.attachment, let mimeType = content.mimeType {
            _ = try database.saveAttachment(messageID: message.id, data: attachment, mimeType: mimeType)
        }
        onMessagesChanged?()
    }

    private func sendHello(to transportID: UUID) throws {
        if let context = sessions[transportID] {
            let envelope = WireEnvelope(kind: .hello, payload: try encoder.encode(context.localHello))
            transportSend?(transportID, try encoder.encode(envelope))
            return
        }
        guard let localIdentity = identity.activeIdentity else { throw IdentityError.missingIdentity }
        let ephemeral = Curve25519.KeyAgreement.PrivateKey()
        let nonce = PasswordKDF.randomData(count: 16)
        let unsigned = HelloPacket(
            identityID: localIdentity.id,
            displayName: localIdentity.displayName,
            identityPublicKey: localIdentity.publicKey,
            agreementPublicKey: ephemeral.publicKey.rawRepresentation,
            nonce: nonce,
            signature: Data()
        )
        let signature = try identity.signingKey().signature(for: unsigned.signedPayload)
        let hello = HelloPacket(
            identityID: unsigned.identityID,
            displayName: unsigned.displayName,
            identityPublicKey: unsigned.identityPublicKey,
            agreementPublicKey: unsigned.agreementPublicKey,
            nonce: unsigned.nonce,
            signature: signature
        )
        sessions[transportID] = SessionContext(
            transportID: transportID,
            localEphemeral: ephemeral,
            localHello: hello
        )
        let envelope = WireEnvelope(kind: .hello, payload: try encoder.encode(hello))
        transportSend?(transportID, try encoder.encode(envelope))
    }

    private func handleHello(transportID: UUID, data: Data) throws {
        let remote = try decoder.decode(HelloPacket.self, from: data)
        guard CryptoEngine.identityID(publicKey: remote.identityPublicKey) == remote.identityID else {
            throw CryptoEngineError.invalidSignature
        }
        try CryptoEngine.verify(
            signature: remote.signature,
            for: remote.signedPayload,
            publicKey: remote.identityPublicKey
        )
        if sessions[transportID] == nil {
            try sendHello(to: transportID)
        }
        guard var context = sessions[transportID] else { return }

        let ordered = [context.localHello, remote].sorted { $0.identityID < $1.identityID }
        var transcript = Data("VeilLink/Transcript/v1".utf8)
        for hello in ordered {
            transcript.append(hello.identityPublicKey)
            transcript.append(hello.agreementPublicKey)
            transcript.append(hello.nonce)
        }
        let key = try CryptoEngine.deriveSessionKey(
            localPrivateKey: context.localEphemeral,
            remotePublicKey: remote.agreementPublicKey,
            transcript: transcript
        )
        context.remoteHello = remote
        context.sessionKey = key
        sessions[transportID] = context
        peerTransport[remote.identityID] = transportID

        let trusted = database.trustedContact(identityID: remote.identityID)
        let trustState: NearbyPeer.TrustState = trusted?.publicKey == remote.identityPublicKey ? .trusted : .awaitingConfirmation
        let code = trustState == .trusted ? nil : CryptoEngine.pairingCode(key: key, transcript: transcript)
        let rssi = nearbyPeers.first(where: { $0.transportID == transportID })?.rssi ?? -100
        let peer = NearbyPeer(
            id: remote.identityID,
            transportID: transportID,
            displayName: remote.displayName,
            rssi: rssi,
            trustState: trustState,
            pairingCode: code,
            lastSeen: Date()
        )
        nearbyPeers.removeAll { $0.transportID == transportID || $0.id == remote.identityID }
        nearbyPeers.append(peer)
    }

    private func handleEncryptedMessage(transportID: UUID, data: Data) throws {
        guard var context = sessions[transportID],
              let remote = context.remoteHello,
              let key = context.sessionKey,
              database.trustedContact(identityID: remote.identityID)?.publicKey == remote.identityPublicKey else {
            throw CryptoEngineError.invalidCiphertext
        }
        let payload = try decoder.decode(EncryptedPayload.self, from: data)
        guard payload.sequence > context.highestReceivedSequence else {
            throw CryptoEngineError.invalidCiphertext
        }
        let plaintext = try CryptoEngine.decrypt(payload, key: key)
        let content = try decoder.decode(WireChatContent.self, from: plaintext)
        context.highestReceivedSequence = payload.sequence
        sessions[transportID] = context

        let conversationID: String
        if let existing = database.conversationID(for: remote.identityID) {
            conversationID = existing
        } else {
            conversationID = try database.createConversation(peerIdentityID: remote.identityID, title: remote.displayName)
        }
        let message = ChatMessage(
            id: payload.messageID,
            conversationID: conversationID,
            senderIdentityID: remote.identityID,
            body: content.kind == .image ? "[图片]" : (content.text ?? ""),
            sentAt: Date(),
            isOutgoing: false,
            deliveryState: .delivered
        )
        try database.saveMessage(message)
        if let attachment = content.attachment, let mimeType = content.mimeType {
            _ = try database.saveAttachment(messageID: message.id, data: attachment, mimeType: mimeType)
        }
        let acknowledgement = WireEnvelope(kind: .acknowledgement, payload: Data(payload.messageID.utf8))
        transportSend?(transportID, try encoder.encode(acknowledgement))
        onMessagesChanged?()
    }
}
