import Combine
import Foundation
import LocalAuthentication

@MainActor
final class AppLockController: ObservableObject {
    @Published private(set) var isEnabled: Bool
    @Published private(set) var isLocked: Bool
    @Published private(set) var failedAttempts = 0
    @Published var errorMessage: String?

    private let keychain: KeychainStore
    private let verifierKey = "app.lock.verifier"
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()
    private var lockedUntil: Date?

    init(keychain: KeychainStore) {
        self.keychain = keychain
        isEnabled = keychain.data(for: verifierKey) != nil
        isLocked = isEnabled
    }

    func configure(pin: String) -> Bool {
        guard pin.count == 6, pin.allSatisfy(\.isNumber) else {
            errorMessage = "请输入 6 位数字。"
            return false
        }
        do {
            let verifier = PasswordKDF.makeVerifier(pin, iterations: 60_000)
            try keychain.set(try encoder.encode(verifier), for: verifierKey)
            isEnabled = true
            isLocked = false
            failedAttempts = 0
            return true
        } catch {
            errorMessage = "应用锁保存失败。"
            return false
        }
    }

    func unlock(pin: String) -> Bool {
        if let lockedUntil, lockedUntil > Date() {
            let seconds = Int(lockedUntil.timeIntervalSinceNow.rounded(.up))
            errorMessage = "尝试次数过多，请在 \(seconds) 秒后重试。"
            return false
        }
        guard let data = keychain.data(for: verifierKey),
              let verifier = try? decoder.decode(PasswordKDF.Verifier.self, from: data) else {
            return false
        }
        guard PasswordKDF.verify(pin, against: verifier) else {
            failedAttempts += 1
            if failedAttempts >= 8 {
                lockedUntil = Date().addingTimeInterval(300)
            } else if failedAttempts >= 5 {
                lockedUntil = Date().addingTimeInterval(30)
            }
            errorMessage = "密码不正确"
            return false
        }
        failedAttempts = 0
        lockedUntil = nil
        errorMessage = nil
        isLocked = false
        return true
    }

    func unlockWithBiometrics() async -> Bool {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            return false
        }
        do {
            let result = try await context.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: "解锁 VeilLink"
            )
            if result { isLocked = false }
            return result
        } catch {
            return false
        }
    }

    func lock() {
        guard isEnabled else { return }
        isLocked = true
    }

    func disable(pin: String) -> Bool {
        guard unlock(pin: pin) else { return false }
        keychain.remove(verifierKey)
        isEnabled = false
        isLocked = false
        return true
    }

    func changePIN(current: String, new: String) -> Bool {
        guard unlock(pin: current) else { return false }
        return configure(pin: new)
    }
}
