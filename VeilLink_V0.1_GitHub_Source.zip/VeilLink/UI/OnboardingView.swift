import SwiftUI

struct OnboardingView: View {
    @ObservedObject var model: AppModel
    @State private var name = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var pin = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer(minLength: 36)
                Image(systemName: "point.3.filled.connected.trianglepath.dotted")
                    .font(.system(size: 54, weight: .light))
                    .foregroundColor(VeilTheme.gold)
                VStack(spacing: 8) {
                    Text("VeilLink")
                        .font(.system(size: 32, weight: .semibold, design: .rounded))
                    Text("创建只属于这台设备的离线身份")
                        .foregroundColor(VeilTheme.secondaryText)
                }

                VStack(spacing: 14) {
                    TextField("用户名", text: $name)
                        .textContentType(.nickname)
                    SecureField("账户密码（至少 8 位）", text: $password)
                        .textContentType(.newPassword)
                    SecureField("确认账户密码", text: $confirmPassword)
                        .textContentType(.newPassword)
                    SecureField("6 位应用锁密码", text: $pin)
                        .keyboardType(.numberPad)
                        .onChange(of: pin) { value in
                            pin = String(value.filter(\.isNumber).prefix(6))
                        }
                }
                .textFieldStyle(VeilTextFieldStyle())

                Button {
                    guard password == confirmPassword else {
                        model.alertMessage = "两次输入的账户密码不一致。"
                        return
                    }
                    _ = model.createInitialProfile(name: name, password: password, pin: pin)
                } label: {
                    Text("创建加密身份")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(canCreate ? VeilTheme.gold : VeilTheme.mutedGold.opacity(0.45))
                        .foregroundColor(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .disabled(!canCreate)

                Text("账户密码用于加密备份；六位密码仅用于本机应用锁。完全离线意味着忘记密码后无法通过服务器找回。")
                    .font(.footnote)
                    .foregroundColor(VeilTheme.secondaryText)
                    .multilineTextAlignment(.center)
                Spacer(minLength: 36)
            }
            .frame(maxWidth: 520)
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity)
        }
    }

    private var canCreate: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        password.count >= 8 && password == confirmPassword && pin.count == 6
    }
}

struct VeilTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(14)
            .background(VeilTheme.elevated)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(Color.white.opacity(0.07), lineWidth: 1)
            )
    }
}
