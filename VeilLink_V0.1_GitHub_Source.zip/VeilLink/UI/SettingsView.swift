import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct SettingsView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var ownerMode: OwnerModeController
    @State private var versionTapCount = 0
    @State private var showsLockSheet = false
    @State private var showsBackupSheet = false
    @State private var showsImporter = false
    @State private var restoreURL: URL?
    @State private var showsRestorePassword = false
    @State private var showsOwnerUnlock = false
    @State private var showsOwnerConsole = false

    init(model: AppModel) {
        self.model = model
        ownerMode = model.ownerMode
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                profileCard
                securityCard
                storageCard
                bluetoothCard
                versionFooter
            }
            .frame(maxWidth: 760)
            .padding()
            .frame(maxWidth: .infinity)
        }
        .background(VeilTheme.background)
        .navigationTitle("设置")
        .sheet(isPresented: $showsLockSheet) {
            LockConfigurationSheet(controller: model.appLock)
        }
        .sheet(isPresented: $showsBackupSheet) {
            BackupPasswordSheet { password in
                model.exportBackup(password: password)
            }
        }
        .fileImporter(isPresented: $showsImporter, allowedContentTypes: [.zip]) { result in
            if case .success(let url) = result {
                restoreURL = url
                showsRestorePassword = true
            }
        }
        .sheet(isPresented: $showsRestorePassword) {
            BackupPasswordSheet(title: "恢复加密备份", actionTitle: "验证并恢复") { password in
                if let restoreURL { model.restoreBackup(url: restoreURL, password: password) }
            }
        }
        .sheet(isPresented: Binding(
            get: { model.exportedBackupURL != nil },
            set: { if !$0 { model.exportedBackupURL = nil } }
        )) {
            if let url = model.exportedBackupURL {
                ShareSheet(items: [url])
            }
        }
        .sheet(isPresented: $showsOwnerUnlock) {
            OwnerUnlockSheet(model: model) {
                showsOwnerConsole = true
            }
        }
        .sheet(isPresented: $showsOwnerConsole) {
            OwnerConsoleView(model: model)
        }
    }

    private var profileCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("本地身份", systemImage: "person.text.rectangle")
                .font(.headline).foregroundColor(VeilTheme.gold)
            Text(model.identity.activeIdentity?.displayName ?? "未创建")
                .font(.title3.weight(.semibold))
            Text(model.identity.activeIdentity?.id ?? "")
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(VeilTheme.secondaryText)
                .textSelection(.enabled)
            HStack {
                Text("设备ID")
                Spacer()
                Text(String(model.identity.deviceID.prefix(8)))
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(VeilTheme.secondaryText)
            }
        }
        .veilCard()
    }

    private var securityCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("安全", systemImage: "lock.shield")
                .font(.headline).foregroundColor(VeilTheme.gold)
            settingButton(
                title: "应用锁",
                detail: model.appLock.isEnabled ? "六位密码与生物识别已启用" : "尚未启用",
                icon: "lock.fill"
            ) { showsLockSheet = true }
            Divider().background(Color.white.opacity(0.07))
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("内容加密").fontWeight(.medium)
                    Text("ChaCha20-Poly1305 · Curve25519")
                        .font(.caption).foregroundColor(VeilTheme.secondaryText)
                }
                Spacer()
                Image(systemName: "checkmark.seal.fill").foregroundColor(.green)
            }
        }
        .veilCard()
    }

    private var storageCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("数据与备份", systemImage: "externaldrive")
                .font(.headline).foregroundColor(VeilTheme.gold)
            settingButton(title: "导出加密ZIP", detail: "保存到文件或分享", icon: "square.and.arrow.up") {
                showsBackupSheet = true
            }
            Divider().background(Color.white.opacity(0.07))
            settingButton(title: "恢复备份", detail: "导入身份、对话与附件", icon: "arrow.counterclockwise") {
                showsImporter = true
            }
            HStack {
                Text("SQLite完整性")
                Spacer()
                Text(model.database.integrityCheck())
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.green)
            }
        }
        .veilCard()
    }

    private var bluetoothCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("蓝牙后台", systemImage: "antenna.radiowaves.left.and.right")
                .font(.headline).foregroundColor(VeilTheme.gold)
            Text(model.bluetooth.statusText).fontWeight(.medium)
            Text("已启用 Central / Peripheral 状态恢复。iOS仍可能降低后台扫描频率；重新打开应用后会继续处理队列。")
                .font(.caption)
                .foregroundColor(VeilTheme.secondaryText)
        }
        .veilCard()
    }

    private var versionFooter: some View {
        VStack(spacing: 5) {
            Text("VeilLink 0.1.0 · Protocol 1")
                .font(.caption)
                .foregroundColor(VeilTheme.secondaryText)
            Text("ZeoStudio")
                .font(.caption2)
                .foregroundColor(VeilTheme.mutedGold)
        }
        .padding(.vertical, 20)
        .frame(maxWidth: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            versionTapCount += 1
            if versionTapCount >= 7 {
                versionTapCount = 0
                if ownerMode.isUnlocked {
                    showsOwnerConsole = true
                } else {
                    showsOwnerUnlock = true
                }
            }
        }
    }

    private func settingButton(title: String, detail: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon).frame(width: 24).foregroundColor(VeilTheme.gold)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).fontWeight(.medium).foregroundColor(VeilTheme.text)
                    Text(detail).font(.caption).foregroundColor(VeilTheme.secondaryText)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundColor(VeilTheme.secondaryText)
            }
        }
    }
}

private struct LockConfigurationSheet: View {
    @ObservedObject var controller: AppLockController
    @Environment(\.dismiss) private var dismiss
    @State private var current = ""
    @State private var newPIN = ""

    var body: some View {
        NavigationView {
            Form {
                if controller.isEnabled {
                    SecureField("当前六位密码", text: $current).keyboardType(.numberPad)
                }
                SecureField("新的六位密码", text: $newPIN).keyboardType(.numberPad)
                if let error = controller.errorMessage {
                    Text(error).foregroundColor(.red)
                }
            }
            .navigationTitle("应用锁")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        let success = controller.isEnabled
                            ? controller.changePIN(current: current, new: newPIN)
                            : controller.configure(pin: newPIN)
                        if success { dismiss() }
                    }
                }
            }
        }
    }
}

private struct BackupPasswordSheet: View {
    let title: String
    let actionTitle: String
    let action: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var password = ""

    init(title: String = "导出加密备份", actionTitle: String = "生成ZIP", action: @escaping (String) -> Void) {
        self.title = title
        self.actionTitle = actionTitle
        self.action = action
    }

    var body: some View {
        NavigationView {
            Form {
                SecureField("账户密码", text: $password)
                Text("该密码用于加密备份内容，不是六位应用锁密码。")
                    .font(.footnote).foregroundColor(.secondary)
            }
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(actionTitle) {
                        action(password)
                        dismiss()
                    }
                    .disabled(password.count < 8)
                }
            }
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
