import SwiftUI
import PhotosUI
import UIKit

struct ConversationListView: View {
    @ObservedObject var model: AppModel
    let usesNavigationLinks: Bool

    var body: some View {
        Group {
            if model.conversations.isEmpty {
                VStack(spacing: 14) {
                    Spacer()
                    Image(systemName: "bubble.left.and.exclamationmark.bubble.right")
                        .font(.system(size: 42, weight: .light))
                        .foregroundColor(VeilTheme.gold)
                    Text("还没有对话").font(.headline)
                    Text("前往“附近”发现设备并核对六码")
                        .font(.subheadline)
                        .foregroundColor(VeilTheme.secondaryText)
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .padding()
            } else {
                List(model.conversations) { conversation in
                    if usesNavigationLinks {
                        NavigationLink(destination: ChatView(model: model, conversation: conversation)) {
                            ConversationRow(conversation: conversation)
                        }
                    } else {
                        Button {
                            model.selectedConversation = conversation
                        } label: {
                            ConversationRow(conversation: conversation)
                        }
                        .listRowBackground(model.selectedConversation?.id == conversation.id ? VeilTheme.gold.opacity(0.12) : Color.clear)
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle("对话")
        .background(VeilTheme.background)
    }
}

private struct ConversationRow: View {
    let conversation: ConversationSummary

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(VeilTheme.gold.opacity(0.16))
                .frame(width: 46, height: 46)
                .overlay(Text(String(conversation.title.prefix(1))).foregroundColor(VeilTheme.gold).fontWeight(.bold))
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(conversation.title).fontWeight(.semibold)
                    Spacer()
                    Text(conversation.updatedAt, style: .time)
                        .font(.caption2)
                        .foregroundColor(VeilTheme.secondaryText)
                }
                Text(conversation.lastMessage.isEmpty ? "已建立安全会话" : conversation.lastMessage)
                    .font(.subheadline)
                    .foregroundColor(VeilTheme.secondaryText)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 5)
        .contentShape(Rectangle())
    }
}

struct ChatView: View {
    @ObservedObject var model: AppModel
    let conversation: ConversationSummary
    @State private var messages: [ChatMessage] = []
    @State private var draft = ""
    @State private var showsPhotoPicker = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(messages) { message in
                            MessageBubble(message: message, database: model.database)
                                .id(message.id)
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) { _ in
                    if let last = messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }

            HStack(alignment: .bottom, spacing: 10) {
                Button { showsPhotoPicker = true } label: {
                    Image(systemName: "photo").font(.title3)
                }
                TextField("加密消息", text: $draft)
                    .textFieldStyle(VeilTextFieldStyle())
                Button(action: send) {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 31))
                        .foregroundColor(draft.isEmpty ? VeilTheme.secondaryText : VeilTheme.gold)
                }
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(12)
            .background(VeilTheme.elevated)
        }
        .background(VeilTheme.background)
        .navigationTitle(conversation.title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: reload)
        .onChange(of: model.messagesRevision) { _ in reload() }
        .sheet(isPresented: $showsPhotoPicker) {
            PhotoPicker { data in
                do {
                    try model.sessions.sendImage(data, to: conversation.peerIdentityID)
                    reload()
                } catch {
                    model.alertMessage = error.localizedDescription
                }
            }
        }
    }

    private func reload() {
        messages = model.database.fetchMessages(conversationID: conversation.id)
    }

    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        do {
            try model.sessions.sendMessage(text, to: conversation.peerIdentityID)
            draft = ""
            reload()
        } catch {
            model.alertMessage = error.localizedDescription
        }
    }
}

private struct MessageBubble: View {
    let message: ChatMessage
    let database: DatabaseStore

    var body: some View {
        HStack {
            if message.isOutgoing { Spacer(minLength: 54) }
            VStack(alignment: message.isOutgoing ? .trailing : .leading, spacing: 5) {
                if let attachment = message.attachment {
                    EncryptedImageView(attachment: attachment, database: database)
                        .frame(maxWidth: 260, maxHeight: 320)
                } else {
                    Text(message.body)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(message.isOutgoing ? VeilTheme.gold : VeilTheme.panel)
                        .foregroundColor(message.isOutgoing ? .black : VeilTheme.text)
                        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
                }
                Text(message.sentAt, style: .time)
                    .font(.caption2)
                    .foregroundColor(VeilTheme.secondaryText)
            }
            if !message.isOutgoing { Spacer(minLength: 54) }
        }
    }
}

private struct EncryptedImageView: View {
    let attachment: ChatAttachment
    let database: DatabaseStore
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .contextMenu {
                        Button("保存到照片") { UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil) }
                    }
            } else {
                ProgressView()
                    .frame(width: 180, height: 140)
                    .background(VeilTheme.panel)
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
        }
        .onAppear {
            if let data = database.loadAttachment(id: attachment.id) {
                image = UIImage(data: data)
            }
        }
    }
}

private struct PhotoPicker: UIViewControllerRepresentable {
    let onPicked: (Data) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 1
        let controller = PHPickerViewController(configuration: configuration)
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: PhotoPicker

        init(parent: PhotoPicker) { self.parent = parent }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let provider = results.first?.itemProvider,
                  provider.canLoadObject(ofClass: UIImage.self) else {
                picker.dismiss(animated: true)
                return
            }
            provider.loadObject(ofClass: UIImage.self) { object, _ in
                guard let source = object as? UIImage,
                      let data = Self.prepare(source) else { return }
                DispatchQueue.main.async {
                    self.parent.onPicked(data)
                    picker.dismiss(animated: true)
                }
            }
        }

        private static func prepare(_ image: UIImage) -> Data? {
            let maximumDimension: CGFloat = 1_280
            let scale = min(1, maximumDimension / max(image.size.width, image.size.height))
            let target = CGSize(width: image.size.width * scale, height: image.size.height * scale)
            let renderer = UIGraphicsImageRenderer(size: target)
            let resized = renderer.image { _ in image.draw(in: CGRect(origin: .zero, size: target)) }
            let qualities: [CGFloat] = [0.78, 0.68, 0.58, 0.48, 0.38, 0.28]
            for quality in qualities {
                if let data = resized.jpegData(compressionQuality: quality), data.count <= 800_000 {
                    return data
                }
            }
            return nil
        }
    }
}
