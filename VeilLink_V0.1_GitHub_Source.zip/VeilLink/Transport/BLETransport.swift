import Combine
import CoreBluetooth
import Foundation

@MainActor
final class BLETransport: NSObject, ObservableObject {
    static let serviceUUID = CBUUID(string: "5D0F88D4-21A2-4DC4-A1E8-A2DF8C9AC001")
    static let dataUUID = CBUUID(string: "5D0F88D4-21A2-4DC4-A1E8-A2DF8C9AC002")

    @Published private(set) var statusText = "正在初始化蓝牙"
    @Published private(set) var isRunning = false
    @Published private(set) var discoveredRSSI: [UUID: Int] = [:]

    var onDiscovered: ((UUID, Int) -> Void)?
    var onConnected: ((UUID) -> Void)?
    var onReceive: ((UUID, Data) -> Void)?

    private var centralManager: CBCentralManager!
    private var peripheralManager: CBPeripheralManager!
    private var localCharacteristic: CBMutableCharacteristic?
    private var remotePeripherals: [UUID: CBPeripheral] = [:]
    private var remoteCharacteristics: [UUID: CBCharacteristic] = [:]
    private var subscribedCentrals: [UUID: CBCentral] = [:]
    private var peripheralOutboundQueue: [Data] = []
    private var centralOutboundQueues: [UUID: [Data]] = [:]
    private let assembler = BLEFragmentAssembler()

    override init() {
        super.init()
        centralManager = CBCentralManager(
            delegate: self,
            queue: nil,
            options: [CBCentralManagerOptionRestoreIdentifierKey: "VeilLink.Central.v1"]
        )
        peripheralManager = CBPeripheralManager(
            delegate: self,
            queue: nil,
            options: [CBPeripheralManagerOptionRestoreIdentifierKey: "VeilLink.Peripheral.v1"]
        )
    }

    func start() {
        isRunning = true
        beginScanningIfPossible()
        beginAdvertisingIfPossible()
    }

    func stop() {
        isRunning = false
        centralManager.stopScan()
        peripheralManager.stopAdvertising()
        statusText = "蓝牙发现已暂停"
    }

    func connect(to id: UUID) {
        guard let peripheral = remotePeripherals[id], peripheral.state == .disconnected else { return }
        centralManager.connect(peripheral, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: true])
    }

    func send(_ data: Data, to transportID: UUID) {
        if let peripheral = remotePeripherals[transportID],
           let characteristic = remoteCharacteristics[transportID],
           peripheral.state == .connected {
            let maximum = peripheral.maximumWriteValueLength(for: .withoutResponse)
            centralOutboundQueues[transportID, default: []].append(
                contentsOf: BLEFragment.split(data, maximumPacketSize: maximum).map(\.encoded)
            )
            drainCentralQueue(peripheral: peripheral, characteristic: characteristic)
            return
        }

        guard subscribedCentrals[transportID] != nil,
              let localCharacteristic else { return }
        for fragment in BLEFragment.split(data, maximumPacketSize: 180) {
            let packet = fragment.encoded
            if !peripheralManager.updateValue(packet, for: localCharacteristic, onSubscribedCentrals: [subscribedCentrals[transportID]!]) {
                peripheralOutboundQueue.append(packet)
            }
        }
    }

    private func drainCentralQueue(peripheral: CBPeripheral, characteristic: CBCharacteristic) {
        let id = peripheral.identifier
        while peripheral.canSendWriteWithoutResponse,
              var queue = centralOutboundQueues[id],
              !queue.isEmpty {
            let packet = queue.removeFirst()
            centralOutboundQueues[id] = queue
            peripheral.writeValue(packet, for: characteristic, type: .withoutResponse)
        }
    }

    private func beginScanningIfPossible() {
        guard isRunning, centralManager.state == .poweredOn else { return }
        centralManager.scanForPeripherals(
            withServices: [Self.serviceUUID],
            options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
        )
        statusText = "正在发现附近设备"
    }

    private func beginAdvertisingIfPossible() {
        guard isRunning, peripheralManager.state == .poweredOn else { return }
        if localCharacteristic == nil {
            let characteristic = CBMutableCharacteristic(
                type: Self.dataUUID,
                properties: [.write, .writeWithoutResponse, .notify],
                value: nil,
                permissions: [.writeable]
            )
            let service = CBMutableService(type: Self.serviceUUID, primary: true)
            service.characteristics = [characteristic]
            localCharacteristic = characteristic
            peripheralManager.removeAllServices()
            peripheralManager.add(service)
        } else {
            advertise()
        }
    }

    private func advertise() {
        guard !peripheralManager.isAdvertising else { return }
        peripheralManager.startAdvertising([
            CBAdvertisementDataServiceUUIDsKey: [Self.serviceUUID],
            CBAdvertisementDataLocalNameKey: "VeilLink"
        ])
    }
}

extension BLETransport: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn: beginScanningIfPossible()
        case .poweredOff: statusText = "蓝牙已关闭"
        case .unauthorized: statusText = "没有蓝牙权限"
        case .unsupported: statusText = "此设备不支持低功耗蓝牙"
        default: statusText = "蓝牙暂不可用"
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        remotePeripherals[peripheral.identifier] = peripheral
        discoveredRSSI[peripheral.identifier] = RSSI.intValue
        onDiscovered?(peripheral.identifier, RSSI.intValue)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        peripheral.discoverServices([Self.serviceUUID])
        statusText = "已建立蓝牙链路"
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        remoteCharacteristics.removeValue(forKey: peripheral.identifier)
        statusText = "连接已断开，等待重连"
    }

    func centralManager(_ central: CBCentralManager, willRestoreState dict: [String: Any]) {
        guard let restored = dict[CBCentralManagerRestoredStatePeripheralsKey] as? [CBPeripheral] else { return }
        for peripheral in restored {
            remotePeripherals[peripheral.identifier] = peripheral
            peripheral.delegate = self
        }
    }
}

extension BLETransport: CBPeripheralDelegate {
    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        guard let characteristic = remoteCharacteristics[peripheral.identifier] else { return }
        drainCentralQueue(peripheral: peripheral, characteristic: characteristic)
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        peripheral.services?.forEach { service in
            peripheral.discoverCharacteristics([Self.dataUUID], for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristic = service.characteristics?.first(where: { $0.uuid == Self.dataUUID }) else { return }
        remoteCharacteristics[peripheral.identifier] = characteristic
        peripheral.setNotifyValue(true, for: characteristic)
        onConnected?(peripheral.identifier)
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if characteristic.isNotifying {
            onConnected?(peripheral.identifier)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let value = characteristic.value,
              let assembled = assembler.ingest(source: peripheral.identifier, packet: value) else { return }
        onReceive?(peripheral.identifier, assembled)
    }
}

extension BLETransport: CBPeripheralManagerDelegate {
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        switch peripheral.state {
        case .poweredOn: beginAdvertisingIfPossible()
        case .poweredOff: statusText = "蓝牙已关闭"
        case .unauthorized: statusText = "没有蓝牙权限"
        default: break
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        guard error == nil else {
            statusText = "蓝牙服务注册失败"
            return
        }
        advertise()
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        subscribedCentrals[central.identifier] = central
        onConnected?(central.identifier)
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        subscribedCentrals.removeValue(forKey: central.identifier)
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        for request in requests {
            guard let value = request.value else { continue }
            if request.characteristic.properties.contains(.write) {
                peripheral.respond(to: request, withResult: .success)
            }
            if let assembled = assembler.ingest(source: request.central.identifier, packet: value) {
                onReceive?(request.central.identifier, assembled)
            }
        }
    }

    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
        guard let localCharacteristic else { return }
        while let packet = peripheralOutboundQueue.first {
            guard peripheral.updateValue(packet, for: localCharacteristic, onSubscribedCentrals: nil) else { return }
            peripheralOutboundQueue.removeFirst()
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, willRestoreState dict: [String: Any]) {
        if let services = dict[CBPeripheralManagerRestoredStateServicesKey] as? [CBMutableService],
           let characteristic = services.compactMap(\.characteristics).flatMap({ $0 }).compactMap({ $0 as? CBMutableCharacteristic }).first {
            localCharacteristic = characteristic
        }
    }
}
