import Foundation

struct BLEFragment {
    static let headerSize = 22
    let messageID: UUID
    let index: UInt16
    let total: UInt16
    let payload: Data

    var encoded: Data {
        var result = Data([0x56, 0x01])
        var uuid = messageID.uuid
        withUnsafeBytes(of: &uuid) { result.append(contentsOf: $0) }
        var bigIndex = index.bigEndian
        var bigTotal = total.bigEndian
        withUnsafeBytes(of: &bigIndex) { result.append(contentsOf: $0) }
        withUnsafeBytes(of: &bigTotal) { result.append(contentsOf: $0) }
        result.append(payload)
        return result
    }

    init?(data: Data) {
        guard data.count >= Self.headerSize, data[0] == 0x56, data[1] == 0x01 else { return nil }
        let uuidBytes = [UInt8](data[2..<18])
        let tuple: uuid_t = (
            uuidBytes[0], uuidBytes[1], uuidBytes[2], uuidBytes[3],
            uuidBytes[4], uuidBytes[5], uuidBytes[6], uuidBytes[7],
            uuidBytes[8], uuidBytes[9], uuidBytes[10], uuidBytes[11],
            uuidBytes[12], uuidBytes[13], uuidBytes[14], uuidBytes[15]
        )
        messageID = UUID(uuid: tuple)
        index = UInt16(data[18]) << 8 | UInt16(data[19])
        total = UInt16(data[20]) << 8 | UInt16(data[21])
        payload = data.dropFirst(Self.headerSize)
    }

    private init(messageID: UUID, index: UInt16, total: UInt16, payload: Data) {
        self.messageID = messageID
        self.index = index
        self.total = total
        self.payload = payload
    }

    static func split(_ data: Data, maximumPacketSize: Int) -> [BLEFragment] {
        let chunkSize = max(1, maximumPacketSize - headerSize)
        let count = max(1, Int(ceil(Double(data.count) / Double(chunkSize))))
        guard count <= Int(UInt16.max) else { return [] }
        let messageID = UUID()
        return (0..<count).map { index in
            let start = min(index * chunkSize, data.count)
            let end = min(start + chunkSize, data.count)
            return BLEFragment(
                messageID: messageID,
                index: UInt16(index),
                total: UInt16(count),
                payload: data[start..<end]
            )
        }
    }
}

final class BLEFragmentAssembler {
    private struct Partial {
        let createdAt: Date
        let total: UInt16
        var chunks: [UInt16: Data]
    }

    private var partials: [String: Partial] = [:]

    func ingest(source: UUID, packet: Data) -> Data? {
        guard let fragment = BLEFragment(data: packet) else { return nil }
        let key = "\(source.uuidString):\(fragment.messageID.uuidString)"
        var partial = partials[key] ?? Partial(createdAt: Date(), total: fragment.total, chunks: [:])
        guard partial.total == fragment.total, fragment.index < fragment.total else { return nil }
        partial.chunks[fragment.index] = fragment.payload
        partials[key] = partial
        prune()

        guard partial.chunks.count == Int(partial.total) else { return nil }
        var output = Data()
        for index in 0..<partial.total {
            guard let chunk = partial.chunks[index] else { return nil }
            output.append(chunk)
        }
        partials.removeValue(forKey: key)
        return output
    }

    private func prune() {
        let cutoff = Date().addingTimeInterval(-600)
        partials = partials.filter { $0.value.createdAt > cutoff }
    }
}
