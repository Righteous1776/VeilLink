import CryptoKit
import Foundation
import SQLite3

enum DatabaseError: LocalizedError {
    case openFailed(String)
    case statementFailed(String)
    case backupFailed(String)

    var errorDescription: String? {
        switch self {
        case .openFailed(let message), .statementFailed(let message), .backupFailed(let message):
            return message
        }
    }
}

final class DatabaseStore {
    let databaseURL: URL
    let attachmentsURL: URL

    private var db: OpaquePointer?
    private var storageKey: SymmetricKey
    private var storageKeyData: Data
    private let keychain: KeychainStore
    private let storageKeyName = "storage.database.key"
    private let queue = DispatchQueue(label: "studio.zeo.veillink.sqlite", qos: .userInitiated)
    private let transient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

    init(keychain: KeychainStore) throws {
        self.keychain = keychain
        if let existing = keychain.data(for: storageKeyName) {
            storageKeyData = existing
            storageKey = SymmetricKey(data: existing)
        } else {
            let generated = PasswordKDF.randomData(count: 32)
            try keychain.set(generated, for: storageKeyName)
            storageKeyData = generated
            storageKey = SymmetricKey(data: generated)
        }
        let fileManager = FileManager.default
        let support = try fileManager.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        ).appendingPathComponent("VeilLink", isDirectory: true)
        try fileManager.createDirectory(at: support, withIntermediateDirectories: true)
        databaseURL = support.appendingPathComponent("veillink.sqlite")
        attachmentsURL = support.appendingPathComponent("Attachments", isDirectory: true)
        try fileManager.createDirectory(at: attachmentsURL, withIntermediateDirectories: true)

        var handle: OpaquePointer?
        let flags = SQLITE_OPEN_CREATE | SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX
        guard sqlite3_open_v2(databaseURL.path, &handle, flags, nil) == SQLITE_OK else {
            let message = handle.map { String(cString: sqlite3_errmsg($0)) } ?? "未知错误"
            sqlite3_close(handle)
            throw DatabaseError.openFailed("数据库打开失败：\(message)")
        }
        db = handle
        try migrate()
    }

    deinit {
        sqlite3_close(db)
    }

    func upsertProfile(_ profile: LocalIdentity) throws {
        try write(
            """
            INSERT INTO profiles(id, display_name, public_key, created_at, is_primary)
            VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                display_name = excluded.display_name,
                is_primary = excluded.is_primary;
            """,
            bindings: [.text(profile.id), .text(profile.displayName), .blob(profile.publicKey),
                       .double(profile.createdAt.timeIntervalSince1970), .int(profile.isPrimary ? 1 : 0)]
        )
    }

    func trustPeer(identityID: String, displayName: String, publicKey: Data) throws {
        try write(
            """
            INSERT INTO contacts(identity_id, display_name, public_key, trust_state, created_at)
            VALUES(?, ?, ?, 'trusted', ?)
            ON CONFLICT(identity_id) DO UPDATE SET
                display_name = excluded.display_name,
                public_key = excluded.public_key,
                trust_state = 'trusted';
            """,
            bindings: [.text(identityID), .text(displayName), .blob(publicKey), .double(Date().timeIntervalSince1970)]
        )
    }

    func createConversation(peerIdentityID: String, title: String) throws -> String {
        let id = UUID().uuidString
        try write(
            "INSERT INTO conversations(id, peer_identity_id, title, updated_at) VALUES(?, ?, ?, ?);",
            bindings: [.text(id), .text(peerIdentityID), .text(title), .double(Date().timeIntervalSince1970)]
        )
        return id
    }

    func trustedContact(identityID: String) -> TrustedContact? {
        read(
            "SELECT identity_id, display_name, public_key FROM contacts WHERE identity_id = ? AND trust_state = 'trusted' LIMIT 1;",
            bindings: [.text(identityID)]
        ) { statement in
            TrustedContact(
                identityID: text(statement, 0),
                displayName: text(statement, 1),
                publicKey: data(statement, 2)
            )
        }.first
    }

    func conversationID(for peerIdentityID: String) -> String? {
        read(
            "SELECT id FROM conversations WHERE peer_identity_id = ? ORDER BY updated_at DESC LIMIT 1;",
            bindings: [.text(peerIdentityID)]
        ) { text($0, 0) }.first
    }

    func saveMessage(_ message: ChatMessage) throws {
        let protectedBody = try ChaChaPoly.seal(Data(message.body.utf8), using: storageKey).combined
        try write(
            """
            INSERT OR REPLACE INTO messages(
                id, conversation_id, sender_identity_id, body_ciphertext,
                sent_at, is_outgoing, delivery_state
            ) VALUES(?, ?, ?, ?, ?, ?, ?);
            """,
            bindings: [
                .text(message.id), .text(message.conversationID), .text(message.senderIdentityID),
                .blob(protectedBody), .double(message.sentAt.timeIntervalSince1970),
                .int(message.isOutgoing ? 1 : 0), .text(message.deliveryState.rawValue)
            ]
        )
        try write(
            "UPDATE conversations SET updated_at = ?, last_message_preview = ? WHERE id = ?;",
            bindings: [.double(message.sentAt.timeIntervalSince1970), .blob(protectedBody), .text(message.conversationID)]
        )
    }

    func saveAttachment(messageID: String, data: Data, mimeType: String) throws -> ChatAttachment {
        let id = UUID().uuidString
        let relativePath = "\(id).bin"
        let destination = attachmentsURL.appendingPathComponent(relativePath)
        let protected = try ChaChaPoly.seal(data, using: storageKey).combined
        try protected.write(to: destination, options: [.atomic, .completeFileProtection])
        let hash = Data(SHA256.hash(data: data))
        try write(
            "INSERT INTO attachments(id, message_id, relative_path, mime_type, byte_count, sha256) VALUES(?, ?, ?, ?, ?, ?);",
            bindings: [.text(id), .text(messageID), .text(relativePath), .text(mimeType), .int(data.count), .blob(hash)]
        )
        return ChatAttachment(id: id, mimeType: mimeType, byteCount: data.count)
    }

    func loadAttachment(id: String) -> Data? {
        let paths: [String] = read(
            "SELECT relative_path FROM attachments WHERE id = ? LIMIT 1;",
            bindings: [.text(id)],
            transform: { text($0, 0) }
        )
        guard let relativePath = paths.first else { return nil }
        let url = attachmentsURL.appendingPathComponent(relativePath)
        guard url.standardizedFileURL.deletingLastPathComponent() == attachmentsURL.standardizedFileURL,
              let protected = try? Data(contentsOf: url),
              let box = try? ChaChaPoly.SealedBox(combined: protected),
              let opened = try? ChaChaPoly.open(box, using: storageKey) else { return nil }
        return opened
    }

    func updateDelivery(messageID: String, state: ChatMessage.DeliveryState) throws {
        try write(
            "UPDATE messages SET delivery_state = ? WHERE id = ?;",
            bindings: [.text(state.rawValue), .text(messageID)]
        )
    }

    func fetchConversations() -> [ConversationSummary] {
        read(
            """
            SELECT id, title, peer_identity_id, COALESCE(last_message_preview, ''), updated_at, unread_count
            FROM conversations ORDER BY updated_at DESC;
            """
        ) { statement in
            let previewBlob = data(statement, 3)
            let preview: String
            if let box = try? ChaChaPoly.SealedBox(combined: previewBlob),
               let clear = try? ChaChaPoly.open(box, using: storageKey) {
                preview = String(data: clear, encoding: .utf8) ?? ""
            } else {
                preview = ""
            }
            return ConversationSummary(
                id: text(statement, 0),
                title: text(statement, 1),
                peerIdentityID: text(statement, 2),
                lastMessage: preview,
                updatedAt: Date(timeIntervalSince1970: sqlite3_column_double(statement, 4)),
                unreadCount: Int(sqlite3_column_int(statement, 5))
            )
        }
    }

    func fetchMessages(conversationID: String) -> [ChatMessage] {
        read(
            """
            SELECT m.id, m.conversation_id, m.sender_identity_id, m.body_ciphertext,
                   m.sent_at, m.is_outgoing, m.delivery_state,
                   a.id, a.mime_type, a.byte_count
            FROM messages m
            LEFT JOIN attachments a ON a.message_id = m.id
            WHERE m.conversation_id = ? ORDER BY m.sent_at ASC;
            """,
            bindings: [.text(conversationID)]
        ) { statement in
            let blob = data(statement, 3)
            let plaintext: Data
            if let box = try? ChaChaPoly.SealedBox(combined: blob),
               let opened = try? ChaChaPoly.open(box, using: storageKey) {
                plaintext = opened
            } else {
                plaintext = Data()
            }
            let attachment: ChatAttachment?
            if sqlite3_column_type(statement, 7) != SQLITE_NULL {
                attachment = ChatAttachment(
                    id: text(statement, 7),
                    mimeType: text(statement, 8),
                    byteCount: Int(sqlite3_column_int64(statement, 9))
                )
            } else {
                attachment = nil
            }
            return ChatMessage(
                id: text(statement, 0),
                conversationID: text(statement, 1),
                senderIdentityID: text(statement, 2),
                body: String(data: plaintext, encoding: .utf8) ?? "",
                sentAt: Date(timeIntervalSince1970: sqlite3_column_double(statement, 4)),
                isOutgoing: sqlite3_column_int(statement, 5) == 1,
                deliveryState: ChatMessage.DeliveryState(rawValue: text(statement, 6)) ?? .failed,
                attachment: attachment
            )
        }
    }

    func createConsistentSnapshot(at destinationURL: URL) throws {
        try queue.sync {
            guard let source = db else { throw DatabaseError.backupFailed("数据库尚未打开。") }
            try? FileManager.default.removeItem(at: destinationURL)
            var destination: OpaquePointer?
            guard sqlite3_open(destinationURL.path, &destination) == SQLITE_OK,
                  let destination else {
                sqlite3_close(destination)
                throw DatabaseError.backupFailed("无法创建备份数据库。")
            }
            defer { sqlite3_close(destination) }

            guard let backup = sqlite3_backup_init(destination, "main", source, "main") else {
                throw DatabaseError.backupFailed(String(cString: sqlite3_errmsg(destination)))
            }
            defer { sqlite3_backup_finish(backup) }
            guard sqlite3_backup_step(backup, -1) == SQLITE_DONE else {
                throw DatabaseError.backupFailed(String(cString: sqlite3_errmsg(destination)))
            }
        }
    }

    func replaceDatabase(with snapshotURL: URL) throws {
        try queue.sync {
            guard let current = db else { throw DatabaseError.openFailed("数据库尚未打开。") }
            var source: OpaquePointer?
            guard sqlite3_open_v2(snapshotURL.path, &source, SQLITE_OPEN_READONLY, nil) == SQLITE_OK,
                  let source else {
                sqlite3_close(source)
                throw DatabaseError.backupFailed("恢复包中的数据库无法打开。")
            }
            defer { sqlite3_close(source) }
            guard let backup = sqlite3_backup_init(current, "main", source, "main") else {
                throw DatabaseError.backupFailed(String(cString: sqlite3_errmsg(current)))
            }
            defer { sqlite3_backup_finish(backup) }
            guard sqlite3_backup_step(backup, -1) == SQLITE_DONE else {
                throw DatabaseError.backupFailed(String(cString: sqlite3_errmsg(current)))
            }
        }
    }

    func integrityCheck() -> String {
        read("PRAGMA integrity_check;") { text($0, 0) }.first ?? "unknown"
    }

    func wrappedStorageKey(using backupKey: SymmetricKey) throws -> Data {
        try ChaChaPoly.seal(storageKeyData, using: backupKey).combined
    }

    func installWrappedStorageKey(_ wrapped: Data, using backupKey: SymmetricKey) throws {
        let box = try ChaChaPoly.SealedBox(combined: wrapped)
        let rawKey = try ChaChaPoly.open(box, using: backupKey)
        guard rawKey.count == 32 else { throw BackupError.corruptedPackage }
        try keychain.set(rawKey, for: storageKeyName)
        storageKeyData = rawKey
        storageKey = SymmetricKey(data: rawKey)
    }

    private func migrate() throws {
        try execute("PRAGMA journal_mode=WAL;")
        try execute("PRAGMA foreign_keys=ON;")
        try execute("PRAGMA synchronous=NORMAL;")
        try execute("PRAGMA busy_timeout=3000;")
        try execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations(
                version INTEGER PRIMARY KEY,
                applied_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS profiles(
                id TEXT PRIMARY KEY,
                display_name TEXT NOT NULL,
                public_key BLOB NOT NULL,
                created_at REAL NOT NULL,
                is_primary INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS contacts(
                identity_id TEXT PRIMARY KEY,
                display_name TEXT NOT NULL,
                public_key BLOB NOT NULL,
                trust_state TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS conversations(
                id TEXT PRIMARY KEY,
                peer_identity_id TEXT NOT NULL,
                title TEXT NOT NULL,
                last_message_preview TEXT,
                updated_at REAL NOT NULL,
                unread_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_conversations_updated
                ON conversations(updated_at DESC);
            CREATE TABLE IF NOT EXISTS messages(
                id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                sender_identity_id TEXT NOT NULL,
                body_ciphertext BLOB NOT NULL,
                sent_at REAL NOT NULL,
                is_outgoing INTEGER NOT NULL,
                delivery_state TEXT NOT NULL,
                FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_messages_conversation_time
                ON messages(conversation_id, sent_at);
            CREATE TABLE IF NOT EXISTS attachments(
                id TEXT PRIMARY KEY,
                message_id TEXT NOT NULL,
                relative_path TEXT NOT NULL,
                mime_type TEXT NOT NULL,
                byte_count INTEGER NOT NULL,
                sha256 BLOB NOT NULL,
                FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS pending_packets(
                id TEXT PRIMARY KEY,
                target_identity_id TEXT NOT NULL,
                encrypted_payload BLOB NOT NULL,
                expires_at REAL NOT NULL,
                retry_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS audit_events(
                id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                redacted_detail TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            INSERT OR IGNORE INTO schema_migrations(version, applied_at)
                VALUES(1, strftime('%s','now'));
            """
        )
    }

    private func execute(_ sql: String) throws {
        try queue.sync {
            guard let db else { throw DatabaseError.openFailed("数据库尚未打开。") }
            var error: UnsafeMutablePointer<Int8>?
            guard sqlite3_exec(db, sql, nil, nil, &error) == SQLITE_OK else {
                let message = error.map { String(cString: $0) } ?? String(cString: sqlite3_errmsg(db))
                sqlite3_free(error)
                throw DatabaseError.statementFailed(message)
            }
        }
    }

    private func write(_ sql: String, bindings: [SQLiteValue] = []) throws {
        try queue.sync {
            guard let db else { throw DatabaseError.openFailed("数据库尚未打开。") }
            var statement: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK,
                  let statement else {
                throw DatabaseError.statementFailed(String(cString: sqlite3_errmsg(db)))
            }
            defer { sqlite3_finalize(statement) }
            bind(bindings, to: statement)
            guard sqlite3_step(statement) == SQLITE_DONE else {
                throw DatabaseError.statementFailed(String(cString: sqlite3_errmsg(db)))
            }
        }
    }

    private func read<T>(
        _ sql: String,
        bindings: [SQLiteValue] = [],
        transform: (OpaquePointer) -> T
    ) -> [T] {
        queue.sync {
            guard let db else { return [] }
            var statement: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK,
                  let statement else { return [] }
            defer { sqlite3_finalize(statement) }
            bind(bindings, to: statement)
            var results: [T] = []
            while sqlite3_step(statement) == SQLITE_ROW {
                results.append(transform(statement))
            }
            return results
        }
    }

    private func bind(_ values: [SQLiteValue], to statement: OpaquePointer) {
        for (offset, value) in values.enumerated() {
            let index = Int32(offset + 1)
            switch value {
            case .text(let value):
                value.withCString { sqlite3_bind_text(statement, index, $0, -1, transient) }
            case .blob(let value):
                value.withUnsafeBytes { buffer in
                    sqlite3_bind_blob(statement, index, buffer.baseAddress, Int32(buffer.count), transient)
                }
            case .double(let value): sqlite3_bind_double(statement, index, value)
            case .int(let value): sqlite3_bind_int64(statement, index, sqlite3_int64(value))
            case .null: sqlite3_bind_null(statement, index)
            }
        }
    }

    private func text(_ statement: OpaquePointer, _ column: Int32) -> String {
        guard let pointer = sqlite3_column_text(statement, column) else { return "" }
        return String(cString: pointer)
    }

    private func data(_ statement: OpaquePointer, _ column: Int32) -> Data {
        guard let bytes = sqlite3_column_blob(statement, column) else { return Data() }
        return Data(bytes: bytes, count: Int(sqlite3_column_bytes(statement, column)))
    }
}

private enum SQLiteValue {
    case text(String)
    case blob(Data)
    case double(Double)
    case int(Int)
    case null
}
