# VeilLink V0.1 architecture

VeilLink is an offline, nearby, end-to-end encrypted messenger for iOS 15 and later.
The initial implementation uses only public Apple frameworks at runtime, except for
ZIPFoundation which is linked into the application for local backup packaging.

## Trust boundaries

1. BLE advertisements contain only the service UUID and a transport name. They do
   not contain usernames, contacts, message text, or long-term private keys.
2. Each local profile owns an Ed25519 identity signing key. Its public-key hash is
   the stable identity ID.
3. Each connection creates a new X25519 ephemeral key and derives a session key by
   HKDF-SHA256.
4. A six-digit short authentication string is shown on both devices. The contact
   is trusted only after both users compare it.
5. Messages use ChaCha20-Poly1305 with an authenticated message ID and sequence.
6. Long-term secrets and local storage keys live in iOS Keychain. Message bodies in
   SQLite are independently encrypted at rest.

## Bluetooth transport

Both devices advertise and scan using CoreBluetooth. A custom GATT service carries
framed data. Frames include a UUID, index, total count, and payload. The receiver
reassembles them with a two-minute expiry. V0.1 supports compressed JPEG payloads
up to 800 KB. Resumable attachment checkpoints are planned for V0.2.

CoreBluetooth state restoration and the bluetooth-central / bluetooth-peripheral
background declarations are enabled. iOS may still throttle scans, suspend the
process, or stop relaunch after a user force-quit. VeilLink therefore persists work
and resumes opportunistically instead of claiming daemon-like background service.

## Persistence and backup

SQLite runs in WAL mode with foreign keys and indexed conversation/message access.
The backup path uses sqlite3_backup to make a consistent snapshot, encrypts the
database, identity bundle, storage key and attachments, then produces a ZIP. Restore
validates the manifest and creates a rollback snapshot before replacing data.

## Adaptive interface

- Compact width: tab navigation and stacked conversation screens.
- Regular width: persistent 330-point sidebar and independent detail area.
- Features remain the same on iPhone 7 and newer devices. Performance adaptation
  is limited to memory, image decoding, concurrency, and animation complexity.

## Owner Mode

Owner Mode is hidden behind seven taps on the version footer. It accepts a signed,
device-bound, expiring capability token for managed builds; V0.1 also permits a
20-minute local session after verifying the active identity password. The owner
public key is embedded, while the private key must remain offline. Capabilities are limited to redacted diagnostics,
protocol tuning, group governance, and consented visual effects. It cannot decrypt
private messages, export user keys, bypass app locks, or execute arbitrary code.
