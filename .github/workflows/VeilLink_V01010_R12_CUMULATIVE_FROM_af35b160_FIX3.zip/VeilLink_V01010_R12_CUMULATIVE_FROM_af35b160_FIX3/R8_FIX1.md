# R8 FIX1

The isolated cumulative run passed R1A through R7, then R8 stopped with:

`REFUSE: scripts/verify-core-release.py: 0.10.5 anchor count=3, expected 1`

The release verifier intentionally contains the version in three positions and the
quoted build in two. FIX1 requires those exact cardinalities and updates all of them.
It does not relax prerequisite, version, transaction, stage-order, or rollback gates.
