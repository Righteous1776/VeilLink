# R10 FIX1

The guarded cumulative run passed R1A through R10, then R11 rejected the
generated `SessionCoordinator.swift`: `679b...` did not equal R11's protected
R10 baseline `1ee9...`.

The af35 tree carries later reconnect/game integration in this file. R10 FIX1
accepts only the known generated hash (or the already-canonical hash), then
normalizes to an embedded canonical R10 file whose SHA-256 must equal R11's
existing `1ee94e...` guard. The R11 baseline hash, its guard, and its installer
are not modified. The overwritten af35/R9 source remains preserved by R10's
existing `docs/history/voice/V0107_R9` snapshot.
