# 给 Work 的执行指令：VeilLink R12 累计重建与 GitHub 对齐

你现在接手的是 VeilLink 的 **R12 累计重建任务**，不是重新规划项目，也不是继续在当前 GitHub `main` 上叠单独的 R12 补丁。

目标只有一个：把仓库重建并对齐到 **V0.10.10 build 52 / R12 Runtime Maintenance** 的真实源码状态。

累计链固定为：
`R1A → R2 → R3 → R4 → R5 → R6 → R7 → R8 → R9 → R10 → R11 → R12`

原 R1 已废弃，禁止使用；R1A 是修正版第一层。

当前远端 `main` 观察到的 HEAD 是：
`a7b1112bcdd82aec79c430edc9ff5966204496d8`
提交名：`Stage guarded V0.10.10 R12 publisher`

注意：这不代表 R12 已经进入 main。该提交只放入了 R12 carrier 和 publisher workflow。R12 发布工作流 run `36018174096` 失败，原因是 GitHub 当前源码与 R12 所要求的 R11 基线不一致。这个保护必须保留，禁止修改 hash、删除 guard 或强行让 R12 小补丁继续执行。

执行步骤如下：

1. 先备份当前远端 `main`。建立明确的备份分支，例如 `backup/pre-r12-cumulative-20260924`。不要删除当前历史。

2. 建立一个**隔离的临时工作区/临时分支**，HEAD 必须精确位于：
`af35b160fcc9b97d3c82963f1dea8ee6dbdb5773`
工作树必须干净。不要从当前 main 直接开始。

3. 将本累计包解压到仓库之外的临时目录。累计包内已经包含 R1A 到 R12 的全部增量 ZIP、SHA-256 manifest、总安装器和验证器。

4. 在 VeilLink 仓库根目录运行：

```bash
python3 /path/to/VeilLink_V01010_R12_CUMULATIVE_FROM_af35b160/verify_cumulative_bundle.py
python3 /path/to/VeilLink_V01010_R12_CUMULATIVE_FROM_af35b160/apply_cumulative_r12.py
```

总安装器会：
- 校验 12 个内嵌补丁 ZIP 的 SHA-256；
- 按固定顺序执行 R1A→R12；
- 每层完成后检查版本/Build；
- 最后执行 `git diff --check`；
- 最后执行 `scripts/verify-runtime-maintenance-r12.py`；
- 任一层失败时回滚到最初 `af35b160...` 基线。

成功必须看到：
`VEILLINK_R12_CUMULATIVE_PASS`
以及最终：`0.10.10 / build 52`。

5. 任意一层失败都立即停止。禁止跳层、手改 SHA、删 baseline guard、继续使用半升级工作树。把失败层、完整错误、`git status --short` 和相关文件 SHA-256 带回分析。

6. 累计重建成功后，先做源码审计，至少确认以下内容都存在且没有倒退：
- Core 默认仍是 Lean Runtime；
- MaleCNS / VFLY / Qwen / llama 等研发历史保留，但不能重新进入 Core 默认发行包；
- Xiangqi/Gomoku/Ludo 原生 Bot 路径保留；
- VeilTalk Lite 保留；
- App Control Plane、Control Plane V2/V3、AutoTune 保留；
- 原始 UI 仍作为主题保留；
- 新的昼夜自动拟物主题保留；
- 首页工具中心与拟物对讲机 UI 保留；
- 聊天语音消息保留；
- PTT 对讲机保留；
- R11 jitter buffer、实时队列和 iPhone 7 PTT 调优保留；
- R12 性能维护保留：取消永久 2 秒出站轮询、BLE activity-aware maintenance、PTT 不再每帧 `Data.removeFirst`、AudioSession 不再每帧重复配置、PTT UI diagnostics 节流、聊天不再无意义重复赋值；
- Wire Protocol 仍为 v4；
- R12 不改变 SQLite schema；
- `docs/history` 的历史快照和 manifest 不得删除。

7. 之后必须跑真实 Apple 工具链。至少完成：
- XcodeGen/工程生成；
- Simulator Build；
- XCTest；
- Release `iphoneos` unsigned build；
- 无签名 IPA 打包。

不能因为 Python verifier 或 Swift parser 通过，就称“构建成功”。

8. 专门检查 iOS 15 / iPhone 7。部署目标必须继续支持 iOS 15；不要无保护使用更高系统 API。重点测试 BLE、录音、语音播放、AudioSession 中断、PTT、拟物主题动画、低亮度和内存压力。

9. 只有累计重建源码通过验证后，才对齐 GitHub `main`。目标是让 main 真正包含 R12 源码，而不是只含 publisher ZIP。建议最终用一个清晰提交，例如：
`Release V0.10.10 build 52 cumulative R12 baseline`

不要为了形式在远端制造 12 个重复迁移提交；累计包和 `docs/history` 已经保留演化记录。

10. 当前临时的 `.github/workflows/veillink-r12-publisher.yml` 和 R12 carrier 只是在旧 main 上尝试迁移的载体。等真实 R12 源码已经进 main 且 CI 通过后，再删除或隔离这些临时 publisher 文件。正常 iOS CI 与 unsigned IPA workflow 不要删。

11. 对齐 main 后再跑 GitHub Actions。必须确认：
- iOS CI PASS；
- XCTest PASS；
- unsigned IPA PASS；
- IPA 对应 `0.10.10 build 52`；
- 记录 run ID、artifact 名称、IPA 大小。

12. 不得为了缩包或修 CI 删除 Experimental AI 历史。规则继续是：**瘦发行版，不毁研发历史**。如果 Core 体积异常，应修 target/source/resource inclusion，而不是毁掉历史文件。

本次任务严格冻结新功能。不要在 R12 对齐过程中开发 R13，不要改 BLE 协议、E2EE 语义、数据库 schema、PTT codec，也不要重新设计拟物 UI。只允许为真实 build/test failure 做最小范围修复，并记录原因。

最终汇报必须包含：
- 最终 main commit SHA；
- `Info.plist` 版本/build；
- 是否出现 `VEILLINK_R12_CUMULATIVE_PASS`；
- 是否有某层需要修复及原因；
- Simulator Build 结果；
- XCTest 结果；
- unsigned device build 结果；
- GitHub Actions run ID；
- IPA artifact 名称和字节大小；
- 临时 R12 publisher/carrier 是否已清理；
- 最终 `git status --short`（必须干净）；
- 尚未解决的问题。

只有 **main 真正包含 R12 源码** 时才允许说“完成”。
