#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,zipfile
H=Path(__file__).resolve().parent
m=json.loads((H/'CUMULATIVE_MANIFEST.json').read_text(encoding='utf-8'))
assert m['baseline_commit']=='af35b160fcc9b97d3c82963f1dea8ee6dbdb5773' and m['target_version']=='0.10.10' and m['target_build']=='52' and len(m['chain'])==12
for i in m['chain']:
 p=H/'patches'/i['archive']
 if not p.is_file(): raise SystemExit(f'MISSING {p}')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=i['archive_sha256']: raise SystemExit(f'SHA FAIL {p.name}')
 with zipfile.ZipFile(p) as z:
  bad=z.testzip()
  if bad: raise SystemExit(f'CRC FAIL {p.name}: {bad}')
  target=f"{i['archive_root']}/{i['apply_script']}"
  if target not in z.namelist(): raise SystemExit(f'APPLIER MISSING {target}')
print('CUMULATIVE_BUNDLE_VERIFY_PASS')
