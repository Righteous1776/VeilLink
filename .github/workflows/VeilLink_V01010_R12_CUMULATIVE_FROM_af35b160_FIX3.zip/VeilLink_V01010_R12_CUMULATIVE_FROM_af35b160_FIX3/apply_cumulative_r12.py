#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, plistlib, subprocess, sys, tempfile, zipfile
HERE=Path(__file__).resolve().parent
PATCHES=HERE/'patches'
MANIFEST=json.loads((HERE/'CUMULATIVE_MANIFEST.json').read_text(encoding='utf-8'))
REPO=Path.cwd().resolve(); BASELINE=MANIFEST['baseline_commit']
def run(*args,cwd=None,capture=False):
    kw={'cwd':str(cwd or REPO),'text':True}
    if capture: kw.update(stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    p=subprocess.run(args,**kw)
    if p.returncode!=0:
        if capture and p.stdout: print(p.stdout)
        raise RuntimeError('command failed: '+' '.join(map(str,args)))
    return (p.stdout or '').strip() if capture else ''
def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def plist_version():
    with (REPO/'VeilLink/Resources/Info.plist').open('rb') as f: obj=plistlib.load(f)
    return str(obj.get('CFBundleShortVersionString')),str(obj.get('CFBundleVersion'))
def rollback():
    print('CUMULATIVE_ROLLBACK: restoring exact baseline')
    subprocess.run(['git','reset','--hard',BASELINE],cwd=REPO)
    subprocess.run(['git','clean','-fd'],cwd=REPO)
if not (REPO/'.git').exists() or not (REPO/'project.yml').is_file(): raise SystemExit('REFUSE: run from VeilLink repository root')
head=run('git','rev-parse','HEAD',capture=True)
if head!=BASELINE: raise SystemExit(f'REFUSE: expected baseline HEAD {BASELINE}, got {head}')
if run('git','status','--porcelain',capture=True).strip(): raise SystemExit('REFUSE: working tree must be clean before cumulative rebuild')
for item in MANIFEST['chain']:
    p=PATCHES/item['archive']
    if not p.is_file(): raise SystemExit(f'REFUSE: missing archive {p.name}')
    actual=sha256(p)
    if actual!=item['archive_sha256']: raise SystemExit(f'REFUSE: archive SHA mismatch {p.name}: {actual}')
try:
    with tempfile.TemporaryDirectory(prefix='veillink-r12-cumulative-') as t:
        t=Path(t)
        for idx,item in enumerate(MANIFEST['chain'],1):
            print(f"[{idx:02d}/{len(MANIFEST['chain']):02d}] APPLY {item['stage']} -> {item['expected_version_after']} ({item['expected_build_after']})")
            s=t/item['stage']; s.mkdir(parents=True,exist_ok=True)
            with zipfile.ZipFile(PATCHES/item['archive'],'r') as z: z.extractall(s)
            script=s/item['archive_root']/item['apply_script']
            if not script.is_file(): raise RuntimeError(f'missing apply script: {script}')
            run(sys.executable,str(script),cwd=REPO)
            v,b=plist_version()
            if (v,b)!=(item['expected_version_after'],item['expected_build_after']): raise RuntimeError(f"{item['stage']} version gate failed: got {v}/{b}")
    run('git','diff','--check')
    v,b=plist_version()
    if (v,b)!=(MANIFEST['target_version'],MANIFEST['target_build']): raise RuntimeError(f'final version mismatch: {v}/{b}')
    verifier=REPO/'scripts/verify-runtime-maintenance-r12.py'
    if not verifier.is_file(): raise RuntimeError('final R12 verifier missing')
    run(sys.executable,str(verifier),cwd=REPO)
    print('VEILLINK_R12_CUMULATIVE_PASS'); print(f'FINAL_VERSION={v}'); print(f'FINAL_BUILD={b}')
except Exception as e:
    print(f'CUMULATIVE_FAILED: {e}',file=sys.stderr); rollback(); raise SystemExit(1)
