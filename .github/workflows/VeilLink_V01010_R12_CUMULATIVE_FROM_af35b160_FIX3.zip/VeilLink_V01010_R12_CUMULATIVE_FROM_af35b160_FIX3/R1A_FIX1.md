# R1A FIX1

The first isolated macOS runner execution stopped at R1A with:

`REFUSE: Core resource exclusions expected one anchor, got 0`

The protected baseline commit and `project.yml` blob matched the package's original
guards. The R1A installer encoded the search anchor newlines as literal `\\n`
characters. FIX1 converts those characters to real newlines only for the named
`Core resource exclusions` anchor. No expected HEAD, blob SHA, version gate, stage
order, feature, protocol, or schema rule was changed.
