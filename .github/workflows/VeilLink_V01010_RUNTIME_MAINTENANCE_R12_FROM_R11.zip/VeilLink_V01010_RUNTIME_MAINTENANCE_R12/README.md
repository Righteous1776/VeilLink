# VeilLink V0.10.10 build 52 · Runtime Maintenance R12

Local-only incremental maintenance package from R11 (V0.10.9 build 51).

This release freezes feature growth and targets runtime cost only. Protocol v4, E2EE semantics, SQLite schema, voice message format and PTT wire kinds are unchanged.

Main changes:
- Removes the permanent 2-second outbound retry timer. Retry maintenance exists only while a trusted live transport and pending outbox both exist.
- BLE maintenance polling becomes activity-aware: slow while idle, moderate while connected, faster only while queues contain data. RSSI sampling is independently throttled.
- PTT TX uses a cursor/periodic compaction instead of `Data.removeFirst` every 80 ms frame.
- PTT playback caches the 8 kHz format and does not reconfigure AVAudioSession on every frame.
- PTT jitter diagnostic publishing is throttled, especially on iPhone 7/A10, to reduce SwiftUI invalidations.
- Chat reloads no longer toggle a loading state for routine ACK/progress refreshes and do not reassign unchanged message arrays.
- Removes a duplicate SQLite `fetchMessage` in attachment checkpoint handling.

Installer is transactional and preserves the replaced R11 files under `docs/history/maintenance/V0109_R11_R12_BASE/` with SHA-256 metadata.

No GitHub/network operation is performed by this package.
