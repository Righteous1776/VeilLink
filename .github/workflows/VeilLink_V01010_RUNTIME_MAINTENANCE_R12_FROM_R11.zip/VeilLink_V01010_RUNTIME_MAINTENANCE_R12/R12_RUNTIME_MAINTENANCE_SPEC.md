# R12 Runtime Maintenance

## Frozen compatibility boundaries
- Wire protocol remains v4.
- PTT wire kinds remain 6/7.
- Voice message codec and attachment checkpoint format remain unchanged.
- No SQLite migration or schema mutation.
- No new user-facing feature or permission.

## Runtime goals
1. Eliminate idle retry polling when there is no deliverable work.
2. Reduce BLE/RSSI wakeups on A10-class devices without slowing queue-stall recovery under load.
3. Remove avoidable memory shifting from 80 ms PTT frame production.
4. Reduce AudioSession and SwiftUI churn during sustained PTT.
5. Avoid unchanged chat-array publication during delivery/progress bursts.

## Device policy
Legacy/iPhone 7 deliberately uses longer maintenance and UI diagnostic intervals. Queue-bearing transports stay on the shortest maintenance interval so active transfers and PTT recovery remain responsive.
