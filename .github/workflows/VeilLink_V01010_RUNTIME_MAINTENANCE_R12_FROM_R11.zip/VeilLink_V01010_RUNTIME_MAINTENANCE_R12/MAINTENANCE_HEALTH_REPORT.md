# R12 Maintenance Health Report

Baseline: V0.10.9 build 51 R11
Target: V0.10.10 build 52 R12

Static/runtime-structure improvements confirmed:
- SessionCoordinator permanent Combine retry timer: 1 -> 0.
- PTT `pendingMuLaw.removeFirst` hot-path shifts: 1 -> 0.
- Chat reload unconditional `messages = loadedMessages`: 1 -> 0.
- BLE maintenance is now activity-aware; RSSI sampling is independently throttled.
- PTT jitter diagnostic publication is device-tier throttled.
- PTT playback format is cached and AVAudioSession setup is no longer called on every scheduled frame.
- Duplicate SQLite message fetch in attachment checkpoint stale-state path removed.

Compatibility held:
- Wire protocol v4 unchanged.
- PTT wire kinds 6/7 unchanged.
- Voice attachment and checkpoint formats unchanged.
- SQLite schema unchanged.
- No new user-facing permission or feature.

Validation limitations:
- No Xcode/iOS build was run in this environment.
- No physical iPhone 7/iPhone 13 BLE/audio session was run in this environment.
