#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys

HERE=Path(__file__).resolve().parent
REPO=Path.cwd().resolve()
sys.path.insert(0,str(HERE))
from upgrade_transaction import FileTransaction

if not (REPO/'project.yml').is_file() or not (REPO/'VeilLink').is_dir():
    raise SystemExit('REFUSE: run from VeilLink project root')

baseline=json.loads((HERE/'BASELINE_SHA256.json').read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for rel,expected in baseline.items():
    p=REPO/rel
    if not p.is_file(): raise SystemExit(f'REFUSE: missing R11 baseline file {rel}')
    actual=sha(p)
    if actual!=expected: raise SystemExit(f'REFUSE: R11 baseline drift {rel}: {actual} != {expected}')

info_path=REPO/'VeilLink/Resources/Info.plist'
info=info_path.read_text(encoding='utf-8')
def plist_value(key):
    m=re.findall(rf'<key>{re.escape(key)}</key>\s*<string>([^<]+)</string>',info)
    if len(m)!=1: raise SystemExit(f'REFUSE: plist {key} count={len(m)}')
    return m[0]
if plist_value('CFBundleShortVersionString')!='0.10.9' or plist_value('CFBundleVersion')!='51':
    raise SystemExit('REFUSE: expected V0.10.9 build 51 R11 baseline')

payload_map={
 'VeilLink/Core/RuntimeMaintenanceTuning.swift':'payload/VeilLink/Core/RuntimeMaintenanceTuning.swift',
 'VeilLink/Security/SessionCoordinator.swift':'payload/VeilLink/Security/SessionCoordinator.swift',
 'VeilLink/Transport/BLETransport.swift':'payload/VeilLink/Transport/BLETransport.swift',
 'VeilLink/UI/ConversationViews.swift':'payload/VeilLink/UI/ConversationViews.swift',
 'VeilLink/Voice/WalkieTalkieAudioController.swift':'payload/VeilLink/Voice/WalkieTalkieAudioController.swift',
 'VeilLinkTests/RuntimeMaintenanceOptimizationR12Tests.swift':'payload/VeilLinkTests/RuntimeMaintenanceOptimizationR12Tests.swift',
}
for dst,src in payload_map.items():
    if not (HERE/src).is_file(): raise SystemExit(f'REFUSE: missing payload {src}')

history_root=Path('docs/history/maintenance/V0109_R11_R12_BASE')
for rel in baseline:
    dest=REPO/history_root/rel
    if dest.exists(): raise SystemExit(f'REFUSE: history destination already exists: {dest.relative_to(REPO)}')
if (REPO/history_root/'manifest.json').exists(): raise SystemExit('REFUSE: R11 history manifest already exists')

try:
    with FileTransaction(REPO) as tx:
        history_entries={}
        for rel,expected in baseline.items():
            source=REPO/rel
            tx.write_bytes(history_root/rel,source.read_bytes())
            history_entries[rel]={'sha256':expected,'bytes':source.stat().st_size}
        tx.write_text(history_root/'manifest.json',json.dumps({
            'source_version':'0.10.9','source_build':'51',
            'purpose':'R12 pre-maintenance local preservation snapshot',
            'files':history_entries,
        },indent=2,ensure_ascii=False)+'\n')

        for dst,src in payload_map.items():
            tx.write_bytes(dst,(HERE/src).read_bytes())

        next_info=info
        next_info,n1=re.subn(r'(<key>CFBundleShortVersionString</key>\s*<string>)0\.10\.9(</string>)',r'\g<1>0.10.10\2',next_info,count=1)
        next_info,n2=re.subn(r'(<key>CFBundleVersion</key>\s*<string>)51(</string>)',r'\g<1>52\2',next_info,count=1)
        if n1!=1 or n2!=1: raise RuntimeError('version mutation failed')
        tx.write_text('VeilLink/Resources/Info.plist',next_info)
        tx.write_bytes('scripts/verify-runtime-maintenance-r12.py',(HERE/'verify-runtime-maintenance-r12.py').read_bytes(),mode=0o755)

        verifier=subprocess.run([sys.executable,str(REPO/'scripts/verify-runtime-maintenance-r12.py')],cwd=REPO,text=True,capture_output=True)
        if verifier.returncode!=0:
            raise RuntimeError('R12 verifier failed: '+(verifier.stdout+verifier.stderr).strip())

        swiftc=shutil.which('swiftc')
        if swiftc:
            for rel in payload_map:
                if rel.endswith('.swift'):
                    parsed=subprocess.run([swiftc,'-frontend','-parse',str(REPO/rel)],cwd=REPO,text=True,capture_output=True)
                    if parsed.returncode!=0:
                        raise RuntimeError(f'Swift parse failed {rel}: '+(parsed.stdout+parsed.stderr).strip())

        if os.environ.get('VEILLINK_FORCE_R12_FAIL')=='1':
            raise RuntimeError('FORCED_FAIL')
        tx.commit()
except Exception as exc:
    raise SystemExit(f'R12 FAILED AND ROLLED BACK: {exc}')

print('VEILLINK_R12_INSTALL_PASS')
