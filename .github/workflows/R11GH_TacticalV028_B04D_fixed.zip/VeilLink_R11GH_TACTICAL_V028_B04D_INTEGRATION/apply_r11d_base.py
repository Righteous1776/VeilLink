#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path.cwd()
BASE = HERE / "apply_r11c_base.py"
PREFLIGHT = HERE / "ci-standard-preflight.py"

if not (REPO / ".git").exists():
    raise SystemExit("Run this script from the repository root.")

subprocess.run([sys.executable, str(BASE)], cwd=REPO, check=True)

gitignore = REPO / ".gitignore"
text = gitignore.read_text(encoding="utf-8")
addition = "\n# Python build/cache hygiene\n__pycache__/\n*.py[cod]\n"
if "__pycache__/" not in text:
    gitignore.write_text(text.rstrip() + addition, encoding="utf-8")

for rel in [
    "scripts/__pycache__/make-local-ai-project.cpython-312.pyc",
    "scripts/__pycache__/verify-vfly-installed.cpython-312.pyc",
    "scripts/__pycache__/write-local-ai-provenance.cpython-312.pyc",
]:
    p = REPO / rel
    if p.exists():
        p.unlink()

destination = REPO / "scripts" / "ci-standard-preflight.py"
destination.write_bytes(PREFLIGHT.read_bytes())
destination.chmod(0o755)

workflow = REPO / ".github" / "workflows" / "ios-ci.yml"
wf = workflow.read_text(encoding="utf-8")
anchor = """      - name: Install XcodeGen
        run: brew install xcodegen 2>&1 | tee ci-artifacts/install-xcodegen.log
"""
insert = """      - name: Static standard preflight
        run: |
          set -o pipefail
          python3 scripts/ci-standard-preflight.py 2>&1 | tee ci-artifacts/static-preflight.log

      - name: Install XcodeGen
        run: brew install xcodegen 2>&1 | tee ci-artifacts/install-xcodegen.log
"""
if wf.count(anchor) != 1:
    raise SystemExit(f"REFUSE: iOS CI insertion anchor count = {wf.count(anchor)}")
workflow.write_text(wf.replace(anchor, insert, 1), encoding="utf-8")

print("R11-D CUMULATIVE PATCH APPLIED")
print("INCLUDES=R11-A,R11-B,R11-C,R11-D")
print("STANDARD_PREFLIGHT=enabled")
print("TRACKED_PYC=removed")
