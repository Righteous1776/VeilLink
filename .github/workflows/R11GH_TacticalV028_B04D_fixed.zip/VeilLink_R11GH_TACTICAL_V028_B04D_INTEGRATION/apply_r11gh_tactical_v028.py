#!/usr/bin/env python3
from pathlib import Path
import shutil, subprocess, sys

HERE=Path(__file__).resolve().parent
REPO=Path.cwd()
if not (REPO/'.git').exists(): raise SystemExit('Run this script from the repository root.')

subprocess.run([sys.executable,str(HERE/'apply_r11gh_base.py')],cwd=REPO,check=True)

for rel in ['VeilLink/Core/TacticalV2','VeilLink/UI/TacticalV2','VeilLink/Security/TacticalPendingRevealSecureStoreV2.swift']:
    if (REPO/rel).exists(): raise SystemExit(f'REFUSE: Tactical V2 target already exists: {rel}')

overlay=HERE/'tactical_overlay'
for src in sorted(overlay.rglob('*')):
    if not src.is_file(): continue
    rel=src.relative_to(overlay)
    dst=REPO/rel
    if dst.exists(): raise SystemExit(f'REFUSE: Tactical overlay would overwrite existing file: {rel}')
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

verifier=REPO/'scripts/verify-tactical-v2-assets.py'
if verifier.exists(): raise SystemExit('REFUSE: scripts/verify-tactical-v2-assets.py already exists')
shutil.copy2(HERE/'verify-tactical-v2-assets.py',verifier)
verifier.chmod(0o755)

def replace_once(path,old,new,label):
    p=REPO/path
    text=p.read_text(encoding='utf-8')
    count=text.count(old)
    if count!=1: raise SystemExit(f'REFUSE: {label} expected one anchor, found {count}')
    p.write_text(text.replace(old,new,1),encoding='utf-8')

replace_once('VeilLink/Security/SessionCoordinator.swift','    func sendImage(_ imageData: Data, mimeType: String, to peerIdentityID: String) throws {\n','    func sendTacticalV2Envelope(\n        _ envelope: TacticalV2.WireEnvelopeV2,\n        to peerIdentityID: String\n    ) throws {\n        let encoded = try TacticalV2.WireCodecV2.encode(envelope)\n        guard encoded.lengthOfBytes(using: .utf8) <= WireProtocol.maximumTextBytes else {\n            throw NSError(\n                domain: "VeilLink",\n                code: 24,\n                userInfo: [NSLocalizedDescriptionKey: "兵棋 V2 操作数据超过当前消息上限。"]\n            )\n        }\n        try queueContent(\n            WireChatContent(\n                kind: .text,\n                text: encoded,\n                attachment: nil,\n                mimeType: nil,\n                sentAt: envelope.createdAt,\n                attachmentByteCount: nil,\n                attachmentSHA256: nil,\n                attachmentChunkCount: nil\n            ),\n            preview: TacticalV2.WireCodecV2.previewText(for: envelope),\n            to: peerIdentityID\n        )\n    }\n\n    func sendImage(_ imageData: Data, mimeType: String, to peerIdentityID: String) throws {\n','Tactical V2 E2EE sender')
replace_once('VeilLink/UI/ConversationViews.swift','            return messages.filter { MiniGameCodec.decode($0.body) == nil && ConversationSearch.matches($0, query: query) }\n','            return messages.filter {\n                MiniGameCodec.decode($0.body) == nil\n                    && TacticalV2.WireCodecV2.decode($0.body) == nil\n                    && ConversationSearch.matches($0, query: query)\n            }\n','hide Tactical V2 from search')
replace_once('VeilLink/UI/ConversationViews.swift','        return messages.filter { message in\n            guard let packet = MiniGameCodec.decode(message.body) else { return true }\n            return packet.command == .invite\n        }\n','        return messages.filter { message in\n            if TacticalV2.WireCodecV2.decode(message.body) != nil { return false }\n            guard let packet = MiniGameCodec.decode(message.body) else { return true }\n            return packet.command == .invite\n        }\n','hide Tactical V2 from transcript')
replace_once('VeilLink/UI/MiniGameViews.swift','    private var latestLocalGameMessage: ChatMessage? {\n        messages.reversed().first { message in\n            guard message.isOutgoing, let packet = MiniGameCodec.decode(message.body) else { return false }\n            return packet.sessionID == sessionID\n        }\n    }\n','    private var latestLocalGameMessage: ChatMessage? {\n        messages.reversed().first { message in\n            guard message.isOutgoing else { return false }\n            if let packet = MiniGameCodec.decode(message.body) {\n                return packet.sessionID == sessionID\n            }\n            if let envelope = TacticalV2.WireCodecV2.decode(message.body) {\n                return envelope.sessionID == sessionID\n            }\n            return false\n        }\n    }\n','Tactical V2 latest local record')
replace_once('VeilLink/UI/MiniGameViews.swift','        case .tactical:\n            if let state = session.tactical {\n                TacticalBoardView(\n                    state: state,\n                    localPlayer: session.localPlayer,\n                    enabled: session.isLocalTurn && !isSending,\n                    onMove: { from, to in\n                        send(command: .move, turn: session.moveCount, move: .tactical(from: from, to: to))\n                    },\n                    onPass: {\n                        send(command: .move, turn: session.moveCount, move: .tacticalPass())\n                    }\n                )\n                .padding(.horizontal, 10)\n            }\n','        case .tactical:\n            if let state = session.tactical {\n                TacticalV2LaunchGateView(\n                    model: model,\n                    conversation: conversation,\n                    session: session,\n                    messages: messages,\n                    legacyState: state,\n                    legacyEnabled: session.isLocalTurn && !isSending,\n                    onLegacyMove: { from, to in\n                        send(command: .move, turn: session.moveCount, move: .tactical(from: from, to: to))\n                    },\n                    onLegacyPass: {\n                        send(command: .move, turn: session.moveCount, move: .tacticalPass())\n                    }\n                )\n            }\n','Tactical V2 launch gate')
replace_once('VeilLink/Core/MiniGames.swift','case .tactical: return "官渡决战 · 六角格轻量历史兵棋"','case .tactical: return "官渡决战 · 战役大地图 · 战争迷雾"','Tactical game subtitle')

preflight=REPO/'scripts/ci-standard-preflight.py'
text=preflight.read_text(encoding='utf-8')
old='    if len(tests) < 38:\n        fail(f"expected at least 38 test source files, got {len(tests)}")'
new='    if len(tests) < 39:\n        fail(f"expected at least 39 test source files, got {len(tests)}")'
if text.count(old)!=1: raise SystemExit('REFUSE: preflight 38-test anchor mismatch')
text=text.replace(old,new,1)
old='        "A9RuntimeConstraintTests.swift",\n    }'
new='        "A9RuntimeConstraintTests.swift",\n        "TacticalV2Tests.swift",\n    }'
if text.count(old)!=1: raise SystemExit('REFUSE: Tactical test inventory anchor mismatch')
text=text.replace(old,new,1)
anchor='    print("Resource JSON: PASS")'
insert='''    print("Resource JSON: PASS")\n    run([\n        sys.executable,\n        str(ROOT / "scripts" / "verify-tactical-v2-assets.py"),\n        "--repo-root",\n        str(ROOT),\n    ])'''
if text.count(anchor)!=1: raise SystemExit('REFUSE: Tactical verifier insertion anchor mismatch')
preflight.write_text(text.replace(anchor,insert,1),encoding='utf-8')

release=REPO/'scripts/verify-release-carrier.py'
rt=release.read_text(encoding='utf-8')
old='    "qwen_sha256": "da2572f16c06133561ce56accaa822216f2391ef4d37fba427801cd6736417d4",'
new=old+'\n    "tactical_map_sha256": "4bd450353ae993b0c8083b97ab5909c8260cd6984be6f6051db1967613edaaa5",'
if rt.count(old)!=1: raise SystemExit('REFUSE: release EXPECTED anchor mismatch')
rt=rt.replace(old,new,1)
old='''    if qwen_sha != EXPECTED["qwen_sha256"]:\n        fail(f"Qwen SHA mismatch: {qwen_sha}")\n\n    core_sha = sha256_file(app / "VeilFlyCore.vfly")'''
new='''    if qwen_sha != EXPECTED["qwen_sha256"]:\n        fail(f"Qwen SHA mismatch: {qwen_sha}")\n\n    tactical_map = find_one_by_name(app, "guandu_large_map_v2_48x27.json")\n    tactical_map_sha = sha256_file(tactical_map)\n    if tactical_map_sha != EXPECTED["tactical_map_sha256"]:\n        fail(f"Tactical map SHA mismatch: {tactical_map_sha}")\n\n    core_sha = sha256_file(app / "VeilFlyCore.vfly")'''
if rt.count(old)!=1: raise SystemExit('REFUSE: release app map anchor mismatch')
rt=rt.replace(old,new,1)
old='''        "notices": notices.relative_to(app).as_posix(),\n        "llama_framework_sha256": sha256_file(app / "Frameworks/llama.framework/llama"),'''
new='''        "notices": notices.relative_to(app).as_posix(),\n        "tactical_v2": {\n            "map_relative_path": tactical_map.relative_to(app).as_posix(),\n            "map_sha256": tactical_map_sha,\n            "map_dimensions": [48, 27],\n            "fow": "redacted-player-view",\n            "wire_protocol": "VLTW2-over-existing-E2EE",\n        },\n        "llama_framework_sha256": sha256_file(app / "Frameworks/llama.framework/llama"),'''
if rt.count(old)!=1: raise SystemExit('REFUSE: release app report anchor mismatch')
rt=rt.replace(old,new,1)
old='''        if sha256_bytes(z.read(qwen_entries[0])) != EXPECTED["qwen_sha256"]:\n            fail("IPA Qwen SHA mismatch")\n\n    return {'''
new='''        if sha256_bytes(z.read(qwen_entries[0])) != EXPECTED["qwen_sha256"]:\n            fail("IPA Qwen SHA mismatch")\n\n        tactical_entries = [n for n in names if n.startswith(prefix) and n.endswith("guandu_large_map_v2_48x27.json")]\n        if len(tactical_entries) != 1:\n            fail(f"expected one Tactical V2 map IPA entry, got {len(tactical_entries)}")\n        if sha256_bytes(z.read(tactical_entries[0])) != EXPECTED["tactical_map_sha256"]:\n            fail("IPA Tactical V2 map SHA mismatch")\n\n    return {'''
if rt.count(old)!=1: raise SystemExit('REFUSE: release IPA map anchor mismatch')
release.write_text(rt.replace(old,new,1),encoding='utf-8')

workflow=REPO/'.github/workflows/malecns-heavy-validation.yml'
wf=workflow.read_text(encoding='utf-8')
wf=wf.replace('VeilLink-unsigned-v0.9.7-b41-DualBrain','VeilLink-unsigned-v0.9.7-b41-DualBrain-TacticalV2')
workflow.write_text(wf,encoding='utf-8')

subprocess.run([sys.executable,str(verifier),'--repo-root',str(REPO)],cwd=REPO,check=True)

print('R11-GH + Tactical V0.2.8 B04D INTEGRATION APPLIED')
print('TACTICAL_TRANSPORT=VLTW2 over existing E2EE text channel')
print('PENDING_REVEAL=Keychain ThisDeviceOnly')
print('DIVERGENCE_HOLD=enabled')
print('STANDARD_TEST_FILES_MIN=39')
