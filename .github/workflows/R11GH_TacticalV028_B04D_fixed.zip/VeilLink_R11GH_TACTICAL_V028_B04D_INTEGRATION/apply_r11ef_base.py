#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path.cwd()
if not (REPO / '.git').exists():
    raise SystemExit('Run this script from the repository root.')

subprocess.run([sys.executable, str(HERE / 'apply_r11d1_base.py')], cwd=REPO, check=True)

EXPECTED_BLOBS = {'VeilLink/Agent/Language/LlamaInferenceEngine.swift': '1e66204def6811fc9aabab012ec4e25867c54e6e', 'VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift': '72e690471f28c92c9cc95a5b116b5c2f6cb9a32b', 'VeilLink/Agent/Integration/AgentGameContextBroker.swift': '7aaa8952837eafb7b5048df9481c76c4719354e4', 'VeilLink/App/AppModel.swift': 'fdc29b06498c6d6869161c1456b3629e080b6974', 'VeilLinkTests/RealLocalInferenceSmokeTests.swift': 'c14aaf859720fb455bb539e1520fa2bfabec39a5', 'scripts/inject-vfly-assets.sh': 'f9d9821031d65750ca8186811d7ed0878390023a'}
def sh(*args):
    return subprocess.check_output(args, cwd=REPO, text=True).strip()
for path, expected in EXPECTED_BLOBS.items():
    p = REPO / path
    if not p.exists(): raise SystemExit(f'REFUSE: missing {path}')
    actual = sh('git', 'hash-object', path)
    if actual != expected: raise SystemExit(f'REFUSE: blob mismatch for {path}: expected {expected}, got {actual}')

for new_path in ['VeilLink/Agent/Language/LlamaCancellationGate.swift', 'scripts/verify-malecns-ranker-assets.py', 'VeilLinkTests/AgentGameExecutionValidationTests.swift']:
    if (REPO / new_path).exists(): raise SystemExit(f'REFUSE: {new_path} already exists')

def replace_once(path, old, new, label):
    p = REPO / path
    text = p.read_text(encoding='utf-8')
    count = text.count(old)
    if count != 1: raise SystemExit(f'REFUSE: {label} expected one anchor, found {count}')
    p.write_text(text.replace(old, new, 1), encoding='utf-8')

replace_once('VeilLink/Agent/Language/LlamaInferenceEngine.swift', '    private var backendInitialized = false\n    private var invalidUTF8: [CChar] = []\n\n    init(configuration: LlamaRuntimeConfiguration) {\n        self.configuration = configuration\n    }', '    private var backendInitialized = false\n    private var invalidUTF8: [CChar] = []\n    private let cancellationGate: LlamaCancellationGate\n\n    init(\n        configuration: LlamaRuntimeConfiguration,\n        cancellationGate: LlamaCancellationGate = LlamaCancellationGate()\n    ) {\n        self.configuration = configuration\n        self.cancellationGate = cancellationGate\n    }', 'Llama engine cancellation gate property')
replace_once('VeilLink/Agent/Language/LlamaInferenceEngine.swift', '        guard let model, let context, let vocab, let sampler, var workingBatch = batch else {\n            throw LlamaEngineError.unavailable\n        }\n\n        try Task.checkCancellation()', '        guard let model, let context, let vocab, let sampler, var workingBatch = batch else {\n            throw LlamaEngineError.unavailable\n        }\n\n        let cancellationGeneration = cancellationGate.snapshot()\n        await Task.yield()\n        try Task.checkCancellation()\n        guard cancellationGate.isCurrent(cancellationGeneration) else { throw CancellationError() }', 'Llama generate start cancellation')
replace_once('VeilLink/Agent/Language/LlamaInferenceEngine.swift', '        while cursor < tokens.count {\n            try Task.checkCancellation()\n            clearBatch(&workingBatch)', '        while cursor < tokens.count {\n            await Task.yield()\n            try Task.checkCancellation()\n            guard cancellationGate.isCurrent(cancellationGeneration) else { throw CancellationError() }\n            clearBatch(&workingBatch)', 'Llama prompt-loop cancellation')
replace_once('VeilLink/Agent/Language/LlamaInferenceEngine.swift', '        for offset in 0..<safeMaxNew {\n            try Task.checkCancellation()\n            let token = llama_sampler_sample(sampler, context, -1)', '        for offset in 0..<safeMaxNew {\n            await Task.yield()\n            try Task.checkCancellation()\n            guard cancellationGate.isCurrent(cancellationGeneration) else { throw CancellationError() }\n            let token = llama_sampler_sample(sampler, context, -1)', 'Llama token-loop cancellation')
replace_once('VeilLink/Agent/Language/LlamaInferenceEngine.swift', '        let tail = filter.finish()\n        if !tail.isEmpty {', '        await Task.yield()\n        try Task.checkCancellation()\n        guard cancellationGate.isCurrent(cancellationGeneration) else { throw CancellationError() }\n\n        let tail = filter.finish()\n        if !tail.isEmpty {', 'Llama tail cancellation')
replace_once('VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift', '    private var engine: LlamaInferenceEngine?\n    private var cancellationEpoch: UInt64 = 0\n    private(set) var lastModelLoadMilliseconds: Int?', '    private var engine: LlamaInferenceEngine?\n    private let cancellationGate = LlamaCancellationGate()\n    private var cancellationEpoch: UInt64 = 0\n    private var shutdownTask: Task<Void, Never>?\n    private(set) var lastModelLoadMilliseconds: Int?', 'runtime cancellation/shutdown properties')
replace_once('VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift', '    func prepare() async throws {\n        guard state == .unloaded || state == .unavailable else { return }\n        state = .loading', '    func prepare() async throws {\n        guard state == .unloaded || state == .unavailable else { return }\n        if let pendingShutdown = shutdownTask {\n            await pendingShutdown.value\n            shutdownTask = nil\n        }\n        state = .loading', 'runtime waits for previous shutdown')
replace_once('VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift', '            let newEngine = LlamaInferenceEngine(configuration: configuration)', '            let newEngine = LlamaInferenceEngine(\n                configuration: configuration,\n                cancellationGate: cancellationGate\n            )', 'runtime shares cancellation gate')
replace_once('VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift', '    func cancel() {\n        cancellationEpoch &+= 1\n        if state == .generating || state == .loading { state = .ready }', '    func cancel() {\n        cancellationEpoch &+= 1\n        cancellationGate.cancel()\n        if state == .generating || state == .loading { state = .ready }', 'runtime cancel reaches engine loop')
replace_once('VeilLink/Agent/Language/LlamaLocalTextModelRuntime.swift', '    func unload() {\n        cancellationEpoch &+= 1\n        let old = engine\n        engine = nil\n        lastGenerationStats = nil\n        state = .unloaded\n        Task { await old?.shutdown() }\n        DiagnosticLogStore.shared.log(.info, .agent, event: "local_ai.model.unload")\n    }', '    func unload() {\n        cancellationEpoch &+= 1\n        cancellationGate.cancel()\n        let old = engine\n        engine = nil\n        lastGenerationStats = nil\n        state = .unloaded\n        shutdownTask?.cancel()\n        shutdownTask = Task { await old?.shutdown() }\n        DiagnosticLogStore.shared.log(.info, .agent, event: "local_ai.model.unload")\n    }', 'runtime serialized unload/reload')
replace_once('VeilLink/Agent/Integration/AgentGameContextBroker.swift', '    func currentSuggestedAction(maximumAge: TimeInterval = 25) -> AgentSuggestedGameAction? {\n        guard let context, context.isLocalTurn,\n              Date().timeIntervalSince(context.capturedAt) <= maximumAge else { return nil }\n        return suggestedAction\n    }\n\n    func markSuggestedActionExecuted', '    func currentSuggestedAction(maximumAge: TimeInterval = 25) -> AgentSuggestedGameAction? {\n        guard let context, context.isLocalTurn,\n              Date().timeIntervalSince(context.capturedAt) <= maximumAge else { return nil }\n        return suggestedAction\n    }\n\n    func currentSuggestedAction(\n        validating session: MiniGameSessionSnapshot,\n        maximumAge: TimeInterval = 25\n    ) -> AgentSuggestedGameAction? {\n        guard let action = currentSuggestedAction(maximumAge: maximumAge),\n              let context,\n              context.sessionID == session.id,\n              let adapter = Self.adapter(for: session),\n              adapter.makeObservation().stateHash == context.stateHash,\n              Self.suggestedActionRemainsLegal(action, in: session) else {\n            return nil\n        }\n        return action\n    }\n\n    static func suggestedActionRemainsLegal(\n        _ action: AgentSuggestedGameAction,\n        in session: MiniGameSessionSnapshot\n    ) -> Bool {\n        guard session.status == .active,\n              session.isLocalTurn,\n              action.sessionID == session.id,\n              action.gameID == session.game.rawValue,\n              action.turn == session.moveCount,\n              let adapter = Self.adapter(for: session) else {\n            return false\n        }\n\n        return adapter.enumerateLegalActions()\n            .filter(adapter.validate)\n            .contains { candidate in\n                Self.move(for: candidate, game: session.game) == action.move\n            }\n    }\n\n    func markSuggestedActionExecuted', 'final game suggestion state validation')
replace_once('VeilLink/App/AppModel.swift', '    @discardableResult\n    func executeAgentSuggestedGameMove() -> String {\n        guard agentControls.allowSuggestedGameMoveExecution else {\n            return "AI 控制中心当前禁止执行建议着法。你仍可以查看分析或手动在棋盘操作。"\n        }\n        guard let action = gameIntelligence.currentSuggestedAction() else {\n            return "当前没有足够新鲜、经过合法动作校验的推荐着法；请回到棋局刷新后再试。"\n        }\n        guard let game = MiniGameKind(rawValue: action.gameID) else {\n            return "当前推荐动作的游戏类型无效。"\n        }\n        let packet = MiniGamePacket(\n            sessionID: action.sessionID,\n            game: game,\n            command: .move,\n            turn: action.turn,\n            move: action.move\n        )\n        do {\n            try sessions.sendMiniGamePacket(packet, to: action.peerIdentityID)\n            gameIntelligence.markSuggestedActionExecuted(action)\n            haptics.send()\n            return "已执行经过原游戏引擎候选校验的建议着法：\\(action.label)。动作仍通过当前 E2EE 游戏消息链路发送。"\n        } catch {\n            haptics.error()\n            return "建议着法未执行：\\(error.localizedDescription)"\n        }\n    }', '    @discardableResult\n    func executeAgentSuggestedGameMove() -> String {\n        guard agentControls.allowSuggestedGameMoveExecution else {\n            return "AI 控制中心当前禁止执行建议着法。你仍可以查看分析或手动在棋盘操作。"\n        }\n        guard let tentative = gameIntelligence.currentSuggestedAction() else {\n            return "当前没有足够新鲜、经过合法动作校验的推荐着法；请回到棋局刷新后再试。"\n        }\n        guard let localIdentityID = identity.activeIdentity?.id,\n              let conversationID = database.conversationID(\n                localIdentityID: localIdentityID,\n                for: tentative.peerIdentityID\n              ),\n              let latestSession = MiniGameSessionBuilder.session(\n                id: tentative.sessionID,\n                from: database.fetchMessages(conversationID: conversationID)\n              ),\n              let action = gameIntelligence.currentSuggestedAction(validating: latestSession),\n              action == tentative else {\n            return "棋局已经变化，这条 AI 建议已失效；请回到棋局刷新后重新获取建议。"\n        }\n        guard let game = MiniGameKind(rawValue: action.gameID) else {\n            return "当前推荐动作的游戏类型无效。"\n        }\n        let packet = MiniGamePacket(\n            sessionID: action.sessionID,\n            game: game,\n            command: .move,\n            turn: action.turn,\n            move: action.move\n        )\n        do {\n            try sessions.sendMiniGamePacket(packet, to: action.peerIdentityID)\n            gameIntelligence.markSuggestedActionExecuted(action)\n            haptics.send()\n            return "已执行刚刚重新通过原游戏引擎校验的建议着法：\\(action.label)。动作仍通过当前 E2EE 游戏消息链路发送。"\n        } catch {\n            haptics.error()\n            return "建议着法未执行：\\(error.localizedDescription)"\n        }\n    }', 'AppModel stale move revalidation')

# Full replacement after blob guard: heavy inference lifecycle test.
(REPO / 'VeilLinkTests/RealLocalInferenceSmokeTests.swift').write_bytes((HERE / 'RealLocalInferenceSmokeTests.swift').read_bytes())

# Add the lock-backed cancellation gate source.
(REPO / 'VeilLink/Agent/Language/LlamaCancellationGate.swift').write_bytes((HERE / 'LlamaCancellationGate.swift').read_bytes())

# Replace non-atomic VFLY injection and add ranker verification.
inject = REPO / 'scripts/inject-vfly-assets.sh'
inject.write_bytes((HERE / 'inject-vfly-assets.sh').read_bytes())
inject.chmod(0o755)
verifier = REPO / 'scripts/verify-malecns-ranker-assets.py'
verifier.write_bytes((HERE / 'verify-malecns-ranker-assets.py').read_bytes())
verifier.chmod(0o755)

# Add standard stale-action regression tests.
(REPO / 'VeilLinkTests/AgentGameExecutionValidationTests.swift').write_bytes((HERE / 'AgentGameExecutionValidationTests.swift').read_bytes())

# Upgrade the standard preflight from 36 to 37 test files.
preflight = REPO / 'scripts/ci-standard-preflight.py'
text = preflight.read_text(encoding='utf-8')
old = '    if len(tests) < 36:\n        fail(f"expected at least 36 test source files, got {len(tests)}")'
new = '    if len(tests) < 37:\n        fail(f"expected at least 37 test source files, got {len(tests)}")'
if text.count(old) != 1: raise SystemExit('REFUSE: preflight test-count anchor mismatch')
text = text.replace(old, new, 1)
old = '        "AgentControlAndLocalGameTests.swift",\n    }'
new = '        "AgentControlAndLocalGameTests.swift",\n        "AgentGameExecutionValidationTests.swift",\n    }'
if text.count(old) != 1: raise SystemExit('REFUSE: preflight required-test anchor mismatch')
text = text.replace(old, new, 1)
old = '    print("MaleCNS manifests: PASS")'
new = '    run([\n        sys.executable,\n        str(ROOT / "scripts" / "verify-malecns-ranker-assets.py"),\n        "--resources",\n        str(RES),\n    ])\n    print("MaleCNS manifests: PASS")'
if text.count(old) != 1: raise SystemExit('REFUSE: preflight ranker verifier anchor mismatch')
preflight.write_text(text.replace(old, new, 1), encoding='utf-8')

print('R11-EF CUMULATIVE PATCH APPLIED')
print('R11-E=llama cancellation + serialized unload/reload + real lifecycle test')
print('R11-F=staged VFLY commit + R7 verifier + final stale-action revalidation')
print('STANDARD_TEST_FILES_MIN=37')
