#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path.cwd()

if not (REPO / ".git").exists():
    raise SystemExit("Run this script from the repository root.")

subprocess.run(
    [sys.executable, str(HERE / "apply_r11d_base.py")],
    cwd=REPO,
    check=True
)

target = REPO / "VeilLinkTests" / "AgentControlAndLocalGameTests.swift"
if target.exists():
    raise SystemExit("REFUSE: AgentControlAndLocalGameTests.swift already exists")
target.write_bytes((HERE / "AgentControlAndLocalGameTests.swift").read_bytes())

preflight = REPO / "scripts" / "ci-standard-preflight.py"
text = preflight.read_text(encoding="utf-8")

old_count = '    if len(tests) < 35:\n        fail(f"expected at least 35 test source files, got {len(tests)}")'
new_count = '    if len(tests) < 36:\n        fail(f"expected at least 36 test source files, got {len(tests)}")'
if text.count(old_count) != 1:
    raise SystemExit(f"REFUSE: preflight test-count anchor count = {text.count(old_count)}")
text = text.replace(old_count, new_count, 1)

old_required = '        "RealLocalInferenceSmokeTests.swift",\n    }'
new_required = '        "RealLocalInferenceSmokeTests.swift",\n        "AgentControlAndLocalGameTests.swift",\n    }'
if text.count(old_required) != 1:
    raise SystemExit(f"REFUSE: preflight required-test anchor count = {text.count(old_required)}")
text = text.replace(old_required, new_required, 1)

preflight.write_text(text, encoding="utf-8")

print("R11-D.1 CUMULATIVE PATCH APPLIED")
print("NEW_TESTS=4")
print("STANDARD_TEST_FILES_MIN=36")
