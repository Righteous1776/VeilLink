# VeilLink Tactical Wargame V0.2.8 · B-04D OPERATIONAL LAYERS

GitHub write permission is still blocked, so this iteration continued locally.

## New gameplay-facing implementation

- Player-visible Supply overlay
- Redacted Threat overlay
- Guandu / Wuchao / Baima / Yangwu objective layer
- Route command assessment:
  - supply status
  - peak exposure
  - average threat
  - nearest objective
- Abstract redacted combat forecast
- Canvas rendering for Supply / Threat / Objective overlays
- Right-side command panel now shows route supply/exposure context
- LaunchGate now computes the local player's supply field from redacted state

## FOW invariant

No operational overlay is allowed to read hidden enemy TruthState.

Confirmed enemy positions may visibly obstruct the local supply estimate.
Partial/suspected contacts contribute only to uncertainty/threat.
Suspected contacts do not expose exact enemy strength.

## Validation

Core compile: PASS
Self-test: PASS
Marker: `B04D_OPERATIONAL_LAYERS_SELFTEST_PASS`
SwiftUI parse: PASS
SQLite integrity: ok

T-059: DONE
T-061: DONE

B-04 remains IN_PROGRESS until the repository can run a real Xcode/iOS CI build.
