# B-04C Session Bridge 集成说明

## 这轮真正解决了什么

旧版本的官渡兵棋只有 VLGM1 `from/to`。

B-04C 增加独立 `VLTW2`：

- hello：确认双方地图/规则能力
- commitment：锁定本回合命令
- reveal：双方都锁定后公开本回合订单
- frameDigest：双方独立解析后交换状态摘要

旧 `VLGM1` 不删除、不改版本。

新对局的升级路径：

`VLGM1 invite/accept`
→ `VLTW2 hello`
→ 能力一致
→ `48×27 + WEGO + FOW V2`

如果另一台手机还是旧版本，没有 VLTW2 hello，则保持 Legacy 7×9。

## 断链 / 重启

提交命令时：

1. 先将本地 `RevealV2` 写入 `PendingRevealStoreV2`
2. 再发送 commitment
3. 对方 commitment 到达后自动发送 reveal
4. 回合成功解析后删除 pending reveal

因此“commit 已发出，但 App 突然退出”不会直接把该回合锁死。

## 安全边界

- VLTW2 仍通过 VeilLink 当前 E2EE 文本通道传输。
- 普通 UI 继续只消费 PlayerIntelState / Redacted View。
- commit/reveal 防止正常客户端看到对方订单后再修改自己的订单。
- 仍不宣称被篡改的端点在 reveal 后无法检查收到的数据。

## Repo overlay

应用 overlay 后运行：

`python3 scripts/apply-tactical-v2-b04c.py`

它会对当前 main 的三个集成点做最小修改：

- `SessionCoordinator.swift`
- `ConversationViews.swift`
- `MiniGameViews.swift`

随后运行：

`bash scripts/validate-tactical-v2.sh`

当前 GitHub connector 没有创建分支权限，所以真实 Xcode CI 尚未执行。
