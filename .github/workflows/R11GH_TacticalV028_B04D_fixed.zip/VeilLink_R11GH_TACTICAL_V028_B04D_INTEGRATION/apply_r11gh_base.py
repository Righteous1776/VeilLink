#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path.cwd()
if not (REPO / '.git').exists():
    raise SystemExit('Run this script from the repository root.')

# Carry R11-A through R11-F forward first.
subprocess.run([sys.executable, str(HERE / 'apply_r11ef_base.py')], cwd=REPO, check=True)

EXPECTED_BLOBS = {'VeilLink/Agent/Compute/A9ComputePlanner.swift': 'f48db12723a703951245e68666d2abb1407a60ec', 'VeilLink/Agent/Compute/A9ComputeGovernor.swift': '335d1cb3aa7a876a79b40d80237ebd4476fd5fc6', 'VeilLink/Agent/Core/AgentCoordinator.swift': '3ade638b9261c26c977466ae4981e5da5fb8c29d', 'VeilLink/Agent/Integration/AgentControlCenterSettings.swift': '3a21bb9e7aa9d9ecc3c9a4a63b468489239f7cbd', 'VeilLink/Agent/MaleCNS/MaleCNSGraphManager.swift': 'c98a39c0f8772921b0ab2155a76deecfd8626eb8', 'VeilLinkTests/A9ComputeGovernorTests.swift': 'b54a21bedf03cba615d57f5107fc7bef3912de6a', 'scripts/package-unsigned-ipa.sh': '7fab2d532f76603abfb4f1ae5d3de88ad76e8f79', 'scripts/verify-dual-brain-app.sh': '9a7657d4c6e79bfeef4de5cb3c36a0f790a75c63'}
def sh(*args):
    return subprocess.check_output(args, cwd=REPO, text=True).strip()

# These files were not changed by R11-EF; guard their audited baseline blobs.
for path, expected in EXPECTED_BLOBS.items():
    p = REPO / path
    if not p.exists(): raise SystemExit(f'REFUSE: missing {path}')
    actual = sh('git', 'hash-object', path)
    if actual != expected: raise SystemExit(f'REFUSE: blob mismatch for {path}: expected {expected}, got {actual}')

for new_path in ['scripts/verify-release-carrier.py', 'VeilLinkTests/A9RuntimeConstraintTests.swift']:
    if (REPO / new_path).exists(): raise SystemExit(f'REFUSE: {new_path} already exists')

def replace_once(path, old, new, label):
    p = REPO / path
    text = p.read_text(encoding='utf-8')
    count = text.count(old)
    if count != 1: raise SystemExit(f'REFUSE: {label} expected one anchor, found {count}')
    p.write_text(text.replace(old, new, 1), encoding='utf-8')

replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '    static func plan(\n        decision: VeilA9Decision,\n        profile: AgentCapabilityProfile,\n        focus: AgentComputeFocus,\n        logicalProcessorCount: Int\n    ) -> VeilA9ComputePlan {\n        let mode = computeMode(for: decision)', '    static func plan(\n        decision: VeilA9Decision,\n        profile: AgentCapabilityProfile,\n        focus: AgentComputeFocus,\n        logicalProcessorCount: Int,\n        foregroundActive: Bool = true,\n        allowExperimentalCore: Bool = false\n    ) -> VeilA9ComputePlan {\n        guard foregroundActive else {\n            return backgroundPlan(profile: profile, focus: focus)\n        }\n\n        let mode = computeMode(for: decision)', 'A9 plan runtime constraints')
replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '            maleCNS: maleCNSBudget(\n                units: maleUnits,\n                mode: mode,\n                profile: profile,\n                logicalProcessorCount: logicalProcessorCount\n            ),', '            maleCNS: maleCNSBudget(\n                units: maleUnits,\n                mode: mode,\n                profile: profile,\n                logicalProcessorCount: logicalProcessorCount,\n                allowExperimentalCore: allowExperimentalCore\n            ),', 'A9 passes experimental Core authorization')
replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '    private static func computeMode(for decision: VeilA9Decision) -> A9ComputeMode {\n        switch decision.level {\n        case .l0Observe:\n            return decision.healthScore >= 90 ? .boost : .balanced\n        case .l1Advisory:\n            return .balanced\n        case .l2Review:\n            return .constrained\n        case .l3Priority:\n            return .preserve\n        case .l4HoldRecommendation, .l5Emergency:\n            return .emergency\n        }\n    }', '    private static func backgroundPlan(\n        profile: AgentCapabilityProfile,\n        focus: AgentComputeFocus\n    ) -> VeilA9ComputePlan {\n        let gross = baseUnits(for: profile.tier)\n        return VeilA9ComputePlan(\n            mode: .preserve,\n            focus: focus,\n            latticeIndex: 0,\n            totalComputeUnits: gross,\n            transportReserveUnits: gross,\n            maleCNSUnits: 0,\n            languageUnits: 0,\n            visionUnits: 0,\n            gameUnits: 0,\n            trainingUnits: 0,\n            maleCNS: .suspended,\n            language: AgentLanguageComputeBudget(\n                maxNewTokens: min(32, profile.maxNewTokens),\n                recentMessageLimit: min(4, profile.recentMessageLimit),\n                keepWarm: false\n            ),\n            vision: AgentVisionComputeBudget(\n                enabled: false,\n                sampleIntervalMilliseconds: 2_400,\n                classificationStride: 4,\n                ocrStride: 8\n            ),\n            game: AgentGameComputeBudget(\n                plannerMilliseconds: 0,\n                searchDepth: 0,\n                rolloutCount: 0,\n                candidateBatchSize: 0\n            ),\n            training: AgentTrainingComputeBudget(\n                enabled: false,\n                cpuBudgetPercent: 0,\n                shardEpisodeLimit: 0\n            )\n        )\n    }\n\n    private static func computeMode(for decision: VeilA9Decision) -> A9ComputeMode {\n        let issueCodes = Set(decision.issues.map(\\.code))\n        if issueCodes.contains("THERMAL_CRITICAL") {\n            return .emergency\n        }\n        if issueCodes.contains("THERMAL_SERIOUS") {\n            return .preserve\n        }\n\n        let base: A9ComputeMode\n        switch decision.level {\n        case .l0Observe:\n            base = decision.healthScore >= 90 ? .boost : .balanced\n        case .l1Advisory:\n            base = .balanced\n        case .l2Review:\n            base = .constrained\n        case .l3Priority:\n            base = .preserve\n        case .l4HoldRecommendation, .l5Emergency:\n            base = .emergency\n        }\n\n        if issueCodes.contains("LOW_POWER_MODE"),\n           base == .boost || base == .balanced {\n            return .constrained\n        }\n        return base\n    }', 'A9 immediate thermal/low-power clamp')
replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '    private static func maleCNSBudget(\n        units: Int,\n        mode: A9ComputeMode,\n        profile: AgentCapabilityProfile,\n        logicalProcessorCount: Int\n    ) -> MaleCNSComputeBudget {', '    private static func maleCNSBudget(\n        units: Int,\n        mode: A9ComputeMode,\n        profile: AgentCapabilityProfile,\n        logicalProcessorCount: Int,\n        allowExperimentalCore: Bool\n    ) -> MaleCNSComputeBudget {', 'A9 MaleCNS Core authorization signature')
replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '        if units >= 360 && profile.tier == .high && mode == .boost {', '        if allowExperimentalCore,\n           units >= 360,\n           profile.tier == .high,\n           mode == .boost {', 'A9 high Core explicit authorization')
replace_once('VeilLink/Agent/Compute/A9ComputePlanner.swift', '        if units >= 210 && profile.tier != .legacyA10 {', '        if allowExperimentalCore,\n           units >= 210,\n           profile.tier != .legacyA10 {', 'A9 balanced Core explicit authorization')
replace_once('VeilLink/Agent/Compute/A9ComputeGovernor.swift', '    @Published private(set) var plan: VeilA9ComputePlan\n    @Published private(set) var focus: AgentComputeFocus = .idle', '    @Published private(set) var plan: VeilA9ComputePlan\n    @Published private(set) var focus: AgentComputeFocus = .idle\n    @Published private(set) var foregroundActive = true\n    @Published private(set) var experimentalCoreEnabled = false', 'A9 governor publishes runtime constraints')
replace_once('VeilLink/Agent/Compute/A9ComputeGovernor.swift', '    func setFocus(_ focus: AgentComputeFocus) {\n        guard self.focus != focus else { return }\n        self.focus = focus\n        recompute()\n    }\n\n    /// Attaches the current MaleCNS runtime', '    func setFocus(_ focus: AgentComputeFocus) {\n        guard self.focus != focus else { return }\n        self.focus = focus\n        recompute()\n    }\n\n    func setForegroundActive(_ active: Bool) {\n        guard foregroundActive != active else { return }\n        foregroundActive = active\n        recompute()\n    }\n\n    func setExperimentalCoreEnabled(_ enabled: Bool) {\n        guard experimentalCoreEnabled != enabled else { return }\n        experimentalCoreEnabled = enabled\n        recompute()\n    }\n\n    /// Attaches the current MaleCNS runtime', 'A9 governor setters')
replace_once('VeilLink/Agent/Compute/A9ComputeGovernor.swift', '        plan = VeilA9ComputePlanner.plan(\n            decision: decision,\n            profile: profile,\n            focus: focus,\n            logicalProcessorCount: logicalProcessorCount\n        )', '        plan = VeilA9ComputePlanner.plan(\n            decision: decision,\n            profile: profile,\n            focus: focus,\n            logicalProcessorCount: logicalProcessorCount,\n            foregroundActive: foregroundActive,\n            allowExperimentalCore: experimentalCoreEnabled\n        )', 'A9 governor recompute uses runtime constraints')
replace_once('VeilLink/Agent/Compute/A9ComputeGovernor.swift', '            "Mode: \\(plan.mode.title)",\n            "Focus: \\(plan.focus.title)",', '            "Mode: \\(plan.mode.title)",\n            "Focus: \\(plan.focus.title)",\n            "Foreground: \\(foregroundActive ? "yes" : "no")",\n            "Experimental Core authorized: \\(experimentalCoreEnabled ? "yes" : "no")",', 'A9 diagnostics include runtime constraints')
replace_once('VeilLink/Agent/Integration/AgentControlCenterSettings.swift', '        case .automatic: return "自动"', '        case .automatic: return "自动 Lite"', 'MaleCNS automatic label')
replace_once('VeilLink/Agent/Integration/AgentControlCenterSettings.swift', '        case .automaticStable:\n            return "按设备与验证门自动选择；不会自动启用未通过部署门的 Core ranker。"', '        case .automaticStable:\n            return "稳定档固定使用 Lite VFLY；Core 仅在本次启动中手动进入实验模式后启用。"', 'automaticStable semantics')
replace_once('VeilLink/Agent/MaleCNS/MaleCNSGraphManager.swift', '    func prepareFromBundle(_ bundle: Bundle = .main) {\n        guard loadTask == nil else { return }', '    nonisolated static func candidateResourceNames(\n        for mode: MaleCNSDeploymentMode,\n        computeTier: AgentComputeTier\n    ) -> [String] {\n        switch mode {\n        case .automatic, .forceLite:\n            return ["VeilFlyLite"]\n        case .experimentalCore:\n            return computeTier == .legacyA10 ? [] : ["VeilFlyCore"]\n        }\n    }\n\n    func prepareFromBundle(_ bundle: Bundle = .main) {\n        guard loadTask == nil else { return }', 'MaleCNS safe candidate resources helper')
replace_once('VeilLink/Agent/MaleCNS/MaleCNSGraphManager.swift', '        let candidateNames: [String]\n        switch deploymentMode {\n        case .automatic:\n            switch profile.tier {\n            case .legacyA10: candidateNames = ["VeilFlyLite"]\n            case .balanced, .high: candidateNames = ["VeilFlyCore", "VeilFlyLite"]\n            }\n        case .forceLite:\n            candidateNames = ["VeilFlyLite"]\n        case .experimentalCore:\n            candidateNames = ["VeilFlyCore"]\n        }', '        let candidateNames = Self.candidateResourceNames(\n            for: deploymentMode,\n            computeTier: profile.tier\n        )', 'MaleCNS automatic stable no longer auto-loads Core')
replace_once('VeilLink/App/AppModel.swift', '        agentControls = AgentControlCenterSettings()\n        maleCNS = MaleCNSGraphManager(profile: agentProfile, governor: computeGovernor)', '        agentControls = AgentControlCenterSettings()\n        computeGovernor.setExperimentalCoreEnabled(\n            agentControls.gameDecisionMode == .experimentalCore\n        )\n        maleCNS = MaleCNSGraphManager(profile: agentProfile, governor: computeGovernor)', 'AppModel initial Core authorization')
replace_once('VeilLink/App/AppModel.swift', '    func handleForegroundTransition() {\n        refreshA9Health()\n        startA9PeriodicSampling()\n    }', '    func handleForegroundTransition() {\n        computeGovernor.setForegroundActive(true)\n        refreshA9Health()\n        startA9PeriodicSampling()\n    }', 'AppModel foreground compute gate')
replace_once('VeilLink/App/AppModel.swift', '    func handleBackgroundTransition() {\n        a9PeriodicTask?.cancel()', '    func handleBackgroundTransition() {\n        computeGovernor.setForegroundActive(false)\n        a9PeriodicTask?.cancel()', 'AppModel background compute gate')
replace_once('VeilLink/App/AppModel.swift', '        agentControls.gameDecisionMode = mode\n        maleCNS.setDeploymentMode(mode.graphDeploymentMode)', '        agentControls.gameDecisionMode = mode\n        computeGovernor.setExperimentalCoreEnabled(mode == .experimentalCore)\n        maleCNS.setDeploymentMode(mode.graphDeploymentMode)', 'AppModel explicit Core mode authorization')
replace_once('VeilLink/App/AppModel.swift', '        agentControls.resetToSafeDefaults()\n        agent.setVisualContextEnabled(agentControls.visualContextEnabled)', '        agentControls.resetToSafeDefaults()\n        computeGovernor.setExperimentalCoreEnabled(false)\n        agent.setVisualContextEnabled(agentControls.visualContextEnabled)', 'AppModel reset disables Core')
replace_once('VeilLink/Agent/Core/AgentCoordinator.swift', '            var streamed = ""\n            do {', '            var streamed = ""\n            let flushIntervalNanoseconds = UInt64(\n                Self.streamingFlushIntervalMilliseconds(for: self.capabilityProfile.tier)\n            ) * 1_000_000\n            var lastUIPublishNanoseconds: UInt64 = 0\n            do {', 'Agent streaming flush state')
replace_once('VeilLink/Agent/Core/AgentCoordinator.swift', '                    streamed += chunk\n                    self.session.updateMessage(id: assistantID, text: streamed)\n                    self.runtimeState = .generating', '                    streamed += chunk\n                    let now = DispatchTime.now().uptimeNanoseconds\n                    if lastUIPublishNanoseconds == 0\n                        || now &- lastUIPublishNanoseconds >= flushIntervalNanoseconds {\n                        self.session.updateMessage(id: assistantID, text: streamed)\n                        lastUIPublishNanoseconds = now\n                    }\n                    self.runtimeState = .generating', 'Agent streaming UI coalescing')
replace_once('VeilLink/Agent/Core/AgentCoordinator.swift', '                self.diagnostics.generationCount += 1', '                self.session.updateMessage(id: assistantID, text: streamed)\n                self.diagnostics.generationCount += 1', 'Agent final stream flush')
replace_once('VeilLink/Agent/Core/AgentCoordinator.swift', '                if streamed.isEmpty {\n                    self.session.updateMessage(id: assistantID, text: "本地运行时暂时不可用：\\(error.localizedDescription)")\n                }', '                if streamed.isEmpty {\n                    self.session.updateMessage(id: assistantID, text: "本地运行时暂时不可用：\\(error.localizedDescription)")\n                } else {\n                    self.session.updateMessage(id: assistantID, text: streamed)\n                }', 'Agent error partial flush')
replace_once('VeilLink/Agent/Core/AgentCoordinator.swift', '    private func syncRuntimeState() {\n        runtimeState = language.state\n    }', '    nonisolated static func streamingFlushIntervalMilliseconds(\n        for tier: AgentComputeTier\n    ) -> Int {\n        switch tier {\n        case .legacyA10: return 50\n        case .balanced: return 35\n        case .high: return 25\n        }\n    }\n\n    private func syncRuntimeState() {\n        runtimeState = language.state\n    }', 'Agent streaming interval policy')
replace_once('VeilLinkTests/A9ComputeGovernorTests.swift', '    func testGreenHighProfileGivesMaleCNSCoreBudget() {\n        let profile = AgentCapabilityProfile.profile(devicePerformanceLabel: "13PRO-HIGH")\n        let plan = VeilA9ComputePlanner.plan(\n            decision: .initial,\n            profile: profile,\n            focus: .maleCNSSandbox,\n            logicalProcessorCount: 6\n        )\n        XCTAssertEqual(plan.mode, .boost)\n        XCTAssertEqual(plan.maleCNS.tier, .core)\n        XCTAssertGreaterThanOrEqual(plan.maleCNS.workerCount, 2)\n        XCTAssertGreaterThan(plan.maleCNS.neuralStepBudget, 100)\n        XCTAssertGreaterThan(plan.maleCNSUnits, plan.languageUnits)\n    }', '    func testGreenHighProfileDefaultsToLiteUntilCoreIsExplicitlyAuthorized() {\n        let profile = AgentCapabilityProfile.profile(devicePerformanceLabel: "13PRO-HIGH")\n        let stable = VeilA9ComputePlanner.plan(\n            decision: .initial,\n            profile: profile,\n            focus: .maleCNSSandbox,\n            logicalProcessorCount: 6\n        )\n        XCTAssertEqual(stable.mode, .boost)\n        XCTAssertEqual(stable.maleCNS.tier, .lite)\n        XCTAssertGreaterThan(stable.maleCNSUnits, stable.languageUnits)\n\n        let experimental = VeilA9ComputePlanner.plan(\n            decision: .initial,\n            profile: profile,\n            focus: .maleCNSSandbox,\n            logicalProcessorCount: 6,\n            allowExperimentalCore: true\n        )\n        XCTAssertEqual(experimental.maleCNS.tier, .core)\n        XCTAssertGreaterThanOrEqual(experimental.maleCNS.workerCount, 2)\n        XCTAssertGreaterThan(experimental.maleCNS.neuralStepBudget, 100)\n    }', 'A9 default Lite test')

p = REPO / 'VeilLink/Agent/Core/AgentCoordinator.swift'
t = p.read_text(encoding='utf-8')
old = '                if streamed.isEmpty { self.session.removeMessage(id: assistantID) }'
new = '                if streamed.isEmpty {\n                    self.session.removeMessage(id: assistantID)\n                } else {\n                    self.session.updateMessage(id: assistantID, text: streamed)\n                }'
count = t.count(old)
if count != 2: raise SystemExit(f'REFUSE: Agent cancellation partial flush expected 2 anchors, found {count}')
p.write_text(t.replace(old, new), encoding='utf-8')

# Convert streaming state to a MainActor reference object so the @Sendable token callback
# does not mutate captured local vars under strict concurrency.
coord = REPO / 'VeilLink/Agent/Core/AgentCoordinator.swift'
coord_text = coord.read_text(encoding='utf-8')
top_old = 'import Combine\nimport Foundation\n\n@MainActor\nfinal class AgentCoordinator: ObservableObject {'
top_new = 'import Combine\nimport Foundation\n\n@MainActor\nprivate final class AgentStreamingAccumulator {\n    var text = ""\n    var lastUIPublishNanoseconds: UInt64 = 0\n}\n\n@MainActor\nfinal class AgentCoordinator: ObservableObject {'
if coord_text.count(top_old) != 1:
    raise SystemExit(f'REFUSE: streaming accumulator top anchor count = {coord_text.count(top_old)}')
coord_text = coord_text.replace(top_old, top_new, 1)
state_old = '            var streamed = ""\n            let flushIntervalNanoseconds = UInt64(\n                Self.streamingFlushIntervalMilliseconds(for: self.capabilityProfile.tier)\n            ) * 1_000_000\n            var lastUIPublishNanoseconds: UInt64 = 0\n            do {'
state_new = '            let stream = AgentStreamingAccumulator()\n            let flushIntervalNanoseconds = UInt64(\n                Self.streamingFlushIntervalMilliseconds(for: self.capabilityProfile.tier)\n            ) * 1_000_000\n            do {'
if coord_text.count(state_old) != 1:
    raise SystemExit(f'REFUSE: streaming state post-anchor count = {coord_text.count(state_old)}')
coord_text = coord_text.replace(state_old, state_new, 1)
callback_old = '                    streamed += chunk\n                    let now = DispatchTime.now().uptimeNanoseconds\n                    if lastUIPublishNanoseconds == 0\n                        || now &- lastUIPublishNanoseconds >= flushIntervalNanoseconds {\n                        self.session.updateMessage(id: assistantID, text: streamed)\n                        lastUIPublishNanoseconds = now\n                    }'
callback_new = '                    stream.text += chunk\n                    let now = DispatchTime.now().uptimeNanoseconds\n                    if stream.lastUIPublishNanoseconds == 0\n                        || now &- stream.lastUIPublishNanoseconds >= flushIntervalNanoseconds {\n                        self.session.updateMessage(id: assistantID, text: stream.text)\n                        stream.lastUIPublishNanoseconds = now\n                    }'
if coord_text.count(callback_old) != 1:
    raise SystemExit(f'REFUSE: streaming callback post-anchor count = {coord_text.count(callback_old)}')
coord_text = coord_text.replace(callback_old, callback_new, 1)
coord_text = coord_text.replace(
    'self.session.updateMessage(id: assistantID, text: streamed)',
    'self.session.updateMessage(id: assistantID, text: stream.text)'
)
coord_text = coord_text.replace('if streamed.isEmpty {', 'if stream.text.isEmpty {')
coord.write_text(coord_text, encoding='utf-8')

# Existing governor test also had a second implicit-Core expectation.
a9test = REPO / 'VeilLinkTests/A9ComputeGovernorTests.swift'
a9text = a9test.read_text(encoding='utf-8')
second_old = '        governor.setFocus(.maleCNSSandbox)\n        XCTAssertEqual(consumer.received.last, governor.plan.maleCNS)\n        XCTAssertEqual(consumer.received.last?.tier, .core)\n\n        governor.update(decision: VeilA9Decision('
second_new = '        governor.setFocus(.maleCNSSandbox)\n        XCTAssertEqual(consumer.received.last, governor.plan.maleCNS)\n        XCTAssertEqual(consumer.received.last?.tier, .lite)\n\n        governor.setExperimentalCoreEnabled(true)\n        XCTAssertEqual(consumer.received.last?.tier, .core)\n\n        governor.update(decision: VeilA9Decision('
if a9text.count(second_old) != 1:
    raise SystemExit(f'REFUSE: second Core expectation anchor count = {a9text.count(second_old)}')
a9test.write_text(a9text.replace(second_old, second_new, 1), encoding='utf-8')


# AppModel was already modified by R11-EF, so use guarded semantic anchors rather than old blob SHA.

# Release closure scripts and tests.
(REPO / 'scripts/verify-release-carrier.py').write_bytes((HERE / 'verify-release-carrier.py').read_bytes())
(REPO / 'scripts/verify-release-carrier.py').chmod(0o755)
(REPO / 'scripts/package-unsigned-ipa.sh').write_bytes((HERE / 'package-unsigned-ipa.sh').read_bytes())
(REPO / 'scripts/package-unsigned-ipa.sh').chmod(0o755)
(REPO / 'scripts/verify-dual-brain-app.sh').write_bytes((HERE / 'verify-dual-brain-app.sh').read_bytes())
(REPO / 'scripts/verify-dual-brain-app.sh').chmod(0o755)
(REPO / 'VeilLinkTests/A9RuntimeConstraintTests.swift').write_bytes((HERE / 'A9RuntimeConstraintTests.swift').read_bytes())

# R11-C created the heavy workflow; replace it with the final R11-H release gate.
(REPO / '.github/workflows/malecns-heavy-validation.yml').write_bytes((HERE / 'malecns-heavy-validation.yml').read_bytes())

# Upgrade standard preflight test inventory 37 -> 38 and require final release tooling.
preflight = REPO / 'scripts/ci-standard-preflight.py'
text = preflight.read_text(encoding='utf-8')
old = '    if len(tests) < 37:\n        fail(f"expected at least 37 test source files, got {len(tests)}")'
new = '    if len(tests) < 38:\n        fail(f"expected at least 38 test source files, got {len(tests)}")'
if text.count(old) != 1: raise SystemExit('REFUSE: preflight 37-test anchor mismatch')
text = text.replace(old, new, 1)
old = '        "AgentGameExecutionValidationTests.swift",\n    }'
new = '        "AgentGameExecutionValidationTests.swift",\n        "A9RuntimeConstraintTests.swift",\n    }'
if text.count(old) != 1: raise SystemExit('REFUSE: preflight required-test anchor mismatch')
text = text.replace(old, new, 1)
old = 'def check_script_syntax():\n    for path in sorted((ROOT / "scripts").glob("*.py")):'
new = '''def check_script_syntax():\n    required = [\n        ROOT / "scripts" / "verify-release-carrier.py",\n        ROOT / "scripts" / "package-unsigned-ipa.sh",\n        ROOT / "scripts" / "verify-dual-brain-app.sh",\n    ]\n    for required_path in required:\n        if not required_path.is_file():\n            fail(f"missing release tooling: {required_path}")\n    for path in sorted((ROOT / "scripts").glob("*.py")):'''
if text.count(old) != 1: raise SystemExit('REFUSE: preflight release-tooling anchor mismatch')
preflight.write_text(text.replace(old, new, 1), encoding='utf-8')

print('R11-GH CUMULATIVE PATCH APPLIED')
print('R11-G=foreground/thermal/power/Core authorization + streaming coalescing')
print('R11-H=clean unsigned packaging + full release carrier verification/provenance')
print('STANDARD_TEST_FILES_MIN=38')
