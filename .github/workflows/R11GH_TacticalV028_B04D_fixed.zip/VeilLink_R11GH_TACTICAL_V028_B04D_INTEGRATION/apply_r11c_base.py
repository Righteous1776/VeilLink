#!/usr/bin/env python3
from pathlib import Path
import subprocess

EXPECTED_HEAD = "ee716e1e91719225e7e740724ac551bc4eeb7acb"
EXPECTED_BLOBS = {
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": "8a6a12ae25fe562e53eb9bcc96dad2d5181793a9",
    "VeilLink/Diagnostics/MetricKitTelemetry.swift": "bbab2622f88b997808bbe02d895d64885a77a927",
    "VeilLink/App/VeilLinkApp.swift": "2eae1aa53437e06c1d3bee1c9f8b502b0d5491dd",
    "VeilLink/UI/MiniGameViews.swift": "77c43c4795c51a24ae4f2f8a6af6d19a1b703d83",
    "VeilLink/UI/FullScreenImageViewer.swift": "4adc018eecc8eed6d2d1d4fa9cb949bbfb40dfca",
    ".github/workflows/ios-ci.yml": "77a0ee92bd2fee2149ab32eb1d8887eb0d929f1d",
    ".github/workflows/local-ai-heavy-validation.yml": "8a15705f10e759bfec306b88bc3c0a15fc0b432b",
    ".github/workflows/malecns-heavy-validation.yml": "557a0f1a959d79b316e6072b92f80362c1a2855a",
    ".github/workflows/swift.yml": "c7928b78ddcae2d49e2188b879ea6ae79d063d77",
    ".github/workflows/sync-v022.yml": "8136cdaaa0b543b749b1d7400bcb19d5ff47ce20",
    ".github/workflows/sync-v036.yml": "a28352ad65db359001cbb11b29cab4c57a61c5a7",
}

def sh(*args):
    return subprocess.check_output(args, text=True).strip()

head = sh("git", "rev-parse", "HEAD")
if head != EXPECTED_HEAD:
    print(f"Archive checkout: validating baseline {EXPECTED_HEAD} by guarded blob hashes (synthetic HEAD {head})")

for path, expected in EXPECTED_BLOBS.items():
    if not Path(path).exists():
        raise SystemExit(f"REFUSE: missing {path}")
    actual = sh("git", "hash-object", path)
    if actual != expected:
        raise SystemExit(f"REFUSE: blob mismatch for {path}: expected {expected}, got {actual}")

if Path("scripts/ci-collect-evidence.py").exists():
    raise SystemExit("REFUSE: scripts/ci-collect-evidence.py already exists")

def replace_once(path, old, new, label):
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"REFUSE: {label} expected exactly one anchor, found {count}")
    p.write_text(text.replace(old, new, 1), encoding="utf-8")

replace_once(
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift",
    '        case .nearby: return "nearby"\n        case .agent: return "agent.home"',
    '        case .nearby: return "nearby"\n        case .games: return "games.lobby"\n        case .agent: return "agent.home"',
    "games telemetry"
)
replace_once(
    "VeilLink/Diagnostics/MetricKitTelemetry.swift",
    "final class MetricKitTelemetryReceiver: NSObject, MXMetricManagerSubscriber {\n    static let shared = MetricKitTelemetryReceiver()\n    private var started = false",
    "final class MetricKitTelemetryReceiver: NSObject, MXMetricManagerSubscriber {\n    @MainActor static let shared = MetricKitTelemetryReceiver()\n    @MainActor private var started = false",
    "MetricKit shared"
)
replace_once(
    "VeilLink/Diagnostics/MetricKitTelemetry.swift",
    "    func start() {\n        guard !started else { return }",
    "    @MainActor\n    func start() {\n        guard !started else { return }",
    "MetricKit start"
)
replace_once(
    "VeilLink/App/VeilLinkApp.swift",
    "private enum VeilChrome {\n    static func configure() {",
    "private enum VeilChrome {\n    @MainActor\n    static func configure() {",
    "VeilChrome MainActor"
)
replace_once(
    "VeilLink/UI/MiniGameViews.swift",
    """    private func reload() {
        reloadGeneration &+= 1
        let generation = reloadGeneration
        let store = model.database
        let conversationID = conversation.id
        DispatchQueue.global(qos: .userInitiated).async {
            let loaded = store.fetchMessages(conversationID: conversationID)
            let loadedSessions = MiniGameSessionBuilder.sessions(from: loaded)
            DispatchQueue.main.async {
                guard generation == reloadGeneration else { return }
                messages = loaded
                sessions = loadedSessions
            }
        }
    }""",
    """    private func reload() {
        reloadGeneration &+= 1
        let generation = reloadGeneration
        let loaded = model.database.fetchMessages(conversationID: conversation.id)
        let loadedSessions = MiniGameSessionBuilder.sessions(from: loaded)
        guard generation == reloadGeneration else { return }
        messages = loaded
        sessions = loadedSessions
    }""",
    "MiniGame hub reload"
)
replace_once(
    "VeilLink/UI/MiniGameViews.swift",
    """    private func reload(notify: Bool) {
        reloadGeneration &+= 1
        let generation = reloadGeneration
        let oldCount = observedMoveCount
        let oldStatus = session?.status
        let store = model.database
        let conversationID = conversation.id
        DispatchQueue.global(qos: .userInitiated).async {
            let loaded = store.fetchMessages(conversationID: conversationID)
            let newSession = MiniGameSessionBuilder.session(id: sessionID, from: loaded)
            DispatchQueue.main.async {
                guard generation == reloadGeneration else { return }
                messages = loaded
                session = newSession
                if let newSession {
                    model.updateAgentGameContext(newSession, conversation: conversation)
                }
                let newCount = newSession?.moveCount ?? 0
                if notify, newCount > oldCount, newSession?.isLocalTurn == true {
                    model.haptics.receive()
                }
                if notify, let newSession, case .finished = newSession.status {
                    if oldStatus != newSession.status { model.haptics.resolved() }
                }
                observedMoveCount = newCount
            }
        }
    }""",
    """    private func reload(notify: Bool) {
        reloadGeneration &+= 1
        let generation = reloadGeneration
        let oldCount = observedMoveCount
        let oldStatus = session?.status
        let loaded = model.database.fetchMessages(conversationID: conversation.id)
        let newSession = MiniGameSessionBuilder.session(id: sessionID, from: loaded)
        guard generation == reloadGeneration else { return }
        messages = loaded
        session = newSession
        if let newSession {
            model.updateAgentGameContext(newSession, conversation: conversation)
        }
        let newCount = newSession?.moveCount ?? 0
        if notify, newCount > oldCount, newSession?.isLocalTurn == true {
            model.haptics.receive()
        }
        if notify, let newSession, case .finished = newSession.status {
            if oldStatus != newSession.status { model.haptics.resolved() }
        }
        observedMoveCount = newCount
    }""",
    "MiniGame session reload"
)
replace_once(
    "VeilLink/UI/FullScreenImageViewer.swift",
    """    private func loadLargeImage() {
        guard !isLoadingLargeImage else { return }
        isLoadingLargeImage = true
        let store = database
        let id = attachmentID
        let targetPixels = ImageViewerPolicy.currentMaxPixelSize

        DispatchQueue.global(qos: .userInitiated).async {
            let decoded: UIImage? = autoreleasepool {
                guard let data = store.loadAttachment(id: id) else { return nil }
                return ImagePreviewCache.downsample(data: data, maxPixelSize: targetPixels)
            }
            DispatchQueue.main.async {
                if let decoded { image = decoded }
                isLoadingLargeImage = false
            }
        }
    }""",
    """    private func loadLargeImage() {
        guard !isLoadingLargeImage else { return }
        isLoadingLargeImage = true
        guard let data = database.loadAttachment(id: attachmentID) else {
            isLoadingLargeImage = false
            return
        }
        let targetPixels = ImageViewerPolicy.currentMaxPixelSize

        DispatchQueue.global(qos: .userInitiated).async {
            let decoded = autoreleasepool {
                ImagePreviewCache.downsample(data: data, maxPixelSize: targetPixels)
            }
            DispatchQueue.main.async {
                if let decoded { image = decoded }
                isLoadingLargeImage = false
            }
        }
    }""",
    "FullScreenImageViewer DB capture"
)

Path("scripts/ci-collect-evidence.py").write_text('#!/usr/bin/env python3\nimport argparse\nimport datetime as dt\nimport hashlib\nimport json\nimport os\nfrom pathlib import Path\nimport re\nimport subprocess\n\nANSI_RE = re.compile(r"\\x1b\\[[0-9;]*m")\nDIAG_RE = re.compile(\n    r"(?P<file>[^:\\n]+\\.(?:swift|m|mm|c|cc|cpp|h)):"\n    r"(?P<line>\\d+):(?P<column>\\d+): "\n    r"(?P<severity>warning|error): (?P<message>.*)"\n)\n\ndef command_output(args):\n    try:\n        return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT).strip()\n    except Exception:\n        return None\n\ndef sha256_file(path):\n    h = hashlib.sha256()\n    with path.open("rb") as f:\n        while True:\n            chunk = f.read(1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n    return h.hexdigest()\n\ndef normalize_line(line):\n    line = ANSI_RE.sub("", line.rstrip())\n    workspace = os.environ.get("GITHUB_WORKSPACE")\n    if workspace:\n        line = line.replace(workspace, "$GITHUB_WORKSPACE")\n    return line\n\ndef collect_diagnostics(logs):\n    errors = []\n    warnings = []\n    seen_errors = set()\n    seen_warnings = set()\n    for log in logs:\n        try:\n            text = log.read_text(encoding="utf-8", errors="replace")\n        except OSError:\n            continue\n        for raw in text.splitlines():\n            line = normalize_line(raw)\n            match = DIAG_RE.search(line)\n            if not match:\n                continue\n            item = {\n                "file": match.group("file"),\n                "line": int(match.group("line")),\n                "column": int(match.group("column")),\n                "message": match.group("message").strip(),\n                "source_log": log.name,\n            }\n            key = (item["file"], item["line"], item["column"], item["message"])\n            if match.group("severity") == "error":\n                if key not in seen_errors:\n                    seen_errors.add(key)\n                    errors.append(item)\n            else:\n                if key not in seen_warnings:\n                    seen_warnings.add(key)\n                    warnings.append(item)\n    return errors[:250], warnings[:500]\n\ndef main():\n    parser = argparse.ArgumentParser()\n    parser.add_argument("--workflow", required=True)\n    parser.add_argument("--phase", default="job")\n    parser.add_argument("--status", required=True)\n    parser.add_argument("--artifact-dir", default="ci-artifacts")\n    parser.add_argument("--output", default="ci-artifacts/CI_EVIDENCE.json")\n    args = parser.parse_args()\n\n    artifact_dir = Path(args.artifact_dir)\n    artifact_dir.mkdir(parents=True, exist_ok=True)\n    logs = sorted(artifact_dir.glob("*.log"))\n    errors, warnings = collect_diagnostics(logs)\n\n    files = []\n    for p in sorted(artifact_dir.rglob("*")):\n        if not p.is_file():\n            continue\n        entry = {\n            "path": p.relative_to(artifact_dir).as_posix(),\n            "bytes": p.stat().st_size,\n        }\n        if p.stat().st_size <= 64 * 1024 * 1024:\n            try:\n                entry["sha256"] = sha256_file(p)\n            except OSError:\n                pass\n        files.append(entry)\n\n    report = {\n        "schema": 1,\n        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),\n        "workflow": args.workflow,\n        "phase": args.phase,\n        "status": args.status,\n        "git_head": command_output(["git", "rev-parse", "HEAD"]),\n        "github": {\n            "run_id": os.environ.get("GITHUB_RUN_ID"),\n            "run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),\n            "workflow": os.environ.get("GITHUB_WORKFLOW"),\n            "event_name": os.environ.get("GITHUB_EVENT_NAME"),\n            "ref": os.environ.get("GITHUB_REF"),\n            "sha": os.environ.get("GITHUB_SHA"),\n        },\n        "runner": {\n            "os": os.environ.get("RUNNER_OS"),\n            "arch": os.environ.get("RUNNER_ARCH"),\n        },\n        "xcode": command_output(["xcodebuild", "-version"]),\n        "system": command_output(["sw_vers"]),\n        "diagnostics": {\n            "error_count": len(errors),\n            "warning_count": len(warnings),\n            "errors": errors,\n            "warnings": warnings,\n        },\n        "evidence_files": files,\n    }\n\n    out = Path(args.output)\n    out.parent.mkdir(parents=True, exist_ok=True)\n    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\\n", encoding="utf-8")\n    print("CI evidence written:", out)\n    print("errors=", len(errors), "warnings=", len(warnings))\n\nif __name__ == "__main__":\n    main()\n', encoding="utf-8")
Path("scripts/ci-collect-evidence.py").chmod(0o755)
Path(".github/workflows/ios-ci.yml").write_text('name: iOS CI\n\non:\n  push:\n    branches: [main]\n  pull_request:\n  workflow_dispatch:\n  workflow_call:\n\npermissions:\n  contents: read\n\njobs:\n  build-and-test:\n    runs-on: macos-15\n    timeout-minutes: 35\n    steps:\n      - uses: actions/checkout@v4\n\n      - name: Prepare evidence directory\n        run: |\n          mkdir -p ci-artifacts\n          {\n            echo "HEAD=$(git rev-parse HEAD)"\n            xcodebuild -version\n            sw_vers\n            echo "RUNNER_ARCH=${RUNNER_ARCH:-unknown}"\n            df -h .\n          } 2>&1 | tee ci-artifacts/environment.log\n\n      - name: Install XcodeGen\n        run: brew install xcodegen 2>&1 | tee ci-artifacts/install-xcodegen.log\n\n      - name: Generate Xcode project\n        run: |\n          set -o pipefail\n          xcodegen generate 2>&1 | tee ci-artifacts/xcodegen.log\n          cp VeilLink.xcodeproj/project.pbxproj ci-artifacts/project.pbxproj\n\n      - name: Build for iOS Simulator\n        run: |\n          set -o pipefail\n          rm -rf ci-artifacts/BuildResults.xcresult\n          xcodebuild             -project VeilLink.xcodeproj             -scheme VeilLink             -configuration Debug             -sdk iphonesimulator             -destination \'generic/platform=iOS Simulator\'             -resultBundlePath ci-artifacts/BuildResults.xcresult             CODE_SIGNING_ALLOWED=NO             build 2>&1 | tee ci-artifacts/ios-simulator-build.log\n\n      - name: Run unit tests\n        run: |\n          set -o pipefail\n          rm -rf TestResults.xcresult\n          bash scripts/ci-test.sh 2>&1 | tee ci-artifacts/unit-tests.log\n\n      - name: Collect CI evidence\n        if: always()\n        env:\n          JOB_STATUS: ${{ job.status }}\n        run: |\n          if [ -d TestResults.xcresult ]; then\n            ditto TestResults.xcresult ci-artifacts/TestResults.xcresult\n          fi\n          python3 scripts/ci-collect-evidence.py             --workflow "iOS CI"             --phase "standard-preflight"             --status "$JOB_STATUS"             --artifact-dir ci-artifacts             --output ci-artifacts/CI_EVIDENCE.json\n\n      - name: Upload CI evidence\n        if: always()\n        uses: actions/upload-artifact@v4\n        with:\n          name: VeilLink-iOS-CI-Evidence-${{ github.run_id }}-${{ github.run_attempt }}\n          path: ci-artifacts\n          if-no-files-found: error\n          retention-days: 14\n', encoding="utf-8")
Path(".github/workflows/local-ai-heavy-validation.yml").write_text('name: Real Local AI heavy validation\n\non:\n  workflow_dispatch:\n  workflow_call:\n\npermissions:\n  contents: read\n\nenv:\n  LLAMA_CPP_COMMIT: b29c606e28a01b1bc8c1351026a0fa6e616bf6c4\n  IOS_MIN_OS_VERSION: \'15.0\'\n  QWEN_MODEL_SHA256: da2572f16c06133561ce56accaa822216f2391ef4d37fba427801cd6736417d4\n  QWEN_MODEL_REVISION: a41486f827d17edd055fe6b3b0ba3f8d427c0519\n\njobs:\n  preflight:\n    uses: ./.github/workflows/ios-ci.yml\n\n  real-local-ai:\n    needs: preflight\n    runs-on: macos-15\n    timeout-minutes: 95\n    steps:\n      - uses: actions/checkout@v4\n\n      - name: Prepare evidence directory\n        run: |\n          mkdir -p ci-artifacts\n          {\n            echo "HEAD=$(git rev-parse HEAD)"\n            xcodebuild -version\n            sw_vers\n            df -h .\n          } 2>&1 | tee ci-artifacts/environment.log\n\n      - name: Install build tools\n        run: brew install xcodegen cmake 2>&1 | tee ci-artifacts/install-build-tools.log\n\n      - name: Build pinned llama.cpp and fetch pinned Qwen model\n        run: |\n          set -o pipefail\n          bash scripts/prepare-real-local-ai.sh 2>&1 | tee ci-artifacts/prepare-real-local-ai.log\n\n      - name: Generate local-AI Xcode project\n        run: |\n          set -o pipefail\n          {\n            xcodegen generate --spec project.local-ai.yml\n            bash scripts/verify-local-ai-project.sh\n          } 2>&1 | tee ci-artifacts/local-ai-project.log\n          cp VeilLink.xcodeproj/project.pbxproj ci-artifacts/project.local-ai.pbxproj\n\n      - name: Build simulator with real llama runtime\n        run: |\n          set -o pipefail\n          rm -rf ci-artifacts/AI-SimulatorBuild.xcresult\n          xcodebuild             -project VeilLink.xcodeproj             -scheme VeilLink             -configuration Debug             -sdk iphonesimulator             -destination \'generic/platform=iOS Simulator\'             -resultBundlePath ci-artifacts/AI-SimulatorBuild.xcresult             CODE_SIGNING_ALLOWED=NO             build 2>&1 | tee ci-artifacts/ai-simulator-build.log\n\n      - name: Run full tests including real Qwen inference smoke test\n        run: |\n          set -o pipefail\n          rm -rf TestResults.xcresult\n          bash scripts/ci-test.sh 2>&1 | tee ci-artifacts/AI_TEST.log\n          grep -q \'VEILLINK_AI_METRICS_JSON=\' ci-artifacts/AI_TEST.log\n          grep \'VEILLINK_AI_METRICS_JSON=\' ci-artifacts/AI_TEST.log | tail -n1 | sed \'s/^.*VEILLINK_AI_METRICS_JSON=//\' > AI_SMOKE_METRICS.json\n          python3 -m json.tool AI_SMOKE_METRICS.json >/dev/null\n          cp AI_SMOKE_METRICS.json ci-artifacts/\n\n      - name: Build unsigned iPhoneOS app\n        run: |\n          set -o pipefail\n          rm -rf DerivedData ci-artifacts/AI-DeviceBuild.xcresult\n          xcodebuild             -project VeilLink.xcodeproj             -scheme VeilLink             -configuration Release             -sdk iphoneos             -derivedDataPath DerivedData             -resultBundlePath ci-artifacts/AI-DeviceBuild.xcresult             CODE_SIGNING_ALLOWED=NO             build 2>&1 | tee ci-artifacts/ai-device-build.log\n\n      - name: Verify real local AI is inside app\n        run: |\n          set -o pipefail\n          bash scripts/verify-real-local-ai-app.sh 2>&1 | tee ci-artifacts/verify-real-local-ai-app.log\n\n      - name: Write validation report\n        run: |\n          python3 - <<\'PY\'\n          import hashlib, json, os, pathlib, subprocess\n          app = pathlib.Path(\'DerivedData/Build/Products/Release-iphoneos/VeilLink.app/VeilLink\')\n          report = {\n              \'schema\': 1,\n              \'result\': \'PASS\',\n              \'llama_cpp_commit\': os.environ[\'LLAMA_CPP_COMMIT\'],\n              \'ios_minimum\': os.environ[\'IOS_MIN_OS_VERSION\'],\n              \'model\': \'Qwen3-0.6B-Q4_0.gguf\',\n              \'model_sha256\': os.environ[\'QWEN_MODEL_SHA256\'],\n              \'model_revision\': os.environ[\'QWEN_MODEL_REVISION\'],\n              \'real_inference_smoke_test\': \'PASS\',\n              \'smoke_metrics\': json.loads(pathlib.Path(\'AI_SMOKE_METRICS.json\').read_text()),\n              \'device_app_build\': \'PASS\',\n              \'app_executable_sha256\': hashlib.sha256(app.read_bytes()).hexdigest(),\n              \'release_eligible\': False,\n              \'release_gate\': \'Final IPA must come from MaleCNS + Qwen dual-brain heavy validation\',\n              \'git_head\': subprocess.check_output([\'git\',\'rev-parse\',\'HEAD\'], text=True).strip(),\n          }\n          pathlib.Path(\'AI_RUNTIME_VALIDATION.json\').write_text(json.dumps(report, indent=2) + \'\\n\')\n          PY\n          cp AI_RUNTIME_VALIDATION.json ci-artifacts/\n\n      - name: Collect heavy-validation evidence\n        if: always()\n        env:\n          JOB_STATUS: ${{ job.status }}\n        run: |\n          if [ -d TestResults.xcresult ]; then\n            ditto TestResults.xcresult ci-artifacts/TestResults.xcresult\n          fi\n          for f in AI_RUNTIME_VALIDATION.json AI_SMOKE_METRICS.json VeilLink/Resources/LocalAIProvenance.json; do\n            if [ -f "$f" ]; then cp "$f" ci-artifacts/; fi\n          done\n          python3 scripts/ci-collect-evidence.py             --workflow "Real Local AI heavy validation"             --phase "real-local-ai"             --status "$JOB_STATUS"             --artifact-dir ci-artifacts             --output ci-artifacts/CI_EVIDENCE.json\n\n      - name: Upload heavy-validation evidence\n        if: always()\n        uses: actions/upload-artifact@v4\n        with:\n          name: VeilLink-RealLocalAI-Evidence-${{ github.run_id }}-${{ github.run_attempt }}\n          path: ci-artifacts\n          if-no-files-found: error\n          compression-level: 0\n          retention-days: 30\n\n      - name: Upload successful runtime validation\n        if: success()\n        uses: actions/upload-artifact@v4\n        with:\n          name: VeilLink-RealLocalAI-Validation\n          path: |\n            AI_RUNTIME_VALIDATION.json\n            AI_SMOKE_METRICS.json\n            VeilLink/Resources/LocalAIProvenance.json\n          if-no-files-found: error\n          compression-level: 0\n          retention-days: 30\n', encoding="utf-8")
Path(".github/workflows/malecns-heavy-validation.yml").write_text('name: MaleCNS + Qwen dual-brain heavy validation\n\non:\n  workflow_dispatch:\n  workflow_call:\n\npermissions:\n  contents: read\n\nenv:\n  LLAMA_CPP_COMMIT: b29c606e28a01b1bc8c1351026a0fa6e616bf6c4\n  IOS_MIN_OS_VERSION: \'15.0\'\n  QWEN_MODEL_SHA256: da2572f16c06133561ce56accaa822216f2391ef4d37fba427801cd6736417d4\n  QWEN_MODEL_REVISION: a41486f827d17edd055fe6b3b0ba3f8d427c0519\n  VFLY_CORE_SHA256: cc8b71d824ecb7f20c821412b316262ecb4dd1faee148077c94825b5889d60de\n  VFLY_LITE_SHA256: 25b4947ec6c2a33502879d92269299120b708e86110157a538f792e327b7abee\n\njobs:\n  preflight:\n    uses: ./.github/workflows/ios-ci.yml\n\n  package-dual-brain-ipa:\n    needs: preflight\n    runs-on: macos-15\n    timeout-minutes: 110\n    steps:\n      - uses: actions/checkout@v4\n\n      - name: Prepare evidence directory\n        run: |\n          mkdir -p ci-artifacts\n          {\n            echo "HEAD=$(git rev-parse HEAD)"\n            xcodebuild -version\n            sw_vers\n            df -h .\n          } 2>&1 | tee ci-artifacts/environment.log\n\n      - name: Verify bundled real VFLY Core/Lite\n        run: |\n          set -euo pipefail\n          {\n            python3 scripts/verify-vfly-installed.py VeilLink/Resources --json-out VFLY_BUNDLED_VERIFY.json\n            echo "$VFLY_CORE_SHA256  VeilLink/Resources/VeilFlyCore.vfly" | shasum -a 256 -c -\n            echo "$VFLY_LITE_SHA256  VeilLink/Resources/VeilFlyLite.vfly" | shasum -a 256 -c -\n            test ! -e VeilLink/Resources/MaleCNSReference.vfly\n          } 2>&1 | tee ci-artifacts/vfly-bundled-verify.log\n          cp VFLY_BUNDLED_VERIFY.json ci-artifacts/\n\n      - name: Install build tools\n        run: brew install xcodegen cmake 2>&1 | tee ci-artifacts/install-build-tools.log\n\n      - name: Prepare real Qwen + llama runtime\n        run: |\n          set -o pipefail\n          bash scripts/prepare-real-local-ai.sh 2>&1 | tee ci-artifacts/prepare-real-local-ai.log\n\n      - name: Generate dual-brain Xcode project\n        run: |\n          set -o pipefail\n          {\n            xcodegen generate --spec project.local-ai.yml\n            bash scripts/verify-local-ai-project.sh\n          } 2>&1 | tee ci-artifacts/dual-brain-project.log\n          cp VeilLink.xcodeproj/project.pbxproj ci-artifacts/project.local-ai.pbxproj\n\n      - name: Build simulator with MaleCNS and Qwen\n        run: |\n          set -o pipefail\n          rm -rf ci-artifacts/DualBrain-SimulatorBuild.xcresult\n          xcodebuild             -project VeilLink.xcodeproj             -scheme VeilLink             -configuration Debug             -sdk iphonesimulator             -destination \'generic/platform=iOS Simulator\'             -resultBundlePath ci-artifacts/DualBrain-SimulatorBuild.xcresult             CODE_SIGNING_ALLOWED=NO             build 2>&1 | tee ci-artifacts/dual-brain-simulator-build.log\n\n      - name: Run complete tests including real inference smoke test\n        run: |\n          set -o pipefail\n          rm -rf TestResults.xcresult\n          bash scripts/ci-test.sh 2>&1 | tee ci-artifacts/AI_TEST.log\n          grep -q \'VEILLINK_AI_METRICS_JSON=\' ci-artifacts/AI_TEST.log\n          grep \'VEILLINK_AI_METRICS_JSON=\' ci-artifacts/AI_TEST.log | tail -n1 | sed \'s/^.*VEILLINK_AI_METRICS_JSON=//\' > AI_SMOKE_METRICS.json\n          python3 -m json.tool AI_SMOKE_METRICS.json >/dev/null\n          cp AI_SMOKE_METRICS.json ci-artifacts/\n\n      - name: Build unsigned iPhoneOS dual-brain app\n        run: |\n          set -o pipefail\n          rm -rf DerivedData ci-artifacts/DualBrain-DeviceBuild.xcresult\n          xcodebuild             -project VeilLink.xcodeproj             -scheme VeilLink             -configuration Release             -sdk iphoneos             -derivedDataPath DerivedData             -resultBundlePath ci-artifacts/DualBrain-DeviceBuild.xcresult             CODE_SIGNING_ALLOWED=NO             build 2>&1 | tee ci-artifacts/dual-brain-device-build.log\n\n      - name: Verify VFLY and real local AI assets\n        run: |\n          set -euo pipefail\n          bash scripts/verify-dual-brain-app.sh             "DerivedData/Build/Products/Release-iphoneos/VeilLink.app"             DUAL_BRAIN_VFLY_VERIFY.json 2>&1 | tee ci-artifacts/verify-dual-brain-app.log\n          cp DUAL_BRAIN_VFLY_VERIFY.json ci-artifacts/\n\n      - name: Package unsigned dual-brain IPA\n        run: |\n          set -o pipefail\n          bash scripts/package-unsigned-ipa.sh 2>&1 | tee ci-artifacts/package-unsigned-ipa.log\n\n      - name: Write dual-brain validation report\n        run: |\n          python3 - <<\'PY2\'\n          import hashlib, json, os, pathlib, subprocess\n          ipa = pathlib.Path(\'build/VeilLink-unsigned.ipa\')\n          report = {\n              \'schema\': 2,\n              \'result\': \'PASS\',\n              \'male_cns\': \'bundled VFLY1 Core/Lite verified\',\n              \'vfly_core_sha256\': os.environ[\'VFLY_CORE_SHA256\'],\n              \'vfly_lite_sha256\': os.environ[\'VFLY_LITE_SHA256\'],\n              \'qwen_model\': \'Qwen3-0.6B-Q4_0.gguf\',\n              \'qwen_sha256\': os.environ[\'QWEN_MODEL_SHA256\'],\n              \'qwen_revision\': os.environ[\'QWEN_MODEL_REVISION\'],\n              \'llama_cpp_commit\': os.environ[\'LLAMA_CPP_COMMIT\'],\n              \'real_inference_smoke_test\': \'PASS\',\n              \'smoke_metrics\': json.loads(pathlib.Path(\'AI_SMOKE_METRICS.json\').read_text()),\n              \'ipa_sha256\': hashlib.sha256(ipa.read_bytes()).hexdigest(),\n              \'ipa_bytes\': ipa.stat().st_size,\n              \'git_head\': subprocess.check_output([\'git\',\'rev-parse\',\'HEAD\'], text=True).strip(),\n          }\n          pathlib.Path(\'DUAL_BRAIN_VALIDATION.json\').write_text(json.dumps(report, indent=2) + \'\\n\')\n          PY2\n          cp DUAL_BRAIN_VALIDATION.json ci-artifacts/\n\n      - name: Collect dual-brain evidence\n        if: always()\n        env:\n          JOB_STATUS: ${{ job.status }}\n        run: |\n          if [ -d TestResults.xcresult ]; then\n            ditto TestResults.xcresult ci-artifacts/TestResults.xcresult\n          fi\n          for f in             VFLY_BUNDLED_VERIFY.json             DUAL_BRAIN_VFLY_VERIFY.json             DUAL_BRAIN_VALIDATION.json             AI_SMOKE_METRICS.json             VeilLink/Resources/VeilFlyAssets.json             VeilLink/Resources/VFLYInstallationVerification.json             VeilLink/Resources/LocalAIProvenance.json; do\n            if [ -f "$f" ]; then cp "$f" ci-artifacts/; fi\n          done\n          python3 scripts/ci-collect-evidence.py             --workflow "MaleCNS + Qwen dual-brain heavy validation"             --phase "dual-brain-release"             --status "$JOB_STATUS"             --artifact-dir ci-artifacts             --output ci-artifacts/CI_EVIDENCE.json\n\n      - name: Upload dual-brain evidence\n        if: always()\n        uses: actions/upload-artifact@v4\n        with:\n          name: VeilLink-DualBrain-Evidence-${{ github.run_id }}-${{ github.run_attempt }}\n          path: ci-artifacts\n          if-no-files-found: error\n          compression-level: 0\n          retention-days: 30\n\n      - name: Upload successful unsigned dual-brain IPA\n        if: success()\n        uses: actions/upload-artifact@v4\n        with:\n          name: VeilLink-unsigned-DualBrain\n          path: |\n            build/VeilLink-unsigned.ipa\n            VeilLink/Resources/VeilFlyAssets.json\n            VeilLink/Resources/VFLYInstallationVerification.json\n            VeilLink/Resources/LocalAIProvenance.json\n            VFLY_BUNDLED_VERIFY.json\n            DUAL_BRAIN_VFLY_VERIFY.json\n            DUAL_BRAIN_VALIDATION.json\n            AI_SMOKE_METRICS.json\n          if-no-files-found: error\n          compression-level: 0\n          retention-days: 30\n', encoding="utf-8")

for obsolete in [
    ".github/workflows/swift.yml",
    ".github/workflows/sync-v022.yml",
    ".github/workflows/sync-v036.yml",
]:
    Path(obsolete).unlink()

print("R11-C CUMULATIVE PATCH APPLIED")
print("BASELINE=" + head)
print("OLD_BOOTSTRAP_SYNC_WORKFLOWS_REMOVED=3")
print("HEAVY_WORKFLOWS=manual_or_reusable_with_standard_preflight")
print("ALWAYS_ON_EVIDENCE=enabled")
