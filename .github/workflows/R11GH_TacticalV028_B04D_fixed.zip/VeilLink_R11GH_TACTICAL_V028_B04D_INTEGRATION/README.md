# VeilLink · R11-GH + Tactical V0.2.8 B04D

Baseline: `ee716e1e91719225e7e740724ac551bc4eeb7acb`

Upstream tactical package SHA-256:
`2f598fb4e28f53e4bd20cf7e8da683717916db037e741ea5aafe8b61a484befe`

This carrier is self-contained and applies R11-A through R11-H first, then integrates Tactical V2.

## Integrated Tactical V2
- legacy VLGM1 / 7×9 fallback remains intact;
- VLTW2 hello / commitment / reveal / frameDigest;
- VLTW2 stays inside existing VeilLink E2EE text transport;
- 48×27 / 1296-cell Guandu runtime map;
- FOW V2 + WEGO + deterministic replay;
- Supply / Threat / Objective / abstract combat-forecast layers;
- landscape Canvas + route command assessment.

## Extra hardening added here
- production pending reveal moved from UserDefaults to Keychain (`WhenUnlockedThisDeviceOnly`);
- session ID is SHA-256-derived before becoming a Keychain account key;
- frameDigest divergence stops later V2 turn resolution;
- divergence puts the UI into a command-hold state;
- LaunchGate failures are surfaced with an alert;
- upstream `__pycache__/*.pyc` is not integrated;
- Tactical source/map checks are part of standard preflight;
- final `.app` and IPA must contain the exact Guandu map SHA.

Guandu map SHA-256:
`4bd450353ae993b0c8083b97ab5909c8260cd6984be6f6051db1967613edaaa5`

## Apply
From a clean checkout at the audited baseline:

```bash
python3 apply_r11gh_tactical_v028.py
git diff --check
git status --short
```

Then run **iOS CI only** first. If that is green, run the dual-brain heavy release gate.

Expected successful final artifact name:
`VeilLink-unsigned-v0.9.7-b41-DualBrain-TacticalV2`

This package does not claim real Xcode, device, or IPA PASS.
