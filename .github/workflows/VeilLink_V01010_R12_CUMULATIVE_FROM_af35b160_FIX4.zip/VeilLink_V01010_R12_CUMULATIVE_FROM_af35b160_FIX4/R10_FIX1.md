# R10 FIX3

The guarded cumulative run passed R1A through R10, then R11 rejected the
generated files did not equal R11's protected R10 baseline:

- `SessionCoordinator.swift`: `679b...` vs `1ee9...`
- `ConversationViews.swift`: `3f4f...` vs `9fb3...`
- `BLELinkReliabilityPolicy.swift`: `bb86...` vs `cc80...`
- `BLETransport.swift`: `0250...` vs `58d0...`
- `Info.plist`: `009d...` vs `5cf3...`

The af35 tree carries later reconnect/game/BLE/chat integration and experimental
AI permission strings. R10 FIX3 accepts only the known generated hashes (or the
already-canonical hashes), then normalizes to embedded canonical R10 files
whose SHA-256 values must equal R11's existing guards. No R11 baseline hash,
guard, or installer is modified. The overwritten af35/R9 sources remain
preserved by R10's existing `docs/history/voice/V0107_R9` snapshot.
