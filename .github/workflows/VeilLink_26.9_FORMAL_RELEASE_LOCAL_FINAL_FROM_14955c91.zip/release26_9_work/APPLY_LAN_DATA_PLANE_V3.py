#!/usr/bin/env python3
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_LAN_DATA_PLANE_V3.py <repo-root>')
root = Path(sys.argv[1]).resolve()

def replace_once(path: Path, old: str, new: str, label: str):
    s = path.read_text()
    count = s.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected anchor exactly once, got {count}')
    path.write_text(s.replace(old, new, 1))

# -----------------------------------------------------------------------------
# LANTransport: make the data plane observable and resilient to one-shot
# Bonjour/TCP connection failures. This is intentionally transport-only; E2EE
# remains in SessionCoordinator.
# -----------------------------------------------------------------------------
p = root / 'VeilLink/Transport/LANTransport.swift'

old = '''enum LANFrameCodec {
    static let maximumPayloadBytes = 96_000
    static let headerBytes = 4
'''
new = '''enum LANDataPlanePolicy {
    // Four 48 KiB chunks per acknowledgement window gives the TCP path a real
    // pipeline without inflating iPhone 7 memory or changing Wire Protocol v4.
    static let attachmentBurstWindow = 4

    static func reconnectDelay(attempt: Int) -> TimeInterval {
        let schedule: [TimeInterval] = [0.35, 0.80, 1.50, 3.0, 5.0]
        return schedule[min(max(attempt, 0), schedule.count - 1)]
    }
}

enum LANFrameCodec {
    static let maximumPayloadBytes = 96_000
    static let headerBytes = 4
'''
replace_once(p, old, new, 'LAN policy insert')

old = '''    @Published private(set) var connectedPeerCount = 0
    @Published private(set) var linkSnapshots: [UUID: LANTurboLinkSnapshot] = [:]
    @Published var peerToPeerBoostEnabled = true
'''
new = '''    @Published private(set) var connectedPeerCount = 0
    @Published private(set) var linkSnapshots: [UUID: LANTurboLinkSnapshot] = [:]
    @Published private(set) var totalPayloadBytesSent: UInt64 = 0
    @Published private(set) var totalPayloadBytesReceived: UInt64 = 0
    @Published private(set) var lastDataPlaneActivityAt: Date?
    @Published var peerToPeerBoostEnabled = true
'''
s = p.read_text()
if s.count(old) != 2: raise SystemExit(f'LAN metrics anchor mismatch: {s.count(old)}')
p.write_text(s.replace(old, new, 1))

old = '''    private var links: [UUID: LANLink] = [:]
    private var endpointToLink: [String: UUID] = [:]
    private var running = false
'''
new = '''    private var links: [UUID: LANLink] = [:]
    private var endpointToLink: [String: UUID] = [:]
    private var discoveredEndpoints: [String: NWEndpoint] = [:]
    private var reconnectAttempts: [String: Int] = [:]
    private var reconnectWorkItems: [String: DispatchWorkItem] = [:]
    private var sentPayloadBytes: UInt64 = 0
    private var receivedPayloadBytes: UInt64 = 0
    private var running = false
'''
replace_once(p, old, new, 'LAN reconnect state')

old = '''    func containsTransport(_ id: UUID) -> Bool {
        queue.sync { links[id] != nil }
    }

    @discardableResult
'''
new = '''    func containsTransport(_ id: UUID) -> Bool {
        queue.sync { links[id] != nil }
    }

    func isReadyTransport(_ id: UUID) -> Bool {
        queue.sync { links[id]?.isReady == true }
    }

    var dataPlaneSummary: String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .binary
        let sent = formatter.string(fromByteCount: Int64(clamping: totalPayloadBytesSent))
        let received = formatter.string(fromByteCount: Int64(clamping: totalPayloadBytesReceived))
        return "TX \\(sent) · RX \\(received)"
    }

    @discardableResult
'''
replace_once(p, old, new, 'LAN ready/summary API')

old = '''        links.removeAll()
        endpointToLink.removeAll()
        publishMain { [weak self] in
'''
new = '''        links.removeAll()
        endpointToLink.removeAll()
        discoveredEndpoints.removeAll()
        reconnectAttempts.removeAll()
        for item in reconnectWorkItems.values { item.cancel() }
        reconnectWorkItems.removeAll()
        publishMain { [weak self] in
'''
replace_once(p, old, new, 'LAN stop reconnect cleanup')

old = '''    private func handleBrowseResultsLocked(_ results: Set<NWBrowser.Result>) {
        guard running else { return }
        let endpoints = results.map(\\.endpoint).filter { !isOwnService($0) }
        publishMain { [weak self] in self?.discoveredServiceCount = endpoints.count }
        for endpoint in endpoints {
            guard shouldInitiateConnection(to: endpoint) else { continue }
            let key = endpointKey(endpoint)
            guard endpointToLink[key] == nil else { continue }
            let connection = NWConnection(to: endpoint, using: makeParameters())
            registerLocked(connection: connection, role: .outgoing, endpointKey: key)
        }
    }
'''
new = '''    private func handleBrowseResultsLocked(_ results: Set<NWBrowser.Result>) {
        guard running else { return }
        let endpoints = results.map(\\.endpoint).filter { !isOwnService($0) }
        publishMain { [weak self] in self?.discoveredServiceCount = endpoints.count }

        var next: [String: NWEndpoint] = [:]
        for endpoint in endpoints where shouldInitiateConnection(to: endpoint) {
            next[endpointKey(endpoint)] = endpoint
        }
        let removed = Set(discoveredEndpoints.keys).subtracting(next.keys)
        for key in removed {
            reconnectWorkItems.removeValue(forKey: key)?.cancel()
            reconnectAttempts.removeValue(forKey: key)
        }
        discoveredEndpoints = next
        for (key, endpoint) in next where endpointToLink[key] == nil {
            connectToDiscoveredEndpointLocked(endpoint, key: key)
        }
    }

    private func connectToDiscoveredEndpointLocked(_ endpoint: NWEndpoint, key: String) {
        guard running, endpointToLink[key] == nil else { return }
        reconnectWorkItems.removeValue(forKey: key)?.cancel()
        let connection = NWConnection(to: endpoint, using: makeParameters())
        registerLocked(connection: connection, role: .outgoing, endpointKey: key)
    }

    private func scheduleReconnectLocked(endpointKey key: String) {
        guard running, endpointToLink[key] == nil, let endpoint = discoveredEndpoints[key] else { return }
        reconnectWorkItems.removeValue(forKey: key)?.cancel()
        let attempt = reconnectAttempts[key, default: 0]
        reconnectAttempts[key] = min(attempt + 1, 32)
        let delay = LANDataPlanePolicy.reconnectDelay(attempt: attempt)
        let item = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.reconnectWorkItems.removeValue(forKey: key)
            guard self.running, self.endpointToLink[key] == nil,
                  let latestEndpoint = self.discoveredEndpoints[key] else { return }
            self.connectToDiscoveredEndpointLocked(latestEndpoint, key: key)
        }
        reconnectWorkItems[key] = item
        queue.asyncAfter(deadline: .now() + delay, execute: item)
    }
'''
replace_once(p, old, new, 'LAN browse reconciliation')

old = '''        case .ready:
            guard !link.isReady else { return }
            link.isReady = true
            receiveNextLocked(link)
'''
new = '''        case .ready:
            guard !link.isReady else { return }
            link.isReady = true
            if link.role == .outgoing {
                reconnectAttempts.removeValue(forKey: link.endpointKey)
                reconnectWorkItems.removeValue(forKey: link.endpointKey)?.cancel()
            }
            receiveNextLocked(link)
'''
replace_once(p, old, new, 'LAN ready resets retry')

old = '''                    let frames = try current.decoder.append(data)
                    for frame in frames {
                        self.publishMain { [weak self] in self?.onReceive?(link.id, frame) }
                    }
'''
new = '''                    let frames = try current.decoder.append(data)
                    for frame in frames {
                        self.recordDataPlaneLocked(received: frame.count)
                        self.publishMain { [weak self] in self?.onReceive?(link.id, frame) }
                    }
'''
replace_once(p, old, new, 'LAN RX accounting')

old = '''                if error != nil {
                    current.connection.cancel()
                    self.removeLinkLocked(link.id)
                    return
                }
                self.drainLocked(current)
'''
new = '''                if error != nil {
                    current.connection.cancel()
                    self.removeLinkLocked(link.id)
                    return
                }
                self.recordDataPlaneLocked(sent: max(0, sentBytes - LANFrameCodec.headerBytes))
                self.drainLocked(current)
'''
replace_once(p, old, new, 'LAN TX accounting')

old = '''    private func removeLinkLocked(_ id: UUID) {
        guard let link = links.removeValue(forKey: id) else { return }
        if endpointToLink[link.endpointKey] == id { endpointToLink.removeValue(forKey: link.endpointKey) }
        publishSnapshotsLocked()
'''
new = '''    private func removeLinkLocked(_ id: UUID) {
        guard let link = links.removeValue(forKey: id) else { return }
        if endpointToLink[link.endpointKey] == id { endpointToLink.removeValue(forKey: link.endpointKey) }
        if link.role == .outgoing { scheduleReconnectLocked(endpointKey: link.endpointKey) }
        publishSnapshotsLocked()
'''
replace_once(p, old, new, 'LAN reconnect on drop')

old = '''    private func publishSnapshotsLocked() {
        let snapshots = Dictionary(uniqueKeysWithValues: links.values.map { link in
'''
new = '''    private func recordDataPlaneLocked(sent: Int = 0, received: Int = 0) {
        if sent > 0 { sentPayloadBytes &+= UInt64(sent) }
        if received > 0 { receivedPayloadBytes &+= UInt64(received) }
        guard sent > 0 || received > 0 else { return }
        let sentTotal = sentPayloadBytes
        let receivedTotal = receivedPayloadBytes
        let now = Date()
        publishMain { [weak self] in
            guard let self else { return }
            self.totalPayloadBytesSent = sentTotal
            self.totalPayloadBytesReceived = receivedTotal
            self.lastDataPlaneActivityAt = now
        }
    }

    private func publishSnapshotsLocked() {
        let snapshots = Dictionary(uniqueKeysWithValues: links.values.map { link in
'''
replace_once(p, old, new, 'LAN data plane accounting helper')

# Non-Network fallback must preserve the same public surface.
old = '''    @Published private(set) var connectedPeerCount = 0
    @Published private(set) var linkSnapshots: [UUID: LANTurboLinkSnapshot] = [:]
    @Published var peerToPeerBoostEnabled = true
'''
new = '''    @Published private(set) var connectedPeerCount = 0
    @Published private(set) var linkSnapshots: [UUID: LANTurboLinkSnapshot] = [:]
    @Published private(set) var totalPayloadBytesSent: UInt64 = 0
    @Published private(set) var totalPayloadBytesReceived: UInt64 = 0
    @Published private(set) var lastDataPlaneActivityAt: Date?
    @Published var peerToPeerBoostEnabled = true
'''
# The first occurrence was already replaced; the fallback remains exactly once now.
replace_once(p, old, new, 'LAN fallback metrics')

old = '''    func containsTransport(_ id: UUID) -> Bool { false }
    func send(_ payload: Data, to transportID: UUID, priority: BLESendPriority) -> TransportSendResult { .temporarilyUnavailable }
'''
new = '''    func containsTransport(_ id: UUID) -> Bool { false }
    func isReadyTransport(_ id: UUID) -> Bool { false }
    var dataPlaneSummary: String { "TX 0 bytes · RX 0 bytes" }
    func send(_ payload: Data, to transportID: UUID, priority: BLESendPriority) -> TransportSendResult { .temporarilyUnavailable }
'''
replace_once(p, old, new, 'LAN fallback ready API')

# -----------------------------------------------------------------------------
# SessionCoordinator: expose actual secure routing and remove the BLE-style
# stop-and-wait bottleneck from LAN attachment data.
# -----------------------------------------------------------------------------
p = root / 'VeilLink/Security/SessionCoordinator.swift'
old = '''enum VeilSessionTransportKind: Int, Sendable {
    case ble = 0
    case lan = 1
    case internet = 2
}
'''
new = '''enum VeilSessionTransportKind: Int, Sendable {
    case ble = 0
    case lan = 1
    case internet = 2

    var diagnosticLabel: String {
        switch self {
        case .ble: return "BLE"
        case .lan: return "LAN"
        case .internet: return "RELAY"
        }
    }
}

enum VeilTransportRoutePolicy {
    static func rank(_ kind: VeilSessionTransportKind) -> Int {
        switch kind {
        case .internet: return 5
        case .ble: return 10
        case .lan: return 20
        }
    }
}
'''
replace_once(p, old, new, 'route policy insert')

old = '''    func transportID(for peerIdentityID: String) -> UUID? {
        peerTransport[peerIdentityID]
    }

    func hasSecureSession(for peerIdentityID: String) -> Bool {
'''
new = '''    func transportID(for peerIdentityID: String) -> UUID? {
        peerTransport[peerIdentityID]
    }

    func transportID(for peerIdentityID: String, kind: VeilSessionTransportKind) -> UUID? {
        let candidates = (peerTransports[peerIdentityID] ?? []).filter {
            transportKinds[$0] == kind && isSecureSessionTransport($0, for: peerIdentityID)
        }
        return candidates.sorted { $0.uuidString < $1.uuidString }.first
    }

    func preferredTransportKind(for peerIdentityID: String) -> VeilSessionTransportKind? {
        guard let id = peerTransport[peerIdentityID] else { return nil }
        return transportKinds[id]
    }

    func secureLANPeerCount() -> Int {
        peerTransports.reduce(into: 0) { count, entry in
            if entry.value.contains(where: { transportKinds[$0] == .lan && isSecureSessionTransport($0, for: entry.key) }) {
                count += 1
            }
        }
    }

    func hasSecureSession(for peerIdentityID: String) -> Bool {
'''
replace_once(p, old, new, 'secure route diagnostics')

old = '''        let state = try database.storeInboundAttachmentChunk(messageID: payload.messageID, index: Int(chunk.index), chunkCount: Int(chunk.total), clearData: chunk.bytes)
        try sendAttachmentCheckpoint(messageID: payload.messageID, nextChunk: state.nextChunk, chunkCount: state.chunkCount, transportID: transportID, context: &context)
        sessions[transportID] = context
'''
new = '''        let state = try database.storeInboundAttachmentChunk(messageID: payload.messageID, index: Int(chunk.index), chunkCount: Int(chunk.total), clearData: chunk.bytes)
        let isLAN = transportKinds[transportID] == .lan
        let shouldCheckpoint = !isLAN || state.completed || state.nextChunk == 0 || state.nextChunk % LANDataPlanePolicy.attachmentBurstWindow == 0
        if shouldCheckpoint {
            try sendAttachmentCheckpoint(messageID: payload.messageID, nextChunk: state.nextChunk, chunkCount: state.chunkCount, transportID: transportID, context: &context)
        }
        sessions[transportID] = context
'''
replace_once(p, old, new, 'LAN checkpoint stride')

old = '''        guard let state, state.chunkCount == expectedChunkCount else {
            failOutbound(messageID: message.id, peerIdentityID: peerIdentityID, localIdentityID: localIdentityID, reason: "本地附件 checkpoint 与图片数据不一致。")
            return false
        }

        let envelope: Data
'''
new = '''        guard let state, state.chunkCount == expectedChunkCount else {
            failOutbound(messageID: message.id, peerIdentityID: peerIdentityID, localIdentityID: localIdentityID, reason: "本地附件 checkpoint 与图片数据不一致。")
            return false
        }

        if state.nextChunk >= 0,
           state.nextChunk < state.chunkCount,
           transportKinds[transportID] == .lan {
            return try sendLANAttachmentBurst(
                message: message,
                data: data,
                state: state,
                peerIdentityID: peerIdentityID,
                transportID: transportID,
                localIdentityID: localIdentityID,
                keys: keys,
                context: &context
            )
        }

        let envelope: Data
'''
replace_once(p, old, new, 'LAN burst branch')

anchor = '''    private func applySendResult(_ result: TransportSendResult, message: ChatMessage, peerIdentityID: String, localIdentityID: String) throws -> Bool {
'''
helper = '''    private func sendLANAttachmentBurst(
        message: ChatMessage,
        data: Data,
        state: DatabaseStore.OutboundAttachmentState,
        peerIdentityID: String,
        transportID: UUID,
        localIdentityID: String,
        keys: SessionKeyMaterial,
        context: inout SessionContext
    ) throws -> Bool {
        let upperChunk = min(state.chunkCount, state.nextChunk + LANDataPlanePolicy.attachmentBurstWindow)
        var accepted = 0
        var terminalResult: TransportSendResult = .temporarilyUnavailable

        sendLoop: for chunkIndex in state.nextChunk..<upperChunk {
            let lower = chunkIndex * WireProtocol.attachmentChunkBytes
            let upper = min(lower + WireProtocol.attachmentChunkBytes, data.count)
            guard lower < upper else { throw CryptoEngineError.invalidCiphertext }
            let clearChunk = try WireCodec.encodeAttachmentChunk(
                WireAttachmentChunk(index: UInt16(chunkIndex), total: UInt16(state.chunkCount), bytes: Data(data[lower..<upper]))
            )
            let encrypted = try CryptoEngine.encrypt(
                clearChunk,
                key: keys.sendKey,
                messageID: message.id,
                sequence: context.nextSendSequence,
                context: "attachment-chunk"
            )
            context.nextSendSequence += 1
            let envelope = try WireCodec.encodeEnvelope(
                version: UInt8(WireProtocol.version),
                kind: .attachmentChunk,
                payload: try WireCodec.encodeEncryptedPayload(encrypted)
            )
            guard envelope.count <= WireProtocol.maximumEnvelopeBytes else { throw CryptoEngineError.invalidCiphertext }
            let result = transportSend?(transportID, envelope, .bulk) ?? .temporarilyUnavailable
            terminalResult = result
            switch result {
            case .accepted:
                accepted += 1
            case .temporarilyUnavailable:
                break sendLoop
            case .unsupportedLink:
                break sendLoop
            }
        }

        if accepted > 0 {
            let didChangeVisibleState = message.deliveryState != .sending
            if didChangeVisibleState { try database.updateDelivery(messageID: message.id, state: .sending) }
            try database.recordAcceptedOutboundAttempt(
                messageID: message.id,
                targetIdentityID: peerIdentityID,
                localIdentityID: localIdentityID
            )
            return didChangeVisibleState
        }
        return try applySendResult(terminalResult, message: message, peerIdentityID: peerIdentityID, localIdentityID: localIdentityID)
    }

'''
# Public nested type is internal; DatabaseStore.OutboundAttachmentState exists as an internal struct.
s = p.read_text()
if s.count(anchor) != 1:
    raise SystemExit(f'LAN burst helper anchor mismatch: {s.count(anchor)}')
p.write_text(s.replace(anchor, helper + anchor, 1))

old = '''    private func transportRank(_ transportID: UUID) -> Int {
        switch transportKinds[transportID] ?? .ble {
        case .internet: return 5
        case .ble: return 10
        case .lan: return 20
        }
    }
'''
new = '''    private func transportRank(_ transportID: UUID) -> Int {
        VeilTransportRoutePolicy.rank(transportKinds[transportID] ?? .ble)
    }
'''
replace_once(p, old, new, 'route rank centralization')

# -----------------------------------------------------------------------------
# Nearby UI: raw TCP links are no longer presented as proof of acceleration.
# Show secure LAN routes plus real payload counters, and keep BLE diagnostics
# visible even while LAN is the preferred route.
# -----------------------------------------------------------------------------
p = root / 'VeilLink/UI/NearbyView.swift'
old = '''                HStack(spacing: 12) {
                    VeilIconDisc(systemName: "wifi", size: 38, highlighted: lanTurbo.connectedPeerCount > 0)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("LAN TURBO")
                            .font(.system(size: 8.5, weight: .bold, design: .monospaced))
                            .tracking(1.0)
                            .foregroundColor(VeilTheme.mutedGold)
                        Text(lanTurbo.statusText)
                            .font(.caption.weight(.semibold))
                            .foregroundColor(VeilTheme.text)
                        Text("同一 Wi-Fi / 热点直连 · E2EE 保持不变")
                            .font(.caption2)
                            .foregroundColor(VeilTheme.secondaryText)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 3) {
                        Text("\\(lanTurbo.connectedPeerCount) LINK")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundColor(lanTurbo.connectedPeerCount > 0 ? VeilTheme.success : VeilTheme.tertiaryText)
                        Text("\\(lanTurbo.discoveredServiceCount) FOUND")
                            .font(.system(size: 8, weight: .medium, design: .monospaced))
                            .foregroundColor(VeilTheme.tertiaryText)
                    }
                }
                .veilCard(emphasized: lanTurbo.connectedPeerCount > 0)
'''
new = '''                HStack(spacing: 12) {
                    VeilIconDisc(systemName: "wifi", size: 38, highlighted: sessions.secureLANPeerCount() > 0)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("LAN TURBO · DATA PLANE")
                            .font(.system(size: 8.5, weight: .bold, design: .monospaced))
                            .tracking(1.0)
                            .foregroundColor(VeilTheme.mutedGold)
                        Text(sessions.secureLANPeerCount() > 0 ? "高速安全路由正在工作" : lanTurbo.statusText)
                            .font(.caption.weight(.semibold))
                            .foregroundColor(VeilTheme.text)
                        Text(lanTurbo.dataPlaneSummary)
                            .font(.caption2.monospaced())
                            .foregroundColor((lanTurbo.totalPayloadBytesSent + lanTurbo.totalPayloadBytesReceived) > 0 ? VeilTheme.success : VeilTheme.secondaryText)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 3) {
                        Text("\\(sessions.secureLANPeerCount()) SECURE")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundColor(sessions.secureLANPeerCount() > 0 ? VeilTheme.success : VeilTheme.tertiaryText)
                        Text("\\(lanTurbo.connectedPeerCount) TCP · \\(lanTurbo.discoveredServiceCount) FOUND")
                            .font(.system(size: 8, weight: .medium, design: .monospaced))
                            .foregroundColor(VeilTheme.tertiaryText)
                    }
                }
                .veilCard(emphasized: sessions.secureLANPeerCount() > 0)
'''
replace_once(p, old, new, 'Nearby LAN truth card')

old = '''                        NearbyPeerCard(model: model, bluetooth: bluetooth, lanTurbo: lanTurbo, peer: peer)
'''
new = '''                        NearbyPeerCard(model: model, bluetooth: bluetooth, lanTurbo: lanTurbo, sessions: sessions, peer: peer)
'''
replace_once(p, old, new, 'Nearby peer session injection')

old = '''    @ObservedObject var bluetooth: BLETransport
    @ObservedObject var lanTurbo: LANTransport
    let peer: NearbyPeer

    private var lanSnapshot: LANTurboLinkSnapshot? {
        lanTurbo.linkSnapshots[peer.transportID]
    }

    private var linkSnapshot: BLEPeerLinkSnapshot? {
        bluetooth.linkSnapshots[peer.transportID] ?? bluetooth.linkSnapshot(for: peer.transportID)
    }
'''
new = '''    @ObservedObject var bluetooth: BLETransport
    @ObservedObject var lanTurbo: LANTransport
    @ObservedObject var sessions: SessionCoordinator
    let peer: NearbyPeer

    private var lanSnapshot: LANTurboLinkSnapshot? {
        guard let id = sessions.transportID(for: peer.id, kind: .lan) else { return nil }
        return lanTurbo.linkSnapshots[id]
    }

    private var linkSnapshot: BLEPeerLinkSnapshot? {
        guard let id = sessions.transportID(for: peer.id, kind: .ble) else { return nil }
        return bluetooth.linkSnapshots[id] ?? bluetooth.linkSnapshot(for: id)
    }
'''
replace_once(p, old, new, 'Nearby dual-link diagnostics')

old = '''                        Text("同一局域网 · 待发 \\(lanSnapshot.pendingFrames) 帧")
                            .font(.system(size: 9.5, weight: .medium, design: .monospaced))
                            .foregroundColor(VeilTheme.tertiaryText)
                    }
                    Spacer()
                    Text("FAST")
'''
new = '''                        Text("实际数据链路 · 待发 \\(lanSnapshot.pendingFrames) 帧 · \\(lanTurbo.dataPlaneSummary)")
                            .font(.system(size: 9.5, weight: .medium, design: .monospaced))
                            .foregroundColor(VeilTheme.tertiaryText)
                            .lineLimit(1)
                            .minimumScaleFactor(0.68)
                    }
                    Spacer()
                    Text(sessions.preferredTransportKind(for: peer.id) == .lan ? "ACTIVE" : "READY")
'''
replace_once(p, old, new, 'Nearby LAN active badge')

# -----------------------------------------------------------------------------
# Tests: pure policy coverage; full NWConnection/device validation remains CI/
# physical-device work.
# -----------------------------------------------------------------------------
test = root / 'VeilLinkTests/LANDataPlanePolicyTests.swift'
test.write_text('''import XCTest\n@testable import VeilLink\n\nfinal class LANDataPlanePolicyTests: XCTestCase {\n    func testLANRanksAboveBLEAndRelay() {\n        XCTAssertGreaterThan(VeilTransportRoutePolicy.rank(.lan), VeilTransportRoutePolicy.rank(.ble))\n        XCTAssertGreaterThan(VeilTransportRoutePolicy.rank(.ble), VeilTransportRoutePolicy.rank(.internet))\n    }\n\n    func testLANUsesBoundedBurstWindow() {\n        XCTAssertEqual(LANDataPlanePolicy.attachmentBurstWindow, 4)\n        XCTAssertGreaterThan(LANDataPlanePolicy.attachmentBurstWindow, 1)\n        XCTAssertLessThanOrEqual(LANDataPlanePolicy.attachmentBurstWindow, 8)\n    }\n\n    func testReconnectBackoffIsBoundedAndMonotonic() {\n        let delays = (0..<8).map { LANDataPlanePolicy.reconnectDelay(attempt: $0) }\n        XCTAssertEqual(delays.first, 0.35, accuracy: 0.001)\n        XCTAssertLessThanOrEqual(delays.last ?? 99, 5.0)\n        for pair in zip(delays, delays.dropFirst()) { XCTAssertLessThanOrEqual(pair.0, pair.1) }\n    }\n}\n''')

print('LAN_DATA_PLANE_V3 applied successfully')
