# VeilLink 26.9 · Build 53

VeilLink 26.9 is the first **formal stable-version target** after the long 0.x engineering line.
The version number intentionally follows a calendar-generation style rather than restarting at 1.0.

## Release identity

- Marketing version: **26.9**
- Build: **53**
- Channel: **Stable**
- Primary platform: **iOS**
- Android: preserved as an experimental/best-effort future target and must not block iOS artifacts.
- Wire protocol: **v4 unchanged**
- Existing SQLite schema: **unchanged by this release-consolidation layer**

## What this stabilization layer changes

This layer does not add a new user-facing transport or security protocol. It closes the release by reducing duplicated lifecycle code and release metadata drift:

1. BLE/LAN/Internet Relay lifecycle transitions now use one AppModel path for identity switching, profile creation, backup restore and legal sealing.
2. `project.yml` is the Xcode build identity source of truth. App and Widget Info.plists inherit `MARKETING_VERSION` and `CURRENT_PROJECT_VERSION`.
3. The Core verifier reads the expected version/build from `project.yml` instead of carrying another hard-coded copy.
4. IPA artifact names are read from the actual built app Info.plist.
5. Android artifact naming is detached from the iOS stable version because Android remains frozen/best-effort.
6. Existing LAN_DATA_PLANE_V3 routing, E2EE, legal gate, onboarding, Apple Soft/Liquid Glass and global Light/Dark behavior are retained.

## Release gate

This local package is the final release-candidate input, not a substitute for Xcode validation.
A **VeilLink 26.9 Stable** release may be declared only after the iOS-primary CI completes successfully and uploads the unsigned IPA artifact for **26.9 (53)**.

Required final checks:

- XcodeGen
- simulator build
- XCTest
- unsigned iPhoneOS Release
- Core release verifier
- artifact version = 26.9 / build = 53
- iPhone 7 smoke test
- iPhone 13 smoke test
- BLE send/receive
- LAN ACTIVE TX/RX increase on real Wi-Fi
- lock / legal gate / first-run onboarding
- all three UI skins in Light/Dark/Auto

No independent cryptographic audit is claimed by this release label.
