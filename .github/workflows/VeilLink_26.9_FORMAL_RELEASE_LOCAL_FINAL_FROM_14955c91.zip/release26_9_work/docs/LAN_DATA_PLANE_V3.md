# LAN_DATA_PLANE_V3

## Severity
P0 functional defect: LAN Turbo could establish and display a TCP/Bonjour link while attachment throughput still behaved like a BLE-paced transfer.

## Root cause
Wire Protocol v4 attachment transfer used a stop-and-wait checkpoint cadence inherited from BLE:

1. send one 48 KiB attachment chunk;
2. wait for receiver checkpoint;
3. send the next chunk.

TCP therefore never had enough data in flight to use local-network bandwidth. A second defect meant an outgoing Bonjour endpoint could fail once and then wait for a browse-result change before another connect attempt, even if the peer stayed visible on the same LAN.

## Fix
- Preserve Wire Protocol v4 and existing E2EE.
- LAN attachment path now sends a bounded 4-chunk burst (~192 KiB clear attachment data) before requiring a checkpoint.
- LAN receiver checkpoints every 4 contiguous chunks, on completion, and at the normal safety boundaries.
- BLE retains the existing one-chunk checkpoint behavior.
- Outgoing Bonjour/TCP endpoints use bounded reconnect backoff: 0.35s, 0.8s, 1.5s, 3s, 5s.
- LAN transport records actual payload TX/RX bytes after framing, instead of treating a raw TCP socket as proof of acceleration.
- SessionCoordinator exposes the preferred secure route and secure LAN peer count.
- Nearby diagnostics show secure LAN routes, real TX/RX counters, and ACTIVE/READY state.
- BLE diagnostics remain visible even while LAN is the preferred route.

## Security
No encryption downgrade. Every LAN link still receives its own authenticated VeilLink session keys. LAN remains an upgrade path for an already trusted identity; this layer does not change first-trust policy, identity verification, replay protection, database encryption, or Wire Protocol framing.

## Compatibility
- iOS 15 remains the floor.
- iPhone 7 keeps a conservative TCP in-flight queue; the four-chunk protocol window is bounded and does not require whole-file buffering beyond the existing attachment cache.
- LAN unavailable/isolated networks still retain BLE and Internet Relay paths.

## Validation performed locally
- Python apply scripts compile.
- New XCTest source parses with swiftc.
- Remote baseline anchor audit against `r12-cumulative-validation @ 14955c91...` passed for LANTransport, SessionCoordinator and NearbyView.
- Local policy simulation confirms 64 chunks require 16 checkpoint windows instead of 64 under the LAN burst policy.
- No Info.plist permission gap: local-network usage description, Bonjour services, and `_veillink._tcp` are present in the validated repository base.

## Still required
- Xcode/iOS SDK typecheck.
- Simulator/XCTest.
- Two-device Bonjour discovery and reconnect test.
- iPhone 7 ↔ iPhone 13 real transfer.
- Measure MiB/s with BLE-only and LAN-active paths.
- Router/hotspot client-isolation regression.
- unsigned iphoneos Release IPA.
