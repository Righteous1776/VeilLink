#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_CURRENT_RELEASE_FIRST_RUN_V1.py <repo-root>')
root = Path(sys.argv[1]).resolve()
here = Path(__file__).resolve().parent

for script in ['APPLY_LEGAL_CONSENT_GATE_V1.py', 'APPLY_RELEASE_ACTIVATION_ONBOARDING_V1.py']:
    completed = subprocess.run([sys.executable, str(here / script), str(root)], check=False)
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)

print('APPLY_CURRENT_RELEASE_FIRST_RUN_V1: PASS')
