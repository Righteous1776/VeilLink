#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_CURRENT_APPLE_SOFT_V1.py <repo-root>')
root = Path(sys.argv[1]).resolve()
here = Path(__file__).resolve().parent

for script in [
    'APPLY_CURRENT_RELEASE_FIRST_RUN_V1.py',
    'APPLY_APPLE_SOFT_LIQUID_GLASS_V1.py',
]:
    subprocess.run([sys.executable, str(here / script), str(root)], check=True)

print('APPLY_CURRENT_APPLE_SOFT_V1: PASS')
