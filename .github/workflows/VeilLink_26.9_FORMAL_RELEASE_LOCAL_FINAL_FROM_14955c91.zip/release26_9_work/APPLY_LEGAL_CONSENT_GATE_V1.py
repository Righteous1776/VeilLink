#!/usr/bin/env python3
from pathlib import Path
import sys, shutil


if len(sys.argv) != 2:
    raise SystemExit("usage: APPLY_LEGAL_CONSENT_GATE_V1.py <repo-root>")
root = Path(sys.argv[1]).resolve()
payload = Path(__file__).resolve().parent

creates = {
    "VeilLink/Legal/VeilLegalConsentController.swift": "VeilLink/Legal/VeilLegalConsentController.swift",
    "VeilLink/UI/LegalConsentGateView.swift": "VeilLink/UI/LegalConsentGateView.swift",
    "VeilLinkTests/LegalConsentTests.swift": "VeilLinkTests/LegalConsentTests.swift",
    "docs/LEGAL_CONSENT_GATE_V1.md": "docs/LEGAL_CONSENT_GATE_V1.md",
}
for dst_rel, src_rel in creates.items():
    dst = root / dst_rel
    if dst.exists():
        raise SystemExit(f"REFUSE: destination already exists: {dst_rel}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(payload / src_rel, dst)

# VeilLinkApp: gate before AppModel construction and bridge legal state to SwiftUI.
p = root / "VeilLink/App/VeilLinkApp.swift"
s = p.read_text()
s = s.replace("import SwiftUI\nimport UIKit\n", "import Combine\nimport SwiftUI\nimport UIKit\n", 1)
old = '''            Group {
                if let model = bootstrap.model {
                    RootContainer(model: model)
'''
new = '''            Group {
                if !bootstrap.legal.isSatisfied {
                    LegalConsentGateView(controller: bootstrap.legal) {
                        bootstrap.activateAfterLegalAcceptance()
                    }
                } else if let model = bootstrap.model {
                    RootContainer(model: model)
'''
if s.count(old) != 1: raise SystemExit("VeilLinkApp gate anchor mismatch")
s = s.replace(old, new, 1)
old = '''@MainActor
private final class AppBootstrap: ObservableObject {
    let model: AppModel?
    let errorMessage: String

    init() {
        let diagnostics = RuntimeDiagnosticsBridge.shared
        diagnostics.recordStartupBegin()
        do {
            model = try AppModel()
            errorMessage = ""
            diagnostics.recordStartupSuccess()
        } catch {
            model = nil
            errorMessage = error.localizedDescription
            diagnostics.recordStartupFailure(error)
        }
    }
}
'''
new = '''@MainActor
private final class AppBootstrap: ObservableObject {
    @Published private(set) var model: AppModel?
    @Published private(set) var errorMessage = ""
    let legal: VeilLegalConsentController

    private let keychain: KeychainStore
    private var legalCancellable: AnyCancellable?

    init() {
        keychain = KeychainStore()
        legal = VeilLegalConsentController(keychain: keychain)
        legalCancellable = legal.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }
        if legal.isSatisfied { initializeModel() }
    }

    func activateAfterLegalAcceptance() {
        guard legal.isSatisfied else { return }
        if model == nil {
            initializeModel()
        } else {
            model?.activateAfterLegalAcceptance()
        }
    }

    private func initializeModel() {
        guard legal.isSatisfied, model == nil else { return }
        let diagnostics = RuntimeDiagnosticsBridge.shared
        diagnostics.recordStartupBegin()
        do {
            model = try AppModel(keychain: keychain, legalConsent: legal)
            errorMessage = ""
            diagnostics.recordStartupSuccess()
        } catch {
            model = nil
            errorMessage = error.localizedDescription
            diagnostics.recordStartupFailure(error)
        }
    }
}
'''
if s.count(old) != 1: raise SystemExit("AppBootstrap anchor mismatch")
s = s.replace(old, new, 1)
# RootContainer must also react immediately if consent is withdrawn from Settings.
old = '''    @ObservedObject var appLock: AppLockController
    @ObservedObject var stressTest: DeviceStressTestController
'''
new = '''    @ObservedObject var appLock: AppLockController
    @ObservedObject var legalConsent: VeilLegalConsentController
    @ObservedObject var stressTest: DeviceStressTestController
'''
if s.count(old) != 1: raise SystemExit("Root legal property anchor mismatch")
s = s.replace(old, new, 1)
old = '''        appLock = model.appLock
        stressTest = DeviceStressTestController.shared
'''
new = '''        appLock = model.appLock
        legalConsent = model.legalConsent
        stressTest = DeviceStressTestController.shared
'''
if s.count(old) != 1: raise SystemExit("Root legal init anchor mismatch")
s = s.replace(old, new, 1)
old = '''            VeilAmbientBackground()
            if identity.activeIdentity == nil {
'''
new = '''            VeilAmbientBackground()
            if !legalConsent.isSatisfied {
                LegalConsentGateView(controller: legalConsent) {
                    model.activateAfterLegalAcceptance()
                }
                .transition(.opacity)
            } else if identity.activeIdentity == nil {
'''
if s.count(old) != 1: raise SystemExit("Root legal UI anchor mismatch")
s = s.replace(old, new, 1)
p.write_text(s)

# AppModel: retain same controller, stop all transports when gated, and refuse start without current acceptance.
p = root / "VeilLink/App/AppModel.swift"
s = p.read_text()
old = '''    let keychain: KeychainStore
    let database: DatabaseStore
'''
new = '''    let keychain: KeychainStore
    let legalConsent: VeilLegalConsentController
    let database: DatabaseStore
'''
if s.count(old) != 1: raise SystemExit("AppModel legal property anchor mismatch")
s = s.replace(old, new, 1)
old = '''    init() throws {
        autoSaveReceivedImages = UserDefaults.standard.bool(forKey: Self.autoSaveReceivedImagesKey)
        let keychain = KeychainStore()
        self.keychain = keychain
        database = try DatabaseStore(keychain: keychain)
'''
new = '''    init(keychain: KeychainStore = KeychainStore(), legalConsent: VeilLegalConsentController? = nil) throws {
        autoSaveReceivedImages = UserDefaults.standard.bool(forKey: Self.autoSaveReceivedImagesKey)
        self.keychain = keychain
        self.legalConsent = legalConsent ?? VeilLegalConsentController(keychain: keychain)
        database = try DatabaseStore(keychain: keychain)
'''
if s.count(old) != 1: raise SystemExit("AppModel init anchor mismatch")
s = s.replace(old, new, 1)
old = '''    func handleForegroundTransition() {
        computeGovernor.setForegroundActive(true)
'''
new = '''    func handleForegroundTransition() {
        guard legalConsent.isSatisfied else { return }
        computeGovernor.setForegroundActive(true)
'''
if s.count(old) != 1: raise SystemExit("foreground guard anchor mismatch")
s = s.replace(old, new, 1)
old = '''    func start() {
        guard identity.activeIdentity != nil else { return }
'''
new = '''    func start() {
        guard legalConsent.isSatisfied, identity.activeIdentity != nil else { return }
'''
if s.count(old) != 1: raise SystemExit("start guard anchor mismatch")
s = s.replace(old, new, 1)
anchor = '''    func createInitialProfile(name: String, password: String, pin: String) -> Bool {
'''
insert = '''    func activateAfterLegalAcceptance() {
        guard legalConsent.isSatisfied else { return }
        handleForegroundTransition()
        start()
    }

    func sealForLegalWithdrawal() {
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: "已撤回当前版本使用授权")
        remotePairing.resetForIdentityChange()
        sessions.clearTransientCaches()
        database.clearTransientCaches()
        ImagePreviewCache.shared.removeAll()
        a9PeriodicTask?.cancel()
        a9PeriodicTask = nil
        computeGovernor.setForegroundActive(false)
        agent.handleBackground()
        appLock.lock()
        ownerMode.lock()
    }

'''
if s.count(anchor) != 1: raise SystemExit("legal lifecycle insert anchor mismatch")
s = s.replace(anchor, insert + anchor, 1)
p.write_text(s)

# Settings: surface acceptance evidence + controlled withdrawal.
p = root / "VeilLink/UI/SettingsView.swift"
s = p.read_text()
old = '''    @ObservedObject var internetRelay: InternetRelayTransport
    @State private var versionTapCount = 0
'''
new = '''    @ObservedObject var internetRelay: InternetRelayTransport
    @ObservedObject var legalConsent: VeilLegalConsentController
    @State private var versionTapCount = 0
'''
if s.count(old) != 1: raise SystemExit("Settings legal property anchor mismatch")
s = s.replace(old, new, 1)
old = '''        internetRelay = model.internetRelay
    }
'''
new = '''        internetRelay = model.internetRelay
        legalConsent = model.legalConsent
    }
'''
if s.count(old) != 1: raise SystemExit("Settings legal init anchor mismatch")
s = s.replace(old, new, 1)
old = '''                securityCard.veilStaggeredEntrance(index: 2)
                storageCard.veilStaggeredEntrance(index: 3)
                mediaCard.veilStaggeredEntrance(index: 4)
'''
new = '''                securityCard.veilStaggeredEntrance(index: 2)
                legalCard.veilStaggeredEntrance(index: 3)
                storageCard.veilStaggeredEntrance(index: 4)
                mediaCard.veilStaggeredEntrance(index: 5)
'''
if s.count(old) != 1: raise SystemExit("Settings legal card list anchor mismatch")
s = s.replace(old, new, 1)
# keep later indexes stable; visual order matters more than exact stagger uniqueness.
anchor = '''    private var storageCard: some View {
'''
legal_card = '''    private var legalCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("协议与授权", systemImage: "signature")
                .font(.headline)
                .foregroundColor(VeilTheme.goldBright)
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(legalConsent.isSatisfied ? "当前版本已签署" : "需要重新签署")
                        .fontWeight(.semibold)
                    Text("\\(legalConsent.currentReleaseID) · \\(VeilLegalConsentController.documentVersion)")
                        .font(.system(size: 9.5, weight: .medium, design: .monospaced))
                        .foregroundColor(VeilTheme.secondaryText)
                }
                Spacer()
                Image(systemName: legalConsent.isSatisfied ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                    .foregroundColor(legalConsent.isSatisfied ? VeilTheme.success : VeilTheme.gold)
            }
            NavigationLink(destination: LegalAgreementReviewView(model: model)) {
                HStack {
                    Text("查看协议、签署凭据与撤回授权")
                    Spacer()
                    Image(systemName: "chevron.right")
                }
            }
            .buttonStyle(VeilPressStyle())
            Text("签署记录绑定 App 版本、Build 与协议全文 SHA-256；任一变化都会要求重新确认。系统权限仍以 iOS 设置为准。")
                .font(.caption2)
                .foregroundColor(VeilTheme.tertiaryText)
        }
        .veilCard()
    }

'''
if s.count(anchor) != 1: raise SystemExit("Settings legal function anchor mismatch")
s = s.replace(anchor, legal_card + anchor, 1)
p.write_text(s)

print("APPLY_LEGAL_CONSENT_GATE_V1: PASS")
