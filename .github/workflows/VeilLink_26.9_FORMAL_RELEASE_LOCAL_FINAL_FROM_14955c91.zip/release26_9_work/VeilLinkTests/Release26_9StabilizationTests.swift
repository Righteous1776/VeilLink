import XCTest
@testable import VeilLink

final class Release26_9StabilizationTests: XCTestCase {
    func testLANRemainsPreferredOverBLEAndRelay() {
        XCTAssertGreaterThan(VeilTransportRoutePolicy.rank(.lan), VeilTransportRoutePolicy.rank(.ble))
        XCTAssertGreaterThan(VeilTransportRoutePolicy.rank(.ble), VeilTransportRoutePolicy.rank(.internet))
    }

    func testLANPipelineRemainsBoundedForLegacyDevices() {
        XCTAssertEqual(LANDataPlanePolicy.attachmentBurstWindow, 4)
        XCTAssertGreaterThan(LANDataPlanePolicy.reconnectDelay(attempt: 4), 0)
    }
}
