#!/usr/bin/env python3
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_RELEASE_26_9_STABILIZATION_V1.py <repo-root>')
root = Path(sys.argv[1]).resolve()


def replace_once(path: Path, old: str, new: str, label: str):
    s = path.read_text(encoding='utf-8')
    count = s.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected anchor exactly once, got {count}')
    path.write_text(s.replace(old, new, 1), encoding='utf-8')


def require_absent(path: Path, needle: str, label: str):
    if path.exists() and needle in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{label}: stale token still present: {needle}')

# -----------------------------------------------------------------------------
# 1) AppModel lifecycle consolidation.
#    Identity changes, backup restore and legal sealing previously duplicated
#    BLE/LAN/Relay stop/start/reset sequences. One authoritative lifecycle path
#    reduces drift and makes future transport additions harder to forget.
# -----------------------------------------------------------------------------
p = root / 'VeilLink/App/AppModel.swift'

old = '''    func start() {
        guard legalConsent.isSatisfied, identity.activeIdentity != nil else { return }
        _ = try? database.cleanupStaleInboundAttachments()
        bluetooth.start()
        lanTurbo.start()
        internetRelay.start(peerIdentityIDs: conversations.map(\\.peerIdentityID))
    }
'''
new = '''    private struct TransportResumePlan {
        let bluetoothWasRunning: Bool
        let lanWasRunning: Bool
    }

    private var knownPeerIdentityIDs: [String] {
        Array(Set(conversations.map(\\.peerIdentityID))).sorted()
    }

    @discardableResult
    private func suspendCommunicationStack(reason: String, resetRemotePairing: Bool = true) -> TransportResumePlan {
        let plan = TransportResumePlan(
            bluetoothWasRunning: bluetooth.isRunning,
            lanWasRunning: lanTurbo.isRunning
        )
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: reason)
        if resetRemotePairing { remotePairing.resetForIdentityChange() }
        return plan
    }

    private func resumeCommunicationStack(_ plan: TransportResumePlan? = nil, forcePrimaryTransports: Bool = false) {
        guard legalConsent.isSatisfied, identity.activeIdentity != nil else { return }
        if forcePrimaryTransports || plan?.bluetoothWasRunning == true { bluetooth.start() }
        if forcePrimaryTransports || plan?.lanWasRunning == true { lanTurbo.start() }
        internetRelay.start(peerIdentityIDs: knownPeerIdentityIDs)
    }

    private func resetIdentityScopedRuntimeState() {
        sessions.resetForIdentityChange()
        gameIntelligence.clear()
        selectedConversation = nil
        activeConversationID = nil
        reloadConversations()
    }

    func start() {
        guard legalConsent.isSatisfied, identity.activeIdentity != nil else { return }
        _ = try? database.cleanupStaleInboundAttachments()
        resumeCommunicationStack(forcePrimaryTransports: true)
    }
'''
replace_once(p, old, new, 'AppModel lifecycle hub')

old = '''    func sealForLegalWithdrawal() {
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: "已撤回当前版本使用授权")
        remotePairing.resetForIdentityChange()
        sessions.clearTransientCaches()
'''
new = '''    func sealForLegalWithdrawal() {
        _ = suspendCommunicationStack(reason: "已撤回当前版本使用授权")
        sessions.clearTransientCaches()
'''
replace_once(p, old, new, 'legal withdrawal lifecycle consolidation')

old = '''    func createAdditionalProfile(name: String, password: String) -> Bool {
        let wasRunning = bluetooth.isRunning
        let wasLANRunning = lanTurbo.isRunning
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: "身份切换中")
        remotePairing.resetForIdentityChange()
        do {
            let profile = try identity.createProfile(displayName: name, password: password)
            try database.upsertProfile(profile)
            sessions.resetForIdentityChange()
            gameIntelligence.clear()
            selectedConversation = nil
            activeConversationID = nil
            reloadConversations()
            if wasRunning { bluetooth.start() }
            if wasLANRunning { lanTurbo.start() }
            internetRelay.start(peerIdentityIDs: conversations.map(\\.peerIdentityID))
            return true
        } catch {
            if wasRunning { bluetooth.start() }
            if wasLANRunning { lanTurbo.start() }
            internetRelay.start(peerIdentityIDs: conversations.map(\\.peerIdentityID))
            alertMessage = error.localizedDescription
            return false
        }
    }
'''
new = '''    func createAdditionalProfile(name: String, password: String) -> Bool {
        let resumePlan = suspendCommunicationStack(reason: "身份切换中")
        do {
            let profile = try identity.createProfile(displayName: name, password: password)
            try database.upsertProfile(profile)
            resetIdentityScopedRuntimeState()
            resumeCommunicationStack(resumePlan)
            return true
        } catch {
            resumeCommunicationStack(resumePlan)
            alertMessage = error.localizedDescription
            return false
        }
    }
'''
replace_once(p, old, new, 'additional profile lifecycle consolidation')

old = '''    func switchIdentity(to id: String, password: String) -> Bool {
        guard identity.activeIdentity?.id != id else { return true }
        let wasRunning = bluetooth.isRunning
        let wasLANRunning = lanTurbo.isRunning
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: "身份切换中")
        remotePairing.resetForIdentityChange()
        guard identity.switchProfile(to: id, password: password) else {
            if wasRunning { bluetooth.start() }
            if wasLANRunning { lanTurbo.start() }
            internetRelay.start(peerIdentityIDs: conversations.map(\\.peerIdentityID))
            alertMessage = "身份密码不正确。"
            return false
        }
        if let active = identity.activeIdentity { try? database.upsertProfile(active) }
        sessions.resetForIdentityChange()
        gameIntelligence.clear()
        selectedConversation = nil
        activeConversationID = nil
        reloadConversations()
        if wasRunning { bluetooth.start() }
        if wasLANRunning { lanTurbo.start() }
        internetRelay.start(peerIdentityIDs: conversations.map(\\.peerIdentityID))
        return true
    }
'''
new = '''    func switchIdentity(to id: String, password: String) -> Bool {
        guard identity.activeIdentity?.id != id else { return true }
        let resumePlan = suspendCommunicationStack(reason: "身份切换中")
        guard identity.switchProfile(to: id, password: password) else {
            resumeCommunicationStack(resumePlan)
            alertMessage = "身份密码不正确。"
            return false
        }
        if let active = identity.activeIdentity { try? database.upsertProfile(active) }
        resetIdentityScopedRuntimeState()
        resumeCommunicationStack(resumePlan)
        return true
    }
'''
replace_once(p, old, new, 'identity switch lifecycle consolidation')

old = '''    func restoreBackup(url: URL, password: String) {
        let accessed = url.startAccessingSecurityScopedResource()
        let wasRunning = bluetooth.isRunning
        bluetooth.stop()
        lanTurbo.stop()
        internetRelay.stop(reason: "正在恢复备份")
        remotePairing.resetForIdentityChange()
        defer {
            if accessed { url.stopAccessingSecurityScopedResource() }
            if wasRunning || identity.activeIdentity != nil { start() }
        }
        do {
            try backups.restoreBackup(from: url, password: password)
            sessions.resetForIdentityChange()
            gameIntelligence.clear()
            selectedConversation = nil
            activeConversationID = nil
            reloadConversations()
            alertMessage = "备份已恢复。"
        } catch {
            sessions.resetForIdentityChange()
            gameIntelligence.clear()
            alertMessage = error.localizedDescription
        }
    }
'''
new = '''    func restoreBackup(url: URL, password: String) {
        let accessed = url.startAccessingSecurityScopedResource()
        _ = suspendCommunicationStack(reason: "正在恢复备份")
        defer {
            if accessed { url.stopAccessingSecurityScopedResource() }
            if identity.activeIdentity != nil { start() }
        }
        do {
            try backups.restoreBackup(from: url, password: password)
            resetIdentityScopedRuntimeState()
            alertMessage = "备份已恢复。"
        } catch {
            sessions.resetForIdentityChange()
            gameIntelligence.clear()
            alertMessage = error.localizedDescription
        }
    }
'''
replace_once(p, old, new, 'backup restore lifecycle consolidation')

# -----------------------------------------------------------------------------
# 2) Release identity: project.yml becomes the build-number source of truth.
#    App and Widget Info.plists consume Xcode build settings instead of carrying
#    independent literals that can drift.
# -----------------------------------------------------------------------------
p = root / 'project.yml'
old = '''  base:
    SWIFT_VERSION: 5.9
    SWIFT_STRICT_CONCURRENCY: complete
'''
new = '''  base:
    SWIFT_VERSION: 5.9
    MARKETING_VERSION: "26.9"
    CURRENT_PROJECT_VERSION: "53"
    SWIFT_STRICT_CONCURRENCY: complete
'''
replace_once(p, old, new, 'release identity in project.yml')

p = root / 'VeilLink/Resources/Info.plist'
replace_once(
    p,
    '''\t<key>CFBundleShortVersionString</key>\n\t<string>0.10.10</string>\n\t<key>CFBundleVersion</key>\n\t<string>52</string>''',
    '''\t<key>CFBundleShortVersionString</key>\n\t<string>$(MARKETING_VERSION)</string>\n\t<key>CFBundleVersion</key>\n\t<string>$(CURRENT_PROJECT_VERSION)</string>''',
    'App release placeholders'
)

# Widget plist uses spaces in the validated baseline.
p = root / 'VeilBackgroundWidget/Info.plist'
old = '''    <key>CFBundleShortVersionString</key>\n    <string>0.10.10</string>\n    <key>CFBundleVersion</key>\n    <string>52</string>'''
new = '''    <key>CFBundleShortVersionString</key>\n    <string>$(MARKETING_VERSION)</string>\n    <key>CFBundleVersion</key>\n    <string>$(CURRENT_PROJECT_VERSION)</string>'''
replace_once(p, old, new, 'Widget release placeholders')

# -----------------------------------------------------------------------------
# 3) Preflight and release verifier consume project.yml instead of stale literals.
# -----------------------------------------------------------------------------
p = root / 'scripts/ci-standard-preflight.py'
s = p.read_text(encoding='utf-8')
old = '''def check_plist():
    info = RES / "Info.plist"
    with info.open("rb") as f:
        plist = plistlib.load(f)
    if plist.get("CFBundleShortVersionString") != "0.10.10":
        fail("unexpected CFBundleShortVersionString")
    if plist.get("CFBundleVersion") != "52":
        fail("unexpected CFBundleVersion")
    modes = set(plist.get("UIBackgroundModes", []))
'''
new = '''def check_plist():
    info = RES / "Info.plist"
    with info.open("rb") as f:
        plist = plistlib.load(f)
    if plist.get("CFBundleShortVersionString") != "$(MARKETING_VERSION)":
        fail("app Info.plist must inherit MARKETING_VERSION from project.yml")
    if plist.get("CFBundleVersion") != "$(CURRENT_PROJECT_VERSION)":
        fail("app Info.plist must inherit CURRENT_PROJECT_VERSION from project.yml")
    widget_info = ROOT / "VeilBackgroundWidget" / "Info.plist"
    with widget_info.open("rb") as f:
        widget = plistlib.load(f)
    if widget.get("CFBundleShortVersionString") != "$(MARKETING_VERSION)" or widget.get("CFBundleVersion") != "$(CURRENT_PROJECT_VERSION)":
        fail("widget release identity must inherit the app build settings")
    project = (ROOT / "project.yml").read_text(encoding="utf-8")
    if 'MARKETING_VERSION: "26.9"' not in project or 'CURRENT_PROJECT_VERSION: "53"' not in project:
        fail("VeilLink 26.9 / Build 53 release identity missing from project.yml")
    modes = set(plist.get("UIBackgroundModes", []))
'''
if s.count(old) != 1:
    raise SystemExit(f'ci-standard-preflight release anchor mismatch: {s.count(old)}')
p.write_text(s.replace(old, new, 1), encoding='utf-8')

# The R10/R12 contract verifiers also carried the former release identity.
# Preserve every feature/protocol assertion while moving only the plist gate to
# the formal build-setting placeholders and project.yml source of truth.
for rel in [
    'scripts/verify-runtime-maintenance-r12.py',
    'scripts/verify-voice-ptt-r10.py',
]:
    p = root / rel
    s = p.read_text(encoding='utf-8')
    old = "for key,value in [('CFBundleShortVersionString','0.10.10'),('CFBundleVersion','52')]:\n"
    new = "for key,value in [('CFBundleShortVersionString','$(MARKETING_VERSION)'),('CFBundleVersion','$(CURRENT_PROJECT_VERSION)')]:\n"
    if s.count(old) != 1:
        raise SystemExit(f'{rel}: legacy plist identity anchor mismatch {s.count(old)}')
    s = s.replace(old, new, 1)
    microphone_anchor = "if 'NSMicrophoneUsageDescription' not in info:"
    project_gate = '''project=(ROOT/'project.yml').read_text(encoding='utf-8')
if 'MARKETING_VERSION: "26.9"' not in project or 'CURRENT_PROJECT_VERSION: "53"' not in project:
    raise SystemExit('FAIL VeilLink 26.9 / Build 53 project identity')
'''
    if s.count(microphone_anchor) != 1:
        raise SystemExit(f'{rel}: microphone gate anchor mismatch {s.count(microphone_anchor)}')
    s = s.replace(microphone_anchor, project_gate + microphone_anchor, 1)
    p.write_text(s, encoding='utf-8')

p = root / 'scripts/verify-maintenance-r8.py'
s = p.read_text(encoding='utf-8')
old = """if not re.search(r'<key>CFBundleShortVersionString</key>\\s*<string>0\\.10\\.10</string>',info): fail('version != 0.10.10')
if not re.search(r'<key>CFBundleVersion</key>\\s*<string>52</string>',info): fail('build != 52')
"""
new = """if not re.search(r'<key>CFBundleShortVersionString</key>\\s*<string>\\$\\(MARKETING_VERSION\\)</string>',info): fail('version must inherit MARKETING_VERSION')
if not re.search(r'<key>CFBundleVersion</key>\\s*<string>\\$\\(CURRENT_PROJECT_VERSION\\)</string>',info): fail('build must inherit CURRENT_PROJECT_VERSION')
project=read('project.yml')
if 'MARKETING_VERSION: "26.9"' not in project or 'CURRENT_PROJECT_VERSION: "53"' not in project: fail('formal release identity missing')
"""
if s.count(old) != 1:
    raise SystemExit(f'verify-maintenance-r8 identity anchor mismatch: {s.count(old)}')
p.write_text(s.replace(old, new, 1), encoding='utf-8')

p = root / 'scripts/verify-ui-theme-r9.py'
s = p.read_text(encoding='utf-8')
old = """if '<string>0.10.10</string>' not in info or '<string>52</string>' not in info:
    raise SystemExit('FAIL version')
"""
new = """if '<string>$(MARKETING_VERSION)</string>' not in info or '<string>$(CURRENT_PROJECT_VERSION)</string>' not in info:
    raise SystemExit('FAIL release identity placeholders')
project = (root / 'project.yml').read_text(encoding='utf-8')
if 'MARKETING_VERSION: "26.9"' not in project or 'CURRENT_PROJECT_VERSION: "53"' not in project:
    raise SystemExit('FAIL formal release identity')
"""
if s.count(old) != 1:
    raise SystemExit(f'verify-ui-theme-r9 identity anchor mismatch: {s.count(old)}')
p.write_text(s.replace(old, new, 1), encoding='utf-8')

p = root / 'scripts/verify-core-release.py'
s = p.read_text(encoding='utf-8')
s = s.replace('import os\n', 'import os\nimport re\n', 1)
old = '''def verify_app(app):
'''
new = '''def expected_release_identity(project_path):
    text = Path(project_path).read_text(encoding="utf-8")
    version_match = re.search(r'^\\s*MARKETING_VERSION:\\s*["\\\']?([^"\\\'\\s#]+)', text, re.MULTILINE)
    build_match = re.search(r'^\\s*CURRENT_PROJECT_VERSION:\\s*["\\\']?([^"\\\'\\s#]+)', text, re.MULTILINE)
    if not version_match or not build_match:
        fail("project.yml release identity is missing")
    return version_match.group(1), build_match.group(1)


def verify_app(app, expected_version, expected_build):
'''
if s.count(old) != 1:
    raise SystemExit(f'verifier function anchor mismatch: {s.count(old)}')
s = s.replace(old, new, 1)
s = s.replace('''    if info.get("CFBundleShortVersionString") != "0.10.10":\n        fail("expected version 0.10.10")\n    if str(info.get("CFBundleVersion")) != "52":\n        fail("expected build 52")\n''', '''    actual_version = str(info.get("CFBundleShortVersionString", ""))\n    actual_build = str(info.get("CFBundleVersion", ""))\n    if actual_version != expected_version:\n        fail(f"expected version {expected_version}, got {actual_version}")\n    if actual_build != expected_build:\n        fail(f"expected build {expected_build}, got {actual_build}")\n''', 1)
s = s.replace('''        "version": "0.10.10",\n        "build": "52",\n''', '''        "version": actual_version,\n        "build": actual_build,\n''', 1)
s = s.replace('''    parser.add_argument("--sums", default="CORE_RELEASE_SHA256SUMS.txt")\n''', '''    parser.add_argument("--sums", default="CORE_RELEASE_SHA256SUMS.txt")\n    parser.add_argument("--project", default="project.yml")\n''', 1)
s = s.replace('''    app_report = verify_app(app)\n''', '''    expected_version, expected_build = expected_release_identity(args.project)\n    app_report = verify_app(app, expected_version, expected_build)\n''', 1)
p.write_text(s, encoding='utf-8')

# -----------------------------------------------------------------------------
# 4) CI artifacts derive their version from the built Info.plist. No stale
#    v0.10.10-b52 artifact names may survive into the formal release.
# -----------------------------------------------------------------------------
for rel, suffix in [
    ('.github/workflows/core-release.yml', ''),
    ('.github/workflows/unsigned-ipa-direct.yml', '-direct'),
]:
    p = root / rel
    s = p.read_text(encoding='utf-8')
    build_anchor = '''      - name: Package unsigned Core IPA\n'''
    identity_step = '''      - name: Read built release identity\n        id: release_identity\n        run: |\n          INFO=\"DerivedData/Build/Products/Release-iphoneos/VeilLink.app/Info.plist\"\n          VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' \"$INFO\")\n          BUILD=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' \"$INFO\")\n          echo \"version=$VERSION\" >> \"$GITHUB_OUTPUT\"\n          echo \"build=$BUILD\" >> \"$GITHUB_OUTPUT\"\n          echo \"VeilLink $VERSION · Build $BUILD\" | tee ci-artifacts/release-identity.log\n\n'''
    if s.count(build_anchor) != 1:
        raise SystemExit(f'{rel}: package anchor mismatch {s.count(build_anchor)}')
    s = s.replace(build_anchor, identity_step + build_anchor, 1)
    stale = f'VeilLink-Core-unsigned-v0.10.10-b52{suffix}'
    dynamic = f'VeilLink-Core-unsigned-v${{{{ steps.release_identity.outputs.version }}}}-b${{{{ steps.release_identity.outputs.build }}}}{suffix}'
    if s.count(stale) != 1:
        raise SystemExit(f'{rel}: stale artifact name anchor mismatch {s.count(stale)}')
    s = s.replace(stale, dynamic, 1)
    p.write_text(s, encoding='utf-8')

p = root / '.github/workflows/dual-platform-release.yml'
s = p.read_text(encoding='utf-8')
old = '          name: VeilLink-Android-APK-v0.10.10-b52\n'
new = '          name: VeilLink-Android-APK-experimental-${{ github.sha }}\n'
if s.count(old) != 1:
    raise SystemExit(f'Android artifact name anchor mismatch: {s.count(old)}')
p.write_text(s.replace(old, new, 1), encoding='utf-8')

# -----------------------------------------------------------------------------
# 5) Release hygiene: the release-critical files must not retain the old carrier
#    version after the migration.
# -----------------------------------------------------------------------------
for rel in [
    'VeilLink/Resources/Info.plist',
    'VeilBackgroundWidget/Info.plist',
    '.github/workflows/core-release.yml',
    '.github/workflows/unsigned-ipa-direct.yml',
    '.github/workflows/dual-platform-release.yml',
    'scripts/verify-core-release.py',
    'scripts/ci-standard-preflight.py',
    'scripts/verify-runtime-maintenance-r12.py',
    'scripts/verify-voice-ptt-r10.py',
    'scripts/verify-maintenance-r8.py',
    'scripts/verify-ui-theme-r9.py',
]:
    path = root / rel
    require_absent(path, '0.10.10', rel)
    require_absent(path, 'b52', rel)

print('APPLY_RELEASE_26_9_STABILIZATION_V1: PASS')
