import SwiftUI

struct LegalConsentGateView: View {
    @ObservedObject var controller: VeilLegalConsentController
    let onAccepted: () -> Void

    @State private var selectedDocument = 0
    @State private var acknowledgment = ""
    @State private var confirmsPermissions = false
    @State private var confirmsRisk = false
    @State private var confirmsVersionRule = false
    @State private var errorText: String?

    private var canSign: Bool {
        confirmsPermissions &&
        confirmsRisk &&
        confirmsVersionRule &&
        acknowledgment.trimmingCharacters(in: .whitespacesAndNewlines) == VeilLegalConsentController.requiredAcknowledgment
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 14) {
                VStack(spacing: 7) {
                    VeilIdentityGlyph(seed: "veillink-legal-gate", size: 66, active: false)
                    Text("使用授权与协议签署")
                        .font(.system(.title2, design: .rounded).weight(.bold))
                    Text("\(controller.currentReleaseID) · 协议 \(VeilLegalConsentController.documentVersion)")
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundColor(VeilTheme.mutedGold)
                    Text(controller.needsSignatureReason)
                        .font(.caption)
                        .foregroundColor(VeilTheme.secondaryText)
                }
                .padding(.top, 10)

                Picker("协议", selection: $selectedDocument) {
                    Text("权限授权说明").tag(0)
                    Text("使用条款与责任边界").tag(1)
                }
                .pickerStyle(.segmented)

                ScrollView {
                    Text(selectedDocument == 0 ? VeilLegalDocuments.permissions : VeilLegalDocuments.terms)
                        .font(.system(size: 14, weight: .regular, design: .rounded))
                        .foregroundColor(VeilTheme.text)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                        .padding(15)
                }
                .background(VeilTheme.elevated.opacity(0.74))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(VeilTheme.hairline, lineWidth: 1))

                VStack(alignment: .leading, spacing: 10) {
                    confirmationToggle("我理解系统权限仍由 iOS 单独控制，本协议不能代替系统授权。", isOn: $confirmsPermissions)
                    confirmationToggle("我已阅读风险告知与责任边界，理解 VeilLink 不适用于紧急或生命安全通信。", isOn: $confirmsRisk)
                    confirmationToggle("我理解每次版本、Build 或协议正文变化后都需要重新签署。", isOn: $confirmsVersionRule)

                    TextField("输入：\(VeilLegalConsentController.requiredAcknowledgment)", text: $acknowledgment)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                        .padding(.horizontal, 12)
                        .frame(height: 46)
                        .background(Color.white.opacity(0.045))
                        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))

                    if let errorText {
                        Text(errorText)
                            .font(.caption)
                            .foregroundColor(.red)
                    }

                    Button {
                        guard canSign else {
                            errorText = "请完成三项确认，并准确输入签署确认语。"
                            return
                        }
                        if controller.accept(acknowledgment: acknowledgment) {
                            errorText = nil
                            onAccepted()
                        } else {
                            errorText = "签署记录未能安全保存，请重试。"
                        }
                    } label: {
                        HStack {
                            Image(systemName: "checkmark.shield.fill")
                            Text("签署并进入 VeilLink")
                            Spacer()
                            Text("SHA-256")
                                .font(.system(size: 9, weight: .bold, design: .monospaced))
                                .foregroundColor(VeilTheme.mutedGold)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(VeilTheme.gold)
                    .disabled(!canSign)

                    Text("不同意不会触发崩溃或自动删除数据；App 将保持锁定，且不会启动 BLE、LAN、Internet Relay 或 Mesh 等核心通信服务。")
                        .font(.caption2)
                        .foregroundColor(VeilTheme.tertiaryText)
                }
            }
            .padding(16)
            .background(VeilAmbientBackground())
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }

    private func confirmationToggle(_ title: String, isOn: Binding<Bool>) -> some View {
        Toggle(isOn: isOn) {
            Text(title)
                .font(.caption)
                .foregroundColor(VeilTheme.secondaryText)
        }
        .toggleStyle(SwitchToggleStyle(tint: VeilTheme.gold))
    }
}

struct LegalAgreementReviewView: View {
    @ObservedObject var model: AppModel
    @ObservedObject var controller: VeilLegalConsentController
    @State private var selectedDocument = 0
    @State private var confirmsWithdrawal = false
    @State private var copied = false

    init(model: AppModel) {
        self.model = model
        controller = model.legalConsent
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("当前签署")
                        .font(.headline)
                        .foregroundColor(VeilTheme.goldBright)
                    legalMetric("版本", controller.currentReleaseID)
                    legalMetric("协议", VeilLegalConsentController.documentVersion)
                    legalMetric("SHA-256", String(controller.currentDocumentSHA256.prefix(20)) + "…")
                    if let record = controller.currentRecord {
                        legalMetric("签署时间", record.acceptedAt.formatted(date: .abbreviated, time: .standard))
                        legalMetric("记录 ID", String(record.acceptanceID.prefix(18)) + "…")
                    }
                }
                .veilCard(emphasized: true)

                Picker("协议", selection: $selectedDocument) {
                    Text("权限授权说明").tag(0)
                    Text("使用条款与责任边界").tag(1)
                }
                .pickerStyle(.segmented)

                Text(selectedDocument == 0 ? VeilLegalDocuments.permissions : VeilLegalDocuments.terms)
                    .font(.system(size: 14, design: .rounded))
                    .foregroundColor(VeilTheme.text)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
                    .padding(15)
                    .background(VeilTheme.elevated.opacity(0.74))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                Button {
                    if let data = controller.evidenceJSON(), let text = String(data: data, encoding: .utf8) {
                        UIPasteboard.general.string = text
                        copied = true
                        model.haptics.resolved()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { copied = false }
                    }
                } label: {
                    Label(copied ? "已复制签署凭据" : "复制签署凭据 JSON", systemImage: copied ? "checkmark.circle.fill" : "doc.on.doc")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.bordered)
                .tint(VeilTheme.gold)

                VStack(alignment: .leading, spacing: 10) {
                    Toggle("我确认要撤回当前版本的使用授权并锁定 VeilLink", isOn: $confirmsWithdrawal)
                        .font(.caption)
                    Button(role: .destructive) {
                        model.sealForLegalWithdrawal()
                        controller.withdraw()
                    } label: {
                        Label("撤回授权并安全封存", systemImage: "lock.shield")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .disabled(!confirmsWithdrawal)
                    Text("安全封存会停止 BLE、LAN、Internet Relay、远程配对并清理临时会话/缓存；不会故意崩溃，也不会自动删除你的聊天数据库。")
                        .font(.caption2)
                        .foregroundColor(VeilTheme.tertiaryText)
                }
                .veilCard()
            }
            .padding(16)
        }
        .background(VeilAmbientBackground())
        .navigationTitle("协议与授权")
    }

    private func legalMetric(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundColor(VeilTheme.secondaryText)
            Spacer(minLength: 12)
            Text(value)
                .font(.system(.caption, design: .monospaced))
                .foregroundColor(VeilTheme.text)
                .multilineTextAlignment(.trailing)
                .textSelection(.enabled)
        }
    }
}
