#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_GLOBAL_LIGHT_DARK_MODE_V1.py <repo-root>')

root = Path(sys.argv[1]).resolve()
payload = Path(__file__).resolve().parent

# This layer must be applied after Apple Soft / Liquid Glass V1.
for required in [
    'VeilLink/Core/VeilAppleMaterialEngine.swift',
    'VeilLink/UI/VeilAppleSoftRootView.swift',
    'VeilLink/Onboarding/VeilFirstRunOnboardingController.swift',
    'VeilLink/Legal/VeilLegalConsentController.swift',
]:
    if not (root / required).exists():
        raise SystemExit(f'REFUSE: previous CURRENT layer missing: {required}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'REFUSE: {label} anchor count={count}')
    return text.replace(old, new, 1)

# Add tests + engineering notes only. All production changes patch the existing shared theme layer,
# so every screen inherits the new appearance mode rather than creating a second parallel UI tree.
creates = {
    'VeilLinkTests/GlobalAppearanceModeTests.swift': 'VeilLinkTests/GlobalAppearanceModeTests.swift',
    'docs/GLOBAL_LIGHT_DARK_MODE_V1.md': 'docs/GLOBAL_LIGHT_DARK_MODE_V1.md',
}
for dst_rel, src_rel in creates.items():
    dst = root / dst_rel
    if dst.exists():
        raise SystemExit(f'REFUSE: destination already exists: {dst_rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(payload / src_rel, dst)

# 1) One global source of truth for Auto / Light / Dark across every manually selectable skin.
p = root / 'VeilLink/Core/AppearanceTheme.swift'
s = p.read_text()
s = replace_once(s,
'''enum VeilAppearanceSelection: String, CaseIterable, Identifiable, Codable {
''',
'''enum VeilColorMode: String, CaseIterable, Identifiable, Codable {
    case automatic
    case light
    case dark

    var id: String { rawValue }

    var title: String {
        switch self {
        case .automatic: return "自动"
        case .light: return "浅色"
        case .dark: return "深色"
        }
    }

    var subtitle: String {
        switch self {
        case .automatic: return "跟随 iOS 外观"
        case .light: return "始终使用白天配色"
        case .dark: return "始终使用夜间配色"
        }
    }

    var systemImage: String {
        switch self {
        case .automatic: return "circle.lefthalf.filled"
        case .light: return "sun.max.fill"
        case .dark: return "moon.stars.fill"
        }
    }

    var preferredColorScheme: ColorScheme? {
        switch self {
        case .automatic: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    func resolvesDark(systemIsDark: Bool) -> Bool {
        switch self {
        case .automatic: return systemIsDark
        case .light: return false
        case .dark: return true
        }
    }
}

enum VeilAppearanceSelection: String, CaseIterable, Identifiable, Codable {
''', 'insert global color mode')

s = replace_once(s,
'''        case .instrumentAuto: return "仪器 · 自动"
''',
'''        case .instrumentAuto: return "拟物仪器"
''', 'instrument theme title')
s = replace_once(s,
'''        case .instrumentAuto: return "现代工业拟物；随系统浅色/深色自动切换。"
''',
'''        case .instrumentAuto: return "柔和仪器拟物；完整支持浅色、深色与跟随系统。"
''', 'instrument theme subtitle')

s = replace_once(s,
'''final class VeilAppearanceController: ObservableObject {
    static let shared = VeilAppearanceController()
    private enum Key { static let selection = "appearance.theme.selection.v1" }

    @Published var selection: VeilAppearanceSelection {
        didSet { UserDefaults.standard.set(selection.rawValue, forKey: Key.selection) }
    }
    @Published private(set) var systemIsDark = true

    private init() {
        selection = UserDefaults.standard.string(forKey: Key.selection)
            .flatMap(VeilAppearanceSelection.init(rawValue:)) ?? .veilOriginal
        systemIsDark = UITraitCollection.current.userInterfaceStyle == .dark
    }

    func update(colorScheme: ColorScheme) { systemIsDark = colorScheme == .dark }
    var isInstrument: Bool { selection == .instrumentAuto }
    var isAppleSoft: Bool { selection == .appleSoft }
    var appearanceLabel: String {
        switch selection {
        case .veilOriginal: return "VEIL ORIGINAL"
        case .appleSoft: return systemIsDark ? "APPLE SOFT · NIGHT" : "APPLE SOFT · DAY"
        case .instrumentAuto: return systemIsDark ? "INSTRUMENT · NIGHT" : "INSTRUMENT · DAY"
        }
    }

    var palette: VeilThemePalette {
        switch selection {
        case .veilOriginal: return Self.original
        case .appleSoft: return systemIsDark ? Self.appleSoftNight : Self.appleSoftDay
        case .instrumentAuto: return systemIsDark ? Self.instrumentNight : Self.instrumentDay
        }
    }
''',
'''final class VeilAppearanceController: ObservableObject {
    static let shared = VeilAppearanceController()
    private enum Key {
        static let selection = "appearance.theme.selection.v1"
        static let colorMode = "appearance.color.mode.v1"
    }

    @Published var selection: VeilAppearanceSelection {
        didSet { UserDefaults.standard.set(selection.rawValue, forKey: Key.selection) }
    }
    @Published var colorMode: VeilColorMode {
        didSet {
            UserDefaults.standard.set(colorMode.rawValue, forKey: Key.colorMode)
            synchronizeSystemAppearance()
        }
    }
    @Published private(set) var systemIsDark = true

    private init() {
        selection = UserDefaults.standard.string(forKey: Key.selection)
            .flatMap(VeilAppearanceSelection.init(rawValue:)) ?? .veilOriginal
        colorMode = UserDefaults.standard.string(forKey: Key.colorMode)
            .flatMap(VeilColorMode.init(rawValue:)) ?? .automatic
        systemIsDark = UITraitCollection.current.userInterfaceStyle == .dark
        synchronizeSystemAppearance()
    }

    /// Environment updates are authoritative only in Auto mode. A forced Light/Dark mode must not
    /// be overwritten by an intermediate UIKit trait while a scene or lock screen is transitioning.
    func update(colorScheme: ColorScheme) {
        guard colorMode == .automatic else { return }
        let next = colorScheme == .dark
        if systemIsDark != next { systemIsDark = next }
    }

    func synchronizeSystemAppearance() {
        guard colorMode == .automatic else { return }
        let style = UITraitCollection.current.userInterfaceStyle
        guard style != .unspecified else { return }
        let next = style == .dark
        if systemIsDark != next { systemIsDark = next }
    }

    func setColorMode(_ mode: VeilColorMode) {
        guard colorMode != mode else { return }
        colorMode = mode
    }

    var preferredColorScheme: ColorScheme? { colorMode.preferredColorScheme }
    var isDarkAppearance: Bool { colorMode.resolvesDark(systemIsDark: systemIsDark) }
    var isInstrument: Bool { selection == .instrumentAuto }
    var isAppleSoft: Bool { selection == .appleSoft }
    var appearanceLabel: String {
        let phase = isDarkAppearance ? "NIGHT" : "DAY"
        switch selection {
        case .veilOriginal: return "VEIL ORIGINAL · \\(phase)"
        case .appleSoft: return "APPLE SOFT · \\(phase)"
        case .instrumentAuto: return "INSTRUMENT · \\(phase)"
        }
    }

    var palette: VeilThemePalette {
        switch selection {
        case .veilOriginal: return isDarkAppearance ? Self.original : Self.originalDay
        case .appleSoft: return isDarkAppearance ? Self.appleSoftNight : Self.appleSoftDay
        case .instrumentAuto: return isDarkAppearance ? Self.instrumentNight : Self.instrumentDay
        }
    }
''', 'appearance controller single source')

# Add an official light palette for the original Veil skin so all three skins have both phases.
original_day = '''    static let originalDay = VeilThemePalette(
        background: Color(red: 0.958, green: 0.952, blue: 0.936),
        backgroundLift: Color(red: 0.988, green: 0.983, blue: 0.970),
        elevated: Color(red: 0.944, green: 0.936, blue: 0.918),
        panel: Color(red: 0.928, green: 0.918, blue: 0.895),
        panelSoft: Color(red: 0.975, green: 0.969, blue: 0.952),
        obsidian: Color(red: 0.902, green: 0.892, blue: 0.868),
        veil: Color(red: 0.932, green: 0.923, blue: 0.904),
        gold: Color(red: 0.72, green: 0.48, blue: 0.12),
        goldBright: Color(red: 0.88, green: 0.61, blue: 0.18),
        goldDeep: Color(red: 0.48, green: 0.29, blue: 0.065),
        mutedGold: Color(red: 0.45, green: 0.36, blue: 0.22),
        paleMetal: Color(red: 0.54, green: 0.51, blue: 0.45),
        text: Color.black.opacity(0.88),
        secondaryText: Color.black.opacity(0.57),
        tertiaryText: Color.black.opacity(0.34),
        hairline: Color.black.opacity(0.085),
        danger: Color(red: 0.80, green: 0.16, blue: 0.18),
        success: Color(red: 0.08, green: 0.56, blue: 0.30),
        metalTop: Color(red: 0.985, green: 0.980, blue: 0.966),
        metalBottom: Color(red: 0.900, green: 0.888, blue: 0.862),
        recess: Color.black.opacity(0.08),
        keycapTop: Color(red: 0.985, green: 0.980, blue: 0.966),
        keycapBottom: Color(red: 0.910, green: 0.900, blue: 0.878),
        indicator: Color(red: 0.82, green: 0.50, blue: 0.10)
    )

'''
s = replace_once(s, '    static let original = VeilThemePalette(\n', original_day + '    static let original = VeilThemePalette(\n', 'original light palette')

# Refine the official Instrument day palette around the accidental warm white/orange state the
# user liked. Night remains the existing dark/orange instrument palette.
replacements = {
'''        background: Color(red: 0.86, green: 0.86, blue: 0.84),''': '''        background: Color(red: 0.934, green: 0.931, blue: 0.910),''',
'''        backgroundLift: Color(red: 0.94, green: 0.94, blue: 0.92),''': '''        backgroundLift: Color(red: 0.977, green: 0.974, blue: 0.958),''',
'''        elevated: Color(red: 0.82, green: 0.82, blue: 0.80),''': '''        elevated: Color(red: 0.910, green: 0.908, blue: 0.890),''',
'''        panel: Color(red: 0.75, green: 0.75, blue: 0.73),''': '''        panel: Color(red: 0.882, green: 0.879, blue: 0.858),''',
'''        panelSoft: Color(red: 0.88, green: 0.88, blue: 0.85),''': '''        panelSoft: Color(red: 0.956, green: 0.953, blue: 0.936),''',
'''        veil: Color(red: 0.68, green: 0.68, blue: 0.66),''': '''        veil: Color(red: 0.846, green: 0.842, blue: 0.820),''',
'''        gold: Color(red: 0.96, green: 0.33, blue: 0.05),''': '''        gold: Color(red: 1.00, green: 0.38, blue: 0.10),''',
'''        goldBright: Color(red: 1.0, green: 0.44, blue: 0.10),''': '''        goldBright: Color(red: 1.0, green: 0.47, blue: 0.14),''',
'''        goldDeep: Color(red: 0.64, green: 0.16, blue: 0.02),''': '''        goldDeep: Color(red: 0.72, green: 0.20, blue: 0.03),''',
'''        hairline: Color.black.opacity(0.13),''': '''        hairline: Color.black.opacity(0.085),''',
'''        metalTop: Color(red: 0.95, green: 0.95, blue: 0.93),''': '''        metalTop: Color(red: 0.970, green: 0.968, blue: 0.952),''',
'''        metalBottom: Color(red: 0.63, green: 0.63, blue: 0.61),''': '''        metalBottom: Color(red: 0.862, green: 0.858, blue: 0.838),''',
'''        keycapTop: Color(red: 0.98, green: 0.98, blue: 0.96),''': '''        keycapTop: Color(red: 0.968, green: 0.966, blue: 0.950),''',
'''        keycapBottom: Color(red: 0.70, green: 0.70, blue: 0.68),''': '''        keycapBottom: Color(red: 0.884, green: 0.880, blue: 0.858),''',
}
for old, new in replacements.items():
    count = s.count(old)
    if count != 1:
        raise SystemExit(f'REFUSE: instrument day palette anchor {old!r} count={count}')
    s = s.replace(old, new, 1)
p.write_text(s)

# 2) Original-theme background must stop injecting black when the user explicitly selects Light.
p = root / 'VeilLink/Core/AppTheme.swift'
s = p.read_text()
old = 'colors: [VeilTheme.backgroundLift, VeilTheme.background, Color.black],'
count = s.count(old)
if count != 2:
    raise SystemExit(f'REFUSE: original background gradient anchor count={count}')
s = s.replace(old, 'colors: [VeilTheme.backgroundLift, VeilTheme.background, VeilAppearanceController.shared.isDarkAppearance ? Color.black : VeilTheme.background],')
p.write_text(s)

# 3) Instrument components must obey the explicit app mode, never read an independent system flag.
p = root / 'VeilLink/Core/SkeuomorphicComponents.swift'
s = p.read_text()
old = 'VeilAppearanceController.shared.systemIsDark'
count = s.count(old)
if count < 1:
    raise SystemExit('REFUSE: no instrument systemIsDark references found')
s = s.replace(old, 'VeilAppearanceController.shared.isDarkAppearance')
p.write_text(s)

# 4) App-level color scheme is now dynamic. This is the authoritative bridge for every screen,
# including onboarding/legal gates shown before AppModel exists.
p = root / 'VeilLink/App/VeilLinkApp.swift'
s = p.read_text()
s = replace_once(s,
'''    @StateObject private var bootstrap = AppBootstrap()
    @Environment(\\.scenePhase) private var scenePhase
''',
'''    @StateObject private var bootstrap = AppBootstrap()
    @StateObject private var appearance = VeilAppearanceController.shared
    @Environment(\\.scenePhase) private var scenePhase
''', 'app appearance observer')
s = replace_once(s,
'''            .preferredColorScheme(.dark)
''',
'''            .preferredColorScheme(appearance.preferredColorScheme)
            .onAppear {
                appearance.synchronizeSystemAppearance()
                VeilChrome.configure()
            }
            .onChange(of: appearance.colorMode) { _ in
                appearance.synchronizeSystemAppearance()
                VeilChrome.configure()
            }
            .onChange(of: appearance.selection) { _ in VeilChrome.configure() }
''', 'remove forced dark scheme')

# Make UIKit bars consume the same palette instead of hard-coding the old dark colors.
s = replace_once(s,
'''        let appleSoft = VeilAppearanceController.shared.isAppleSoft
        let navigation = UINavigationBarAppearance()
''',
'''        let appearance = VeilAppearanceController.shared
        let appleSoft = appearance.isAppleSoft
        let navigation = UINavigationBarAppearance()
''', 'chrome appearance source')
s = replace_once(s,
'''        } else {
            navigation.configureWithOpaqueBackground()
            navigation.backgroundColor = UIColor(red: 0.012, green: 0.013, blue: 0.017, alpha: 0.96)
            navigation.shadowColor = UIColor.white.withAlphaComponent(0.045)
            navigation.titleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]
            navigation.largeTitleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]
        }

        let navigationBar = UINavigationBar.appearance()
''',
'''        } else {
            navigation.configureWithOpaqueBackground()
            navigation.backgroundColor = UIColor(VeilTheme.background).withAlphaComponent(0.96)
            navigation.shadowColor = UIColor(VeilTheme.hairline)
            navigation.titleTextAttributes = [.foregroundColor: UIColor(VeilTheme.text)]
            navigation.largeTitleTextAttributes = [.foregroundColor: UIColor(VeilTheme.text)]
        }

        let navigationBar = UINavigationBar.appearance()
''', 'adaptive navigation chrome')
s = replace_once(s,
'''        navigationBar.tintColor = appleSoft ? .systemBlue : UIColor(red: 0.86, green: 0.64, blue: 0.24, alpha: 1)
''',
'''        navigationBar.tintColor = appleSoft ? .systemBlue : UIColor(VeilTheme.gold)
''', 'adaptive nav tint')
s = replace_once(s,
'''        } else {
            tab.configureWithOpaqueBackground()
            tab.backgroundColor = UIColor(red: 0.020, green: 0.021, blue: 0.026, alpha: 0.985)
            tab.shadowColor = UIColor.white.withAlphaComponent(0.05)
        }
        let selected = appleSoft ? UIColor.systemBlue : UIColor(red: 0.98, green: 0.82, blue: 0.46, alpha: 1)
        let normal = appleSoft ? UIColor.secondaryLabel : UIColor.white.withAlphaComponent(0.42)
''',
'''        } else {
            tab.configureWithOpaqueBackground()
            tab.backgroundColor = UIColor(VeilTheme.background).withAlphaComponent(0.985)
            tab.shadowColor = UIColor(VeilTheme.hairline)
        }
        let selected = appleSoft ? UIColor.systemBlue : UIColor(VeilTheme.goldBright)
        let normal = appleSoft ? UIColor.secondaryLabel : UIColor(VeilTheme.secondaryText)
''', 'adaptive tab chrome')
p.write_text(s)

# 5) AdaptiveRoot is still the system-trait synchronizer in Auto mode. Explicit modes are guarded
# by AppearanceController.update() and therefore cannot be overwritten by transient scene traits.
p = root / 'VeilLink/UI/AdaptiveRootView.swift'
s = p.read_text()
s = replace_once(s,
'''        .onChange(of: appearance.selection) { _ in VeilChrome.configure() }
''',
'''        .onChange(of: appearance.selection) { _ in VeilChrome.configure() }
        .onChange(of: appearance.colorMode) { _ in VeilChrome.configure() }
''', 'adaptive root color mode chrome')
p.write_text(s)

# 6) Lock screen explicitly observes the global appearance source. This prevents the reported
# stale-light / stale-dark state after background transitions or biometric sheets.
p = root / 'VeilLink/UI/LockScreenView.swift'
s = p.read_text()
s = replace_once(s,
'''    @ObservedObject var controller: AppLockController
    @ObservedObject var haptics: HapticEngine
    @State private var pin = ""
''',
'''    @ObservedObject var controller: AppLockController
    @ObservedObject var haptics: HapticEngine
    @ObservedObject private var appearance = VeilAppearanceController.shared
    @Environment(\\.colorScheme) private var colorScheme
    @State private var pin = ""
''', 'lock appearance state')
s = replace_once(s,
'''            .padding(24)
        }
    }
''',
'''            .padding(24)
        }
        .onAppear { appearance.update(colorScheme: colorScheme) }
        .onChange(of: colorScheme) { appearance.update(colorScheme: $0) }
    }
''', 'lock trait synchronization')
# Make numeric keys use the shared card primitive in all skins. This both improves contrast and
# removes duplicated shadow/clip work that was visible as occasional stalls on iPhone 7.
s = replace_once(s,
'''            Text(value)
                .font(.system(size: 27, weight: .regular, design: .rounded))
                .frame(width: 68, height: 68)
                .background(VeilTheme.elevated.opacity(0.78))
                .clipShape(VeilPanelShape(cut: 11, radius: 7))
                .overlay(
                    VeilPanelShape(cut: 11, radius: 7)
                        .stroke(VeilTheme.hairline, lineWidth: 1)
                )
                .overlay(alignment: .topLeading) {
                    Rectangle().fill(VeilTheme.gold.opacity(0.22)).frame(width: 13, height: 1).padding(.leading, 7)
                }
''',
'''            Text(value)
                .font(.system(size: 27, weight: .regular, design: .rounded))
                .foregroundColor(VeilTheme.text)
                .frame(width: 68, height: 68)
                .background(lockKeySurface)
''', 'lock key shared surface')
s = replace_once(s,
'''        .buttonStyle(VeilPressStyle())
    }
}
''',
'''        .buttonStyle(VeilPressStyle())
    }

    @ViewBuilder
    private var lockKeySurface: some View {
        if appearance.isAppleSoft {
            VeilAppleSoftSurface(cornerRadius: 22, emphasized: false)
        } else if appearance.isInstrument {
            VeilInstrumentPlate(shape: RoundedRectangle(cornerRadius: 18, style: .continuous), emphasized: false)
        } else {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(VeilTheme.elevated.opacity(0.90))
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(VeilTheme.hairline, lineWidth: 1)
                )
                .shadow(
                    color: Color.black.opacity(VeilRenderProfile.usesLegacyCompositorPath ? 0.08 : 0.14),
                    radius: VeilRenderProfile.usesLegacyCompositorPath ? 2 : 7,
                    x: 0,
                    y: VeilRenderProfile.usesLegacyCompositorPath ? 1 : 4
                )
        }
    }
}
''', 'lock key surface helper')
p.write_text(s)

# 7) Settings: make color mode a separate dimension from skin selection. Switches are intentionally
# non-animated; a theme change should feel immediate and should not animate every visible card.
p = root / 'VeilLink/UI/SettingsView.swift'
s = p.read_text()
s = replace_once(s,
'''            if appearance.selection != .veilOriginal {
                HStack(spacing: 7) {
''',
'''            Divider().background(VeilTheme.hairline)
            VStack(alignment: .leading, spacing: 9) {
                Text("显示模式")
                    .font(.caption.weight(.semibold))
                    .foregroundColor(VeilTheme.secondaryText)
                HStack(spacing: 8) {
                    ForEach(VeilColorMode.allCases) { mode in
                        Button {
                            var transaction = Transaction()
                            transaction.disablesAnimations = true
                            withTransaction(transaction) {
                                appearance.setColorMode(mode)
                            }
                            VeilChrome.configure()
                            haptics.selection()
                        } label: {
                            VStack(spacing: 5) {
                                Image(systemName: mode.systemImage)
                                    .font(.system(size: 16, weight: .semibold))
                                Text(mode.title)
                                    .font(.caption.weight(.semibold))
                            }
                            .foregroundColor(appearance.colorMode == mode ? VeilTheme.goldBright : VeilTheme.secondaryText)
                            .frame(maxWidth: .infinity)
                            .frame(height: 56)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(appearance.colorMode == mode ? VeilTheme.gold.opacity(0.11) : VeilTheme.elevated.opacity(0.55))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(appearance.colorMode == mode ? VeilTheme.gold.opacity(0.28) : VeilTheme.hairline, lineWidth: 0.8)
                            )
                        }
                        .buttonStyle(VeilPressStyle())
                    }
                }
                Text(appearance.colorMode.subtitle)
                    .font(.caption2)
                    .foregroundColor(VeilTheme.tertiaryText)
            }

            if appearance.selection != .veilOriginal {
                HStack(spacing: 7) {
''', 'settings display mode controls')
p.write_text(s)

print('APPLY_GLOBAL_LIGHT_DARK_MODE_V1: PASS')
