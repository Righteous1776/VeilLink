#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_APPLE_SOFT_LIQUID_GLASS_V1.py <repo-root>')

root = Path(sys.argv[1]).resolve()
payload = Path(__file__).resolve().parent

# Require the immediately previous cumulative layer.
for required in [
    'VeilLink/Onboarding/VeilFirstRunOnboardingController.swift',
    'VeilLink/UI/VeilReleaseActivationView.swift',
    'VeilLink/Legal/VeilLegalConsentController.swift',
]:
    if not (root / required).exists():
        raise SystemExit(f'REFUSE: previous release-first-run layer missing: {required}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'REFUSE: {label} anchor count={count}')
    return text.replace(old, new, 1)

creates = {
    'VeilLink/Core/VeilAppleMaterialEngine.swift': 'VeilLink/Core/VeilAppleMaterialEngine.swift',
    'VeilLink/UI/VeilAppleSoftRootView.swift': 'VeilLink/UI/VeilAppleSoftRootView.swift',
    'VeilLinkTests/AppleSoftThemeTests.swift': 'VeilLinkTests/AppleSoftThemeTests.swift',
    'docs/APPLE_SOFT_LIQUID_GLASS_V1.md': 'docs/APPLE_SOFT_LIQUID_GLASS_V1.md',
}
for dst_rel, src_rel in creates.items():
    dst = root / dst_rel
    if dst.exists():
        raise SystemExit(f'REFUSE: destination already exists: {dst_rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(payload / src_rel, dst)

# 1) Appearance theme: add the manually selectable Apple Soft skin.
p = root / 'VeilLink/Core/AppearanceTheme.swift'
s = p.read_text()
s = replace_once(s,
'''enum VeilAppearanceSelection: String, CaseIterable, Identifiable, Codable {
    case veilOriginal
    case instrumentAuto
''',
'''enum VeilAppearanceSelection: String, CaseIterable, Identifiable, Codable {
    case veilOriginal
    case appleSoft
    case instrumentAuto
''', 'appearance case')
s = replace_once(s,
'''        switch self {
        case .veilOriginal: return "Veil 原生"
        case .instrumentAuto: return "仪器 · 自动"
        }
''',
'''        switch self {
        case .veilOriginal: return "Veil 原生"
        case .appleSoft: return "Apple Soft"
        case .instrumentAuto: return "仪器 · 自动"
        }
''', 'appearance title')
s = replace_once(s,
'''        switch self {
        case .veilOriginal: return "保留现有黑金、切角面板与 Veil 动效。"
        case .instrumentAuto: return "现代工业拟物；随系统浅色/深色自动切换。"
        }
    }
}
''',
'''        switch self {
        case .veilOriginal: return "保留现有黑金、切角面板与 Veil 动效。"
        case .appleSoft: return "苹果式软质拟物；iOS 26 自动接入底层 Liquid Glass。"
        case .instrumentAuto: return "现代工业拟物；随系统浅色/深色自动切换。"
        }
    }

    var previewSystemImage: String {
        switch self {
        case .veilOriginal: return "sparkles"
        case .appleSoft: return "circle.grid.2x2.fill"
        case .instrumentAuto: return "dial.medium.fill"
        }
    }

    var previewSurfaceColor: Color {
        switch self {
        case .veilOriginal: return Color(red: 0.02, green: 0.02, blue: 0.03)
        case .appleSoft: return Color(red: 0.91, green: 0.93, blue: 0.97)
        case .instrumentAuto: return Color(red: 0.38, green: 0.38, blue: 0.40)
        }
    }
}
''', 'appearance subtitle/helpers')
s = replace_once(s,
'''    func update(colorScheme: ColorScheme) { systemIsDark = colorScheme == .dark }
    var isInstrument: Bool { selection == .instrumentAuto }
    var appearanceLabel: String {
        isInstrument ? (systemIsDark ? "INSTRUMENT · NIGHT" : "INSTRUMENT · DAY") : "VEIL ORIGINAL"
    }

    var palette: VeilThemePalette {
        guard isInstrument else { return Self.original }
        return systemIsDark ? Self.instrumentNight : Self.instrumentDay
    }
''',
'''    func update(colorScheme: ColorScheme) { systemIsDark = colorScheme == .dark }
    var isInstrument: Bool { selection == .instrumentAuto }
    var isAppleSoft: Bool { selection == .appleSoft }
    var appearanceLabel: String {
        switch selection {
        case .veilOriginal: return "VEIL ORIGINAL"
        case .appleSoft: return systemIsDark ? "APPLE SOFT · NIGHT" : "APPLE SOFT · DAY"
        case .instrumentAuto: return systemIsDark ? "INSTRUMENT · NIGHT" : "INSTRUMENT · DAY"
        }
    }

    var palette: VeilThemePalette {
        switch selection {
        case .veilOriginal: return Self.original
        case .appleSoft: return systemIsDark ? Self.appleSoftNight : Self.appleSoftDay
        case .instrumentAuto: return systemIsDark ? Self.instrumentNight : Self.instrumentDay
        }
    }
''', 'appearance controller')

apple_palettes = '''    static let appleSoftDay = VeilThemePalette(
        background: Color(red: 0.950, green: 0.956, blue: 0.974),
        backgroundLift: Color(red: 0.982, green: 0.984, blue: 0.992),
        elevated: Color(red: 0.972, green: 0.976, blue: 0.988),
        panel: Color(red: 0.935, green: 0.944, blue: 0.968),
        panelSoft: Color(red: 0.985, green: 0.987, blue: 0.995),
        obsidian: Color(red: 0.890, green: 0.905, blue: 0.940),
        veil: Color(red: 0.925, green: 0.936, blue: 0.962),
        gold: Color(red: 0.090, green: 0.455, blue: 0.930),
        goldBright: Color(red: 0.170, green: 0.535, blue: 1.000),
        goldDeep: Color(red: 0.035, green: 0.275, blue: 0.665),
        mutedGold: Color(red: 0.315, green: 0.430, blue: 0.610),
        paleMetal: Color(red: 0.650, green: 0.690, blue: 0.760),
        text: Color.black.opacity(0.88),
        secondaryText: Color.black.opacity(0.56),
        tertiaryText: Color.black.opacity(0.34),
        hairline: Color.black.opacity(0.075),
        danger: Color(red: 0.88, green: 0.18, blue: 0.20),
        success: Color(red: 0.08, green: 0.62, blue: 0.34),
        metalTop: Color(red: 0.985, green: 0.987, blue: 0.995),
        metalBottom: Color(red: 0.900, green: 0.916, blue: 0.950),
        recess: Color.black.opacity(0.08),
        keycapTop: Color.white.opacity(0.96),
        keycapBottom: Color(red: 0.905, green: 0.920, blue: 0.950),
        indicator: Color(red: 0.090, green: 0.455, blue: 0.930)
    )

    static let appleSoftNight = VeilThemePalette(
        background: Color(red: 0.055, green: 0.057, blue: 0.064),
        backgroundLift: Color(red: 0.085, green: 0.088, blue: 0.098),
        elevated: Color(red: 0.105, green: 0.108, blue: 0.120),
        panel: Color(red: 0.120, green: 0.124, blue: 0.138),
        panelSoft: Color(red: 0.145, green: 0.150, blue: 0.166),
        obsidian: Color(red: 0.075, green: 0.078, blue: 0.088),
        veil: Color(red: 0.095, green: 0.098, blue: 0.110),
        gold: Color(red: 0.180, green: 0.530, blue: 1.000),
        goldBright: Color(red: 0.340, green: 0.645, blue: 1.000),
        goldDeep: Color(red: 0.070, green: 0.310, blue: 0.720),
        mutedGold: Color(red: 0.430, green: 0.550, blue: 0.720),
        paleMetal: Color(red: 0.700, green: 0.730, blue: 0.790),
        text: Color.white.opacity(0.94),
        secondaryText: Color.white.opacity(0.62),
        tertiaryText: Color.white.opacity(0.38),
        hairline: Color.white.opacity(0.085),
        danger: Color(red: 1.00, green: 0.30, blue: 0.32),
        success: Color(red: 0.22, green: 0.82, blue: 0.50),
        metalTop: Color(red: 0.165, green: 0.170, blue: 0.185),
        metalBottom: Color(red: 0.090, green: 0.092, blue: 0.102),
        recess: Color.black.opacity(0.42),
        keycapTop: Color(red: 0.165, green: 0.170, blue: 0.185),
        keycapBottom: Color(red: 0.095, green: 0.098, blue: 0.110),
        indicator: Color(red: 0.230, green: 0.575, blue: 1.000)
    )

'''
s = replace_once(s, '    static let instrumentDay = VeilThemePalette(\n', apple_palettes + '    static let instrumentDay = VeilThemePalette(\n', 'apple palettes')
p.write_text(s)

# 2) Global theme primitives: Apple-soft geometry/materials propagate through existing screens.
p = root / 'VeilLink/Core/AppTheme.swift'
s = p.read_text()
s = replace_once(s,
'''    static var goldGradient: LinearGradient { LinearGradient(colors: [goldBright, gold, goldDeep], startPoint: .topLeading, endPoint: .bottomTrailing) }
    static var metalGradient: LinearGradient { LinearGradient(colors: [Color.white.opacity(0.72), paleMetal, gold.opacity(0.78), goldDeep], startPoint: .topLeading, endPoint: .bottomTrailing) }
    static var surfaceGradient: LinearGradient { LinearGradient(colors: [Color.white.opacity(0.040), Color.white.opacity(0.010)], startPoint: .topLeading, endPoint: .bottomTrailing) }
''',
'''    static var goldGradient: LinearGradient {
        VeilAppearanceController.shared.isAppleSoft
            ? LinearGradient(colors: [goldBright, gold], startPoint: .topLeading, endPoint: .bottomTrailing)
            : LinearGradient(colors: [goldBright, gold, goldDeep], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    static var metalGradient: LinearGradient {
        VeilAppearanceController.shared.isAppleSoft
            ? LinearGradient(colors: [panelSoft, panel], startPoint: .topLeading, endPoint: .bottomTrailing)
            : LinearGradient(colors: [Color.white.opacity(0.72), paleMetal, gold.opacity(0.78), goldDeep], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
    static var surfaceGradient: LinearGradient {
        VeilAppearanceController.shared.isAppleSoft
            ? LinearGradient(colors: [Color.white.opacity(0.18), Color.white.opacity(0.015)], startPoint: .top, endPoint: .bottom)
            : LinearGradient(colors: [Color.white.opacity(0.040), Color.white.opacity(0.010)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
''', 'theme gradients')
s = replace_once(s,
'''    func path(in rect: CGRect) -> Path {
        if VeilAppearanceController.shared.isInstrument {
            return RoundedRectangle(cornerRadius: max(12, radius * 1.8), style: .continuous).path(in: rect)
        }
''',
'''    func path(in rect: CGRect) -> Path {
        if VeilAppearanceController.shared.isAppleSoft {
            return RoundedRectangle(cornerRadius: max(18, radius * 2.4), style: .continuous).path(in: rect)
        }
        if VeilAppearanceController.shared.isInstrument {
            return RoundedRectangle(cornerRadius: max(12, radius * 1.8), style: .continuous).path(in: rect)
        }
''', 'panel geometry')
s = replace_once(s,
'''        Group {
            if VeilAppearanceController.shared.isInstrument {
                VeilInstrumentBackground()
            } else
            if VeilRenderProfile.usesLegacyCompositorPath {
''',
'''        Group {
            if VeilAppearanceController.shared.isAppleSoft {
                VeilAppleSoftBackground()
            } else if VeilAppearanceController.shared.isInstrument {
                VeilInstrumentBackground()
            } else if VeilRenderProfile.usesLegacyCompositorPath {
''', 'ambient background')
s = replace_once(s,
'''    @ViewBuilder
    func body(content: Content) -> some View {
        if VeilAppearanceController.shared.isInstrument {
            content
                .padding(16)
                .background(VeilInstrumentPlate(shape: RoundedRectangle(cornerRadius: emphasized ? 22 : 18, style: .continuous), emphasized: emphasized))
        } else if VeilRenderProfile.usesLegacyCompositorPath {
''',
'''    @ViewBuilder
    func body(content: Content) -> some View {
        if VeilAppearanceController.shared.isAppleSoft {
            content
                .padding(16)
                .background(VeilAppleSoftSurface(cornerRadius: emphasized ? 28 : 23, emphasized: emphasized))
        } else if VeilAppearanceController.shared.isInstrument {
            content
                .padding(16)
                .background(VeilInstrumentPlate(shape: RoundedRectangle(cornerRadius: emphasized ? 22 : 18, style: .continuous), emphasized: emphasized))
        } else if VeilRenderProfile.usesLegacyCompositorPath {
''', 'card modifier')
old_glass = '''struct VeilGlassModifier: ViewModifier {
    let cornerRadius: CGFloat

    @ViewBuilder
    func body(content: Content) -> some View {
        if VeilRenderProfile.usesLegacyCompositorPath {
            content
                .background(VeilTheme.elevated.opacity(0.96))
                .overlay(
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .stroke(VeilTheme.hairline, lineWidth: 1)
                )
        } else {
            content
                .background(VeilTheme.elevated.opacity(0.90))
                .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .stroke(VeilTheme.hairline, lineWidth: 1)
                )
                .overlay(alignment: .top) {
                    LinearGradient(
                        colors: [Color.clear, Color.white.opacity(0.11), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .frame(height: 1)
                    .padding(.horizontal, 18)
                }
                .shadow(color: Color.black.opacity(0.18), radius: 10, x: 0, y: 5)
        }
    }
}
'''
new_glass = '''struct VeilGlassModifier: ViewModifier {
    let cornerRadius: CGFloat

    func body(content: Content) -> some View {
        content.modifier(VeilPlatformGlassSurfaceModifier(cornerRadius: cornerRadius, interactive: false))
    }
}
'''
s = replace_once(s, old_glass, new_glass, 'glass modifier')
old_press = '''struct VeilPressStyle: ButtonStyle {
    @Environment(\\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        let pressed = configuration.isPressed
        configuration.label
            .scaleEffect(pressed && !reduceMotion ? VeilMotionPolicy.pressScale : 1)
            .offset(y: pressed ? (VeilAppearanceController.shared.isInstrument ? 2.5 : 1.4) : 0)
            .brightness(pressed ? -0.035 : 0)
            .opacity(pressed ? 0.96 : 1)
            .shadow(
                color: Color.black.opacity(pressed ? 0.10 : (VeilMotionPolicy.allowsFullSpatialEffects ? 0.22 : 0.12)),
                radius: pressed ? 2 : (VeilMotionPolicy.allowsFullSpatialEffects ? 7 : 3),
                x: 0,
                y: pressed ? 1 : (VeilMotionPolicy.allowsFullSpatialEffects ? 4 : 2)
            )
            .animation(reduceMotion ? nil : VeilMotionPolicy.spring, value: pressed)
    }
}
'''
new_press = '''struct VeilPressStyle: ButtonStyle {
    @Environment(\\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        let pressed = configuration.isPressed
        let appleSoft = VeilAppearanceController.shared.isAppleSoft
        configuration.label
            .scaleEffect(pressed && !reduceMotion ? (appleSoft ? 0.982 : VeilMotionPolicy.pressScale) : 1)
            .offset(y: pressed ? (appleSoft ? 0.8 : (VeilAppearanceController.shared.isInstrument ? 2.5 : 1.4)) : 0)
            .brightness(pressed ? (appleSoft ? -0.018 : -0.035) : 0)
            .opacity(pressed ? (appleSoft ? 0.90 : 0.96) : 1)
            .shadow(
                color: Color.black.opacity(appleSoft ? (pressed ? 0.04 : 0.08) : (pressed ? 0.10 : (VeilMotionPolicy.allowsFullSpatialEffects ? 0.22 : 0.12))),
                radius: pressed ? 2 : (appleSoft ? 5 : (VeilMotionPolicy.allowsFullSpatialEffects ? 7 : 3)),
                x: 0,
                y: pressed ? 1 : (appleSoft ? 3 : (VeilMotionPolicy.allowsFullSpatialEffects ? 4 : 2))
            )
            .animation(reduceMotion ? nil : (appleSoft ? .easeOut(duration: 0.13) : VeilMotionPolicy.spring), value: pressed)
    }
}
'''
s = replace_once(s, old_press, new_press, 'press style')
old_icon = '''struct VeilIconDisc: View {
    let systemName: String
    var size: CGFloat = 34
    var highlighted = false

    var body: some View {
        ZStack {
            Circle()
                .fill(highlighted ? VeilTheme.gold.opacity(0.14) : Color.white.opacity(0.038))
            Circle()
                .stroke(highlighted ? VeilTheme.gold.opacity(0.30) : VeilTheme.hairline, lineWidth: 1)
            if highlighted {
                Circle()
                    .trim(from: 0.04, to: 0.42)
                    .stroke(VeilTheme.goldBright.opacity(0.70), lineWidth: 1)
                    .rotationEffect(.degrees(-30))
                    .padding(2)
            }
            Image(systemName: systemName)
                .font(.system(size: size * 0.43, weight: .semibold))
                .foregroundColor(highlighted ? VeilTheme.goldBright : VeilTheme.secondaryText)
        }
        .frame(width: size, height: size)
    }
}
'''
new_icon = '''struct VeilIconDisc: View {
    let systemName: String
    var size: CGFloat = 34
    var highlighted = false

    @ViewBuilder
    var body: some View {
        if VeilAppearanceController.shared.isAppleSoft {
            ZStack {
                Circle()
                    .fill(highlighted ? VeilTheme.gold.opacity(0.12) : VeilTheme.panelSoft)
                    .shadow(color: Color.black.opacity(0.10), radius: 6, x: 0, y: 3)
                    .shadow(color: Color.white.opacity(0.60), radius: 5, x: -3, y: -3)
                Circle()
                    .stroke(highlighted ? VeilTheme.gold.opacity(0.24) : VeilTheme.hairline, lineWidth: 0.8)
                Image(systemName: systemName)
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundColor(highlighted ? VeilTheme.goldBright : VeilTheme.secondaryText)
            }
            .frame(width: size, height: size)
        } else {
            ZStack {
                Circle()
                    .fill(highlighted ? VeilTheme.gold.opacity(0.14) : Color.white.opacity(0.038))
                Circle()
                    .stroke(highlighted ? VeilTheme.gold.opacity(0.30) : VeilTheme.hairline, lineWidth: 1)
                if highlighted {
                    Circle()
                        .trim(from: 0.04, to: 0.42)
                        .stroke(VeilTheme.goldBright.opacity(0.70), lineWidth: 1)
                        .rotationEffect(.degrees(-30))
                        .padding(2)
                }
                Image(systemName: systemName)
                    .font(.system(size: size * 0.43, weight: .semibold))
                    .foregroundColor(highlighted ? VeilTheme.goldBright : VeilTheme.secondaryText)
            }
            .frame(width: size, height: size)
        }
    }
}
'''
s = replace_once(s, old_icon, new_icon, 'icon disc')
p.write_text(s)

# 3) Root shell: only the Apple Soft UI changes navigation structure.
p = root / 'VeilLink/UI/AdaptiveRootView.swift'
s = p.read_text()
s = replace_once(s,
'''        Group {
            if horizontalSizeClass == .regular {
                TabletLayout(model: model)
            } else {
                PhoneLayout(model: model)
            }
        }
''',
'''        Group {
            if appearance.isAppleSoft {
                VeilAppleSoftRootView(model: model)
            } else if horizontalSizeClass == .regular {
                TabletLayout(model: model)
            } else {
                PhoneLayout(model: model)
            }
        }
''', 'adaptive root apple soft')
s = replace_once(s,
'''        .onAppear { appearance.update(colorScheme: colorScheme) }
        .onChange(of: colorScheme) { appearance.update(colorScheme: $0) }
''',
'''        .onAppear {
            appearance.update(colorScheme: colorScheme)
            VeilChrome.configure()
        }
        .onChange(of: colorScheme) {
            appearance.update(colorScheme: $0)
            VeilChrome.configure()
        }
        .onChange(of: appearance.selection) { _ in VeilChrome.configure() }
''', 'adaptive root chrome refresh')
p.write_text(s)

# 4) Settings appearance picker: surface the third skin without metallic preview semantics.
p = root / 'VeilLink/UI/SettingsView.swift'
s = p.read_text()
s = replace_once(s,
'''                            RoundedRectangle(cornerRadius: 9)
                                .fill(choice == .veilOriginal ? VeilTheme.obsidian : VeilAppearanceController.shared.palette.metalTop)
                            Image(systemName: choice == .veilOriginal ? "sparkles" : "dial.medium.fill")
''',
'''                            RoundedRectangle(cornerRadius: 9)
                                .fill(choice.previewSurfaceColor)
                            Image(systemName: choice.previewSystemImage)
''', 'settings theme preview')
s = replace_once(s,
'''            if appearance.selection == .instrumentAuto {
                HStack(spacing: 7) {
                    VeilIndicatorLamp(active: true)
                    Text("当前：\\(appearance.appearanceLabel)")
                }
                .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                .foregroundColor(VeilTheme.secondaryText)
            }
        }
        .veilCard(emphasized: appearance.selection == .instrumentAuto)
        .veilDynamicGlow(active: appearance.selection == .instrumentAuto, emphasized: true)
''',
'''            if appearance.selection != .veilOriginal {
                HStack(spacing: 7) {
                    if appearance.selection == .instrumentAuto {
                        VeilIndicatorLamp(active: true)
                    } else {
                        Image(systemName: "circle.grid.2x2.fill")
                            .foregroundColor(VeilTheme.goldBright)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("当前：\\(appearance.appearanceLabel)")
                        if appearance.selection == .appleSoft {
                            Text(VeilPlatformMaterialEngine.diagnosticLabel)
                                .font(.system(size: 7.5, weight: .medium, design: .monospaced))
                        }
                    }
                }
                .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                .foregroundColor(VeilTheme.secondaryText)
            }
        }
        .veilCard(emphasized: appearance.selection != .veilOriginal)
        .veilDynamicGlow(active: appearance.selection == .instrumentAuto, emphasized: true)
''', 'settings theme status')
p.write_text(s)

# 5) UIKit chrome: do not force black opaque bars when Apple Soft is selected.
p = root / 'VeilLink/App/VeilLinkApp.swift'
s = p.read_text()
s = replace_once(s, 'private enum VeilChrome {\n', 'enum VeilChrome {\n', 'VeilChrome visibility')
s = replace_once(s,
'''    @MainActor
    static func configure() {
        let navigation = UINavigationBarAppearance()
        navigation.configureWithOpaqueBackground()
        navigation.backgroundColor = UIColor(red: 0.012, green: 0.013, blue: 0.017, alpha: 0.96)
        navigation.shadowColor = UIColor.white.withAlphaComponent(0.045)
        navigation.titleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]
        navigation.largeTitleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]

        let navigationBar = UINavigationBar.appearance()
        navigationBar.standardAppearance = navigation
        navigationBar.compactAppearance = navigation
        navigationBar.scrollEdgeAppearance = navigation
        navigationBar.tintColor = UIColor(red: 0.86, green: 0.64, blue: 0.24, alpha: 1)

        let tab = UITabBarAppearance()
        tab.configureWithOpaqueBackground()
        tab.backgroundColor = UIColor(red: 0.020, green: 0.021, blue: 0.026, alpha: 0.985)
        tab.shadowColor = UIColor.white.withAlphaComponent(0.05)
        let selected = UIColor(red: 0.98, green: 0.82, blue: 0.46, alpha: 1)
        let normal = UIColor.white.withAlphaComponent(0.42)
''',
'''    @MainActor
    static func configure() {
        let appleSoft = VeilAppearanceController.shared.isAppleSoft
        let navigation = UINavigationBarAppearance()
        if appleSoft {
            navigation.configureWithTransparentBackground()
            navigation.backgroundColor = .clear
            if #available(iOS 26.0, *) {
                // Keep system chrome unpainted so current SDKs can supply native Liquid Glass.
            } else {
                navigation.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
            }
            navigation.shadowColor = .clear
            navigation.titleTextAttributes = [.foregroundColor: UIColor.label]
            navigation.largeTitleTextAttributes = [.foregroundColor: UIColor.label]
        } else {
            navigation.configureWithOpaqueBackground()
            navigation.backgroundColor = UIColor(red: 0.012, green: 0.013, blue: 0.017, alpha: 0.96)
            navigation.shadowColor = UIColor.white.withAlphaComponent(0.045)
            navigation.titleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]
            navigation.largeTitleTextAttributes = [.foregroundColor: UIColor.white.withAlphaComponent(0.94)]
        }

        let navigationBar = UINavigationBar.appearance()
        navigationBar.standardAppearance = navigation
        navigationBar.compactAppearance = navigation
        navigationBar.scrollEdgeAppearance = navigation
        navigationBar.tintColor = appleSoft ? .systemBlue : UIColor(red: 0.86, green: 0.64, blue: 0.24, alpha: 1)

        let tab = UITabBarAppearance()
        if appleSoft {
            tab.configureWithTransparentBackground()
            tab.backgroundColor = .clear
            if #available(iOS 26.0, *) {
                // Standard tab chrome can adopt platform Liquid Glass.
            } else {
                tab.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
            }
            tab.shadowColor = .clear
        } else {
            tab.configureWithOpaqueBackground()
            tab.backgroundColor = UIColor(red: 0.020, green: 0.021, blue: 0.026, alpha: 0.985)
            tab.shadowColor = UIColor.white.withAlphaComponent(0.05)
        }
        let selected = appleSoft ? UIColor.systemBlue : UIColor(red: 0.98, green: 0.82, blue: 0.46, alpha: 1)
        let normal = appleSoft ? UIColor.secondaryLabel : UIColor.white.withAlphaComponent(0.42)
''', 'VeilChrome body')
p.write_text(s)

print('APPLY_APPLE_SOFT_LIQUID_GLASS_V1: PASS')
