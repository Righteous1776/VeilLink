# VeilLink 26.9 · Build 53 — FORMAL RELEASE LOCAL FINAL

**CURRENT. Do not restart R1→R12. Do not rebuild from `main`.**

Validated iOS base remains:

`r12-cumulative-validation @ 14955c9143f202ac1f19a37d78d88735da8bb0cb`

Ordered cumulative layers:

1. `LEGAL_CONSENT_GATE_V1`
2. `RELEASE_ACTIVATION_ONBOARDING_V1`
3. `APPLE_SOFT_LIQUID_GLASS_V1`
4. `GLOBAL_LIGHT_DARK_MODE_V1`
5. `LAN_DATA_PLANE_V3`
6. `VEILLINK_26_9_STABILIZATION_V1` ← CURRENT / FORMAL RELEASE TARGET

Preferred one-shot application:

```bash
python3 APPLY_CURRENT_VEILLINK_26_9.py <repo-root>
```

Never fuzzy-apply around a failed guard.

## Formal release identity

- Product: **VeilLink 26.9**
- Build: **53**
- Channel: **Stable**
- iOS: **primary release platform**
- Android: **preserved, experimental/best-effort, never blocks IPA**

The `26.9` public version intentionally leaves the historical `0.x` engineering line and adopts a calendar-generation style rather than restarting at `1.0`.

## What this final stabilization layer does

- consolidates repeated BLE/LAN/Relay identity-transition lifecycle code into one AppModel path;
- makes `project.yml` the Xcode release-identity source of truth;
- makes App + Live Activity Widget inherit the same version/build;
- makes release verification read the expected identity from `project.yml`;
- makes IPA artifact names come from the **actual built app Info.plist**;
- removes stale `v0.10.10-b52` naming from release-critical CI;
- keeps Android non-blocking and decouples its experimental artifact name from the iOS stable carrier;
- does **not** change Wire Protocol v4, database schema, E2EE algorithms, trust policy or the LAN V3 data-plane protocol.

## Promotion rule

This package is the **final local release input**. It becomes the official VeilLink 26.9 release only after Work applies it once and the iOS-primary CI succeeds with an unsigned IPA whose built Info.plist reports:

`CFBundleShortVersionString = 26.9`

`CFBundleVersion = 53`

Do not spend CI/token budget fixing Android before the IPA exists.
