#!/usr/bin/env python3
from pathlib import Path
import hashlib
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: APPLY_RELEASE_ACTIVATION_ONBOARDING_V1.py <repo-root>')

root = Path(sys.argv[1]).resolve()
payload = Path(__file__).resolve().parent

required_legal_sha = 'c9624a18a695295f3ea6e548fb45324ee705682c7ad2e17349a7dcd1e16359fa'
legal_path = root / 'VeilLink/UI/LegalConsentGateView.swift'
if not legal_path.exists():
    raise SystemExit('REFUSE: LEGAL_CONSENT_GATE_V1 must be applied first')
actual = hashlib.sha256(legal_path.read_bytes()).hexdigest()
if actual != required_legal_sha:
    raise SystemExit(f'REFUSE: unexpected LegalConsentGateView.swift sha256 {actual}')

creates = {
    'VeilLink/Onboarding/VeilFirstRunOnboardingController.swift': 'VeilLink/Onboarding/VeilFirstRunOnboardingController.swift',
    'VeilLink/UI/VeilReleaseOnboardingPrimitives.swift': 'VeilLink/UI/VeilReleaseOnboardingPrimitives.swift',
    'VeilLink/UI/VeilReleaseActivationView.swift': 'VeilLink/UI/VeilReleaseActivationView.swift',
    'VeilLinkTests/ReleaseActivationOnboardingTests.swift': 'VeilLinkTests/ReleaseActivationOnboardingTests.swift',
    'docs/RELEASE_ACTIVATION_ONBOARDING_V1.md': 'docs/RELEASE_ACTIVATION_ONBOARDING_V1.md',
}
for dst_rel, src_rel in creates.items():
    dst = root / dst_rel
    if dst.exists():
        raise SystemExit(f'REFUSE: destination already exists: {dst_rel}')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(payload / src_rel, dst)

# Replace the legal gate only from the exact LEGAL_CONSENT_GATE_V1 source.
shutil.copy2(payload / 'VeilLink/UI/LegalConsentGateView.RELEASE_V1.swift', legal_path)

p = root / 'VeilLink/App/VeilLinkApp.swift'
s = p.read_text()
old = '''if !bootstrap.legal.isSatisfied {
                    LegalConsentGateView(controller: bootstrap.legal) {
                        bootstrap.activateAfterLegalAcceptance()
                    }
                } else if let model = bootstrap.model {
'''
new = '''if !bootstrap.onboarding.isCompleted {
                    VeilReleaseActivationView(
                        controller: bootstrap.onboarding,
                        legal: bootstrap.legal
                    ) {
                        bootstrap.completeFirstActivation()
                    }
                } else if !bootstrap.legal.isSatisfied {
                    LegalConsentGateView(controller: bootstrap.legal) {
                        bootstrap.activateAfterLegalAcceptance()
                    }
                } else if let model = bootstrap.model {
'''
if s.count(old) != 1:
    raise SystemExit('VeilLinkApp activation gate anchor mismatch')
s = s.replace(old, new, 1)

old = '''    let legal: VeilLegalConsentController

    private let keychain: KeychainStore
'''
new = '''    let legal: VeilLegalConsentController
    let onboarding: VeilFirstRunOnboardingController

    private let keychain: KeychainStore
'''
if s.count(old) != 1:
    raise SystemExit('AppBootstrap onboarding property anchor mismatch')
s = s.replace(old, new, 1)

old = '''        keychain = KeychainStore()
        legal = VeilLegalConsentController(keychain: keychain)
        legalCancellable = legal.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }
        if legal.isSatisfied { initializeModel() }
'''
new = '''        keychain = KeychainStore()
        legal = VeilLegalConsentController(keychain: keychain)
        onboarding = VeilFirstRunOnboardingController()
        legalCancellable = legal.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }
        if legal.isSatisfied && onboarding.isCompleted { initializeModel() }
'''
if s.count(old) != 1:
    raise SystemExit('AppBootstrap onboarding init anchor mismatch')
s = s.replace(old, new, 1)

old = '''    func activateAfterLegalAcceptance() {
        guard legal.isSatisfied else { return }
        if model == nil {
            initializeModel()
        } else {
            model?.activateAfterLegalAcceptance()
        }
    }

    private func initializeModel() {
'''
new = '''    func completeFirstActivation() {
        guard legal.isSatisfied else { return }
        onboarding.complete()
        if model == nil {
            initializeModel()
        } else {
            model?.activateAfterLegalAcceptance()
        }
    }

    func activateAfterLegalAcceptance() {
        guard legal.isSatisfied, onboarding.isCompleted else { return }
        if model == nil {
            initializeModel()
        } else {
            model?.activateAfterLegalAcceptance()
        }
    }

    private func initializeModel() {
'''
if s.count(old) != 1:
    raise SystemExit('AppBootstrap completion anchor mismatch')
s = s.replace(old, new, 1)

old = '''    private func initializeModel() {
        guard legal.isSatisfied, model == nil else { return }
'''
new = '''    private func initializeModel() {
        guard legal.isSatisfied, onboarding.isCompleted, model == nil else { return }
'''
if s.count(old) != 1:
    raise SystemExit('AppBootstrap initialize guard anchor mismatch')
s = s.replace(old, new, 1)
p.write_text(s)

print('APPLY_RELEASE_ACTIVATION_ONBOARDING_V1: PASS')
