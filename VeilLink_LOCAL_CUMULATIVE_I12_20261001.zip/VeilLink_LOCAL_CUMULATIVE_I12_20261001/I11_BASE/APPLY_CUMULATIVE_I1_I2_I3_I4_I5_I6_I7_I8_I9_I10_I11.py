from pathlib import Path
import subprocess
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9_I10_I11.py /path/to/VeilLink")
root = Path(sys.argv[1]).resolve()
base = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(base / "I10_BASE" / "APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9_I10.py"), str(root)], check=True)
subprocess.run([sys.executable, str(base / "I11_APPLY.py"), str(root)], check=True)
subprocess.run([sys.executable, str(base / "I11_VERIFY.py"), str(root)], check=True)
print("CUMULATIVE I1→I11 PASS")
