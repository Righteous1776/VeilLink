from pathlib import Path
import shutil
import sys

I10_REQUIRED = {
    "VeilLink/Agent/Compute/A10UltraComputeCore.swift": ["protocol A10UltraComputeRuntime"],
    "VeilLink/Agent/Integration/VeilThreeCorePlan.swift": ["THREE_CORE_INSERTION_READY"],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": ['event: "agent.three_core_state"'],
}

I11_MARKERS = {
    "VeilLink/Diagnostics/CollaborativeStressProtocol.swift": [
        "enum CollaborativeStressFrameKind",
        "CollaborativeStressInboundBulkAccumulator",
        "syntheticVoiceWAV",
        "case bulkReady",
    ],
    "VeilLink/Diagnostics/CollaborativeStressCoordinator.swift": [
        "final class CollaborativeStressCoordinator",
        "stress.collab.session.begin",
        "MiniGameCodec.encode",
        "bulkReadyTransfers",
        "stress.collab.bulk.remote_ready_timeout",
    ],
    "VeilLink/Security/SessionCoordinator.swift": [
        "onCollaborativeStressFrame",
        "sendCollaborativeStressFrame",
        "sendCollaborativeStressBulkChunk",
        "CollaborativeStressCodec.decode",
        "pruneCollaborativeStressMessageIDs",
    ],
    "VeilLink/Diagnostics/DeviceStressTestController.swift": [
        "CollaborativeStressCoordinator.shared.attach",
        '"stress-collaborative.json"',
    ],
    "VeilLink/UI/DeviceStressTestView.swift": [
        "协同设备压力",
        "发送协同邀请",
        "接收邀请并开始",
    ],
    "VeilLinkTests/CollaborativeStressProtocolTests.swift": [
        "testFrameRoundTripAndPrefixIsolation",
        "testBulkAccumulatorVerifiesDigestAndOrdering",
        "testBulkReadyRequiresMatchingTransferIdentityFields",
    ],
}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_session_coordinator(text: str) -> str:
    text = replace_once(
        text,
        "    var onInboundMessageReceived: (() -> Void)?\n    var onDeliveryConfirmed: (() -> Void)?",
        "    var onInboundMessageReceived: (() -> Void)?\n    var onDeliveryConfirmed: (() -> Void)?\n    var onCollaborativeStressFrame: ((CollaborativeStressFrame, String) -> Void)?\n    var onCollaborativeStressBulkReceipt: ((CollaborativeStressBulkReceipt, String) -> Void)?",
        "stress callbacks",
    )
    text = replace_once(
        text,
        "    private var outboundAttachmentCacheBytes = 0\n    private var maximumOutboundAttachmentCacheBytes: Int { VeilDevicePerformance.current.outboundAttachmentCacheBytes }",
        "    private var outboundAttachmentCacheBytes = 0\n    private var collaborativeStressInboundBulk: [String: CollaborativeStressInboundBulkAccumulator] = [:]\n    private var collaborativeStressMessageIDs: [String: TimeInterval] = [:]\n    private let collaborativeStressMessageIDTTL: TimeInterval = 10 * 60\n    private var maximumOutboundAttachmentCacheBytes: Int { VeilDevicePerformance.current.outboundAttachmentCacheBytes }",
        "stress inbound storage",
    )
    text = replace_once(
        text,
        "    func clearTransientCaches() {\n        clearOutboundAttachmentCache()\n    }",
        "    func clearTransientCaches() {\n        clearOutboundAttachmentCache()\n        collaborativeStressInboundBulk.removeAll(keepingCapacity: false)\n    }",
        "stress transient cleanup",
    )
    text = replace_once(
        text,
        "        sessions.removeValue(forKey: transportID)\n        packetAbuseLimiter.reset(transportID)\n        peerTransport = peerTransport.filter { $0.value != transportID }",
        "        sessions.removeValue(forKey: transportID)\n        packetAbuseLimiter.reset(transportID)\n        collaborativeStressInboundBulk.removeAll(keepingCapacity: false)\n        collaborativeStressMessageIDs.removeAll(keepingCapacity: false)\n        peerTransport = peerTransport.filter { $0.value != transportID }",
        "stress disconnect cleanup",
    )
    text = replace_once(
        text,
        "        nearbyPeers.removeAll()\n        clearOutboundAttachmentCache()\n        lastError = nil",
        "        nearbyPeers.removeAll()\n        clearOutboundAttachmentCache()\n        collaborativeStressInboundBulk.removeAll(keepingCapacity: false)\n        collaborativeStressMessageIDs.removeAll(keepingCapacity: false)\n        lastError = nil",
        "stress identity reset cleanup",
    )

    anchor = """    func hasSecureSession(for peerIdentityID: String) -> Bool {
        guard let transportID = peerTransport[peerIdentityID],
              let context = sessions[transportID] else { return false }
        return context.remoteHello != nil && context.keys != nil
    }

"""
    insertion = anchor + r'''    /// Diagnostics-only ephemeral E2EE lane. The peer must already be trusted and secure-ready.
    /// Frames never enter normal message/outbox persistence.
    func sendCollaborativeStressFrame(
        _ frame: CollaborativeStressFrame,
        to peerIdentityID: String
    ) -> TransportSendResult {
        guard let transportID = peerTransport[peerIdentityID],
              var context = sessions[transportID],
              let remote = context.remoteHello,
              let keys = context.keys,
              remote.identityID == peerIdentityID,
              database.trustedContact(localIdentityID: context.localHello.identityID, identityID: peerIdentityID)?.publicKey == remote.identityPublicKey,
              identity.activeIdentity?.id == context.localHello.identityID else {
            return .temporarilyUnavailable
        }
        do {
            let stressText = try CollaborativeStressCodec.encode(frame)
            guard stressText.lengthOfBytes(using: .utf8) <= WireProtocol.maximumTextBytes else { return .unsupportedLink }
            let content = WireChatContent(
                kind: .text,
                text: stressText,
                attachment: nil,
                mimeType: nil,
                sentAt: Date(),
                attachmentByteCount: nil,
                attachmentSHA256: nil,
                attachmentChunkCount: nil
            )
            let messageID = UUID().uuidString
            let encrypted = try CryptoEngine.encrypt(
                try encoder.encode(content),
                key: keys.sendKey,
                messageID: messageID,
                sequence: context.nextSendSequence,
                context: "chat"
            )
            context.nextSendSequence += 1
            let envelope = try WireCodec.encodeEnvelope(
                version: UInt8(WireProtocol.version),
                kind: .encryptedMessage,
                payload: try WireCodec.encodeEncryptedPayload(encrypted)
            )
            guard envelope.count <= WireProtocol.maximumEnvelopeBytes else { return .unsupportedLink }
            let result = transportSend?(transportID, envelope, .control) ?? .temporarilyUnavailable
            sessions[transportID] = context
            return result
        } catch {
            lastError = "协同压力测试控制帧发送失败：\(error.localizedDescription)"
            sessions[transportID] = context
            return .temporarilyUnavailable
        }
    }

    /// Sends diagnostics-only binary pressure through the real encrypted attachmentChunk/BLE bulk lane.
    /// No messages/attachments/outbound_queue rows are created.
    func sendCollaborativeStressBulkChunk(
        sessionID: String,
        epoch: UInt64,
        transferID: String,
        wireMessageID: String,
        index: Int,
        total: Int,
        bytes: Data,
        to peerIdentityID: String
    ) -> TransportSendResult {
        guard UUID(uuidString: sessionID) != nil,
              epoch > 0,
              UUID(uuidString: transferID) != nil,
              UUID(uuidString: wireMessageID) != nil,
              total > 0,
              index >= 0,
              index < total,
              total <= Int(UInt16.max),
              !bytes.isEmpty,
              bytes.count <= CollaborativeStressCodec.bulkChunkBytes,
              let transportID = peerTransport[peerIdentityID],
              var context = sessions[transportID],
              let remote = context.remoteHello,
              let keys = context.keys,
              remote.identityID == peerIdentityID,
              database.trustedContact(localIdentityID: context.localHello.identityID, identityID: peerIdentityID)?.publicKey == remote.identityPublicKey else {
            return .temporarilyUnavailable
        }
        do {
            let clear = try WireCodec.encodeAttachmentChunk(
                WireAttachmentChunk(index: UInt16(index), total: UInt16(total), bytes: bytes)
            )
            let encrypted = try CryptoEngine.encrypt(
                clear,
                key: keys.sendKey,
                messageID: wireMessageID,
                sequence: context.nextSendSequence,
                context: "attachment-chunk"
            )
            context.nextSendSequence += 1
            let envelope = try WireCodec.encodeEnvelope(
                version: UInt8(WireProtocol.version),
                kind: .attachmentChunk,
                payload: try WireCodec.encodeEncryptedPayload(encrypted)
            )
            guard envelope.count <= WireProtocol.maximumEnvelopeBytes else { return .unsupportedLink }
            let result = transportSend?(transportID, envelope, .bulk) ?? .temporarilyUnavailable
            sessions[transportID] = context
            return result
        } catch {
            lastError = "协同压力测试 bulk 发送失败：\(error.localizedDescription)"
            sessions[transportID] = context
            return .temporarilyUnavailable
        }
    }

'''
    text = replace_once(text, anchor, insertion, "stress secure send APIs")

    old = """        guard context.replayWindow.accept(payload.sequence) else { throw CryptoEngineError.invalidCiphertext }

        if database.isLocallyDeletedMessage(messageID: payload.messageID, senderIdentityID: remote.identityID) {"""
    new = """        guard context.replayWindow.accept(payload.sequence) else { throw CryptoEngineError.invalidCiphertext }

        // I11 frames share the authenticated chat cipher for backward compatibility, but any
        // VLSTRESS1 envelope is consumed before SQLite. A malformed lab envelope is rejected,
        // never silently stored as a normal chat message on an I11 peer.
        if content.kind == .text, let text = content.text, text.hasPrefix(CollaborativeStressCodec.prefix) {
            guard let stressFrame = CollaborativeStressCodec.decode(text) else { throw CryptoEngineError.invalidCiphertext }
            try CollaborativeStressCodec.validate(stressFrame)
            if stressFrame.kind == .bulkBegin, let wireMessageID = stressFrame.wireMessageID {
                guard database.fetchMessage(id: wireMessageID) == nil,
                      collaborativeStressInboundBulk.count < 8 else { throw CryptoEngineError.invalidCiphertext }
                pruneCollaborativeStressMessageIDs()
                collaborativeStressMessageIDs[wireMessageID] = ProcessInfo.processInfo.systemUptime + collaborativeStressMessageIDTTL
                collaborativeStressInboundBulk[wireMessageID] = try CollaborativeStressInboundBulkAccumulator(frame: stressFrame)
            }
            sessions[transportID] = context
            onCollaborativeStressFrame?(stressFrame, remote.identityID)
            return
        }

        if database.isLocallyDeletedMessage(messageID: payload.messageID, senderIdentityID: remote.identityID) {"""
    text = replace_once(text, old, new, "stress text interception")

    old = """        guard chunk.bytes.count <= WireProtocol.attachmentChunkBytes,
              context.replayWindow.accept(payload.sequence) else { throw CryptoEngineError.invalidCiphertext }
        let state = try database.storeInboundAttachmentChunk(messageID: payload.messageID, index: Int(chunk.index), chunkCount: Int(chunk.total), clearData: chunk.bytes)"""
    new = """        guard chunk.bytes.count <= WireProtocol.attachmentChunkBytes,
              context.replayWindow.accept(payload.sequence) else { throw CryptoEngineError.invalidCiphertext }

        if let accumulator = collaborativeStressInboundBulk[payload.messageID] {
            do {
                let receipt = try accumulator.accept(index: Int(chunk.index), total: Int(chunk.total), bytes: chunk.bytes)
                sessions[transportID] = context
                if let receipt {
                    collaborativeStressInboundBulk.removeValue(forKey: payload.messageID)
                    onCollaborativeStressBulkReceipt?(receipt, remote.identityID)
                }
                return
            } catch {
                collaborativeStressInboundBulk.removeValue(forKey: payload.messageID)
                sessions[transportID] = context
                throw error
            }
        }
        pruneCollaborativeStressMessageIDs()
        if collaborativeStressMessageIDs[payload.messageID] != nil {
            // Memory-pressure cleanup may intentionally discard the accumulator while encrypted
            // chunks are still in flight. Keep a bounded TTL tombstone so late lab chunks are
            // dropped instead of misrouting them into the production attachment database path.
            sessions[transportID] = context
            return
        }

        let state = try database.storeInboundAttachmentChunk(messageID: payload.messageID, index: Int(chunk.index), chunkCount: Int(chunk.total), clearData: chunk.bytes)"""
    text = replace_once(text, old, new, "stress bulk interception")
    text = replace_once(
        text,
        "    private func retryDueOutbound() { try? database.expireOutboundMessages(); for peerIdentityID in Set(peerTransport.keys) { flushOutbound(for: peerIdentityID) } }",
        "    private func pruneCollaborativeStressMessageIDs() {\n        let now = ProcessInfo.processInfo.systemUptime\n        collaborativeStressMessageIDs = collaborativeStressMessageIDs.filter { $0.value > now }\n    }\n\n    private func retryDueOutbound() { try? database.expireOutboundMessages(); for peerIdentityID in Set(peerTransport.keys) { flushOutbound(for: peerIdentityID) } }",
        "stress message id TTL prune helper",
    )
    return text


def patch_stress_controller(text: str) -> str:
    text = replace_once(
        text,
        "    func attach(model: AppModel) {\n        self.model = model\n        recoverIncompleteCheckpointIfNeeded()\n    }",
        "    func attach(model: AppModel) {\n        self.model = model\n        CollaborativeStressCoordinator.shared.attach(model: model)\n        recoverIncompleteCheckpointIfNeeded()\n    }",
        "collaborative attach",
    )
    text = replace_once(
        text,
        "    func handleSceneActive(_ active: Bool) {\n        guard isRunning, !active else { return }\n        stop(reason: \"app_left_foreground\")\n    }",
        "    func handleSceneActive(_ active: Bool) {\n        CollaborativeStressCoordinator.shared.handleSceneActive(active)\n        guard isRunning, !active else { return }\n        stop(reason: \"app_left_foreground\")\n    }",
        "collaborative foreground fuse",
    )
    text = replace_once(
        text,
        "    func noteMemoryWarning() {\n        guard isRunning else { return }\n        memoryWarningCount += 1",
        "    func noteMemoryWarning() {\n        CollaborativeStressCoordinator.shared.noteMemoryWarning()\n        guard isRunning else { return }\n        memoryWarningCount += 1",
        "collaborative memory fuse",
    )
    text = replace_once(
        text,
        """        DeviceStressCommandBus.post(.settingsClosePresentations)
        DeviceStressCommandBus.post(.agentCloseDiagnostics)
        DeviceStressCommandBus.post(.chatCloseConversation)

        model.selectedSection = baselineSection""",
        """        DeviceStressCommandBus.post(.settingsClosePresentations)
        DeviceStressCommandBus.post(.agentCloseDiagnostics)
        DeviceStressCommandBus.post(.chatCloseConversation)
        if CollaborativeStressCoordinator.shared.state != .idle,
           CollaborativeStressCoordinator.shared.state != .completed {
            CollaborativeStressCoordinator.shared.stop(reason: "burn_in_finished")
        }

        model.selectedSection = baselineSection""",
        "collaborative cleanup on burn-in finish",
    )
    old = """            let summaryData = try encoder.encode(summary)
            let stepsData = try encoder.encode(stepResults)
            let readable = makeReadableReport(summary: summary)
            lastExportURL = try RuntimeDiagnosticsBridge.shared.exportBundle(
                for: model,
                reason: "stress.auto_export",
                extraFiles: [
                    "stress-summary.json": summaryData,
                    "stress-steps.json": stepsData,
                    "stress-report.txt": Data(readable.utf8)
                ]
            )"""
    new = """            let summaryData = try encoder.encode(summary)
            let stepsData = try encoder.encode(stepResults)
            let readable = makeReadableReport(summary: summary)
            var extraFiles: [String: Data] = [
                "stress-summary.json": summaryData,
                "stress-steps.json": stepsData,
                "stress-report.txt": Data(readable.utf8)
            ]
            if let collaborative = CollaborativeStressCoordinator.shared.snapshotData() {
                extraFiles["stress-collaborative.json"] = collaborative
            }
            lastExportURL = try RuntimeDiagnosticsBridge.shared.exportBundle(
                for: model,
                reason: "stress.auto_export",
                extraFiles: extraFiles
            )"""
    return replace_once(text, old, new, "collaborative export")


def patch_stress_view(text: str) -> str:
    text = replace_once(
        text,
        r'''    @ObservedObject private var controller = DeviceStressTestController.shared
    @Environment(\.dismiss) private var dismiss
    let onStart: () -> Void''',
        r'''    @ObservedObject private var controller = DeviceStressTestController.shared
    @ObservedObject private var collaborative = CollaborativeStressCoordinator.shared
    @Environment(\.dismiss) private var dismiss
    @State private var selectedCollaborativePeerID = ""
    let onStart: () -> Void''',
        "collaborative view state",
    )
    section = r'''                Section("协同设备压力") {
                    if let invitation = collaborative.pendingInvitation,
                       let peer = collaborative.pendingInvitationPeerID {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("收到协同压力邀请").font(.headline)
                            Text("设备 \(String(peer.prefix(8)).uppercased()) · CODE \(String(invitation.sessionID.prefix(6)).uppercased())")
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(VeilTheme.gold)
                            Text("只进入临时 E2EE Stress Channel；不会写入普通聊天记录。")
                                .font(.caption2).foregroundColor(VeilTheme.secondaryText)
                        }
                        HStack {
                            Button("接收邀请并开始") { collaborative.acceptPendingInvitation() }
                                .buttonStyle(.borderedProminent).tint(VeilTheme.gold)
                            Button("拒绝") { collaborative.declinePendingInvitation() }.buttonStyle(.bordered)
                        }
                    } else {
                        Picker("协同设备", selection: $selectedCollaborativePeerID) {
                            Text("选择设备").tag("")
                            ForEach(model.conversations) { conversation in
                                let secure = model.sessions.hasSecureSession(for: conversation.peerIdentityID)
                                Text("\(conversation.title)\(secure ? " · SECURE" : " · OFFLINE")")
                                    .tag(conversation.peerIdentityID)
                            }
                        }
                        stressToggle("双向高速文字", detail: "synthetic text 走真实加密消息链路，但在 SQLite 入库前截获。", isOn: Binding(get: { collaborative.scenario.enableText }, set: { collaborative.scenario.enableText = $0 }))
                        stressToggle("图片级 bulk", detail: "合成二进制图片负载走真实 attachmentChunk / BLE bulk 队列，不读取相册。", isOn: Binding(get: { collaborative.scenario.enableImages }, set: { collaborative.scenario.enableImages = $0 }))
                        stressToggle("语音级 WAV/PCM bulk", detail: "本地生成 WAV/PCM 风格负载，不开启麦克风、不采集真实语音。", isOn: Binding(get: { collaborative.scenario.enableVoice }, set: { collaborative.scenario.enableVoice = $0 }))
                        stressToggle("临时五子棋协议", detail: "用真实 MiniGameCodec + GomokuState 双机收发，不进入正式对局历史。", isOn: Binding(get: { collaborative.scenario.enableGame }, set: { collaborative.scenario.enableGame = $0 }))
                        HStack {
                            Text("状态"); Spacer()
                            Text(collaborative.state.rawValue.uppercased())
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(collaborative.state == .running ? VeilTheme.success : VeilTheme.secondaryText)
                        }
                        if collaborative.metrics.sentFrames > 0 || collaborative.metrics.receivedFrames > 0 {
                            Text("TX \(collaborative.metrics.sentFrames) / RX \(collaborative.metrics.receivedFrames) · drop \(collaborative.metrics.droppedFrames) · backpressure \(collaborative.metrics.temporaryUnavailableCount) · bulk ok \(collaborative.metrics.bulkTransfersVerified) · game \(collaborative.metrics.gamePacketsReceived)")
                                .font(.caption2.monospacedDigit()).foregroundColor(VeilTheme.secondaryText)
                        }
                        HStack {
                            Button("发送协同邀请") {
                                collaborative.attach(model: model)
                                collaborative.invite(peerIdentityID: selectedCollaborativePeerID)
                            }
                            .buttonStyle(.borderedProminent).tint(VeilTheme.gold)
                            .disabled(selectedCollaborativePeerID.isEmpty || collaborative.state == .running || collaborative.state == .inviting)
                            if collaborative.state == .running || collaborative.state == .ready || collaborative.state == .inviting {
                                Button("停止协同", role: .destructive) { collaborative.stop(reason: "user_stop") }.buttonStyle(.bordered)
                            }
                        }
                    }
                } header: {
                    Text("TEMP E2EE STRESS CHANNEL")
                } footer: {
                    Text("双方必须先完成普通 VeilLink 信任与 Secure Session。邀请不会自动配对，也不会自动开始；旧版本可能把兼容压力帧显示成普通测试文本，因此协同测试应使用同一 I11 构建。")
                }

                Section("安全熔断") {'''
    text = replace_once(text, '                Section("安全熔断") {', section, "collaborative stress UI")
    text = replace_once(
        text,
        '                    Text("测试不会主动删除消息、身份或联系人，不会自动确认配对，不会发送真实聊天/附件，不会改写账号密码。BLE churn 与内存 trim 属于有意施压路径。")',
        '                    Text("本机 Burn-In 不发送真实聊天。协同模式只发送 synthetic 临时压力帧/二进制负载；不读取真实聊天正文、相册、麦克风、密钥或 Prompt。BLE churn 与内存 trim 属于有意施压路径。")',
        "stress privacy footer",
    )
    return replace_once(
        text,
        '        .preferredColorScheme(.dark)\n        .telemetryScreen("owner.stress.configure")',
        '        .preferredColorScheme(.dark)\n        .onAppear {\n            collaborative.attach(model: model)\n            if selectedCollaborativePeerID.isEmpty {\n                selectedCollaborativePeerID = model.conversations.first(where: { model.sessions.hasSecureSession(for: $0.peerIdentityID) })?.peerIdentityID ?? ""\n            }\n        }\n        .telemetryScreen("owner.stress.configure")',
        "collaborative view attach",
    )


def copy_payload(root: Path, package_root: Path) -> None:
    for source in (package_root / "Payload").rglob("*"):
        if source.is_file():
            rel = source.relative_to(package_root / "Payload")
            destination = root / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)


def apply(root: Path, package_root: Path) -> None:
    try:
        require_markers(root, I11_MARKERS, "I11 already applied")
        print("I11 already present; verification only.")
        return
    except Exception:
        pass
    require_markers(root, I10_REQUIRED, "I10 prerequisite")
    p = root / "VeilLink/Security/SessionCoordinator.swift"
    p.write_text(patch_session_coordinator(p.read_text(encoding="utf-8")), encoding="utf-8")
    p = root / "VeilLink/Diagnostics/DeviceStressTestController.swift"
    p.write_text(patch_stress_controller(p.read_text(encoding="utf-8")), encoding="utf-8")
    p = root / "VeilLink/UI/DeviceStressTestView.swift"
    p.write_text(patch_stress_view(p.read_text(encoding="utf-8")), encoding="utf-8")
    copy_payload(root, package_root)
    require_markers(root, I11_MARKERS, "I11 post-apply")


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 I11_APPLY.py /path/to/VeilLink")
    root = Path(sys.argv[1]).resolve()
    if not (root / "project.yml").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")
    apply(root, Path(__file__).resolve().parent)
    print("I11 COLLABORATIVE_STRESS_LAB_READY applied.")


if __name__ == "__main__":
    main()
