# VeilLink Unified Engineering Ledger — I11

## State

`I1 → I11 cumulative`

`COLLABORATIVE_STRESS_LAB_READY`

I11 expands diagnostics/stress coverage. It does not change production chat semantics or declare a new production transport protocol.

## Closed / improved

### STRESS_SINGLE_DEVICE_COVERAGE_GAP
Previous burn-in primarily exercised local UI, BLE churn, storage integrity, Agent/MaleCNS, cache/memory cleanup and diagnostics. I11 adds an actual second-device synchronized load path over an established secure peer session.

### STRESS_TEMP_CHAT_SCHEMA_COLLISION
VeilLink's normal data model has one conversation for a local-identity/peer pair. Creating a second fake “temporary conversation” would collide with real-chat semantics. I11 therefore uses an **ephemeral protocol lane**, not another production Conversation row.

### STRESS_REAL_CHAT_POLLUTION
`VLSTRESS1` control frames are decrypted on the normal authenticated session but intercepted before normal chat persistence. Synthetic bulk message IDs are kept in an in-memory registry so `attachmentChunk` traffic is intercepted before normal attachment tables.

### STRESS_BULK_PATH_NOT_REALISTIC
The discarded early I11 draft represented media as small base64/text chunks. Final I11 instead routes synthetic image and WAV/PCM bytes through the real encrypted `attachmentChunk` + BLE `.bulk` path. A bulk manifest must be accepted before any chunk is emitted.

### STRESS_BULK_MANIFEST_BACKPRESSURE_RACE
During self-audit, a race was found where chunks could theoretically be emitted after an unaccepted manifest. Final I11 retries the manifest first and aborts the transfer if it cannot be locally accepted.

### STRESS_MEMORY_TRIM_MISROUTE_RISK
If a memory-pressure cleanup drops an in-memory stress accumulator while encrypted chunks are still in flight, those chunk IDs remain marked as stress IDs. Late chunks are dropped instead of falling through into production attachment persistence.

### STRESS_EXTERNAL_SYNC_MISSING
Adds coordinator / participant roles, invite / explicit accept / decline, shared session UUID + epoch, synchronized start, local/remote completion and stop/fuse propagation.

### STRESS_TEXT_COVERAGE
Adds bidirectional synthetic text bursts through the secure `encryptedMessage` path. No real chat plaintext is sampled.

### STRESS_IMAGE_COVERAGE
Adds deterministic synthetic binary image-class payloads over the real bulk lane. No Photo Library content is read.

### STRESS_VOICE_CLASS_COVERAGE
Adds deterministic WAV/PCM-style binary payloads. No microphone or environmental audio is recorded. This is a transport/resource proxy only; VeilLink still has no production voice-message protocol.

### STRESS_GAME_COVERAGE
Adds isolated Gomoku pressure using `MiniGameCodec` and `GomokuState`. Self-audit fixed a per-game turn-reset bug so a restarted temporary game begins again with host turn 0 instead of inheriting a global turn parity.

### STRESS_BACKPRESSURE_FALSE_PASS
Self-audit found that an earlier bulk loop could reach its retry limit and continue as if accepted. Final I11 uses an explicit `accepted` gate; retry exhaustion marks the transfer failed.

### STRESS_BLACKBOX_CORRELATION
The regular burn-in export now adds `stress-collaborative.json`. Runtime logs use `stress.collab.*` events and record only structural/numeric metadata, not synthetic payload bodies.


### STRESS_REMOTE_MANIFEST_ACCEPTANCE_GAP
Final re-audit found that local transport acceptance of `bulkBegin` did not prove the peer had created its stress accumulator. I11 now requires an explicit peer `bulkReady` carrying the same transfer/wire IDs before the first bulk chunk can be emitted. This closes the lost-manifest / arriving-chunk production-path hazard.

### STRESS_MESSAGE_ID_TOMBSTONE_GROWTH
Stress wire message IDs are now stored as 10-minute uptime-based tombstones rather than an unbounded Set. Late chunks remain isolated after accumulator trim, while repeated lab sessions cannot grow the guard structure without bound.

## Safety / privacy invariants

- existing trusted contact required;
- Secure Session required;
- remote explicit acceptance required;
- no automatic pairing;
- no real chat plaintext source;
- no user photo source;
- no microphone capture;
- no password/key/prompt logging;
- existing foreground / thermal / battery / memory-warning fuses remain authoritative;
- collaborative stress is lab-only and cannot become a production chat feature through this patch.

## Remaining validation

- real iPhone 7 ↔ iPhone 13 Xcode/IPA build and runtime test;
- weak-link and 1–2 wall RTT/backpressure behavior;
- combined local Burn-In + collaborative bulk + game load;
- memory peak and leak trend during repeated 1–2 MB transfers;
- background/foreground transition during a synchronized epoch;
- verify both peers converge to completed/failed after one-sided disconnect;
- measure old-build visible-text fallback behavior before intentionally testing mixed versions;
- when production Voice Message exists, replace the WAV/PCM proxy with the actual codec pipeline.

No Xcode, XCTest or physical-device PASS is claimed by I11 itself.
