# VeilLink Local Cumulative I11 — Collaborative Stress Lab

I11 continues directly from I10.

State: **COLLABORATIVE_STRESS_LAB_READY**

Apply cumulatively with:

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9_I10_I11.py /path/to/VeilLink
```

Then run the normal XcodeGen → XCTest → iphoneos build chain on macOS.

## What I11 adds

I11 upgrades the existing owner burn-in harness from mostly single-device UI/storage/Agent/BLE churn into an optional synchronized two-device lab.

- invite another **already trusted + Secure Session ready** VeilLink peer;
- remote device must explicitly accept before any load starts;
- establish an ephemeral `VLSTRESS1` E2EE stress channel that is intercepted before normal chat persistence;
- bidirectional high-rate synthetic text traffic through the authenticated encrypted-message path;
- synthetic image-class binary traffic through the real encrypted `attachmentChunk` / BLE bulk lane, gated by a peer `bulkReady` accumulator handshake;
- synthetic WAV/PCM voice-class binary traffic through the same bulk lane, **without microphone capture**;
- temporary Gomoku traffic using the real `MiniGameCodec` and `GomokuState`, isolated from formal game history;
- record accepted/backpressure/dropped frames, bulk integrity receipts, game decode/apply results and ping RTT;
- export `stress-collaborative.json` with the normal black-box bundle.

## Database / privacy boundary

The temporary channel is not a second production conversation. VeilLink currently has one normal conversation per local identity / peer pair, so I11 deliberately does **not** create a fake temporary SQLite conversation.

Control frames reuse the existing authenticated chat cipher for compatibility, but I11 peers intercept the `VLSTRESS1` envelope before `messages` / `conversations` writes. Binary stress chunks are registered in an in-memory accumulator and intercepted before normal attachment persistence. The sender waits for an explicit peer `bulkReady` before emitting chunks; completed/abandoned stress message IDs retain a bounded 10-minute TTL tombstone so late chunks cannot fall into production attachment handling.

The stress lab does not source:

- real chat plaintext;
- user photos;
- microphone recordings;
- passwords / app-lock PINs;
- identity/session keys;
- AI prompts.

## Important voice limitation

Current VeilLink still has no production voice-message wire protocol. I11 therefore generates deterministic WAV/PCM-style test bytes to create voice-sized binary pressure. This tests encryption, chunking, BLE bulk queues and memory pressure, but is **not** a claim that production Voice Message encoding/decoding has been tested.

When a real voice-message codec is added later, it should replace the synthetic generator behind the same collaborative scenario interface.

## Compatibility behavior

I11 uses the existing authenticated `encryptedMessage` envelope for stress control instead of inventing an unknown new `WireKind`. This prevents an older peer from immediately treating the packet kind itself as protocol abuse. However, an older build cannot intercept `VLSTRESS1` before chat persistence and may display the synthetic control text. Therefore two-device stress runs should use the same I11 build on both devices.

## First real-device validation sequence

1. Install the same I11 build on iPhone 7 and iPhone 13.
2. Complete ordinary trust pairing and confirm Secure Session ready.
3. Open Owner → Device Stress on both devices.
4. Select the other secure peer and send a collaborative invitation.
5. Explicitly accept on the other device.
6. Start with text-only, then add image bulk, WAV/PCM bulk, game, and finally BLE churn / local burn-in together.
7. Inspect `stress-collaborative.json`, runtime logs, MetricKit and the normal stress summary.

Static parser and patch audits do not replace Xcode/XCTest or physical-device validation.
