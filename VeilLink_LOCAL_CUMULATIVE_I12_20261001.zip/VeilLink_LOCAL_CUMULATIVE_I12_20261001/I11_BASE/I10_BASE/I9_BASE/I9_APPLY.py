from pathlib import Path
import shutil
import sys

I8_REQUIRED = {
    "VeilLink/Health/VeilKernelRuntimeSelector.swift": [
        'case a10OnlyLab = "A10_ULTRA_ONLY_LAB"',
        'final class VeilKernelRuntimeSelector',
        'productionCutover: "DENIED"',
    ],
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        '@Published private(set) var lastRuntimeSample: VeilKernelRuntimeSampleRecord?',
        'func evaluateA10UltraIsolated(',
        'func recordA9Only(',
    ],
    "VeilLink/Agent/Compute/A9ComputeGovernor.swift": [
        '@Published private(set) var planFrozen = false',
        'func setPlanFrozen(_ frozen: Bool)',
    ],
    "VeilLink/App/AppModel.swift": [
        'let kernelRuntime: VeilKernelRuntimeSelector',
        'switch runtimeEnvironment.mode',
        'case .a10OnlyLab:',
        'func setKernelRuntimeMode(_ mode: VeilKernelRuntimeMode)',
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "kernel.runtime_sample"',
        '"kernel_mode": env.mode.rawValue',
    ],
}

I9_MARKERS = {
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        'func resetRuntimeEpoch(reason: String)',
        '@Published private(set) var runtimeEpochResetCount: UInt64 = 0',
        'activeProcessorCount: Int',
        'physicalMemoryBytes: UInt64',
        'let combinedCPU = baseline.cpu &+ ultraCPU',
    ],
    "VeilLink/Agent/Compute/A9ComputeGovernor.swift": [
        'recomputeOnUnfreeze: Bool = true',
    ],
    "VeilLink/App/AppModel.swift": [
        'private var hostForegroundActive = true',
        'gameRuntimeState: gameIntelligence.context == nil ? "IDLE" : "ACTIVE"',
        'VeilKernelHostSafetyPolicy.fallbackReason(for: input)',
        'recomputeOnUnfreeze: false',
        'a10Ultra.resetRuntimeEpoch(reason:',
    ],
    "VeilLink/Health/VeilKernelHostSafetyPolicy.swift": [
        'enum VeilKernelHostSafetyPolicy',
        'HOST_STORAGE_P0_FALLBACK',
        'HOST_THERMAL_CRITICAL_FALLBACK',
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        '"signal_provenance": "RAW_HOST_PRE_DECISION"',
        '"combined_cpu_us": String((record.a9CPUNanos &+ record.ultraCPUNanos) / 1_000)',
    ],
}

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)

def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")

def patch_shadow(text: str) -> str:
    text = replace_once(text,
'''struct A10UltraOmegaHostContext: Equatable, Sendable {
    let foregroundActive: Bool
    let computeMode: String
    let totalComputeUnits: Int
    let transportReserveUnits: Int
    let systemAvailable: Bool
    let gameRuntimeState: String
}''',
'''struct A10UltraOmegaHostContext: Equatable, Sendable {
    // Raw host facts only. Never place A9 Decision / Compute Plan outputs in this structure.
    let foregroundActive: Bool
    let systemAvailable: Bool
    let gameRuntimeState: String
    let activeProcessorCount: Int
    let physicalMemoryBytes: UInt64
}''', 'raw host context')

    text = replace_once(text,
'''    @Published private(set) var lastRuntimeSample: VeilKernelRuntimeSampleRecord?
    @Published private(set) var isolatedSampleCount: UInt64 = 0

    private var epoch: UInt64 = 0''',
'''    @Published private(set) var lastRuntimeSample: VeilKernelRuntimeSampleRecord?
    @Published private(set) var isolatedSampleCount: UInt64 = 0
    @Published private(set) var runtimeEpochResetCount: UInt64 = 0
    @Published private(set) var lastRuntimeEpochResetReason = "BOOT"

    private var epoch: UInt64 = 0''', 'runtime epoch publications')

    anchor = '    func makeSharedSample(input: VeilA9Input, hostContext: A10UltraOmegaHostContext) -> A10UltraOmegaSharedSample {'
    insertion = '''    /// Runtime-mode boundaries are measurement boundaries. Persistence and pending A9 pairing
    /// must never leak across A9-only / Dual / A10-only experiments.
    func resetRuntimeEpoch(reason: String) {
        pendingA9 = nil
        ultraNonGreenSinceUptime = nil
        runtimeEpochResetCount &+= 1
        lastRuntimeEpochResetReason = reason
    }

'''
    text = replace_once(text, anchor, insertion + anchor, 'runtime epoch reset method')

    text = replace_once(text,
'''            String(input.lowPowerMode), input.databaseIntegrity.title, String(context.foregroundActive), context.computeMode,
            String(context.totalComputeUnits), String(context.transportReserveUnits), String(context.systemAvailable), context.gameRuntimeState
''',
'''            String(input.lowPowerMode), input.databaseIntegrity.title, String(context.foregroundActive),
            String(context.systemAvailable), context.gameRuntimeState, String(context.activeProcessorCount),
            String(context.physicalMemoryBytes)
''', 'raw signal digest context')

    text = replace_once(text,
'''            let rss = max(rssBefore, A10UltraOmegaMetrics.rssBytes())
            let divergence = Self.classify(a9: baseline.decision, ultra: result.compatibilityDecision)
            let match = divergence == .d0
            let energyProxy = max(1, cpuEnd &- cpuStart) * UInt64(max(1, sample.rawInput.thermalLevel.rawValue + 1))
''',
'''            let rss = max(rssBefore, A10UltraOmegaMetrics.rssBytes())
            let divergence = Self.classify(a9: baseline.decision, ultra: result.compatibilityDecision)
            let match = divergence == .d0
            let ultraCPU = cpuEnd &- cpuStart
            let combinedCPU = baseline.cpu &+ ultraCPU
            let energyProxy = max(1, combinedCPU) * UInt64(max(1, sample.rawInput.thermalLevel.rawValue + 1))
''', 'dual combined energy')

    text = replace_once(text,
'''                a9LatencyNanos: baseline.latency, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: baseline.cpu, ultraCPUNanos: cpuEnd &- cpuStart,
                ultraPhysicalSlotCount: result.physicalSlotCount, rssBytes: rss,
''',
'''                a9LatencyNanos: baseline.latency, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: baseline.cpu, ultraCPUNanos: ultraCPU,
                ultraPhysicalSlotCount: result.physicalSlotCount, rssBytes: rss,
''', 'dual ultra cpu reuse')

    text = replace_once(text,
'''        } catch {
            let wallEnd = A10UltraOmegaMetrics.monotonicNanos()
            let cpuEnd = A10UltraOmegaMetrics.threadCPUNanos()
            let record = A10UltraOmegaComparisonRecord(''',
'''        } catch {
            let wallEnd = A10UltraOmegaMetrics.monotonicNanos()
            let cpuEnd = A10UltraOmegaMetrics.threadCPUNanos()
            let ultraCPU = cpuEnd &- cpuStart
            let combinedCPU = baseline.cpu &+ ultraCPU
            let record = A10UltraOmegaComparisonRecord(''', 'dual failure cpu accounting')

    text = replace_once(text,
'''                a9LatencyNanos: baseline.latency, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: baseline.cpu, ultraCPUNanos: cpuEnd &- cpuStart,
                ultraPhysicalSlotCount: 0, rssBytes: A10UltraOmegaMetrics.rssBytes(),
                thermalState: sample.rawInput.thermalLevel.rawValue,
                batteryPermille: A10UltraOmegaMetrics.batteryPermille(), energyProxy: 0,
''',
'''                a9LatencyNanos: baseline.latency, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: baseline.cpu, ultraCPUNanos: ultraCPU,
                ultraPhysicalSlotCount: 0, rssBytes: A10UltraOmegaMetrics.rssBytes(),
                thermalState: sample.rawInput.thermalLevel.rawValue,
                batteryPermille: A10UltraOmegaMetrics.batteryPermille(),
                energyProxy: max(1, combinedCPU) * UInt64(max(1, sample.rawInput.thermalLevel.rawValue + 1)),
''', 'dual failure combined energy')

    text = replace_once(text,
r'''            "Fallback events: \(state.fallbackEventCount)",
            "Isolated lab samples: \(isolatedSampleCount)",
            "Mutation authority: 0",''',
r'''            "Fallback events: \(state.fallbackEventCount)",
            "Isolated lab samples: \(isolatedSampleCount)",
            "Runtime epoch resets: \(runtimeEpochResetCount) · last \(lastRuntimeEpochResetReason)",
            "Mutation authority: 0",''', 'runtime reset diagnostics')
    return text

def patch_governor(text: str) -> str:
    return replace_once(text,
'''    func setPlanFrozen(_ frozen: Bool) {
        guard planFrozen != frozen else { return }
        planFrozen = frozen
        if !frozen { recompute() }
    }''',
'''    func setPlanFrozen(_ frozen: Bool, recomputeOnUnfreeze: Bool = true) {
        guard planFrozen != frozen else { return }
        planFrozen = frozen
        if !frozen, recomputeOnUnfreeze { recompute() }
    }''', 'non-stale unfreeze control')

def patch_app_model(text: str) -> str:
    text = replace_once(text,
'''    private var pendingConversationRefresh = false
    private static let autoSaveReceivedImagesKey = "media.autoSaveReceivedImages"
''',
'''    private var pendingConversationRefresh = false
    private var hostForegroundActive = true
    private static let autoSaveReceivedImagesKey = "media.autoSaveReceivedImages"
''', 'host lifecycle state')

    text = replace_once(text,
'''        kernelRuntime.$mode
            .sink { [weak self] mode in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.computeGovernor.setPlanFrozen(mode == .a10OnlyLab)
                    self.scheduleA9Refresh()
                }
            }
            .store(in: &a9Cancellables)
''', '', 'remove async mode side-effect sink')

    text = replace_once(text,
'''        let ultraContext = A10UltraOmegaHostContext(
            foregroundActive: computeGovernor.foregroundActive,
            computeMode: computeGovernor.plan.mode.rawValue,
            totalComputeUnits: computeGovernor.plan.totalComputeUnits,
            transportReserveUnits: computeGovernor.plan.transportReserveUnits,
            systemAvailable: true,
            gameRuntimeState: "HOST_MANAGED"
        )''',
'''        let ultraContext = A10UltraOmegaHostContext(
            foregroundActive: hostForegroundActive,
            systemAvailable: true,
            gameRuntimeState: gameIntelligence.context == nil ? "IDLE" : "ACTIVE",
            activeProcessorCount: max(1, ProcessInfo.processInfo.activeProcessorCount),
            physicalMemoryBytes: ProcessInfo.processInfo.physicalMemory
        )''', 'raw A10 host context')

    text = replace_once(text,
'''        case .a10OnlyLab:
            let ultraHealthy = a10Ultra.evaluateA10UltraIsolated(sample: ultraSample, runtime: runtimeEnvironment)
            if !ultraHealthy {
                computeGovernor.setPlanFrozen(false)
                kernelRuntime.forceA9Fallback(reason: "ULTRA_INTERNAL_FAILURE")
                scheduleA9Refresh()
            }
        }''',
'''        case .a10OnlyLab:
            let ultraHealthy = a10Ultra.evaluateA10UltraIsolated(sample: ultraSample, runtime: runtimeEnvironment)
            let hostSafetyReason = VeilKernelHostSafetyPolicy.fallbackReason(for: input)
            if !ultraHealthy || hostSafetyReason != nil {
                let reason = hostSafetyReason?.rawValue ?? "ULTRA_INTERNAL_FAILURE"
                kernelRuntime.forceA9Fallback(reason: reason)
                a10Ultra.resetRuntimeEpoch(reason: reason)
                computeGovernor.setPlanFrozen(false, recomputeOnUnfreeze: false)
                // Recover A9 on the next MainActor turn, not after the ordinary 600 ms debounce.
                Task { @MainActor [weak self] in self?.refreshA9Health() }
            }
        }''', 'lab immediate safe fallback')

    text = replace_once(text,
'''    func setKernelRuntimeMode(_ mode: VeilKernelRuntimeMode) {
        computeGovernor.setPlanFrozen(mode == .a10OnlyLab)
        kernelRuntime.select(mode, source: "USER")
        refreshA9Health()
    }

    func exitA10OnlyLabToA9() {
        computeGovernor.setPlanFrozen(false)
        kernelRuntime.forceA9Fallback(reason: "USER_EXIT_LAB")
        refreshA9Health()
    }
''',
'''    func setKernelRuntimeMode(_ mode: VeilKernelRuntimeMode) {
        guard mode != kernelRuntime.mode else { return }
        if mode == .a10OnlyLab {
            // Freeze before entering LAB so no A9 plan can mutate between selection and first sample.
            computeGovernor.setPlanFrozen(true)
            a10Ultra.resetRuntimeEpoch(reason: "ENTER_A10_ONLY_LAB")
            kernelRuntime.select(mode, source: "USER")
        } else {
            // Switch authority label first, clear Ultra persistence, then unfreeze without replaying
            // the stale pre-LAB A9 decision. The fresh sample below supplies the next A9 plan.
            kernelRuntime.select(mode, source: "USER")
            a10Ultra.resetRuntimeEpoch(reason: "MODE_CHANGE_\\(mode.rawValue)")
            computeGovernor.setPlanFrozen(false, recomputeOnUnfreeze: false)
        }
        refreshA9Health()
    }

    func exitA10OnlyLabToA9() {
        kernelRuntime.forceA9Fallback(reason: "USER_EXIT_LAB")
        a10Ultra.resetRuntimeEpoch(reason: "USER_EXIT_LAB")
        computeGovernor.setPlanFrozen(false, recomputeOnUnfreeze: false)
        refreshA9Health()
    }
''', 'transactional runtime mode switch')

    text = replace_once(text,
'''    func handleForegroundTransition() {
        computeGovernor.setForegroundActive(true)
        refreshA9Health()''',
'''    func handleForegroundTransition() {
        hostForegroundActive = true
        computeGovernor.setForegroundActive(true)
        refreshA9Health()''', 'host foreground true')

    text = replace_once(text,
'''    func handleBackgroundTransition() {
        computeGovernor.setForegroundActive(false)''',
'''    func handleBackgroundTransition() {
        hostForegroundActive = false
        computeGovernor.setForegroundActive(false)''', 'host foreground false')
    return text

def patch_diagnostics(text: str) -> str:
    text = replace_once(text,
'''                            "signal_digest": record.signalDigest,
                            "a9_light": record.a9Decision?.light ?? "disabled",''',
'''                            "signal_digest": record.signalDigest,
                            "signal_provenance": "RAW_HOST_PRE_DECISION",
                            "a9_light": record.a9Decision?.light ?? "disabled",''', 'raw signal provenance telemetry')
    text = replace_once(text,
'''                            "a9_cpu_us": String(record.a9CPUNanos / 1_000),
                            "ultra_cpu_us": String(record.ultraCPUNanos / 1_000),''',
'''                            "a9_cpu_us": String(record.a9CPUNanos / 1_000),
                            "ultra_cpu_us": String(record.ultraCPUNanos / 1_000),
                            "combined_cpu_us": String((record.a9CPUNanos &+ record.ultraCPUNanos) / 1_000),''', 'combined cpu telemetry')
    text = replace_once(text,
'''                            "energy_proxy": String(record.energyProxy),
                            "ble_state": record.bleState,''',
'''                            "energy_proxy": String(record.energyProxy),
                            "energy_proxy_scope": env.mode == .dualShadow ? "COMBINED_A9_ULTRA" : "ACTIVE_RAIL_ONLY",
                            "ble_state": record.bleState,''', 'energy scope telemetry')
    return text

def patch_shadow_tests(text: str) -> str:
    old = '''        let context = A10UltraOmegaHostContext(
            foregroundActive: true, computeMode: "balanced", totalComputeUnits: 400,
            transportReserveUnits: 40, systemAvailable: true, gameRuntimeState: "HOST_MANAGED"
        )'''
    new = '''        let context = A10UltraOmegaHostContext(
            foregroundActive: true, systemAvailable: true, gameRuntimeState: "IDLE",
            activeProcessorCount: 4, physicalMemoryBytes: 2_000_000_000
        )'''
    if text.count(old) != 2:
        raise RuntimeError(f"shadow test context: expected 2 matches, found {text.count(old)}")
    text = text.replace(old, new)
    anchor = '\n    func testStage0NeverPromotesUltra() {'
    addition = '''
    func testRuntimeEpochResetIsExplicitAndObservable() {
        let coordinator = A10UltraOmegaShadowCoordinator()
        XCTAssertEqual(coordinator.runtimeEpochResetCount, 0)
        coordinator.resetRuntimeEpoch(reason: "TEST_MODE_BOUNDARY")
        XCTAssertEqual(coordinator.runtimeEpochResetCount, 1)
        XCTAssertEqual(coordinator.lastRuntimeEpochResetReason, "TEST_MODE_BOUNDARY")
    }

'''
    return replace_once(text, anchor, '\n' + addition + '    func testStage0NeverPromotesUltra() {', 'epoch reset test')

def copy_payload(here: Path, root: Path) -> None:
    mapping = {
        here / "Payload/VeilLink/Health/VeilKernelHostSafetyPolicy.swift": root / "VeilLink/Health/VeilKernelHostSafetyPolicy.swift",
        here / "Payload/VeilLinkTests/VeilKernelHostSafetyPolicyTests.swift": root / "VeilLinkTests/VeilKernelHostSafetyPolicyTests.swift",
        here / "Payload/docs/A10UltraOmega/I9_RUNTIME_ISOLATION_HARDENING.md": root / "docs/A10UltraOmega/I9_RUNTIME_ISOLATION_HARDENING.md",
    }
    for src, dst in mapping.items():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: I9_APPLY.py <VeilLink repo root>")
    root = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    if (root / "VeilLink/Health/VeilKernelHostSafetyPolicy.swift").exists():
        require_markers(root, I9_MARKERS, "I9 verify")
        print("I9 already applied; markers verified.")
        return
    require_markers(root, I8_REQUIRED, "I8 prerequisite")
    targets = {
        "VeilLink/Health/A10UltraOmegaShadow.swift": patch_shadow,
        "VeilLink/Agent/Compute/A9ComputeGovernor.swift": patch_governor,
        "VeilLink/App/AppModel.swift": patch_app_model,
        "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": patch_diagnostics,
        "VeilLinkTests/A10UltraOmegaShadowTests.swift": patch_shadow_tests,
    }
    transformed = {rel: fn((root/rel).read_text(encoding="utf-8")) for rel, fn in targets.items()}
    backup = root / ".veillink-local-iter/I9-backup"
    if backup.exists(): shutil.rmtree(backup)
    for rel in targets:
        src = root/rel; dst = backup/rel
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, dst)
    for rel, value in transformed.items():
        (root/rel).write_text(value, encoding="utf-8")
    copy_payload(here, root)
    require_markers(root, I9_MARKERS, "I9 post-apply")
    print("I9 applied: raw-host isolation + runtime-epoch isolation + safe LAB recovery.")

if __name__ == "__main__":
    main()
