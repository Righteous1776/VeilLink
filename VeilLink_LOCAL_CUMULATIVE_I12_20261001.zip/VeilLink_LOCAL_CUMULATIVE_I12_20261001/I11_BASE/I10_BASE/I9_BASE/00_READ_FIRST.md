# VeilLink I9 — Deep Repair / Shadow Isolation

I9 is cumulative on I8 and does **not** promote A10 Ultra Ω to production authority.

Apply:

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9.py /path/to/VeilLink
```

Then run the normal XcodeGen / XCTest / iphoneos build chain.

The key correction is architectural: A10 Ultra Ω no longer receives A9 Compute Plan outputs in its HostContext or signal digest. Both rails branch from the same pre-decision host health input.
