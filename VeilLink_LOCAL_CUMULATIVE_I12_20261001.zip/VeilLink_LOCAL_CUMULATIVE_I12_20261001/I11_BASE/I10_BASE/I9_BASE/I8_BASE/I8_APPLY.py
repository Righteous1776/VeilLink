from pathlib import Path
import shutil
import sys

I7_REQUIRED = {
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        'static let chipName = "A10 Ultra Ω"',
        'final class A10UltraOmegaShadowCoordinator',
        'func evaluateA10UltraShadow(sample: A10UltraOmegaSharedSample)',
    ],
    "VeilLink/App/AppModel.swift": [
        "let a10Ultra: A10UltraOmegaShadowCoordinator",
        "a10Ultra = A10UltraOmegaShadowCoordinator()",
        "a10Ultra.evaluateA10UltraShadow(sample: ultraSample)",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "a10_ultra.shadow_sample"',
    ],
    "VeilLink/Agent/Compute/A9ComputeGovernor.swift": [
        "final class VeilA9ComputeGovernor",
        "private func recompute()",
    ],
}

I8_MARKERS = {
    "VeilLink/Health/VeilKernelRuntimeSelector.swift": [
        'case a9Only = "A9_ONLY"',
        'case dualShadow = "A9_PLUS_A10_ULTRA_SHADOW"',
        'case a10OnlyLab = "A10_ULTRA_ONLY_LAB"',
        'final class VeilKernelRuntimeSelector',
        'productionCutover: "DENIED"',
    ],
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        "@Published private(set) var lastRuntimeSample: VeilKernelRuntimeSampleRecord?",
        "func recordA9Only(",
        "func evaluateA10UltraIsolated(",
        "runtime: VeilKernelRuntimeEnvironment? = nil",
        "Isolated lab samples:",
    ],
    "VeilLink/Agent/Compute/A9ComputeGovernor.swift": [
        "@Published private(set) var planFrozen = false",
        "func setPlanFrozen(_ frozen: Bool)",
        "guard !planFrozen else { return }",
    ],
    "VeilLink/App/AppModel.swift": [
        "let kernelRuntime: VeilKernelRuntimeSelector",
        "kernelRuntime = VeilKernelRuntimeSelector()",
        "switch runtimeEnvironment.mode",
        "case .a10OnlyLab:",
        "a10Ultra.evaluateA10UltraIsolated",
        "func setKernelRuntimeMode(_ mode: VeilKernelRuntimeMode)",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "kernel.runtime_mode"',
        'event: "kernel.runtime_sample"',
        '"kernel_mode": env.mode.rawValue',
        '"production_authority": env.productionAuthority',
    ],
    "VeilLink/UI/SettingsView.swift": [
        "private var kernelRuntimeCard: some View",
        'Label("内核运行模式", systemImage: "cpu")',
        'A10 Ultra Ω 单轨实验不会成为生产 Cutover',
        'alert("进入 A10 Ultra Ω 单轨实验？"',
    ],
    "VeilLinkTests/VeilKernelRuntimeSelectorTests.swift": [
        "testA10OnlyLabDisablesA9ButDoesNotGrantProductionAuthority",
        "testA10OnlyLabIsNotPersistedAcrossRestart",
    ],
}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_a10_shadow(text: str) -> str:
    text = replace_once(
        text,
        "    @Published private(set) var state = A10UltraOmegaShadowState.initial\n    @Published private(set) var lastComparison: A10UltraOmegaComparisonRecord?\n",
        "    @Published private(set) var state = A10UltraOmegaShadowState.initial\n    @Published private(set) var lastComparison: A10UltraOmegaComparisonRecord?\n    @Published private(set) var lastRuntimeSample: VeilKernelRuntimeSampleRecord?\n    @Published private(set) var isolatedSampleCount: UInt64 = 0\n",
        "runtime sample publications",
    )
    text = replace_once(
        text,
        "    func evaluateA10UltraShadow(sample: A10UltraOmegaSharedSample) {",
        "    func evaluateA10UltraShadow(sample: A10UltraOmegaSharedSample, runtime: VeilKernelRuntimeEnvironment? = nil) {",
        "shadow runtime environment signature",
    )
    text = replace_once(
        text,
        "    func evaluate(_ sample: A10UltraOmegaSharedSample, persistenceSeconds: Int) -> A10UltraOmegaShadowDecision {",
        "    func evaluate(_ sample: A10UltraOmegaSharedSample, persistenceSeconds: Int) throws -> A10UltraOmegaShadowDecision {",
        "Ultra runner throwable backend contract",
    )
    text = replace_once(
        text,
        "            let result = runner.evaluate(sample, persistenceSeconds: ultraPersistenceSeconds)",
        "            let result = try runner.evaluate(sample, persistenceSeconds: ultraPersistenceSeconds)",
        "dual Ultra runner try",
    )
    text = replace_once(
        text,
        "            lastComparison = record\n            state = Self.increment(state, divergence: divergence, fallback: false)",
        "            lastComparison = record\n            if let runtime { lastRuntimeSample = Self.runtimeRecord(from: record, environment: runtime) }\n            state = Self.increment(state, divergence: divergence, fallback: false)",
        "dual success runtime record",
    )
    text = replace_once(
        text,
        "            lastComparison = record\n            state = Self.increment(state, divergence: .d5, fallback: true)",
        "            lastComparison = record\n            if let runtime { lastRuntimeSample = Self.runtimeRecord(from: record, environment: runtime) }\n            state = Self.increment(state, divergence: .d5, fallback: true)",
        "dual failure runtime record",
    )

    anchor = "\n    func setTestPhase(_ phase: A10UltraOmegaTestPhase) {\n"
    if text.count(anchor) != 1:
        raise RuntimeError(f"isolated methods anchor: expected 1, found {text.count(anchor)}")
    insertion = r'''
    func recordA9Only(
        sample: A10UltraOmegaSharedSample,
        decision: VeilA9Decision,
        budget: VeilA9ComputePlan,
        latencyNanos: UInt64,
        cpuNanos: UInt64,
        runtime: VeilKernelRuntimeEnvironment
    ) {
        let a9 = VeilKernelDecisionSnapshot.fromA9(decision)
        let envelope = VeilKernelComputeBudgetEnvelope.fromA9(budget)
        let energyProxy = max(1, cpuNanos) * UInt64(max(1, sample.rawInput.thermalLevel.rawValue + 1))
        lastRuntimeSample = VeilKernelRuntimeSampleRecord(
            sampleID: sample.sampleID, epoch: sample.epoch, timestamp: sample.timestamp,
            sourceDomains: sample.sourceDomains, signalDigest: sample.signalDigest, environment: runtime,
            a9Decision: a9, ultraDecision: nil, a9Budget: envelope, ultraBudget: nil,
            decisionMatch: nil, divergenceClass: "NOT_COMPARABLE_A9_ONLY",
            a9LatencyNanos: latencyNanos, ultraLatencyNanos: 0,
            a9CPUNanos: cpuNanos, ultraCPUNanos: 0, ultraPhysicalSlotCount: 0,
            rssBytes: A10UltraOmegaMetrics.rssBytes(), thermalState: sample.rawInput.thermalLevel.rawValue,
            batteryPermille: A10UltraOmegaMetrics.batteryPermille(), energyProxy: energyProxy,
            bleState: Self.bleState(for: sample.rawInput), queueDepth: sample.rawInput.controlPendingPackets,
            droppedEventCount: state.droppedEventCount, ultraRestartCount: 0,
            fallbackEvent: false, guardianStatus: "NOT_ACTIVE", rageStatus: "NOT_ACTIVE", vaultStatus: "NOT_ACTIVE",
            runtimeBackend: "A9_ONLY"
        )
    }

    @discardableResult
    func evaluateA10UltraIsolated(
        sample: A10UltraOmegaSharedSample,
        runtime: VeilKernelRuntimeEnvironment
    ) -> Bool {
        let preliminary = A10UltraOmegaCompatibilityNormalizer.aggregate(sample.rawInput, persistenceSeconds: 0)
        let ultraPersistenceSeconds: Int
        if preliminary.light == 0 {
            ultraNonGreenSinceUptime = nil
            ultraPersistenceSeconds = 0
        } else if let since = ultraNonGreenSinceUptime, sample.uptime >= since {
            ultraPersistenceSeconds = min(9_999, Int(sample.uptime - since))
        } else {
            ultraNonGreenSinceUptime = sample.uptime
            ultraPersistenceSeconds = 0
        }

        let wallStart = A10UltraOmegaMetrics.monotonicNanos()
        let cpuStart = A10UltraOmegaMetrics.threadCPUNanos()
        let rssBefore = A10UltraOmegaMetrics.rssBytes()
        do {
            let result = try runner.evaluate(sample, persistenceSeconds: ultraPersistenceSeconds)
            let wallEnd = A10UltraOmegaMetrics.monotonicNanos()
            let cpuEnd = A10UltraOmegaMetrics.threadCPUNanos()
            let rss = max(rssBefore, A10UltraOmegaMetrics.rssBytes())
            let cpuNanos = cpuEnd &- cpuStart
            isolatedSampleCount &+= 1
            lastRuntimeSample = VeilKernelRuntimeSampleRecord(
                sampleID: sample.sampleID, epoch: sample.epoch, timestamp: sample.timestamp,
                sourceDomains: sample.sourceDomains, signalDigest: sample.signalDigest, environment: runtime,
                a9Decision: nil, ultraDecision: result.compatibilityDecision,
                a9Budget: nil, ultraBudget: result.budget,
                decisionMatch: nil, divergenceClass: "NOT_COMPARABLE_A10_ONLY_LAB",
                a9LatencyNanos: 0, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: 0, ultraCPUNanos: cpuNanos,
                ultraPhysicalSlotCount: result.physicalSlotCount, rssBytes: rss,
                thermalState: sample.rawInput.thermalLevel.rawValue,
                batteryPermille: A10UltraOmegaMetrics.batteryPermille(),
                energyProxy: max(1, cpuNanos) * UInt64(max(1, sample.rawInput.thermalLevel.rawValue + 1)),
                bleState: Self.bleState(for: sample.rawInput), queueDepth: sample.rawInput.controlPendingPackets,
                droppedEventCount: state.droppedEventCount, ultraRestartCount: 0,
                fallbackEvent: false, guardianStatus: result.guardianStatus, rageStatus: result.rageStatus, vaultStatus: result.vaultStatus,
                runtimeBackend: result.backend
            )
            return true
        } catch {
            let wallEnd = A10UltraOmegaMetrics.monotonicNanos()
            let cpuEnd = A10UltraOmegaMetrics.threadCPUNanos()
            lastRuntimeSample = VeilKernelRuntimeSampleRecord(
                sampleID: sample.sampleID, epoch: sample.epoch, timestamp: sample.timestamp,
                sourceDomains: sample.sourceDomains, signalDigest: sample.signalDigest, environment: runtime,
                a9Decision: nil, ultraDecision: nil, a9Budget: nil, ultraBudget: nil,
                decisionMatch: false, divergenceClass: A10UltraOmegaDivergenceClass.d5.rawValue,
                a9LatencyNanos: 0, ultraLatencyNanos: wallEnd &- wallStart,
                a9CPUNanos: 0, ultraCPUNanos: cpuEnd &- cpuStart,
                ultraPhysicalSlotCount: 0, rssBytes: A10UltraOmegaMetrics.rssBytes(),
                thermalState: sample.rawInput.thermalLevel.rawValue,
                batteryPermille: A10UltraOmegaMetrics.batteryPermille(), energyProxy: 0,
                bleState: Self.bleState(for: sample.rawInput), queueDepth: sample.rawInput.controlPendingPackets,
                droppedEventCount: state.droppedEventCount, ultraRestartCount: 1,
                fallbackEvent: true, guardianStatus: "FAILED", rageStatus: "FAILED", vaultStatus: "FAILED",
                runtimeBackend: A10UltraOmegaRelease.runtimeBackend
            )
            return false
        }
    }
'''
    text = text.replace(anchor, insertion + anchor, 1)

    text = replace_once(
        text,
        '            "Fallback events: \\(state.fallbackEventCount)",\n            "Mutation authority: 0",',
        '            "Fallback events: \\(state.fallbackEventCount)",\n            "Isolated lab samples: \\(isolatedSampleCount)",\n            "Mutation authority: 0",',
        "isolated count report",
    )

    helper_anchor = "\n    private static func classify(a9: VeilKernelDecisionSnapshot, ultra: VeilKernelDecisionSnapshot) -> A10UltraOmegaDivergenceClass {\n"
    if text.count(helper_anchor) != 1:
        raise RuntimeError(f"runtime helper anchor: expected 1, found {text.count(helper_anchor)}")
    helper = r'''
    private static func runtimeRecord(
        from record: A10UltraOmegaComparisonRecord,
        environment: VeilKernelRuntimeEnvironment
    ) -> VeilKernelRuntimeSampleRecord {
        VeilKernelRuntimeSampleRecord(
            sampleID: record.sampleID, epoch: record.epoch, timestamp: record.timestamp,
            sourceDomains: record.sourceDomains, signalDigest: record.signalDigest, environment: environment,
            a9Decision: record.a9, ultraDecision: record.ultra,
            a9Budget: record.a9Budget, ultraBudget: record.ultraBudget,
            decisionMatch: record.decisionMatch, divergenceClass: record.divergence.rawValue,
            a9LatencyNanos: record.a9LatencyNanos, ultraLatencyNanos: record.ultraLatencyNanos,
            a9CPUNanos: record.a9CPUNanos, ultraCPUNanos: record.ultraCPUNanos,
            ultraPhysicalSlotCount: record.ultraPhysicalSlotCount, rssBytes: record.rssBytes,
            thermalState: record.thermalState, batteryPermille: record.batteryPermille,
            energyProxy: record.energyProxy, bleState: record.bleState, queueDepth: record.queueDepth,
            droppedEventCount: record.droppedEventCount, ultraRestartCount: record.ultraRestartCount,
            fallbackEvent: record.fallbackEvent,
            guardianStatus: record.guardianStatus, rageStatus: record.rageStatus, vaultStatus: record.vaultStatus,
            runtimeBackend: record.runtimeBackend
        )
    }

    private static func bleState(for input: VeilA9Input) -> String {
        input.bluetoothRunning ? (input.connectedPeerCount > 0 ? "CONNECTED" : "RUNNING_NO_PEER") : "STOPPED"
    }
'''
    text = text.replace(helper_anchor, helper + helper_anchor, 1)
    return text



def patch_governor(text: str) -> str:
    text = replace_once(
        text,
        "    @Published private(set) var experimentalCoreEnabled = false\n",
        "    @Published private(set) var experimentalCoreEnabled = false\n    @Published private(set) var planFrozen = false\n",
        "governor frozen state",
    )
    method_anchor = '''    func setExperimentalCoreEnabled(_ enabled: Bool) {
        guard experimentalCoreEnabled != enabled else { return }
        experimentalCoreEnabled = enabled
        recompute()
    }
'''
    method_new = method_anchor + '''
    /// I8 LAB isolation: keep the last already-committed A9 plan byte-for-byte stable while
    /// A10 Ultra Ω is measured alone. Unfreezing immediately recomputes from the last A9 decision.
    func setPlanFrozen(_ frozen: Bool) {
        guard planFrozen != frozen else { return }
        planFrozen = frozen
        if !frozen { recompute() }
    }
'''
    text = replace_once(text, method_anchor, method_new, "governor freeze method")
    text = replace_once(
        text,
        "    private func recompute() {\n        plan = VeilA9ComputePlanner.plan(",
        "    private func recompute() {\n        guard !planFrozen else { return }\n        plan = VeilA9ComputePlanner.plan(",
        "governor recompute freeze gate",
    )
    text = replace_once(
        text,
        '            "Experimental Core authorized: \\(experimentalCoreEnabled ? "yes" : "no")",\n',
        '            "Experimental Core authorized: \\(experimentalCoreEnabled ? "yes" : "no")",\n            "Plan frozen: \\(planFrozen ? "yes" : "no")",\n',
        "governor report freeze state",
    )
    return text

def patch_app_model(text: str) -> str:
    text = replace_once(
        text,
        "    let latticeKernel: VeilLatticeKernelBridge\n    let a10Ultra: A10UltraOmegaShadowCoordinator\n    let agentControls: AgentControlCenterSettings\n",
        "    let latticeKernel: VeilLatticeKernelBridge\n    let a10Ultra: A10UltraOmegaShadowCoordinator\n    let kernelRuntime: VeilKernelRuntimeSelector\n    let agentControls: AgentControlCenterSettings\n",
        "kernel runtime property",
    )
    text = replace_once(
        text,
        "        latticeKernel = VeilLatticeKernelBridge()\n        a10Ultra = A10UltraOmegaShadowCoordinator()\n        agentControls = AgentControlCenterSettings()\n",
        "        latticeKernel = VeilLatticeKernelBridge()\n        a10Ultra = A10UltraOmegaShadowCoordinator()\n        kernelRuntime = VeilKernelRuntimeSelector()\n        agentControls = AgentControlCenterSettings()\n",
        "kernel runtime initialization",
    )

    monitor_anchor = '''        a9Health.$decision
            .sink { [weak self] decision in
                Task { @MainActor [weak self] in self?.computeGovernor.update(decision: decision) }
            }
            .store(in: &a9Cancellables)
'''
    monitor_new = monitor_anchor + '''        kernelRuntime.$mode
            .sink { [weak self] mode in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.computeGovernor.setPlanFrozen(mode == .a10OnlyLab)
                    self.scheduleA9Refresh()
                }
            }
            .store(in: &a9Cancellables)
'''
    text = replace_once(text, monitor_anchor, monitor_new, "kernel mode monitoring")

    old_flow = '''        // I7 Stage 0: create one raw-host sample before either decision rail consumes it.
        // A9 stays production-authoritative. A10 Ultra Ω receives the same raw VeilA9Input copy
        // through its Host Adapter and never consumes an A9 Decision as input.
        let ultraContext = A10UltraOmegaHostContext(
            foregroundActive: computeGovernor.foregroundActive,
            computeMode: computeGovernor.plan.mode.rawValue,
            totalComputeUnits: computeGovernor.plan.totalComputeUnits,
            transportReserveUnits: computeGovernor.plan.transportReserveUnits,
            systemAvailable: true,
            gameRuntimeState: "HOST_MANAGED"
        )
        let ultraSample = a10Ultra.makeSharedSample(input: input, hostContext: ultraContext)
        let a9Timing = A10UltraOmegaShadowCoordinator.timingStart()
        a9Health.evaluate(input)
        // Ensure the baseline budget recorded for this exact sample is current. The existing
        // Combine observer may recompute the same plan again; this explicit update is idempotent.
        computeGovernor.update(decision: a9Health.decision)
        latticeKernel.recordComputePlan(computeGovernor.plan)
        let a9Elapsed = A10UltraOmegaShadowCoordinator.timingElapsed(from: a9Timing)
        latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)
        a10Ultra.recordA9Primary(
            sample: ultraSample,
            decision: a9Health.decision,
            budget: computeGovernor.plan,
            latencyNanos: a9Elapsed.wall,
            cpuNanos: a9Elapsed.cpu
        )
        a10Ultra.evaluateA10UltraShadow(sample: ultraSample)'''
    new_flow = '''        // I8 manual runtime selector: every mode still starts from one raw host sample.
        // A10-only LAB is an experiment rail, not a production cutover. In that mode A9 health
        // evaluation is skipped and the host keeps the last already-committed safe compute budget.
        let ultraContext = A10UltraOmegaHostContext(
            foregroundActive: computeGovernor.foregroundActive,
            computeMode: computeGovernor.plan.mode.rawValue,
            totalComputeUnits: computeGovernor.plan.totalComputeUnits,
            transportReserveUnits: computeGovernor.plan.transportReserveUnits,
            systemAvailable: true,
            gameRuntimeState: "HOST_MANAGED"
        )
        let ultraSample = a10Ultra.makeSharedSample(input: input, hostContext: ultraContext)
        let runtimeEnvironment = kernelRuntime.beginSample()

        switch runtimeEnvironment.mode {
        case .a9Only:
            let a9Timing = A10UltraOmegaShadowCoordinator.timingStart()
            a9Health.evaluate(input)
            computeGovernor.update(decision: a9Health.decision)
            latticeKernel.recordComputePlan(computeGovernor.plan)
            let a9Elapsed = A10UltraOmegaShadowCoordinator.timingElapsed(from: a9Timing)
            latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)
            a10Ultra.recordA9Only(
                sample: ultraSample,
                decision: a9Health.decision,
                budget: computeGovernor.plan,
                latencyNanos: a9Elapsed.wall,
                cpuNanos: a9Elapsed.cpu,
                runtime: runtimeEnvironment
            )

        case .dualShadow:
            let a9Timing = A10UltraOmegaShadowCoordinator.timingStart()
            a9Health.evaluate(input)
            computeGovernor.update(decision: a9Health.decision)
            latticeKernel.recordComputePlan(computeGovernor.plan)
            let a9Elapsed = A10UltraOmegaShadowCoordinator.timingElapsed(from: a9Timing)
            latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)
            a10Ultra.recordA9Primary(
                sample: ultraSample,
                decision: a9Health.decision,
                budget: computeGovernor.plan,
                latencyNanos: a9Elapsed.wall,
                cpuNanos: a9Elapsed.cpu
            )
            a10Ultra.evaluateA10UltraShadow(sample: ultraSample, runtime: runtimeEnvironment)

        case .a10OnlyLab:
            let ultraHealthy = a10Ultra.evaluateA10UltraIsolated(sample: ultraSample, runtime: runtimeEnvironment)
            if !ultraHealthy {
                computeGovernor.setPlanFrozen(false)
                kernelRuntime.forceA9Fallback(reason: "ULTRA_INTERNAL_FAILURE")
                scheduleA9Refresh()
            }
        }'''
    text = replace_once(text, old_flow, new_flow, "runtime-selected decision flow")

    text = replace_once(
        text,
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report()
            + "\\n\\n" + latticeKernel.report()
            + "\\n\\n" + a10Ultra.report()
            + "\\n\\n" + computeGovernor.report()
    }''',
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report()
            + "\\n\\n" + kernelRuntime.report()
            + "\\n\\n" + latticeKernel.report()
            + "\\n\\n" + a10Ultra.report()
            + "\\n\\n" + computeGovernor.report()
    }''',
        "runtime diagnostics report",
    )

    anchor = "\n    func runA9StorageCheck() {\n"
    if text.count(anchor) != 1:
        raise RuntimeError(f"runtime selector method anchor: expected 1, found {text.count(anchor)}")
    methods = r'''
    func setKernelRuntimeMode(_ mode: VeilKernelRuntimeMode) {
        computeGovernor.setPlanFrozen(mode == .a10OnlyLab)
        kernelRuntime.select(mode, source: "USER")
        refreshA9Health()
    }

    func exitA10OnlyLabToA9() {
        computeGovernor.setPlanFrozen(false)
        kernelRuntime.forceA9Fallback(reason: "USER_EXIT_LAB")
        refreshA9Health()
    }
'''
    text = text.replace(anchor, "\n" + methods + anchor, 1)
    return text


def patch_runtime_diagnostics(text: str) -> str:
    legacy_start = "\n        model.a10Ultra.$lastComparison\n"
    anchor = "\n        model.maleCNS.$state\n"
    if text.count(legacy_start) != 1 or text.count(anchor) != 1:
        raise RuntimeError(
            f"runtime telemetry anchors: lastComparison={text.count(legacy_start)} maleCNS={text.count(anchor)}"
        )
    start_index = text.index(legacy_start)
    end_index = text.index(anchor, start_index)
    # I8 supersedes I7's per-sample comparison + state events with one unified environment-tagged event.
    text = text[:start_index] + text[end_index:]
    insertion = r'''
        model.kernelRuntime.$mode
            .sink { _ in
                Task { @MainActor in
                    let env = model.kernelRuntime.snapshot()
                    self.store.log(
                        env.mode.isExperimental ? .warning : .info,
                        .a9,
                        event: "kernel.runtime_mode",
                        screen: DeepTelemetry.shared.currentScreen,
                        metadata: [
                            "kernel_mode": env.mode.rawValue,
                            "mode_epoch": String(env.modeEpoch),
                            "mode_session_id": env.modeSessionID,
                            "selection_source": env.selectionSource,
                            "production_authority": env.productionAuthority,
                            "fallback_policy": env.fallbackPolicy,
                            "a9_enabled": String(env.a9EvaluationEnabled),
                            "ultra_enabled": String(env.ultraEvaluationEnabled),
                            "mutation_authority": String(env.mutationAuthority),
                            "production_cutover": env.productionCutover,
                            "last_fallback_reason": model.kernelRuntime.lastFallbackReason ?? "none"
                        ]
                    )
                }
            }
            .store(in: &cancellables)

        model.a10Ultra.$lastRuntimeSample
            .compactMap { $0 }
            .sink { record in
                Task { @MainActor in
                    let env = record.environment
                    self.store.log(
                        record.fallbackEvent ? .warning : .debug,
                        .a9,
                        event: "kernel.runtime_sample",
                        screen: DeepTelemetry.shared.currentScreen,
                        metadata: [
                            "kernel_mode": env.mode.rawValue,
                            "mode_epoch": String(env.modeEpoch),
                            "mode_session_id": env.modeSessionID,
                            "mode_sample_ordinal": String(env.modeSampleOrdinal),
                            "mode_elapsed_ms": String(max(0, Int(record.timestamp.timeIntervalSince(env.enteredAt) * 1_000))),
                            "selection_source": env.selectionSource,
                            "production_authority": env.productionAuthority,
                            "fallback_policy": env.fallbackPolicy,
                            "a9_enabled": String(env.a9EvaluationEnabled),
                            "ultra_enabled": String(env.ultraEvaluationEnabled),
                            "mutation_authority": String(env.mutationAuthority),
                            "production_cutover": env.productionCutover,
                            "device_profile": VeilDevicePerformance.diagnosticLabel,
                            "render_profile": VeilRenderProfile.diagnosticLabel,
                            "foreground_active": String(model.computeGovernor.foregroundActive),
                            "compute_focus": model.computeGovernor.focus.rawValue,
                            "a9_plan_frozen": String(model.computeGovernor.planFrozen),
                            "sample_id": record.sampleID,
                            "epoch": String(record.epoch),
                            "timestamp": ISO8601DateFormatter().string(from: record.timestamp),
                            "source_domain": record.sourceDomains.joined(separator: ","),
                            "signal_digest": record.signalDigest,
                            "a9_light": record.a9Decision?.light ?? "disabled",
                            "a9_level": record.a9Decision.map { String($0.level) } ?? "disabled",
                            "a9_risk_bp": record.a9Decision.map { String($0.riskBasisPoints) } ?? "disabled",
                            "a9_budget": record.a9Budget?.mode ?? "disabled",
                            "ultra_light": record.ultraDecision?.light ?? "disabled",
                            "ultra_level": record.ultraDecision.map { String($0.level) } ?? "disabled",
                            "ultra_risk_bp": record.ultraDecision.map { String($0.riskBasisPoints) } ?? "disabled",
                            "ultra_budget": record.ultraBudget?.mode ?? "disabled",
                            "decision_match": record.decisionMatch.map { String($0) } ?? "not_comparable",
                            "divergence_class": record.divergenceClass,
                            "a9_latency_us": String(record.a9LatencyNanos / 1_000),
                            "ultra_latency_us": String(record.ultraLatencyNanos / 1_000),
                            "a9_cpu_us": String(record.a9CPUNanos / 1_000),
                            "ultra_cpu_us": String(record.ultraCPUNanos / 1_000),
                            "ultra_physical_slot_count": String(record.ultraPhysicalSlotCount),
                            "rss_bytes": String(record.rssBytes),
                            "thermal_state": String(record.thermalState),
                            "battery_permille": String(record.batteryPermille),
                            "energy_proxy": String(record.energyProxy),
                            "ble_state": record.bleState,
                            "queue_depth": String(record.queueDepth),
                            "dropped_event_count": String(record.droppedEventCount),
                            "ultra_restart_count": String(record.ultraRestartCount),
                            "fallback_event": String(record.fallbackEvent),
                            "guardian_status": record.guardianStatus,
                            "rage_status": record.rageStatus,
                            "vault_status": record.vaultStatus,
                            "runtime_backend": record.runtimeBackend
                        ]
                    )
                }
            }
            .store(in: &cancellables)
'''
    return text.replace(anchor, insertion + anchor, 1)


def patch_settings(text: str) -> str:
    text = replace_once(
        text,
        "    @State private var diagnosticsCopied = false\n",
        "    @State private var diagnosticsCopied = false\n    @State private var requestedKernelMode: VeilKernelRuntimeMode?\n    @State private var showsA10OnlyLabWarning = false\n",
        "settings kernel state",
    )
    text = replace_once(
        text,
        "                bluetoothCard\n                a9HealthCard\n                versionFooter\n",
        "                bluetoothCard\n                a9HealthCard\n                kernelRuntimeCard\n                versionFooter\n",
        "settings runtime card placement",
    )
    text = replace_once(
        text,
        '''        .background(VeilAmbientBackground())
        .navigationTitle("设置")
        .sheet(isPresented: $showsLockSheet) {''',
        '''        .background(VeilAmbientBackground())
        .navigationTitle("设置")
        .alert("进入 A10 Ultra Ω 单轨实验？", isPresented: $showsA10OnlyLabWarning) {
            Button("取消", role: .cancel) { requestedKernelMode = nil }
            Button("进入实验", role: .destructive) {
                model.setKernelRuntimeMode(.a10OnlyLab)
                requestedKernelMode = nil
            }
        } message: {
            Text("A9 将停止本轮健康裁决，A10 Ultra Ω 独立运行；宿主冻结进入实验前最后一份安全预算。A10 仍无 mutation authority，失败或重启会自动回 A9。这不是生产 Cutover。")
        }
        .sheet(isPresented: $showsLockSheet) {''',
        "A10-only lab confirmation",
    )

    anchor = "\n    private var versionFooter: some View {\n"
    if text.count(anchor) != 1:
        raise RuntimeError(f"kernel runtime card anchor: expected 1, found {text.count(anchor)}")
    card = r'''
    private var kernelRuntimeCard: some View {
        let runtime = model.kernelRuntime
        let environment = runtime.snapshot()
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("内核运行模式", systemImage: "cpu")
                    .font(.headline)
                    .foregroundColor(VeilTheme.goldBright)
                Spacer()
                Text(environment.mode.isExperimental ? "LAB" : "CONTROLLED")
                    .font(.caption.weight(.bold).monospaced())
                    .foregroundColor(environment.mode.isExperimental ? VeilTheme.gold : VeilTheme.secondaryText)
            }

            Picker("内核运行模式", selection: Binding(
                get: { runtime.mode },
                set: { requested in
                    if requested == .a10OnlyLab, runtime.mode != .a10OnlyLab {
                        requestedKernelMode = requested
                        showsA10OnlyLabWarning = true
                    } else {
                        model.setKernelRuntimeMode(requested)
                    }
                }
            )) {
                ForEach(VeilKernelRuntimeMode.allCases) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .pickerStyle(.menu)
            .tint(VeilTheme.gold)

            Text(runtime.mode.detail)
                .font(.caption)
                .foregroundColor(VeilTheme.secondaryText)

            VStack(spacing: 7) {
                HStack {
                    Text("生产裁决")
                    Spacer()
                    Text(environment.productionAuthority)
                        .font(.caption.monospaced())
                        .foregroundColor(VeilTheme.secondaryText)
                }
                HStack {
                    Text("A9 / A10 Ultra Ω")
                    Spacer()
                    Text("\(environment.a9EvaluationEnabled ? "ON" : "OFF") / \(environment.ultraEvaluationEnabled ? "ON" : "OFF")")
                        .font(.caption.monospaced())
                        .foregroundColor(VeilTheme.secondaryText)
                }
                HStack {
                    Text("本模式样本")
                    Spacer()
                    Text("\(runtime.currentModeSampleCount)")
                        .font(.caption.monospacedDigit())
                        .foregroundColor(VeilTheme.secondaryText)
                }
                HStack {
                    Text("环境 ID")
                    Spacer()
                    Text(String(environment.modeSessionID.prefix(8)).uppercased())
                        .font(.caption.monospaced())
                        .foregroundColor(VeilTheme.tertiaryText)
                }
            }
            .font(.subheadline)

            Text("A10 Ultra Ω 单轨实验不会成为生产 Cutover；黑匣子会把 kernel_mode、环境 ID、两路是否启用、延迟/CPU/RSS/温控/电量代理与 fallback 一起记录。")
                .font(.caption)
                .foregroundColor(VeilTheme.tertiaryText)

            if runtime.mode == .a10OnlyLab {
                Button {
                    model.exitA10OnlyLabToA9()
                    haptics.resolved()
                } label: {
                    Label("立即退出实验并回到 A9", systemImage: "arrow.uturn.backward.circle")
                }
                .buttonStyle(.bordered)
                .tint(VeilTheme.gold)
            }

            if let reason = runtime.lastFallbackReason {
                Text("最近自动回退：\(reason)")
                    .font(.caption2)
                    .foregroundColor(VeilTheme.gold)
            }
        }
        .veilCard()
    }
'''
    text = text.replace(anchor, "\n" + card + anchor, 1)
    return text


def copy_payload(here: Path, root: Path) -> None:
    mapping = {
        here / "Payload/VeilLink/Health/VeilKernelRuntimeSelector.swift": root / "VeilLink/Health/VeilKernelRuntimeSelector.swift",
        here / "Payload/VeilLinkTests/VeilKernelRuntimeSelectorTests.swift": root / "VeilLinkTests/VeilKernelRuntimeSelectorTests.swift",
        here / "Payload/docs/A10UltraOmega/KERNEL_RUNTIME_SELECTOR_V1.md": root / "docs/A10UltraOmega/KERNEL_RUNTIME_SELECTOR_V1.md",
    }
    for src, dst in mapping.items():
        if not src.exists():
            raise RuntimeError(f"missing I8 payload: {src}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I8_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    require_markers(root, I7_REQUIRED, "I7 prerequisite")

    selector = root / "VeilLink/Health/VeilKernelRuntimeSelector.swift"
    if selector.exists() and 'case a10OnlyLab = "A10_ULTRA_ONLY_LAB"' in selector.read_text(encoding="utf-8"):
        require_markers(root, I8_MARKERS, "existing I8")
        print("I8 already present; no duplicate mutation performed")
        return 0

    backup = root / ".veillink-local-iter/I8-backup"
    backup.mkdir(parents=True, exist_ok=True)
    for rel in [
        "VeilLink/Health/A10UltraOmegaShadow.swift",
        "VeilLink/Agent/Compute/A9ComputeGovernor.swift",
        "VeilLink/App/AppModel.swift",
        "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift",
        "VeilLink/UI/SettingsView.swift",
    ]:
        src = root / rel
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    shadow = root / "VeilLink/Health/A10UltraOmegaShadow.swift"
    shadow.write_text(patch_a10_shadow(shadow.read_text(encoding="utf-8")), encoding="utf-8")
    governor = root / "VeilLink/Agent/Compute/A9ComputeGovernor.swift"
    governor.write_text(patch_governor(governor.read_text(encoding="utf-8")), encoding="utf-8")
    app = root / "VeilLink/App/AppModel.swift"
    app.write_text(patch_app_model(app.read_text(encoding="utf-8")), encoding="utf-8")
    diag = root / "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"
    diag.write_text(patch_runtime_diagnostics(diag.read_text(encoding="utf-8")), encoding="utf-8")
    settings = root / "VeilLink/UI/SettingsView.swift"
    settings.write_text(patch_settings(settings.read_text(encoding="utf-8")), encoding="utf-8")
    copy_payload(here, root)
    require_markers(root, I8_MARKERS, "I8 post-apply")
    print("I8 Kernel Runtime Selector installed")
    print("Modes: A9_ONLY / A9_PLUS_A10_ULTRA_SHADOW / A10_ULTRA_ONLY_LAB")
    print("PRODUCTION_CUTOVER = DENIED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
