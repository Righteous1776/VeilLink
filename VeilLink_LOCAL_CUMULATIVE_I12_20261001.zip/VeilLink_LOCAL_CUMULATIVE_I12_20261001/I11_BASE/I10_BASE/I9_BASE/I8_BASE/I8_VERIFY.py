from pathlib import Path
import sys
from I8_APPLY import I8_MARKERS, require_markers


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I8_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    require_markers(root, I8_MARKERS, "I8 verify")
    selector = (root / "VeilLink/Health/VeilKernelRuntimeSelector.swift").read_text(encoding="utf-8")
    if 'case .a10OnlyLab: return "HOST_FROZEN_BASELINE"' not in selector:
        raise RuntimeError("A10-only LAB authority wall missing")
    if 'mutationAuthority: 0' not in selector:
        raise RuntimeError("mutation authority wall missing")
    shadow = (root / "VeilLink/Health/A10UltraOmegaShadow.swift").read_text(encoding="utf-8")
    if "evaluateA10UltraIsolated" not in shadow:
        raise RuntimeError("isolated Ultra path missing")
    print("I8 VERIFY PASS")
    print("Manual modes are black-box tagged; A10-only remains LAB and cutover denied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
