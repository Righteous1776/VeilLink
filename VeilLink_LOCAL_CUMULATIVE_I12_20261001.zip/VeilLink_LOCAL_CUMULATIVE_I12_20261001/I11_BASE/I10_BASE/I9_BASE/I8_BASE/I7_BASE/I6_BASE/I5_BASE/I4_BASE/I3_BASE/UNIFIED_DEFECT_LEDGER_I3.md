# VeilLink 统一缺陷账本 — 累计 I3 状态

Base authority: `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`

## 已进入累计修复

- **P0 Face ID privacy crash** — I1：补 `NSFaceIDUsageDescription`。
- **P0 iPhone 7 游戏每步卡死/闪退高可信路径** — I1：恢复后台 rebuild、去掉本地双 rebuild、A9/A10 compact-safe、去 O(N²) 合法动作重复枚举、游戏失败操作可重试。
- **P0 Keychain protected-data 误判永久丢钥匙** — I2：`errSecItemNotFound` 与 transient/unexpected Keychain failure 分流；数据库密钥暂不可读时只安全停止，绝不生成新 key。
- **P1 游戏跨设备墙钟排序** — I2：accept/move 因果不再通过两台设备 `Date()` 比大小。
- **P1 撤回邀请 / 认输混用** — I2：新增 `.cancelInvite`；旧 pending `.resign` 仅作向后兼容。
- **P1 接受后立即认输被误判取消** — I2：accept 后 turn 0 `.resign` 明确认输。
- **P1 并发双邀请** — I2：8 秒碰撞窗内同游戏邀请确定性合并。
- **P2 幽灵邀请永久占位** — I2：30 分钟未响应退出活动队列并显示过期。
- **P2 聊天列表邀请文案方向错误** — I2：发送端使用 outgoing preview。
- **P1/P2 聊天框直接游戏邀请入口回归** — I1：恢复“发送游戏邀请”，支持聊天卡内接受/拒绝/重试。
- **P1 BLE peripheral TX pump 背压后永久停滞** — I3：实现 `peripheralManagerIsReady(toUpdateSubscribers:)`，系统 TX queue 恢复后立即继续 drain。
- **P1 BLE central TX pump 依赖单一回调** — I3：保留 CoreBluetooth ready callback 为主路径，增加低频有界 safety probe，避免 missed callback 永久挂队列。
- **P1 双角色链路任一角色断线误杀安全会话** — I3：新增 role-aware `reconcileConnectionEvent`；只有最后一条 GATT-ready 通道消失才触发 SessionCoordinator disconnect。
- **P1 reconnect/rekey stale fragment 污染** — I3：真正 transport epoch 结束时按 source 清空未完成 BLE 分片；stop/full recover 清空全部对应缓存。
- **P2 BLE 物理连接过早显示“加密链路已就绪”** — I3：显式状态 `DISCOVERED -> PHY_CONNECTED -> GATT_READY`；游戏 UI 再叠加 `SECURE_SESSION_READY`。
- **P1/P2 黑匣子看不到 readiness 分层** — I3：新增 `transport_stage`，nearby peer telemetry 增加 `secure=true/false`。

## I3 后仍未关闭

- **BLE secure-ready churn / unverifiable frame**：I3 已修复两个高可信具体来源（双角色误断会话、跨 epoch 未完成分片），但必须用新黑匣子做双机 reconnect/rekey 压测后才能关闭。
- **iPhone 7 游戏每步闪退**：I1/I2/I3 已显著削减主线程与 BLE churn，但仍缺 iPhone 7 MetricKit crash stack，不能宣称真机闭环。
- A9 ghost BLE snapshots、persistence 按回调次数、BLE-centric health。
- LAN Turbo / Relay / Mesh telemetry 缺口与游戏 transport 状态统一。
- 黑匣子 stall false-positive / UI hierarchy observer effect 的工程化降采样。
- 主题：真正 light/system 主题、系统 Form/List Sheet 统一、锁屏横屏、小字号/Dynamic Type。

## I3 真机验收矩阵

1. iPhone 7 ↔ iPhone 13，双方分别作为 central/peripheral，确认状态依次出现 `PHY_CONNECTED / GATT_READY / SECURE_SESSION_READY`。
2. 连续游戏操作 + 文本小包，制造 CoreBluetooth 背压，确认 `peripheralManagerIsReady` 后队列继续下降而非增长至 watchdog disconnect。
3. dual-role 场景主动断一条角色，确认 secure session 不被销毁，另一角色继续收发。
4. 真正全链路断开再重连，确认 partial assembler 被清空，不出现旧 transport epoch 拼包。
5. 重复 20 次 reconnect/rekey，统计 `session.error / unverifiable` 是否归零或显著下降。
6. iPhone 7 连续走棋 30 手，观察 crash / thermal / main-thread stall / queue pending。

## 证据边界

I3 是**本地累计源码修复包**，未写入 GitHub main；GitHub App 对 refs 写入此前返回 403。当前环境不是 macOS/Xcode，已完成补丁器语法检查、GitHub 当前源码替换点唯一性审计、包结构/哈希校验，但不能冒充 XCTest、iphoneos build 或真机 BLE 已通过。
