from pathlib import Path
import hashlib
import shutil
import sys

BASE_HEAD = "152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f"
EXPECTED_BLOBS = {
    "VeilLink/UI/MiniGameViews.swift": "4f18c8122ab7862a96ac396e9ae1ad4063a77d2c",
    "VeilLink/UI/ConversationViews.swift": "0fdc2737941b586f4451acc6e842ddecaa27c713",
    "VeilLink/Agent/Integration/AgentGameContextBroker.swift": "4988cc172794187e9312574df519fceca29adbc2",
    "VeilLink/Core/DevicePerformanceProfile.swift": "0471a8a36c114fd099cdaca9f66f85f082322119",
    "VeilLink/Core/MiniGames.swift": "7e9c3895376a1afc7223f8a3776c63404de2a38b",
    "VeilLink/Resources/Info.plist": "bd8eec7748827523d66443afb590d7b7d1ab0373",
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def patch_info(text: str) -> str:
    old = '''\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>仅在你启用自动保存或主动选择时，将收到的图片保存到照片。</string>\n\t<key>NSCameraUsageDescription</key>'''
    new = '''\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>仅在你启用自动保存或主动选择时，将收到的图片保存到照片。</string>\n\t<key>NSFaceIDUsageDescription</key>\n\t<string>VeilLink 使用 Face ID 在本机解锁应用；生物识别数据由系统处理，VeilLink 不读取或保存。</string>\n\t<key>NSCameraUsageDescription</key>'''
    return replace_once(text, old, new, "Info.plist Face ID usage")


def patch_device_profile(text: str) -> str:
    old = '''    static var diagnosticLabel: String {\n        "\\(current.label) · \\(machineIdentifier)"\n    }\n}'''
    new = '''    /// Keep the per-move critical path intentionally small on A9/A10-era 2 GB devices.\n    /// Performance overrides must not disable this safety gate.\n    static var prefersLightweightGameRuntime: Bool {\n        switch machineIdentifier {\n        case "iPhone8,4",\n             "iPhone9,1", "iPhone9,2", "iPhone9,3", "iPhone9,4":\n            return true\n        default:\n            return false\n        }\n    }\n\n    static var diagnosticLabel: String {\n        "\\(current.label) · \\(machineIdentifier)"\n    }\n}'''
    return replace_once(text, old, new, "DevicePerformance lightweight game gate")


def patch_agent_broker(text: str) -> str:
    old = '''        let observation = adapter.makeObservation()\n        let legal = adapter.enumerateLegalActions().filter(adapter.validate)\n        let rankedScores: [AgentActionScore]\n        if AgentGameRegistry.isTrainingEnabled(session.game), let policyRuntime {\n            rankedScores = (try? policyRuntime.rankedLegalActions(adapter: adapter)) ?? []\n        } else {\n            rankedScores = []\n        }'''
    new = '''        let observation = adapter.makeObservation()\n\n        // A9/A10-era devices keep the UI/game transaction path rule-only. The old path ran\n        // full legal-action enumeration + model ranking on MainActor after every local/remote\n        // move, which can stall or terminate iPhone 7 under SwiftUI/BLE/database pressure.\n        if VeilDevicePerformance.prefersLightweightGameRuntime {\n            context = AgentGameContext(\n                capturedAt: capturedAt,\n                sessionID: session.id,\n                gameID: session.game.rawValue,\n                gameTitle: session.game.title,\n                conversationTitle: conversationTitle,\n                peerIdentityID: peerIdentityID,\n                status: status,\n                stateHash: observation.stateHash,\n                turn: session.moveCount,\n                localPlayer: localPlayer.rawValue,\n                isLocalTurn: session.isLocalTurn,\n                policyMode: "compact-safe",\n                stateDescription: Self.stateDescription(for: session),\n                recommendations: [],\n                note: "Compact-device safe mode: move ranking and MaleCNS rerank are deferred outside the live game transaction.",\n                maleCNS: nil\n            )\n            return\n        }\n\n        // enumerateLegalActions() already returns legal candidates for the built-in adapters.\n        // Do not call validate() per candidate (which recursively re-enumerated the whole set),\n        // and do not ask rankedLegalActions() to enumerate it a second time.\n        let legal = adapter.enumerateLegalActions()\n        let rankedScores: [AgentActionScore]\n        if AgentGameRegistry.isTrainingEnabled(session.game), let policyRuntime {\n            rankedScores = (try? policyRuntime.scores(observation: observation, candidates: legal)) ?? []\n        } else {\n            rankedScores = []\n        }'''
    return replace_once(text, old, new, "AgentGameContextBroker per-move hot path")


def patch_minigames_core(text: str) -> str:
    old = '''        let compatible = events.filter { $0.1.version == MiniGamePacket.currentVersion }'''
    new = '''        let compatible = events.filter { event in\n            guard event.1.version == MiniGamePacket.currentVersion else { return false }\n            // Keep a failed invite visible so the sender can retry it from the chat card, but\n            // never let an outbound command that definitively failed/cancelled mutate the\n            // reconstructed board or terminal state. A retry flips the message back to queued.\n            if event.0.isOutgoing, event.0.deliveryState == .failed || event.0.deliveryState == .cancelled {\n                return event.1.command == .invite\n            }\n            return true\n        }'''
    return replace_once(text, old, new, "MiniGameSessionBuilder failed outbound filtering")


def patch_conversation(text: str) -> str:
    old = '''                            Divider()\n                            Button {\n                                miniGameInitialSessionID = nil\n                                showsMiniGames = true\n                            } label: {\n                                Label("双人小游戏", systemImage: "gamecontroller")\n                            }'''
    new = '''                            Divider()\n                            Menu {\n                                ForEach(MiniGameKind.allCases) { game in\n                                    Button {\n                                        sendGameInvite(game)\n                                    } label: {\n                                        Label(game.title, systemImage: game.icon)\n                                    }\n                                }\n                            } label: {\n                                Label("发送游戏邀请", systemImage: "paperplane.fill")\n                            }\n                            Button {\n                                miniGameInitialSessionID = nil\n                                showsMiniGames = true\n                            } label: {\n                                Label("游戏大厅", systemImage: "gamecontroller")\n                            }'''
    text = replace_once(text, old, new, "Chat + menu direct game invite")

    old = '''                                MiniGameConversationCard(session: gameSession) {\n                                    miniGameInitialSessionID = gameSession.id\n                                    showsMiniGames = true\n                                    model.haptics.selection()\n                                }'''
    new = '''                                MiniGameConversationCard(\n                                    session: gameSession,\n                                    onOpen: {\n                                        miniGameInitialSessionID = gameSession.id\n                                        showsMiniGames = true\n                                        model.haptics.selection()\n                                    },\n                                    onAccept: gameSession.status == .invited && !gameSession.hostIsLocal ? {\n                                        respondToGameInvite(gameSession, command: .accept)\n                                    } : nil,\n                                    onDecline: gameSession.status == .invited && !gameSession.hostIsLocal ? {\n                                        respondToGameInvite(gameSession, command: .decline)\n                                    } : nil,\n                                    onRetry: message.isOutgoing && message.deliveryState == .failed ? {\n                                        retry(message)\n                                    } : nil\n                                )'''
    text = replace_once(text, old, new, "Inline game invitation actions")

    old = '''    private func send() {\n        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)'''
    new = '''    private func sendGameInvite(_ game: MiniGameKind) {\n        if let existing = gameSessionsByID.values.first(where: { session in\n            guard session.game == game else { return false }\n            switch session.status {\n            case .invited, .active: return true\n            case .declined, .cancelled, .finished: return false\n            }\n        }) {\n            miniGameInitialSessionID = existing.id\n            showsMiniGames = true\n            model.haptics.selection()\n            return\n        }\n\n        let packet = MiniGamePacket(game: game, command: .invite)\n        do {\n            try model.sessions.sendMiniGamePacket(packet, to: conversation.peerIdentityID)\n            RuntimeDiagnosticsBridge.shared.recordSemanticAction(\n                "game.invite.send",\n                metadata: ["game": game.rawValue, "source": "chat"]\n            )\n            model.haptics.send()\n        } catch {\n            model.alertMessage = error.localizedDescription\n            model.haptics.error()\n        }\n    }\n\n    private func respondToGameInvite(_ session: MiniGameSessionSnapshot, command: MiniGameCommand) {\n        guard session.status == .invited, !session.hostIsLocal, command == .accept || command == .decline else { return }\n        let packet = MiniGamePacket(\n            sessionID: session.id,\n            game: session.game,\n            command: command,\n            turn: 0,\n            move: nil\n        )\n        do {\n            try model.sessions.sendMiniGamePacket(packet, to: conversation.peerIdentityID)\n            RuntimeDiagnosticsBridge.shared.recordSemanticAction(\n                command == .accept ? "game.invite.accept" : "game.invite.decline",\n                metadata: ["game": session.game.rawValue, "source": "chat"]\n            )\n            command == .accept ? model.haptics.resolved() : model.haptics.selection()\n        } catch {\n            model.alertMessage = error.localizedDescription\n            model.haptics.error()\n        }\n    }\n\n    private func send() {\n        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)'''
    text = replace_once(text, old, new, "Chat game invitation helpers")

    old = '''                        .accessibilityHint("发送图片或打开双人小游戏")'''
    new = '''                        .accessibilityHint("发送图片、直接发送游戏邀请或打开游戏大厅")'''
    text = replace_once(text, old, new, "Chat add-menu accessibility hint")
    return text


def patch_minigame_views(text: str) -> str:
    text = replace_once(
        text,
        '''            .background(VeilAmbientBackground().ignoresSafeArea())\n            .navigationTitle("双人小游戏")''',
        '''            .background(VeilAmbientBackground())\n            .navigationTitle("双人小游戏")''',
        "MiniGameHub iOS15 safe-area background"
    )

    old = '''    private func reload() {\n        reloadGeneration &+= 1\n        let generation = reloadGeneration\n        let loaded = model.database.fetchMessages(conversationID: conversation.id)\n        let loadedSessions = MiniGameSessionBuilder.sessions(from: loaded)\n        guard generation == reloadGeneration else { return }\n        messages = loaded\n        sessions = loadedSessions\n    }'''
    new = '''    private func reload() {\n        reloadGeneration &+= 1\n        let generation = reloadGeneration\n        let store = model.database\n        let conversationID = conversation.id\n        DispatchQueue.global(qos: .userInitiated).async {\n            let loaded = store.fetchMessages(conversationID: conversationID)\n            let loadedSessions = MiniGameSessionBuilder.sessions(from: loaded)\n            DispatchQueue.main.async {\n                guard generation == reloadGeneration else { return }\n                messages = loaded\n                sessions = loadedSessions\n            }\n        }\n    }'''
    text = replace_once(text, old, new, "MiniGameHub background reload")

    old_struct = '''struct MiniGameConversationCard: View {\n    let session: MiniGameSessionSnapshot\n    let onOpen: () -> Void\n\n    private var statusText: String {\n        switch session.status {\n        case .invited: return session.hostIsLocal ? "已邀请对方 · 等待接受" : "邀请你加入 · 点击回应"\n        case .active:\n            if session.game == .xiangqi, let state = session.xiangqi, state.isCurrentPlayerInCheck {\n                let checker = state.currentPlayer.opponent\n                let streak = state.consecutiveCheckCount(for: checker)\n                let suffix = streak >= 2 ? " · 连续将军×\\(streak)" : ""\n                return (session.isLocalTurn ? "轮到你 · 正在被将军" : "对方回合 · 将军") + suffix\n            }\n            return session.isLocalTurn ? "轮到你行动" : "等待对方行动"\n        case .declined: return "邀请已被拒绝"\n        case .cancelled: return "邀请已取消"\n        case .finished(let winner):\n            guard let winner else {\n                if session.xiangqi?.drawReason == .threefoldRepetition { return "对局结束 · 三次重复和棋" }\n                return "对局结束 · 和棋"\n            }\n            return winner == session.localPlayer ? "对局结束 · 你赢了" : "对局结束 · 对方获胜"\n        }\n    }\n\n    var body: some View {\n        Button(action: onOpen) {\n            VStack(alignment: .leading, spacing: 12) {\n                HStack(spacing: 11) {\n                    ZStack {\n                        Circle().fill(VeilTheme.gold.opacity(0.10))\n                        Image(systemName: session.game.icon)\n                            .font(.system(size: 20, weight: .semibold))\n                            .foregroundColor(VeilTheme.gold)\n                    }\n                    .frame(width: 42, height: 42)\n                    VStack(alignment: .leading, spacing: 3) {\n                        Text(session.game.title)\n                            .font(.headline)\n                            .foregroundColor(VeilTheme.text)\n                        Text(statusText)\n                            .font(.caption)\n                            .foregroundColor(session.isLocalTurn ? VeilTheme.gold : VeilTheme.secondaryText)\n                    }\n                    Spacer()\n                    Image(systemName: "chevron.right")\n                        .font(.caption.weight(.bold))\n                        .foregroundColor(VeilTheme.tertiaryText)\n                }\n\n                HStack(spacing: 8) {\n                    Label("E2EE", systemImage: "lock.fill")\n                    Text("·")\n                    Text(session.game == .tactical ? "\\(session.moveCount) 道命令" : "\\(session.moveCount) 手")\n                    Text("·")\n                    Text("#\\(session.id.prefix(4))")\n                    Spacer()\n                    Text(session.status == .active ? "进入棋局" : "查看")\n                        .fontWeight(.semibold)\n                        .foregroundColor(VeilTheme.gold)\n                }\n                .font(.caption2.monospacedDigit())\n                .foregroundColor(VeilTheme.tertiaryText)\n            }\n            .padding(14)\n            .background(VeilTheme.elevated.opacity(0.92))\n            .clipShape(VeilPanelShape(cut: 14, radius: 8))\n            .overlay(VeilPanelShape(cut: 14, radius: 8).stroke(session.isLocalTurn ? VeilTheme.gold.opacity(0.28) : VeilTheme.hairline, lineWidth: 1))\n            .overlay(alignment: .topLeading) {\n                Rectangle()\n                    .fill(session.isLocalTurn ? VeilTheme.gold : VeilTheme.hairline)\n                    .frame(width: session.isLocalTurn ? 42 : 18, height: 1)\n                    .padding(.leading, 12)\n            }\n        }\n        .buttonStyle(VeilPressStyle())\n        .accessibilityLabel("\\(session.game.title)，\\(statusText)，点击打开棋局")\n    }\n}'''
    new_struct = '''struct MiniGameConversationCard: View {\n    let session: MiniGameSessionSnapshot\n    let onOpen: () -> Void\n    let onAccept: (() -> Void)?\n    let onDecline: (() -> Void)?\n    let onRetry: (() -> Void)?\n\n    init(\n        session: MiniGameSessionSnapshot,\n        onOpen: @escaping () -> Void,\n        onAccept: (() -> Void)? = nil,\n        onDecline: (() -> Void)? = nil,\n        onRetry: (() -> Void)? = nil\n    ) {\n        self.session = session\n        self.onOpen = onOpen\n        self.onAccept = onAccept\n        self.onDecline = onDecline\n        self.onRetry = onRetry\n    }\n\n    private var isIncomingInvitation: Bool { session.status == .invited && !session.hostIsLocal }\n\n    private var statusText: String {\n        switch session.status {\n        case .invited: return session.hostIsLocal ? "已邀请对方 · 等待接受" : "邀请你加入 · 可直接回应"\n        case .active:\n            if session.game == .xiangqi, let state = session.xiangqi, state.isCurrentPlayerInCheck {\n                let checker = state.currentPlayer.opponent\n                let streak = state.consecutiveCheckCount(for: checker)\n                let suffix = streak >= 2 ? " · 连续将军×\\(streak)" : ""\n                return (session.isLocalTurn ? "轮到你 · 正在被将军" : "对方回合 · 将军") + suffix\n            }\n            return session.isLocalTurn ? "轮到你行动" : "等待对方行动"\n        case .declined: return "邀请已被拒绝"\n        case .cancelled: return "邀请已取消"\n        case .finished(let winner):\n            guard let winner else {\n                if session.xiangqi?.drawReason == .threefoldRepetition { return "对局结束 · 三次重复和棋" }\n                return "对局结束 · 和棋"\n            }\n            return winner == session.localPlayer ? "对局结束 · 你赢了" : "对局结束 · 对方获胜"\n        }\n    }\n\n    var body: some View {\n        VStack(alignment: .leading, spacing: 12) {\n            Button(action: onOpen) {\n                VStack(alignment: .leading, spacing: 12) {\n                    HStack(spacing: 11) {\n                        ZStack {\n                            Circle().fill(VeilTheme.gold.opacity(isIncomingInvitation ? 0.16 : 0.10))\n                            Image(systemName: session.game.icon)\n                                .font(.system(size: 20, weight: .semibold))\n                                .foregroundColor(VeilTheme.gold)\n                        }\n                        .frame(width: 42, height: 42)\n                        VStack(alignment: .leading, spacing: 3) {\n                            Text(session.game.title)\n                                .font(.headline)\n                                .foregroundColor(VeilTheme.text)\n                            Text(statusText)\n                                .font(.caption)\n                                .foregroundColor(isIncomingInvitation || session.isLocalTurn ? VeilTheme.gold : VeilTheme.secondaryText)\n                        }\n                        Spacer()\n                        Image(systemName: "chevron.right")\n                            .font(.caption.weight(.bold))\n                            .foregroundColor(VeilTheme.tertiaryText)\n                    }\n\n                    HStack(spacing: 8) {\n                        Label("E2EE", systemImage: "lock.fill")\n                        Text("·")\n                        Text(session.game == .tactical ? "\\(session.moveCount) 道命令" : "\\(session.moveCount) 手")\n                        Text("·")\n                        Text("#\\(session.id.prefix(4))")\n                        Spacer()\n                        Text(session.status == .active ? "进入棋局" : (isIncomingInvitation ? "查看详情" : "查看"))\n                            .fontWeight(.semibold)\n                            .foregroundColor(VeilTheme.gold)\n                    }\n                    .font(.caption2.monospacedDigit())\n                    .foregroundColor(VeilTheme.tertiaryText)\n                }\n            }\n            .buttonStyle(.plain)\n\n            if isIncomingInvitation, let onDecline, let onAccept {\n                HStack(spacing: 10) {\n                    Button("拒绝", action: onDecline)\n                        .buttonStyle(VeilGameSecondaryButtonStyle())\n                    Button("接受", action: onAccept)\n                        .buttonStyle(VeilGamePrimaryButtonStyle())\n                }\n            }\n\n            if let onRetry {\n                Button(action: onRetry) {\n                    Label("重新发送邀请", systemImage: "arrow.clockwise")\n                        .frame(maxWidth: .infinity)\n                }\n                .buttonStyle(VeilGameSecondaryButtonStyle())\n                .foregroundColor(VeilTheme.danger)\n            }\n        }\n        .padding(14)\n        .background(VeilTheme.elevated.opacity(0.92))\n        .clipShape(VeilPanelShape(cut: 14, radius: 8))\n        .overlay(\n            VeilPanelShape(cut: 14, radius: 8)\n                .stroke(isIncomingInvitation || session.isLocalTurn ? VeilTheme.gold.opacity(0.42) : VeilTheme.hairline, lineWidth: isIncomingInvitation ? 1.4 : 1)\n        )\n        .overlay(alignment: .topLeading) {\n            Rectangle()\n                .fill(isIncomingInvitation || session.isLocalTurn ? VeilTheme.gold : VeilTheme.hairline)\n                .frame(width: isIncomingInvitation || session.isLocalTurn ? 42 : 18, height: 1)\n                .padding(.leading, 12)\n        }\n        .accessibilityElement(children: .contain)\n        .accessibilityLabel("\\(session.game.title)，\\(statusText)")\n    }\n}'''
    text = replace_once(text, old_struct, new_struct, "MiniGameConversationCard inline controls")

    text = replace_once(
        text,
        '''                .background(VeilAmbientBackground().ignoresSafeArea())\n                .navigationTitle(session.game.title)''',
        '''                .background(VeilAmbientBackground())\n                .navigationTitle(session.game.title)''',
        "MiniGameSession iOS15 safe-area background"
    )
    text = replace_once(
        text,
        '''                    .background(VeilAmbientBackground().ignoresSafeArea())\n            }''',
        '''                    .background(VeilAmbientBackground())\n            }''',
        "MiniGameSession loading iOS15 safe-area background"
    )

    old = '''                    MiniGameLinkStatusView(\n                        bluetooth: model.bluetooth,\n                        sessions: model.sessions,\n                        peerIdentityID: conversation.peerIdentityID,\n                        latestGameMessage: latestLocalGameMessage\n                    )\n                    .padding(.horizontal, 14)'''
    new = '''                    MiniGameLinkStatusView(\n                        bluetooth: model.bluetooth,\n                        sessions: model.sessions,\n                        peerIdentityID: conversation.peerIdentityID,\n                        latestGameMessage: latestLocalGameMessage\n                    )\n                    .padding(.horizontal, 14)\n\n                    if let failed = latestLocalGameMessage, failed.deliveryState == .failed {\n                        Button {\n                            retryGameMessage(failed)\n                        } label: {\n                            Label("重新发送上一条游戏操作", systemImage: "arrow.clockwise")\n                                .frame(maxWidth: .infinity)\n                        }\n                        .buttonStyle(VeilGameSecondaryButtonStyle())\n                        .foregroundColor(VeilTheme.danger)\n                        .padding(.horizontal, 14)\n                        .disabled(isSending)\n                    }'''
    text = replace_once(text, old, new, "Game failed-command retry UI")

    old = '''        do {\n            try model.sessions.sendMiniGamePacket(packet, to: conversation.peerIdentityID)\n            model.haptics.send()\n            selectedXiangqiIndex = nil\n            reload(notify: false)\n        } catch {\n            model.alertMessage = error.localizedDescription\n            model.haptics.error()\n        }\n        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) { isSending = false }\n    }'''
    new = '''        do {\n            try model.sessions.sendMiniGamePacket(packet, to: conversation.peerIdentityID)\n            RuntimeDiagnosticsBridge.shared.recordSemanticAction(\n                "game.command.send",\n                metadata: ["game": session.game.rawValue, "command": command.rawValue, "turn": "\\(turn)"]\n            )\n            model.haptics.send()\n            selectedXiangqiIndex = nil\n            // queueContent() already schedules messagesRevision. Do not synchronously rebuild the\n            // whole encrypted history here and then rebuild it a second time on that revision.\n            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {\n                if isSending { isSending = false }\n            }\n        } catch {\n            isSending = false\n            model.alertMessage = error.localizedDescription\n            model.haptics.error()\n        }\n    }\n\n    private func retryGameMessage(_ message: ChatMessage) {\n        guard !isSending else { return }\n        isSending = true\n        do {\n            try model.sessions.retryMessage(message.id, to: conversation.peerIdentityID)\n            RuntimeDiagnosticsBridge.shared.recordSemanticAction(\n                "game.command.retry",\n                metadata: ["session": sessionID]\n            )\n            model.haptics.impact()\n            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {\n                if isSending { isSending = false }\n            }\n        } catch {\n            isSending = false\n            model.alertMessage = error.localizedDescription\n            model.haptics.error()\n        }\n    }'''
    text = replace_once(text, old, new, "Game send de-dup + retry")

    old = '''    private func reload(notify: Bool) {\n        reloadGeneration &+= 1\n        let generation = reloadGeneration\n        let oldCount = observedMoveCount\n        let oldStatus = session?.status\n        let loaded = model.database.fetchMessages(conversationID: conversation.id)\n        let newSession = MiniGameSessionBuilder.session(id: sessionID, from: loaded)\n        guard generation == reloadGeneration else { return }\n        messages = loaded\n        session = newSession\n        if let newSession {\n            model.updateAgentGameContext(newSession, conversation: conversation)\n        }\n        let newCount = newSession?.moveCount ?? 0\n        if notify, newCount > oldCount, newSession?.isLocalTurn == true {\n            model.haptics.receive()\n        }\n        if notify, let newSession, case .finished = newSession.status {\n            if oldStatus != newSession.status { model.haptics.resolved() }\n        }\n        observedMoveCount = newCount\n    }'''
    new = '''    private func reload(notify: Bool) {\n        reloadGeneration &+= 1\n        let generation = reloadGeneration\n        let oldCount = observedMoveCount\n        let oldStatus = session?.status\n        let store = model.database\n        let conversationID = conversation.id\n        DispatchQueue.global(qos: .userInitiated).async {\n            let loaded = store.fetchMessages(conversationID: conversationID)\n            let newSession = MiniGameSessionBuilder.session(id: sessionID, from: loaded)\n            DispatchQueue.main.async {\n                guard generation == reloadGeneration else { return }\n                messages = loaded\n                session = newSession\n                isSending = false\n                if let newSession {\n                    model.updateAgentGameContext(newSession, conversation: conversation)\n                }\n                let newCount = newSession?.moveCount ?? 0\n                if notify, newCount > oldCount, newSession?.isLocalTurn == true {\n                    model.haptics.receive()\n                }\n                if notify, let newSession, case .finished = newSession.status {\n                    if oldStatus != newSession.status { model.haptics.resolved() }\n                }\n                observedMoveCount = newCount\n            }\n        }\n    }'''
    text = replace_once(text, old, new, "MiniGameSession background rebuild")
    return text

PATCHERS = {
    "VeilLink/UI/MiniGameViews.swift": patch_minigame_views,
    "VeilLink/UI/ConversationViews.swift": patch_conversation,
    "VeilLink/Agent/Integration/AgentGameContextBroker.swift": patch_agent_broker,
    "VeilLink/Core/DevicePerformanceProfile.swift": patch_device_profile,
    "VeilLink/Core/MiniGames.swift": patch_minigames_core,
    "VeilLink/Resources/Info.plist": patch_info,
}


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I1_APPLY.py /path/to/current/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "project.yml").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    original = {}
    for rel, expected in EXPECTED_BLOBS.items():
        path = root / rel
        data = path.read_bytes()
        actual = git_blob_sha(data)
        if actual != expected:
            raise RuntimeError(f"{rel}: source blob mismatch; expected {expected}, got {actual}. Refusing to patch the wrong base.")
        original[rel] = data.decode("utf-8")

    backup = root / ".veillink-local-iter" / "I1-backup"
    backup.mkdir(parents=True, exist_ok=True)
    changed = {}
    for rel, patcher in PATCHERS.items():
        changed[rel] = patcher(original[rel])

    # Write only after every replacement has validated.
    for rel, new_text in changed.items():
        path = root / rel
        target_backup = backup / rel
        target_backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target_backup)
        path.write_text(new_text, encoding="utf-8")
        print(f"PATCHED {rel} -> {git_blob_sha(new_text.encode('utf-8'))}")

    print("I1 applied. Base HEAD contract:", BASE_HEAD)
    print("Backups:", backup)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
