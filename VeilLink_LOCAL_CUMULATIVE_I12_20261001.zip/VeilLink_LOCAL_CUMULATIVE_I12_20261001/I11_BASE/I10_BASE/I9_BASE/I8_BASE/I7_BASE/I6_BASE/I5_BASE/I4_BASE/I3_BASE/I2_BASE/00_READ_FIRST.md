# VeilLink 本地累计迭代 I2

**Authority:** GitHub `main` = `152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`，I2 必须建立在 I1 之上。

这不是新的 R1/R2 发布线。目录内自带 I1 基线，因此可以：

```bash
python3 APPLY_CUMULATIVE_I1_I2.py /path/to/VeilLink
```

也可以对已经应用 I1 的源码单独执行：

```bash
python3 I2_APPLY.py /path/to/VeilLink
python3 I2_VERIFY.py /path/to/VeilLink
```

## I2 已修

1. **P0 Keychain/数据库误判**：`errSecInteractionNotAllowed` / `errSecNotAvailable` 不再被折叠成 `nil`。数据库只在 Keychain 明确返回 `errSecItemNotFound` 且数据库不存在时生成新密钥；暂时不可读直接安全停止。
2. **游戏跨设备墙钟**：邀请接受与棋局 move 的因果判断不再依赖两台手机 `Date()` 的大小关系。接受存在后，由 turn + 规则引擎重建棋局。
3. **撤回邀请 ≠ 认输**：新增 `MiniGameCommand.cancelInvite`。新版本撤回使用独立命令；旧 VLGM1 的“pending resign”仍兼容读取。
4. **立即认输误判**：接受后 turn 0 的 `.resign` 现在是正常认输，不再被当成撤回邀请。
5. **邀请生命周期**：30 分钟未响应邀请退出活动对局队列，聊天卡/棋局页明确显示“邀请已过期”。
6. **并发双邀请**：8 秒内同一游戏的交叉邀请通过 session UUID + 已推进状态做确定性合并，避免两端各等一局。
7. **聊天列表方向文案**：本机发送邀请不再显示“邀请你玩”，新增 outgoing preview。
8. 新增对应 XCTest 源码用例：clock skew、cancel/resign 区分、邀请过期/并发合并、Keychain transient status 分类。

## 仍留到后续累计层

- BLE Secure Ready churn / TX pump stall。
- A9 ghost snapshot / persistence 时间语义 / 多传输感知。
- LAN Turbo / Relay / Mesh 诊断盲区。
- 深浅色主题、系统 Sheet 风格统一、锁屏横屏布局。
- iPhone 7 真机 MetricKit crash stack 仍需要新的 I1/I2 构建实测闭环。

## 真机 I2 最小验收

- iPhone 7 ↔ iPhone 13：两机系统时间人为错开 5 分钟，邀请→接受→连续 20 手，状态仍一致。
- 双方在 3 秒内同时发同一种游戏邀请，只保留一条活动对局。
- 邀请后立即撤回：双方显示取消；接受后立即认输：双方显示认输结束，二者不得混淆。
- 锁屏/刚解锁状态启动 App：若 Keychain 暂不可用，只显示安全重试提示，不允许出现“永久密钥丢失”误判，更不允许生成新数据库密钥。
