# VeilLink 本地累计迭代 I3

**基线：** `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`

这不是新的 R1/R2 分支。I3 继续叠加 I1 + I2，包内已经完整携带 I2_BASE。

## 一键累计应用

在 VeilLink 仓库根目录之外运行：

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3.py /path/to/VeilLink
```

行为：

1. fresh `152c3ab...`：自动应用 I1 -> I2 -> I3；
2. 已到 I2：只应用 I3；
3. 已到 I3：不重复写，只运行 I3 验证；
4. 任何基线文件漂移、旧 marker 不匹配或替换点不是唯一命中：整层拒绝写入；
5. I3 写入前自动备份到 `.veillink-local-iter/I3-backup/`。

## I3 修复重点

- 修复 `CBPeripheralManager.updateValue(...) == false` 后缺失恢复回调造成的外围方向 TX pump 永久停滞；
- central 方向保留官方 `peripheralIsReady(toSendWriteWithoutResponse:)` 主回调，并增加低频有界 safety probe；
- BLE 状态不再把物理连接说成“加密链路已就绪”，显式区分 `DISCOVERED / PHY_CONNECTED / GATT_READY`；游戏 UI 再叠加 `SECURE_SESSION_READY`；
- 双角色链路中，一条角色掉线不再误杀仍由另一条 GATT 角色维持的安全会话；
- 真正 transport epoch 结束时清空该来源未完成 BLE 分片，避免 reconnect/rekey 后旧分片污染新会话；
- 黑匣子新增 `transport_stage` 与 secure-ready 证据；
- 增加 BLE 分片 epoch reset 与 readiness stage 单测。

## 验收边界

当前环境不是 macOS/Xcode，I3 只完成了本地源码补丁、静态替换点审计和补丁器自身语法验证。**没有宣称 iPhone 7 / iPhone 13 真机 BLE、XCTest、iphoneos build 已通过。**

后续真实门槛：XcodeGen -> XCTest -> unsigned iphoneos build -> iPhone 7 + iPhone 13 双机 backpressure / dual-role / reconnect / game invite matrix。
