from pathlib import Path
import subprocess
import sys

REQUIRED = {
    "VeilLink/Transport/BLETransport.swift": [
        "private var lastSeenAt: [UUID: TimeInterval] = [:]",
        "private let passiveDiscoveryRetention: TimeInterval = 15",
        "private func pruneStaleDiscoveryState(now: TimeInterval)",
        "lastSeenAt[id] = now",
    ],
    "VeilLink/Transport/BLELinkSnapshot.swift": [
        "var isA9Relevant: Bool",
        "var contributesLinkQualityToA9: Bool",
    ],
    "VeilLink/Health/VeilA9Lattice.swift": [
        "enum VeilA9TransportCoverage",
        "case bluetoothOnly = \"BLE_ONLY\"",
        "persistentDurationThresholdSeconds = 30",
        "var persistenceSeconds: Int { persistenceRuns }",
    ],
    "VeilLink/Health/VeilA9HealthMonitor.swift": [
        "private var nonGreenSinceUptime: TimeInterval?",
        "uptime: TimeInterval = ProcessInfo.processInfo.systemUptime",
        "Persistence: \\(decision.persistenceSeconds) s",
        "Transport coverage: \\(transportCoverage.title)",
    ],
    "VeilLink/App/AppModel.swift": [
        "bluetooth.linkSnapshots.values.filter(\\.isA9Relevant)",
        "let liveQualitySnapshots = snapshots.filter(\\.contributesLinkQualityToA9)",
        "transportCoverage: .bluetoothOnly",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "enum DeepTelemetryStallPolicy",
        "heartbeatResumeGraceUntilUptime",
        "applicationActive = UIApplication.shared.applicationState == .active",
        "postInteractionSnapshotTask",
        "minimumInterval: TimeInterval = VeilDevicePerformance.current.transferVisualComplexity == .full ? 0.75 : 1.5",
        "viewLimit = VeilDevicePerformance.current.transferVisualComplexity == .full ? 1_200 : 700",
        "DeepTelemetry.shared.setApplicationActive(true)",
        "DeepTelemetry.shared.setApplicationActive(false)",
    ],
    "VeilLink/Diagnostics/DiagnosticLogStore.swift": [
        "private let flushThresholdBytes = 256 * 1_024",
        "flushesSinceDiskUsageRefresh",
        "Task.sleep(nanoseconds: 1_500_000_000)",
        "private func rotateIfNeeded(incomingBytes: Int) -> Bool",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        '"persistence_seconds": String(decision.persistenceSeconds)',
        '"transport_coverage": model.a9Health.transportCoverage.rawValue',
    ],
    "VeilLinkTests/A9HealthLatticeTests.swift": [
        "testPersistenceUsesElapsedTimeNotCallbackVolume",
        "testPersistentThresholdRepresentsSeconds",
    ],
    "VeilLinkTests/DiagnosticLogStoreTests.swift": [
        "testStallPolicyRejectsSuspensionAndResumeGrace",
    ],
    "VeilLinkTests/BLELinkSnapshotTests.swift": [
        "testPassiveDiscoveryDoesNotContributeToA9Health",
    ],
}

FORBIDDEN = {
    "VeilLink/Health/VeilA9HealthMonitor.swift": [
        "persistenceRuns = min(9_999, persistenceRuns + 1)",
        '"Persistence runs: \\(decision.persistenceRuns)"',
    ],
    "VeilLink/App/AppModel.swift": [
        "weakPeerCount: snapshots.filter { $0.quality == .weak }.count",
        "minimumLinkHealth: snapshots.map(\\.healthScore).min()",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "lastHeartbeatAt = Date()",
        "now.timeIntervalSince(lastSnapshotAt) < 0.25",
        "visibleViewCount(in: window, limit: 2_500)",
        "DispatchQueue.main.asyncAfter(deadline: .now() + 0.06)",
        'captureUIHierarchy(reason: "controller.appear", force: true)',
    ],
    "VeilLink/Diagnostics/DiagnosticLogStore.swift": [
        "private let flushThresholdBytes = 64 * 1_024",
        "Task.sleep(nanoseconds: 600_000_000)",
    ],
}


def fail(message: str):
    print("FAIL:", message)
    raise SystemExit(1)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I4_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()

    for rel, needles in REQUIRED.items():
        p = root / rel
        if not p.exists():
            fail(f"missing {rel}")
        source = p.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in source:
                fail(f"{rel}: missing {needle!r}")

    for rel, needles in FORBIDDEN.items():
        source = (root / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle in source:
                fail(f"{rel}: forbidden pre-I4 path remains: {needle!r}")

    # Parse every I4-modified Swift file. -parse works without resolving Apple SDK modules,
    # so this catches syntax damage even in a non-macOS local audit environment.
    swift_files = [rel for rel in REQUIRED if rel.endswith(".swift")]
    for rel in swift_files:
        p = subprocess.run(["swiftc", "-parse", str(root / rel)], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout)
            print(p.stderr)
            fail(f"swiftc -parse failed: {rel}")
    print(f"PASS swiftc -parse ({len(swift_files)} I4 files)")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I4 static verification")
    print("NEXT: XcodeGen + XCTest + iphoneos build, then A9/telemetry burn-in on iPhone 7 + iPhone 13.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
