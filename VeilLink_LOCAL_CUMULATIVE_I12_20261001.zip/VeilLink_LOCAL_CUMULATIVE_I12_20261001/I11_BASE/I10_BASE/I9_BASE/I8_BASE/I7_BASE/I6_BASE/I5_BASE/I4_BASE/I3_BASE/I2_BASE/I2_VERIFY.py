from pathlib import Path
import subprocess
import sys

REQUIRED = {
    "VeilLink/Security/KeychainStore.swift": [
        "func readData(for key: String) throws -> Data?",
        "case errSecItemNotFound:",
        "KeychainError.temporarilyUnavailable",
    ],
    "VeilLink/Storage/DatabaseStore.swift": [
        "encryptionKeyTemporarilyUnavailable",
        "existingKeyData = try keychain.readData(for: storageKeyName)",
        "应用不会生成新密钥或覆盖数据库",
    ],
    "VeilLink/Security/SessionCoordinator.swift": ["MiniGameCodec.outgoingPreviewText(for: packet)"],
    "VeilLink/Core/MiniGames.swift": [
        "case cancelInvite",
        "outgoingPreviewText",
        "invitationTimeout",
        "coalescedLiveSessions",
        "cross-device wall clocks are never used",
    ],
    "VeilLink/UI/ConversationViews.swift": [
        "coalescedLiveSessions",
        "!gameSession.isInvitationExpired",
        "!session.isInvitationExpired",
    ],
    "VeilLink/UI/MiniGameViews.swift": [
        "邀请已过期",
        "send(command: .cancelInvite",
        "coalescedLiveSessions(sessions)",
    ],
    "VeilLinkTests/MiniGameTests.swift": [
        "testClockSkewDoesNotDropAcceptanceOrNextMove",
        "testImmediateResignAfterAcceptanceIsNotMisclassifiedAsInviteCancellation",
        "testInvitationExpiryAndConcurrentInviteCoalescing",
    ],
    "VeilLinkTests/DatabaseStoreTests.swift": [
        "testKeychainProtectedDataStatusesAreTransientNotMissing",
    ],
}

FORBIDDEN = {
    "VeilLink/UI/MiniGameViews.swift": ["Button(\"撤回邀请\") { send(command: .resign, turn: 0, move: nil) }"],
    "VeilLink/Security/SessionCoordinator.swift": ["preview: MiniGameCodec.previewText(for: packet)"],
    "VeilLink/Storage/DatabaseStore.swift": ["if let existing = keychain.data(for: storageKeyName)"],
}


def fail(msg: str):
    print("FAIL:", msg)
    raise SystemExit(1)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I2_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    for rel, needles in REQUIRED.items():
        p = root / rel
        if not p.exists(): fail(f"missing {rel}")
        t = p.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in t: fail(f"{rel}: missing {needle!r}")
    for rel, needles in FORBIDDEN.items():
        t = (root / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle in t: fail(f"{rel}: forbidden old path remains: {needle!r}")

    core = (root / "VeilLink/Core/MiniGames.swift").read_text(encoding="utf-8")
    if "!eventOrder($0, invite)" in core or "eventOrder(lifecycleEvent" in core:
        fail("MiniGameSessionBuilder still uses cross-device wall-clock event order for state causality")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I2 static verification")
    print("NEXT: XcodeGen + XCTest + unsigned iphoneos build; then two-device iPhone 7/iPhone 13 invite/cancel/clock-skew/reconnect matrix.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
