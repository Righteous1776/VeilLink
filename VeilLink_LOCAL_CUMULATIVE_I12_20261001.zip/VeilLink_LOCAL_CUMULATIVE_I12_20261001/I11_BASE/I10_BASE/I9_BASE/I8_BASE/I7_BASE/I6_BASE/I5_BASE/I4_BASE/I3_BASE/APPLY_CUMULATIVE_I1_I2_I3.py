from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink/Resources/Info.plist").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    # Bring a fresh main or an I1 tree to cumulative I2 first.
    run([sys.executable, HERE / "I2_BASE/APPLY_CUMULATIVE_I1_I2.py", root])

    # Idempotent I3: never rewrite an already-I3 tree.
    transport = (root / "VeilLink/Transport/BLETransport.swift").read_text(encoding="utf-8")
    snapshot = (root / "VeilLink/Transport/BLELinkSnapshot.swift").read_text(encoding="utf-8")
    already_i3 = (
        "peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)" in transport
        and "enum BLETransportStage" in snapshot
        and "reconcileConnectionEvent" in transport
    )
    if not already_i3:
        run([sys.executable, HERE / "I3_APPLY.py", root])
    run([sys.executable, HERE / "I3_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
