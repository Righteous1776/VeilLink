from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink/Resources/Info.plist").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    run([sys.executable, HERE / "I4_BASE/APPLY_CUMULATIVE_I1_I2_I3_I4.py", root])

    theme = (root / "VeilLink/Core/AppTheme.swift").read_text(encoding="utf-8")
    lock = (root / "VeilLink/UI/LockScreenView.swift").read_text(encoding="utf-8")
    already_i5 = "enum VeilUILayoutPolicy" in theme and "VeilUILayoutPolicy.lockUsesHorizontalLayout" in lock
    if not already_i5:
        run([sys.executable, HERE / "I5_APPLY.py", root])
    run([sys.executable, HERE / "I5_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 -> I4 -> I5 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
