from pathlib import Path
import subprocess
import sys

REQUIRED = {
    "VeilLink/Resources/Info.plist": ["NSFaceIDUsageDescription", "VeilLink 使用 Face ID 在本机解锁应用"],
    "VeilLink/Core/DevicePerformanceProfile.swift": ["prefersLightweightGameRuntime", 'case "iPhone9,1", "iPhone9,2", "iPhone9,3", "iPhone9,4"'],
    "VeilLink/Agent/Integration/AgentGameContextBroker.swift": ["compact-safe", "policyRuntime.scores(observation: observation, candidates: legal)"],
    "VeilLink/Core/MiniGames.swift": ["never let an outbound command that definitively failed/cancelled mutate"],
    "VeilLink/UI/ConversationViews.swift": ["发送游戏邀请", "game.invite.send", "respondToGameInvite"],
    "VeilLink/UI/MiniGameViews.swift": ["重新发送上一条游戏操作", "game.command.retry", "DispatchQueue.global(qos: .userInitiated).async"],
}
FORBIDDEN = {
    "VeilLink/Agent/Integration/AgentGameContextBroker.swift": ["adapter.enumerateLegalActions().filter(adapter.validate)", "policyRuntime.rankedLegalActions(adapter: adapter)"],
}

def fail(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 I1_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    for rel, needles in REQUIRED.items():
        path = root / rel
        if not path.exists(): fail(f"missing {rel}")
        text = path.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in text: fail(f"{rel}: missing marker {needle!r}")
    for rel, needles in FORBIDDEN.items():
        text = (root / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle in text: fail(f"{rel}: old hot path still present: {needle!r}")

    mv = (root / "VeilLink/UI/MiniGameViews.swift").read_text(encoding="utf-8")
    if mv.count("reload(notify: false)") != 1:
        fail("MiniGameViews: expected only the onAppear reload(notify:false); duplicate local-send rebuild may remain")
    if '.background(VeilAmbientBackground().ignoresSafeArea())\n                .navigationTitle(session.game.title)' in mv:
        fail("MiniGameSession still bypasses the iOS 15 safe-area compositor guard")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I1 static verification")
    print("NEXT: run XcodeGen + simulator/unit tests + unsigned iphoneos build on macOS CI, then reproduce two-device game turns on iPhone 7/iPhone 13.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
