# VeilLink 本地累计迭代 I1

**Base authority:** GitHub `main` at `152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`.

这是累计迭代包，不是新的 R1→R12 重跑。I2 必须建立在 I1 已应用源码之上。

## I1 目标

1. 修复 iPhone 7 联机游戏“一步触发一次/两次全历史同步重建”的主线程回归。
2. A9/A10 2GB 设备进入游戏 `compact-safe`：实时棋局不在 MainActor 上跑训练排序与 MaleCNS rerank。
3. 消除 Agent 游戏合法动作的 O(N²) 重复枚举：一次枚举，直接对同一候选集评分。
4. 本机发送游戏命令后不再立即同步 rebuild，再等 `messagesRevision` 触发一次后台重建。
5. 游戏命令发送失败/取消后，不再继续污染棋盘重建；失败邀请仍保留，便于重试。
6. 游戏页面增加“重新发送上一条游戏操作”。
7. 恢复聊天 `+` 菜单中的“发送游戏邀请”，可直接选择五子棋/象棋/飞行棋/兵棋。
8. 收到邀请后，聊天卡可直接“接受/拒绝”；发送失败邀请可直接重试。
9. 增加关键游戏语义遥测：invite send/accept/decline、command send/retry。
10. 修复游戏 Hub/Session 对 iOS 15 兼容背景保护的绕过。
11. 补 `NSFaceIDUsageDescription`，关闭已知 Face ID 隐私键 P0 崩溃入口。

## 使用

```bash
python3 I1_APPLY.py /path/to/VeilLink
python3 I1_VERIFY.py /path/to/VeilLink
```

补丁器先验证 6 个目标文件的 Git blob SHA；任意文件不是当前基线都会拒绝执行，不会半套覆盖。
原文件自动备份到：`.veillink-local-iter/I1-backup/`。

## I1 不宣称已解决

- 尚无 iPhone 7 MetricKit crash stack，因此“一步闪退”的异常类型仍需要新真机包验证；I1 修复的是目前已定位到的高可信主线程/状态链根因。
- Keychain protected-data 误判、BLE Secure Ready churn、TX pump stall、A9 ghost/persistence、多传输 telemetry、主题/白天模式尚未进入 I1。
- 游戏跨设备墙钟排序、`resign` 同时承担撤回邀请/认输、并发双邀请冲突，留到 I2 协议层修复，避免 I1 同时改 wire semantics。

## 真机验收最小矩阵

- iPhone 7 ↔ iPhone 13：五子棋连续至少 30 手；双方交替落子，不允许崩溃/无响应。
- 两端各自发起邀请：聊天内直发、接受、拒绝、失败重试均验证。
- BLE 暂断后恢复：失败操作出现明确重试入口，重试后双方棋盘一致。
- iPhone 7 检查触控：轮到本机时棋盘必须可点；非本机回合要明确显示等待而非“静默吃点击”。
