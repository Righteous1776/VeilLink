from pathlib import Path
import hashlib
import shutil
import sys

BASE_HEAD = "152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f"
BASE_BLOBS_UNCHANGED_BY_I1 = {
    "VeilLink/Security/KeychainStore.swift": "1501cb5f57928f2aa98de43d59980a6e27e4d41c",
    "VeilLink/Storage/DatabaseStore.swift": "97613d55c38628e69bf6973421098652d27fc2c5",
    "VeilLink/Security/SessionCoordinator.swift": "0df0090a8219afa178ee0fcc4f04e243e199ce5c",
    "VeilLinkTests/MiniGameTests.swift": "b1ebf3ba2f119dcc6dd5524eb69b3eefb66f7177",
    "VeilLinkTests/DatabaseStoreTests.swift": "0e02764ae165279ff7ac2fcecf24dcd7ee99989e",
}

I1_MARKERS = {
    "VeilLink/Core/MiniGames.swift": ["never let an outbound command that definitively failed/cancelled mutate"],
    "VeilLink/UI/ConversationViews.swift": ["发送游戏邀请", "respondToGameInvite", "game.invite.send"],
    "VeilLink/UI/MiniGameViews.swift": ["重新发送上一条游戏操作", "game.command.retry", "DispatchQueue.global(qos: .userInitiated).async"],
    "VeilLink/Resources/Info.plist": ["NSFaceIDUsageDescription"],
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def patch_keychain(text: str) -> str:
    old = '''enum KeychainError: Error {
    case unexpectedStatus(OSStatus)
}'''
    new = '''enum KeychainError: LocalizedError {
    case temporarilyUnavailable(OSStatus)
    case unexpectedStatus(OSStatus)

    var errorDescription: String? {
        let status: OSStatus
        switch self {
        case .temporarilyUnavailable(let value), .unexpectedStatus(let value): status = value
        }
        let detail = SecCopyErrorMessageString(status, nil) as String? ?? "OSStatus \\(status)"
        switch self {
        case .temporarilyUnavailable:
            return "Keychain 当前暂不可读取：\\(detail)"
        case .unexpectedStatus:
            return "Keychain 读取失败：\\(detail)"
        }
    }
}'''
    text = replace_once(text, old, new, "Keychain error semantics")

    old = '''    func data(for key: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess else { return nil }
        return result as? Data
    }'''
    new = '''    static func isTransientReadStatus(_ status: OSStatus) -> Bool {
        status == errSecInteractionNotAllowed || status == errSecNotAvailable
    }

    /// Distinguishes "item genuinely missing" from "Keychain cannot be read right now".
    /// Callers that protect irreplaceable state (database keys) must use this throwing API.
    func readData(for key: String) throws -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        switch status {
        case errSecSuccess:
            guard let data = result as? Data else { throw KeychainError.unexpectedStatus(errSecDecode) }
            return data
        case errSecItemNotFound:
            return nil
        default:
            if Self.isTransientReadStatus(status) { throw KeychainError.temporarilyUnavailable(status) }
            throw KeychainError.unexpectedStatus(status)
        }
    }

    /// Compatibility accessor for non-critical preferences. Critical key material must call readData(for:).
    func data(for key: String) -> Data? {
        try? readData(for: key)
    }'''
    return replace_once(text, old, new, "Keychain throwing read API")


def patch_database(text: str) -> str:
    old = '''    case encryptionKeyMissing
    case encryptionKeyMismatch'''
    new = '''    case encryptionKeyMissing
    case encryptionKeyTemporarilyUnavailable(String)
    case encryptionKeyMismatch'''
    text = replace_once(text, old, new, "DatabaseError key unavailable case")

    old = '''        case .encryptionKeyMissing:
            return "本地数据库仍存在，但其加密密钥已从 Keychain 丢失。VeilLink 已停止打开数据，避免用新密钥覆盖原状态。"
        case .encryptionKeyMismatch:
            return "本地数据库加密密钥与现有数据不匹配。VeilLink 已停止继续读写，请使用有效备份恢复。"'''
    new = '''        case .encryptionKeyMissing:
            return "本地数据库仍存在，但 Keychain 明确报告加密密钥不存在。VeilLink 已停止打开数据，避免用新密钥覆盖原状态。"
        case .encryptionKeyTemporarilyUnavailable(let detail):
            return "本地数据库仍安全保留，但设备当前无法读取 Keychain 加密密钥。请先解锁设备后重新打开 VeilLink；应用不会生成新密钥或覆盖数据库。\\n\\(detail)"
        case .encryptionKeyMismatch:
            return "本地数据库加密密钥与现有数据不匹配。VeilLink 已停止继续读写，请使用有效备份恢复。"'''
    text = replace_once(text, old, new, "DatabaseError copy")

    old = '''        let databaseAlreadyExists = fileManager.fileExists(atPath: databaseURL.path)
        if let existing = keychain.data(for: storageKeyName) {
            guard existing.count == 32 else { throw DatabaseError.encryptionKeyMismatch }
            storageKeyData = existing
            storageKey = SymmetricKey(data: existing)
        } else {
            guard !databaseAlreadyExists else { throw DatabaseError.encryptionKeyMissing }
            let generated = PasswordKDF.randomData(count: 32)
            try keychain.set(generated, for: storageKeyName)
            storageKeyData = generated
            storageKey = SymmetricKey(data: generated)
        }'''
    new = '''        let databaseAlreadyExists = fileManager.fileExists(atPath: databaseURL.path)
        let existingKeyData: Data?
        do {
            existingKeyData = try keychain.readData(for: storageKeyName)
        } catch {
            // Never collapse a protected-data / Keychain availability failure into "missing".
            // Doing so can incorrectly diagnose permanent key loss while the device is merely locked.
            throw DatabaseError.encryptionKeyTemporarilyUnavailable(error.localizedDescription)
        }

        if let existing = existingKeyData {
            guard existing.count == 32 else { throw DatabaseError.encryptionKeyMismatch }
            storageKeyData = existing
            storageKey = SymmetricKey(data: existing)
        } else {
            guard !databaseAlreadyExists else { throw DatabaseError.encryptionKeyMissing }
            let generated = PasswordKDF.randomData(count: 32)
            try keychain.set(generated, for: storageKeyName)
            storageKeyData = generated
            storageKey = SymmetricKey(data: generated)
        }'''
    return replace_once(text, old, new, "Database keychain read classification")


def patch_session_coordinator(text: str) -> str:
    old = '''            preview: MiniGameCodec.previewText(for: packet),'''
    new = '''            preview: MiniGameCodec.outgoingPreviewText(for: packet),'''
    return replace_once(text, old, new, "Outgoing game conversation preview")


def patch_minigames(text: str) -> str:
    old = '''enum MiniGameCommand: String, Codable {
    case invite
    case accept
    case decline
    case move
    case resign
}'''
    new = '''enum MiniGameCommand: String, Codable {
    case invite
    case accept
    case decline
    case cancelInvite
    case move
    case resign
}'''
    text = replace_once(text, old, new, "MiniGame explicit cancelInvite command")

    old = '''    static func previewText(for packet: MiniGamePacket) -> String {
        switch packet.command {
        case .invite: return "[小游戏] 邀请你玩\\(packet.game.title)"
        case .accept: return "[小游戏] 已接受\\(packet.game.title)对局"
        case .decline: return "[小游戏] 已拒绝\\(packet.game.title)对局"
        case .move: return "[小游戏] \\(packet.game.title) · 对局更新"
        case .resign: return "[小游戏] \\(packet.game.title) · 对局结束"
        }
    }'''
    new = '''    static func previewText(for packet: MiniGamePacket) -> String {
        switch packet.command {
        case .invite: return "[小游戏] 邀请你玩\\(packet.game.title)"
        case .accept: return "[小游戏] 已接受\\(packet.game.title)对局"
        case .decline: return "[小游戏] 已拒绝\\(packet.game.title)对局"
        case .cancelInvite: return "[小游戏] \\(packet.game.title) · 邀请已撤回"
        case .move: return "[小游戏] \\(packet.game.title) · 对局更新"
        case .resign: return "[小游戏] \\(packet.game.title) · 对局结束"
        }
    }

    static func outgoingPreviewText(for packet: MiniGamePacket) -> String {
        switch packet.command {
        case .invite: return "[小游戏] 已邀请对方玩\\(packet.game.title)"
        case .accept: return "[小游戏] 你已接受\\(packet.game.title)对局"
        case .decline: return "[小游戏] 你已拒绝\\(packet.game.title)对局"
        case .cancelInvite: return "[小游戏] 你已撤回\\(packet.game.title)邀请"
        case .move: return "[小游戏] \\(packet.game.title) · 你已操作"
        case .resign: return "[小游戏] \\(packet.game.title) · 你已认输"
        }
    }'''
    text = replace_once(text, old, new, "MiniGame directional previews")

    old = '''    var localOutcome: MiniGameOutcome? {
        guard case .finished(let winner) = status else { return nil }
        guard let winner else { return .draw }
        return winner == localPlayer ? .win : .loss
    }
}'''
    new = '''    static let invitationTimeout: TimeInterval = 30 * 60

    func invitationIsExpired(at now: Date = Date()) -> Bool {
        guard status == .invited else { return false }
        return now.timeIntervalSince(invitedAt) >= Self.invitationTimeout
    }

    var isInvitationExpired: Bool { invitationIsExpired() }

    var localOutcome: MiniGameOutcome? {
        guard case .finished(let winner) = status else { return nil }
        guard let winner else { return .draw }
        return winner == localPlayer ? .win : .loss
    }
}'''
    text = replace_once(text, old, new, "MiniGame invitation expiry")

    marker = "never let an outbound command that definitively failed/cancelled mutate"
    if marker not in text:
        raise RuntimeError("MiniGameSessionBuilder: I1 failed-outbound filter marker missing")
    start = text.find("enum MiniGameSessionBuilder {")
    if start < 0:
        raise RuntimeError("MiniGameSessionBuilder start not found")
    if text[start:].count("enum MiniGameSessionBuilder {") != 1:
        raise RuntimeError("MiniGameSessionBuilder appears more than once")

    builder = r'''enum MiniGameSessionBuilder {
    static let concurrentInviteCollisionWindow: TimeInterval = 8

    static func sessions(from messages: [ChatMessage]) -> [MiniGameSessionSnapshot] {
        let decoded: [(ChatMessage, MiniGamePacket)] = messages.compactMap { message in
            guard let packet = MiniGameCodec.decode(message.body) else { return nil }
            return (message, packet)
        }
        let grouped = Dictionary(grouping: decoded, by: { $0.1.sessionID })
        return grouped.compactMap { sessionID, events in
            build(sessionID: sessionID, events: events)
        }.sorted { $0.lastActivity > $1.lastActivity }
    }

    static func session(id: String, from messages: [ChatMessage]) -> MiniGameSessionSnapshot? {
        let events: [(ChatMessage, MiniGamePacket)] = messages.compactMap { message in
            guard let packet = MiniGameCodec.decode(message.body), packet.sessionID == id else { return nil }
            return (message, packet)
        }
        return build(sessionID: id, events: events)
    }

    static func sessionsByID(from messages: [ChatMessage]) -> [String: MiniGameSessionSnapshot] {
        Dictionary(uniqueKeysWithValues: sessions(from: messages).map { ($0.id, $0) })
    }

    /// The UI exposes one live session per game. Near-simultaneous cross-invites are coalesced
    /// deterministically instead of leaving two contradictory "waiting" sessions on the peers.
    static func coalescedLiveSessions(
        _ sessions: [MiniGameSessionSnapshot],
        now: Date = Date()
    ) -> [MiniGameSessionSnapshot] {
        let live = sessions.filter { snapshot in
            guard !snapshot.invitationIsExpired(at: now) else { return false }
            switch snapshot.status {
            case .invited, .active: return true
            case .declined, .cancelled, .finished: return false
            }
        }

        return live.filter { candidate in
            let collisionGroup = sessions.filter { other in
                guard other.game == candidate.game else { return false }
                return abs(other.invitedAt.timeIntervalSince(candidate.invitedAt)) <= concurrentInviteCollisionWindow
            }
            guard collisionGroup.count > 1 else { return true }

            // Once either invitation has progressed beyond pending, keep that session canonical.
            // Otherwise both peers choose the same UUID-lexicographic winner.
            let progressed = collisionGroup.filter { $0.status != .invited }
            let pool = progressed.isEmpty ? collisionGroup : progressed
            guard let canonical = pool.min(by: { $0.id < $1.id }) else { return true }
            return candidate.id == canonical.id
        }.sorted { $0.lastActivity > $1.lastActivity }
    }

    static func replay(sessionID: String, from messages: [ChatMessage]) -> [MiniGameReplayFrame] {
        let ordered: [(ChatMessage, MiniGamePacket)] = messages.compactMap { message in
            guard let packet = MiniGameCodec.decode(message.body), packet.sessionID == sessionID else { return nil }
            return (message, packet)
        }.sorted(by: semanticEventOrder)
        guard !ordered.isEmpty else { return [] }

        var frames: [MiniGameReplayFrame] = []
        var previous: MiniGameSessionSnapshot?
        for offset in ordered.indices {
            let prefix = Array(ordered.prefix(offset + 1))
            guard let snapshot = build(sessionID: sessionID, events: prefix) else { continue }
            let changed = previous == nil || previous?.status != snapshot.status || previous?.moveCount != snapshot.moveCount
            guard changed else { continue }
            let packet = ordered[offset].1
            let label: String
            switch packet.command {
            case .invite: label = "邀请对局"
            case .accept: label = "对局开始"
            case .decline: label = "邀请被拒绝"
            case .cancelInvite: label = "邀请已撤回"
            case .resign: label = snapshot.status == .cancelled ? "邀请已撤回（旧协议）" : "认输结束"
            case .move:
                let unit = snapshot.game == .tactical ? "道命令" : "手"
                if case .finished(let winner) = snapshot.status, winner == nil {
                    label = "第 \(snapshot.moveCount) \(unit) · 和棋"
                } else {
                    label = "第 \(snapshot.moveCount) \(unit)"
                }
            }
            frames.append(MiniGameReplayFrame(id: packet.actionID, index: frames.count, label: label, snapshot: snapshot))
            previous = snapshot
        }
        return frames
    }

    private static func build(sessionID: String, events: [(ChatMessage, MiniGamePacket)]) -> MiniGameSessionSnapshot? {
        let compatible = events.filter { event in
            guard event.1.version == MiniGamePacket.currentVersion else { return false }
            // Keep a failed invite visible so the sender can retry it from the chat card, but
            // never let an outbound command that definitively failed/cancelled mutate the
            // reconstructed board or terminal state. A retry flips the message back to queued.
            if event.0.isOutgoing, event.0.deliveryState == .failed || event.0.deliveryState == .cancelled {
                return event.1.command == .invite
            }
            return true
        }

        let ordered = Dictionary(grouping: compatible, by: { $0.1.actionID })
            .values
            .compactMap { duplicates in duplicates.min(by: duplicatePreferenceOrder) }
            .sorted(by: semanticEventOrder)

        guard let invite = ordered.first(where: { $0.1.command == .invite && $0.1.turn == 0 }) else { return nil }
        let game = invite.1.game
        let hostIsLocal = invite.0.isOutgoing
        let invitedAt = invite.1.createdAt
        let actor: (ChatMessage) -> MiniGamePlayer = { message in
            message.isOutgoing == hostIsLocal ? .host : .guest
        }
        let valid = ordered.filter { $0.1.game == game && $0.1.actionID != invite.1.actionID }
        let activity: ((ChatMessage, MiniGamePacket)) -> Date = { $0.1.createdAt }

        let guestDecisions = valid.filter { event in
            actor(event.0) == .guest && (event.1.command == .accept || event.1.command == .decline)
        }.sorted(by: sameSenderOrder)
        let guestDecision = guestDecisions.first

        let explicitCancellation = valid.filter { event in
            actor(event.0) == .host && event.1.command == .cancelInvite && event.1.turn == 0
        }.min(by: sameSenderOrder)

        let legacyCancellation = valid.filter { event in
            actor(event.0) == .host && event.1.command == .resign && event.1.turn == 0
        }.min(by: sameSenderOrder)

        let initialGomoku = game == .gomoku ? GomokuState() : nil
        let initialXiangqi = game == .xiangqi ? XiangqiState() : nil
        let initialLudo = game == .ludo ? LudoState() : nil
        let initialTactical = game == .tactical ? TacticalState() : nil

        let hasGameplayMove = valid.contains { $0.1.command == .move }
        if let explicitCancellation, !hasGameplayMove {
            return MiniGameSessionSnapshot(
                id: sessionID, game: game, hostIsLocal: hostIsLocal, status: .cancelled,
                invitedAt: invitedAt, startedAt: nil, lastActivity: activity(explicitCancellation),
                gomoku: initialGomoku, xiangqi: initialXiangqi, ludo: initialLudo, tactical: initialTactical,
                endedByResignation: false
            )
        }

        if guestDecision?.1.command == .decline {
            return MiniGameSessionSnapshot(
                id: sessionID, game: game, hostIsLocal: hostIsLocal, status: .declined,
                invitedAt: invitedAt, startedAt: nil, lastActivity: guestDecision.map(activity) ?? invitedAt,
                gomoku: initialGomoku, xiangqi: initialXiangqi, ludo: initialLudo, tactical: initialTactical,
                endedByResignation: false
            )
        }

        guard let accepted = guestDecision, accepted.1.command == .accept else {
            // Backward compatibility for old VLGM1 clients that used host resign(turn:0) to
            // withdraw a still-pending invitation. Once accept exists, resign is a real resignation.
            if let legacyCancellation {
                return MiniGameSessionSnapshot(
                    id: sessionID, game: game, hostIsLocal: hostIsLocal, status: .cancelled,
                    invitedAt: invitedAt, startedAt: nil, lastActivity: activity(legacyCancellation),
                    gomoku: initialGomoku, xiangqi: initialXiangqi, ludo: initialLudo, tactical: initialTactical,
                    endedByResignation: false
                )
            }
            return MiniGameSessionSnapshot(
                id: sessionID, game: game, hostIsLocal: hostIsLocal, status: .invited,
                invitedAt: invitedAt, startedAt: nil, lastActivity: invitedAt,
                gomoku: initialGomoku, xiangqi: initialXiangqi, ludo: initialLudo, tactical: initialTactical,
                endedByResignation: false
            )
        }

        let startedAt = activity(accepted)
        let gameplayEvents = valid.filter { $0.1.command == .move || $0.1.command == .resign }
        let gameplayEventsByTurn = Dictionary(grouping: gameplayEvents, by: { $0.1.turn })
        var gomoku = initialGomoku
        var xiangqi = initialXiangqi
        var ludo = initialLudo
        var tactical = initialTactical
        var resignationWinner: MiniGamePlayer?
        var usedActionIDs = Set<String>()
        var effectiveLastActivity = startedAt

        // Wire v1 has no cross-device causal sequence number. Once acceptance exists, game-rule
        // turn validation is authoritative; cross-device wall clocks are never used to decide
        // whether a move happened "before" or "after" acceptance.
        replayLoop: while resignationWinner == nil {
            let turn: Int
            switch game {
            case .gomoku: turn = gomoku?.moveCount ?? 0
            case .xiangqi: turn = xiangqi?.moveCount ?? 0
            case .ludo: turn = ludo?.turn ?? 0
            case .tactical: turn = tactical?.turn ?? 0
            }

            let candidates = (gameplayEventsByTurn[turn] ?? [])
                .filter { !usedActionIDs.contains($0.1.actionID) }
                .sorted(by: gameplayOrder)
            guard !candidates.isEmpty else { break }

            var advanced = false
            for event in candidates {
                let packet = event.1
                guard usedActionIDs.insert(packet.actionID).inserted else { continue }
                let player = actor(event.0)
                if packet.command == .resign {
                    resignationWinner = player.opponent
                    effectiveLastActivity = max(effectiveLastActivity, activity(event))
                    break replayLoop
                }
                guard packet.command == .move, let move = packet.move else { continue }
                let applied: Bool
                switch game {
                case .gomoku:
                    applied = move.to.map { gomoku?.apply(index: $0, actor: player) ?? false } ?? false
                case .xiangqi:
                    if let from = move.from, let to = move.to {
                        applied = xiangqi?.apply(from: from, to: to, actor: player) ?? false
                    } else { applied = false }
                case .ludo:
                    applied = move.piece.map { ludo?.apply(pieceIndex: $0, actor: player, sessionID: sessionID) ?? false } ?? false
                case .tactical:
                    if move.piece == -1, move.from == nil, move.to == nil {
                        applied = tactical?.apply(from: nil, to: nil, actor: player, sessionID: sessionID) ?? false
                    } else {
                        applied = tactical?.apply(from: move.from, to: move.to, actor: player, sessionID: sessionID) ?? false
                    }
                }
                if applied {
                    effectiveLastActivity = max(effectiveLastActivity, activity(event))
                    advanced = true
                    break
                }
            }
            if !advanced { break }

            let hasWinner: Bool
            switch game {
            case .gomoku: hasWinner = gomoku?.winner != nil || gomoku?.isDraw == true
            case .xiangqi: hasWinner = xiangqi?.winner != nil
            case .ludo: hasWinner = ludo?.winner != nil
            case .tactical: hasWinner = tactical?.winner != nil || tactical?.isDraw == true
            }
            if hasWinner { break }
        }

        let boardWinner: MiniGamePlayer?
        let boardDraw: Bool
        switch game {
        case .gomoku:
            boardWinner = gomoku?.winner
            boardDraw = gomoku?.isDraw == true
        case .xiangqi:
            boardWinner = xiangqi?.winner
            boardDraw = xiangqi?.isDraw == true
        case .ludo:
            boardWinner = ludo?.winner
            boardDraw = false
        case .tactical:
            boardWinner = tactical?.winner
            boardDraw = tactical?.isDraw == true
        }

        let status: MiniGameSessionStatus
        if let winner = resignationWinner ?? boardWinner {
            status = .finished(winner: winner)
        } else if boardDraw {
            status = .finished(winner: nil)
        } else {
            status = .active
        }

        return MiniGameSessionSnapshot(
            id: sessionID, game: game, hostIsLocal: hostIsLocal, status: status,
            invitedAt: invitedAt, startedAt: startedAt, lastActivity: effectiveLastActivity,
            gomoku: gomoku, xiangqi: xiangqi, ludo: ludo, tactical: tactical,
            endedByResignation: resignationWinner != nil
        )
    }

    private static func duplicatePreferenceOrder(_ lhs: (ChatMessage, MiniGamePacket), _ rhs: (ChatMessage, MiniGamePacket)) -> Bool {
        if lhs.1.createdAt != rhs.1.createdAt { return lhs.1.createdAt < rhs.1.createdAt }
        if lhs.1.game.rawValue != rhs.1.game.rawValue { return lhs.1.game.rawValue < rhs.1.game.rawValue }
        if lhs.1.command.rawValue != rhs.1.command.rawValue { return lhs.1.command.rawValue < rhs.1.command.rawValue }
        if lhs.1.turn != rhs.1.turn { return lhs.1.turn < rhs.1.turn }
        let leftMove = [lhs.1.move?.from ?? -2, lhs.1.move?.to ?? -2, lhs.1.move?.piece ?? -2]
        let rightMove = [rhs.1.move?.from ?? -2, rhs.1.move?.to ?? -2, rhs.1.move?.piece ?? -2]
        if leftMove != rightMove {
            for (left, right) in zip(leftMove, rightMove) where left != right { return left < right }
        }
        return lhs.0.id < rhs.0.id
    }

    private static func phaseRank(_ command: MiniGameCommand) -> Int {
        switch command {
        case .invite: return 0
        case .accept, .decline, .cancelInvite: return 1
        case .move, .resign: return 2
        }
    }

    private static func commandRank(_ command: MiniGameCommand) -> Int {
        switch command {
        case .invite: return 0
        case .cancelInvite: return 1
        case .decline: return 2
        case .accept: return 3
        case .move: return 4
        case .resign: return 5
        }
    }

    private static func semanticEventOrder(_ lhs: (ChatMessage, MiniGamePacket), _ rhs: (ChatMessage, MiniGamePacket)) -> Bool {
        let lp = phaseRank(lhs.1.command), rp = phaseRank(rhs.1.command)
        if lp != rp { return lp < rp }
        if lhs.1.turn != rhs.1.turn { return lhs.1.turn < rhs.1.turn }
        let lc = commandRank(lhs.1.command), rc = commandRank(rhs.1.command)
        if lc != rc { return lc < rc }
        return lhs.1.actionID < rhs.1.actionID
    }

    private static func sameSenderOrder(_ lhs: (ChatMessage, MiniGamePacket), _ rhs: (ChatMessage, MiniGamePacket)) -> Bool {
        if lhs.1.createdAt != rhs.1.createdAt { return lhs.1.createdAt < rhs.1.createdAt }
        return lhs.1.actionID < rhs.1.actionID
    }

    private static func gameplayOrder(_ lhs: (ChatMessage, MiniGamePacket), _ rhs: (ChatMessage, MiniGamePacket)) -> Bool {
        // createdAt is only comparable when both candidates originate from the same device.
        // isOutgoing equality is preserved on both peers even though its boolean value flips.
        if lhs.0.isOutgoing == rhs.0.isOutgoing, lhs.1.createdAt != rhs.1.createdAt {
            return lhs.1.createdAt < rhs.1.createdAt
        }
        return lhs.1.actionID < rhs.1.actionID
    }
}
'''
    return text[:start] + builder


def patch_conversation(text: str) -> str:
    old = '''        return messages.filter { message in
            if TacticalV2.WireCodecV2.decode(message.body) != nil { return false }
            guard let packet = MiniGameCodec.decode(message.body) else { return true }
            return packet.command == .invite
        }'''
    new = '''        let preferredLiveIDs = Set(
            MiniGameSessionBuilder.coalescedLiveSessions(Array(gameSessionsByID.values)).map(\\.id)
        )
        return messages.filter { message in
            if TacticalV2.WireCodecV2.decode(message.body) != nil { return false }
            guard let packet = MiniGameCodec.decode(message.body) else { return true }
            guard packet.command == .invite else { return false }
            guard let session = gameSessionsByID[packet.sessionID] else { return true }
            if session.status == .invited || session.status == .active {
                return session.isInvitationExpired || preferredLiveIDs.contains(session.id)
            }
            return true
        }'''
    text = replace_once(text, old, new, "Chat concurrent invite coalescing")

    text = replace_once(
        text,
        '''onAccept: gameSession.status == .invited && !gameSession.hostIsLocal ? {''',
        '''onAccept: gameSession.status == .invited && !gameSession.hostIsLocal && !gameSession.isInvitationExpired ? {''',
        "Chat inline accept expiry guard",
    )
    text = replace_once(
        text,
        '''onDecline: gameSession.status == .invited && !gameSession.hostIsLocal ? {''',
        '''onDecline: gameSession.status == .invited && !gameSession.hostIsLocal && !gameSession.isInvitationExpired ? {''',
        "Chat inline decline expiry guard",
    )

    old = '''    private func sendGameInvite(_ game: MiniGameKind) {
        if let existing = gameSessionsByID.values.first(where: { session in
            guard session.game == game else { return false }
            switch session.status {
            case .invited, .active: return true
            case .declined, .cancelled, .finished: return false
            }
        }) {'''
    new = '''    private func sendGameInvite(_ game: MiniGameKind) {
        if let existing = MiniGameSessionBuilder
            .coalescedLiveSessions(Array(gameSessionsByID.values))
            .first(where: { $0.game == game }) {'''
    text = replace_once(text, old, new, "Chat direct invite stale/conflict guard")

    old = '''    private func respondToGameInvite(_ session: MiniGameSessionSnapshot, command: MiniGameCommand) {
        guard session.status == .invited, !session.hostIsLocal, command == .accept || command == .decline else { return }'''
    new = '''    private func respondToGameInvite(_ session: MiniGameSessionSnapshot, command: MiniGameCommand) {
        guard session.status == .invited,
              !session.hostIsLocal,
              !session.isInvitationExpired,
              command == .accept || command == .decline else { return }'''
    return replace_once(text, old, new, "Chat expired invite response guard")


def patch_minigame_views(text: str) -> str:
    old = '''    private var liveSessions: [MiniGameSessionSnapshot] {
        sessions.filter {
            switch $0.status {
            case .invited, .active: return true
            case .declined, .cancelled, .finished: return false
            }
        }
    }'''
    new = '''    private var liveSessions: [MiniGameSessionSnapshot] {
        MiniGameSessionBuilder.coalescedLiveSessions(sessions)
    }'''
    text = replace_once(text, old, new, "Game Hub live-session coalescing")

    old = '''    private var historySessions: [MiniGameSessionSnapshot] {
        sessions.filter {
            switch $0.status {
            case .invited, .active: return false
            case .declined, .cancelled, .finished: return true
            }
        }
    }'''
    new = '''    private var historySessions: [MiniGameSessionSnapshot] {
        sessions.filter {
            if $0.isInvitationExpired { return true }
            switch $0.status {
            case .invited, .active: return false
            case .declined, .cancelled, .finished: return true
            }
        }
    }'''
    text = replace_once(text, old, new, "Game Hub expired invite history")

    old = '''    private var needsAttention: Bool { session.status == .invited && !session.hostIsLocal }'''
    new = '''    private var needsAttention: Bool {
        session.status == .invited && !session.hostIsLocal && !session.isInvitationExpired
    }'''
    text = replace_once(text, old, new, "Session row expired attention")

    old = '''        switch session.status {
        case .invited: return session.hostIsLocal ? "等待对方接受" : "邀请你加入"'''
    new = '''        switch session.status {
        case .invited:
            if session.isInvitationExpired { return "邀请已过期" }
            return session.hostIsLocal ? "等待对方接受" : "邀请你加入"'''
    text = replace_once(text, old, new, "Session row expired label")

    old = '''    private var isIncomingInvitation: Bool { session.status == .invited && !session.hostIsLocal }'''
    new = '''    private var isIncomingInvitation: Bool {
        session.status == .invited && !session.hostIsLocal && !session.isInvitationExpired
    }'''
    text = replace_once(text, old, new, "Conversation card expired attention")

    old = '''        switch session.status {
        case .invited: return session.hostIsLocal ? "已邀请对方 · 等待接受" : "邀请你加入 · 可直接回应"'''
    new = '''        switch session.status {
        case .invited:
            if session.isInvitationExpired { return "邀请已过期 · 可重新发起" }
            return session.hostIsLocal ? "已邀请对方 · 等待接受" : "邀请你加入 · 可直接回应"'''
    text = replace_once(text, old, new, "Conversation card expired label")

    old = '''    @ViewBuilder
    private func invitationView(_ session: MiniGameSessionSnapshot) -> some View {
        if session.hostIsLocal {'''
    new = '''    @ViewBuilder
    private func invitationView(_ session: MiniGameSessionSnapshot) -> some View {
        if session.isInvitationExpired {
            VStack(spacing: 16) {
                Image(systemName: "clock.badge.exclamationmark")
                    .font(.system(size: 46, weight: .light))
                    .foregroundColor(VeilTheme.secondaryText)
                Text("邀请已过期")
                    .font(.title3.bold())
                    .foregroundColor(VeilTheme.text)
                Text("这条邀请超过 30 分钟未完成响应，已退出活动对局队列。你可以返回后重新发起。")
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .foregroundColor(VeilTheme.secondaryText)
                Button("返回小游戏") { dismiss() }
                    .buttonStyle(VeilGamePrimaryButtonStyle())
            }
            .padding(28)
        } else if session.hostIsLocal {'''
    text = replace_once(text, old, new, "Expired invite session view")

    old = '''                    Button("撤回邀请") { send(command: .resign, turn: 0, move: nil) }'''
    new = '''                    Button("撤回邀请") { send(command: .cancelInvite, turn: 0, move: nil) }'''
    return replace_once(text, old, new, "Explicit cancelInvite UI")


def patch_minigame_tests(text: str) -> str:
    old = '''    func testSessionIgnoresMoveSentBeforeInvitationWasAccepted() throws {
        let conversationID = UUID().uuidString
        let invite = MiniGamePacket(game: .gomoku, command: .invite, createdAt: Date(timeIntervalSince1970: 10))
        let premature = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .move, turn: 0, move: .gomoku(index: 112), createdAt: Date(timeIntervalSince1970: 11))
        let accept = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .accept, createdAt: Date(timeIntervalSince1970: 12))
        let messages = [
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(invite), sentAt: Date(timeIntervalSince1970: 10), isOutgoing: true, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(premature), sentAt: Date(timeIntervalSince1970: 11), isOutgoing: true, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "guest", body: try MiniGameCodec.encode(accept), sentAt: Date(timeIntervalSince1970: 12), isOutgoing: false, deliveryState: .delivered)
        ]
        let snapshot = MiniGameSessionBuilder.session(id: invite.sessionID, from: messages)
        XCTAssertEqual(snapshot?.status, .active)
        XCTAssertEqual(snapshot?.moveCount, 0)
        XCTAssertEqual(snapshot?.gomoku?.value(at: 112), 0)
    }'''
    new = '''    func testSessionDoesNotApplyMoveWithoutAcceptance() throws {
        let conversationID = UUID().uuidString
        let invite = MiniGamePacket(game: .gomoku, command: .invite, createdAt: Date(timeIntervalSince1970: 10))
        let premature = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .move, turn: 0, move: .gomoku(index: 112), createdAt: Date(timeIntervalSince1970: 11))
        let messages = [
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(invite), sentAt: Date(timeIntervalSince1970: 10), isOutgoing: true, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(premature), sentAt: Date(timeIntervalSince1970: 11), isOutgoing: true, deliveryState: .delivered)
        ]
        let snapshot = MiniGameSessionBuilder.session(id: invite.sessionID, from: messages)
        XCTAssertEqual(snapshot?.status, .invited)
        XCTAssertEqual(snapshot?.moveCount, 0)
        XCTAssertEqual(snapshot?.gomoku?.value(at: 112), 0)
    }'''
    text = replace_once(text, old, new, "MiniGame acceptance gate test")

    old = '''        let cancel = MiniGamePacket(sessionID: invite.sessionID, game: .xiangqi, command: .resign, turn: 0, createdAt: Date(timeIntervalSince1970: 21))'''
    new = '''        let cancel = MiniGamePacket(sessionID: invite.sessionID, game: .xiangqi, command: .cancelInvite, turn: 0, createdAt: Date(timeIntervalSince1970: 21))'''
    text = replace_once(text, old, new, "MiniGame cancel test uses explicit command")

    anchor = '''    func testLudoCaptureMetadataAndFinishedCountersStayConsistent() {'''
    addition = r'''    func testClockSkewDoesNotDropAcceptanceOrNextMove() throws {
        let conversationID = UUID().uuidString
        let invite = MiniGamePacket(game: .gomoku, command: .invite, createdAt: Date(timeIntervalSince1970: 1_000))
        // Guest clock is far behind host clock.
        let accept = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .accept, createdAt: Date(timeIntervalSince1970: 100))
        // Host legitimately moves after receiving accept even though its wall clock is still "before" guest time in another scenario.
        let move = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .move, turn: 0, move: .gomoku(index: 112), createdAt: Date(timeIntervalSince1970: 1_001))
        let messages = [
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(invite), sentAt: invite.createdAt, isOutgoing: true, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "guest", body: try MiniGameCodec.encode(accept), sentAt: accept.createdAt, isOutgoing: false, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(move), sentAt: move.createdAt, isOutgoing: true, deliveryState: .delivered)
        ]
        let snapshot = MiniGameSessionBuilder.session(id: invite.sessionID, from: messages)
        XCTAssertEqual(snapshot?.status, .active)
        XCTAssertEqual(snapshot?.moveCount, 1)
        XCTAssertEqual(snapshot?.gomoku?.value(at: 112), 1)
    }

    func testImmediateResignAfterAcceptanceIsNotMisclassifiedAsInviteCancellation() throws {
        let conversationID = UUID().uuidString
        let invite = MiniGamePacket(game: .gomoku, command: .invite, createdAt: Date(timeIntervalSince1970: 10))
        let accept = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .accept, createdAt: Date(timeIntervalSince1970: 20))
        let resign = MiniGamePacket(sessionID: invite.sessionID, game: .gomoku, command: .resign, turn: 0, createdAt: Date(timeIntervalSince1970: 21))
        let messages = [
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(invite), sentAt: invite.createdAt, isOutgoing: true, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "guest", body: try MiniGameCodec.encode(accept), sentAt: accept.createdAt, isOutgoing: false, deliveryState: .delivered),
            ChatMessage(id: UUID().uuidString, conversationID: conversationID, senderIdentityID: "host", body: try MiniGameCodec.encode(resign), sentAt: resign.createdAt, isOutgoing: true, deliveryState: .delivered)
        ]
        let snapshot = MiniGameSessionBuilder.session(id: invite.sessionID, from: messages)
        XCTAssertEqual(snapshot?.status, .finished(winner: .guest))
        XCTAssertTrue(snapshot?.endedByResignation == true)
    }

    func testInvitationExpiryAndConcurrentInviteCoalescing() {
        let now = Date(timeIntervalSince1970: 10_000)
        func pending(_ id: String, offset: TimeInterval) -> MiniGameSessionSnapshot {
            MiniGameSessionSnapshot(
                id: id, game: .gomoku, hostIsLocal: true, status: .invited,
                invitedAt: now.addingTimeInterval(offset), startedAt: nil, lastActivity: now.addingTimeInterval(offset),
                gomoku: GomokuState(), xiangqi: nil, ludo: nil, endedByResignation: false
            )
        }
        let old = pending(UUID().uuidString, offset: -MiniGameSessionSnapshot.invitationTimeout - 1)
        XCTAssertTrue(old.invitationIsExpired(at: now))

        let a = pending("00000000-0000-0000-0000-000000000001", offset: 0)
        let b = pending("00000000-0000-0000-0000-000000000002", offset: 1)
        XCTAssertEqual(MiniGameSessionBuilder.coalescedLiveSessions([b, a], now: now).map(\.id), [a.id])
    }

'''
    if anchor not in text:
        raise RuntimeError("MiniGame tests insertion anchor missing")
    text = text.replace(anchor, addition + anchor, 1)
    return text


def patch_database_tests(text: str) -> str:
    if "import Security" not in text:
        text = replace_once(text, "import CryptoKit\nimport XCTest", "import CryptoKit\nimport Security\nimport XCTest", "Database tests Security import")
    anchor = '''final class DatabaseStoreTests: XCTestCase {
    private func makeStore() throws -> (DatabaseStore, URL) {'''
    new = '''final class DatabaseStoreTests: XCTestCase {
    func testKeychainProtectedDataStatusesAreTransientNotMissing() {
        XCTAssertTrue(KeychainStore.isTransientReadStatus(errSecInteractionNotAllowed))
        XCTAssertTrue(KeychainStore.isTransientReadStatus(errSecNotAvailable))
        XCTAssertFalse(KeychainStore.isTransientReadStatus(errSecItemNotFound))
    }

    private func makeStore() throws -> (DatabaseStore, URL) {'''
    return replace_once(text, anchor, new, "Database keychain status classification test")


PATCHERS = {
    "VeilLink/Security/KeychainStore.swift": patch_keychain,
    "VeilLink/Storage/DatabaseStore.swift": patch_database,
    "VeilLink/Security/SessionCoordinator.swift": patch_session_coordinator,
    "VeilLink/Core/MiniGames.swift": patch_minigames,
    "VeilLink/UI/ConversationViews.swift": patch_conversation,
    "VeilLink/UI/MiniGameViews.swift": patch_minigame_views,
    "VeilLinkTests/MiniGameTests.swift": patch_minigame_tests,
    "VeilLinkTests/DatabaseStoreTests.swift": patch_database_tests,
}


def verify_preconditions(root: Path) -> None:
    for rel, markers in I1_MARKERS.items():
        p = root / rel
        if not p.exists(): raise RuntimeError(f"missing I1 target {rel}")
        t = p.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in t:
                raise RuntimeError(f"{rel}: I1 marker missing: {marker!r}. Apply I1 first.")

    for rel, expected in BASE_BLOBS_UNCHANGED_BY_I1.items():
        p = root / rel
        actual = git_blob_sha(p.read_bytes())
        if actual != expected:
            raise RuntimeError(f"{rel}: pre-I2 blob mismatch; expected {expected}, got {actual}. Refusing to patch drifted source.")


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I2_APPLY.py /path/to/I1-applied/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "project.yml").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    verify_preconditions(root)
    originals = {rel: (root / rel).read_text(encoding="utf-8") for rel in PATCHERS}
    changed = {rel: patcher(originals[rel]) for rel, patcher in PATCHERS.items()}

    # All replacements were validated above; only now write files.
    backup = root / ".veillink-local-iter" / "I2-backup"
    for rel, new_text in changed.items():
        p = root / rel
        b = backup / rel
        b.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, b)
        p.write_text(new_text, encoding="utf-8")
        print(f"PATCHED {rel} -> {git_blob_sha(new_text.encode('utf-8'))}")

    print("I2 applied on top of I1. Base authority:", BASE_HEAD)
    print("Backups:", backup)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
