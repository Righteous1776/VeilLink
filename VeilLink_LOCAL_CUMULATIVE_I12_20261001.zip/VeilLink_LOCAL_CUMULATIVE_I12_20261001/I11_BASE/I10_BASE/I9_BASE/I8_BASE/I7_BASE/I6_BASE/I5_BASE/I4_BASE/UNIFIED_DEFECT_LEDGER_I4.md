# VeilLink 统一缺陷账本 — I4

基线：`main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`
累计层：I1 -> I2 -> I3 -> I4

## 本层关闭 / 缓解

- **P1 A9 ghost BLE pollution — CLOSED IN SOURCE**：passive discovery-only UUID 15 秒后过期；A9 只读取 `isA9Relevant` 链路。
- **P1 A9 persistence callback amplification — CLOSED IN SOURCE**：不再 `+1 per evaluate`；改为 monotonic `systemUptime` 连续非绿秒数，30 秒才进入 persistence axis。
- **P1 A9 BLE-centric reporting ambiguity — CLOSED FOR CURRENT MAIN SEMANTICS**：报告新增 transport coverage，当前明确为 `BLE_ONLY`；不声称覆盖当前 main 中不存在的 LAN/Relay/Mesh。
- **P1 false main-thread stall after suspension — CLOSED IN SOURCE**：仅 active 状态、且恢复宽限期后允许报 stall。
- **P1 diagnostic observer effect / excessive UI snapshots — MITIGATED IN SOURCE**：snapshot 合并 + 0.75/1.5 秒节流 + 1200/700 view 上限；controller appear 不再 force；日志 flush 批量化且减少目录扫描。
- **P2 black-box A9 evidence ambiguity — CLOSED IN SOURCE**：新增 `persistence_seconds`、`transport_coverage`。

## 纠正旧账本

当前 main 中没有证据表明 A9 会直接调用 `ble.refresh`、切换通信优先级或 mutation transport。A9 当前的直接下游是 Compute Governor。旧账本中这类“自动调 BLE”的描述撤销；应保留的问题是“BLE-only 输入会误导全局健康/算力预算”。

## 延续未闭环

- **P0 iPhone 7 联机游戏逐步闪退**：I1 已修高可信主线程/AI放大链；仍等待真机 crash stack 与 burn-in。
- **P0 Keychain protected-data 暂不可读误判永久密钥丢失**：I2 源码修复，等待锁屏/解锁真实生命周期验证。
- **P1 BLE secure-ready churn / TX pump / dual-role teardown**：I3 源码修复，等待 iPhone 7 ↔ iPhone 13 双机验证。
- **P1 reconnect/rekey unverifiable frame**：I3 已清 transport epoch 残片并收紧 role teardown；仍需连续重连/rekey 压测。
- **P1 LAN Turbo / Internet Relay / Mesh telemetry blind spot**：当前 main 根本没有对应实现；必须等 26.9 formal source 回灌后继续。
- **P1/P2 UI 主题、横屏锁屏、iOS15 ScrollView safe-area、固定微型字号、系统 Form/自定义主题割裂**：未在 I4 修改，继续排队。
- **P2 UI screen label 滞后**：尚未独立修复。

## 真机 I4 验收指标

在 iPhone 7 与 iPhone 13 分别连续运行至少 30 分钟：

1. 无交互的陌生 BLE discovery-only 节点应在约 15 秒后从 linkSnapshots/A9 输入消失；
2. 100 次短时间 link snapshot 更新不能把 `persistence_seconds` 推进 100；
3. 后台 5 分钟再回前台，不应生成约 300 秒 `performance.main_thread_stall`；
4. 90 秒 UI stress 下 hierarchy snapshot 数应显著低于旧包的数千级；
5. diagnostics 自身不应成为 thermal critical 的主要触发源；
6. A9 报告必须明确写出 `Transport coverage: 仅 BLE...`，直到真实多传输 telemetry 接入。
