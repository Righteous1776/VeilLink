# VeilLink 26.9 — Unified Defect Ledger

Audit date: 2026-09-26
Scope: Build 53 DeepTelemetry export + current GitHub main structural review + previously established black-box findings.

> Important provenance note: DeepTelemetry identifies the running binary as VeilLink 26.9 (53), while current `main` `Info.plist` still declares 0.9.7 (41). Therefore this ledger distinguishes runtime-confirmed findings from structural findings in current main; pixel-identical Build 53 source still needs the formal carrier to be treated as the exact binary source.

## Confirmed / closed-loop

### P0
- FACEID_PRIVACY_CRASH — `NSFaceIDUsageDescription` missing while AppLockController invokes LocalAuthentication. MetricKit captured real Build 53 termination. Same class existed in Build 52.
- KEYCHAIN_TRANSIENT_READ_AS_KEY_LOSS — Keychain non-success statuses collapse to `nil`; protected-data / locked-device temporary unreadability can be misreported as permanent DB encryption-key loss.

### P1 — transport / diagnostics / architecture
- BLE_SECURE_READY_CHURN — physical BLE connect/disconnect activity greatly exceeds secure-session-ready events; pre-stress window also showed physical links without secure-ready completion.
- MAIN_THREAD_STALL_FALSE_POSITIVE — heartbeat Timer measures suspension/background gaps as UI stalls.
- DIAGNOSTICS_OBSERVER_EFFECT — high-rate UI hierarchy / BLE / nearby / A9 capture materially loads the app; JSON/file work and UI traversal can occur on MainActor.
- A9_STALE_BLE_GHOSTS — stale RSSI/link snapshots remain in health inputs and can lower current A9 health after peers disappear.
- A9_PERSISTENCE_IS_EVENT_COUNT — persistence increases per evaluate callback rather than elapsed fault time, so noisy event rates make faults look more persistent.
- A9_BLE_CENTRIC_MULTITRANSPORT_ERROR — health model primarily consumes BLE while LAN Turbo / Internet Relay / Mesh are omitted.
- LAN_RELAY_MESH_TELEMETRY_BLIND_SPOT — Runtime Context and event chain cannot locate failures across Bonjour/TCP/E2EE/route selection/provider failover.
- BLE_STATE_LABEL_COLLAPSE — `didConnect` is surfaced as “已建立蓝牙链路” before GATT discovery, notify subscription and secure Hello complete.
- IOS15_SCROLL_BACKGROUND_GUARD_BYPASS — AppTheme explicitly avoids ignoresSafeArea-on-ScrollView for legacy iOS 15 compositor, but several game views add `VeilAmbientBackground().ignoresSafeArea()` back to ScrollViews, reintroducing the documented content jump/disappearance risk on iPhone 7-class devices.
- LOCK_SCREEN_LANDSCAPE_OVERFLOW — iPhone landscape is declared supported, but LockScreen has a fixed 4-row keypad + fixed glyph/title/PIN spacing with no ScrollView or landscape branch. Required content height exceeds ~390 pt landscape viewport, so clipping/inaccessible controls are structurally inevitable.

### P2 — UI / theme / telemetry quality
- DARK_ONLY_THEME — WindowGroup globally forces `.preferredColorScheme(.dark)`. There is no real daytime/light theme or system-following mode.
- SYSTEM_SHEET_THEME_FRAGMENTATION — Settings subflows use native `Form`/`List` sheets (lock, backup, identity, delete, password, new identity) without the Veil panel/background system, causing abrupt system-grouped visual language inside an otherwise custom UI.
- FIXED_MICROTYPOGRAPHY — many screens use explicit 5–10 pt fonts, single-line limits and minimumScaleFactor compression. This is fragile on compact widths and does not participate in normal Dynamic Type scaling like semantic text styles.
- UI_TELEMETRY_SCREEN_LAG — 95 stress snapshots have a requested tab target that disagrees with the snapshot `screen` tag (e.g. tab Nearby while screen remains chats.list). Diagnostics can attribute a visual issue to the prior page.
- SCREENSHOT_EVENTS_WITHOUT_PIXELS — telemetry records 8 `ui.screenshot_taken` events, but the export contains no screenshot image payloads/files. The black box therefore cannot prove pixel-level misalignment, clipping, contrast, or theme defects.
- LANDSCAPE_VISUAL_COVERAGE_WEAK — 132 orientation-change events exist, but only 6/3619 UI snapshots are 844x390 landscape, so current black-box coverage is inadequate for landscape UI validation.
- RELEASE_SOURCE_PROVENANCE_SPLIT — runtime says 26.9 (53), current main plist says 0.9.7 (41). Release carrier/workflow overlays and main source are not a single bit-identical audit source.

## High-confidence pending targeted reproduction
- BLE_SEND_PUMP_STALL_STRONG_LINK — RSSI around -46 dBm / ATT 512 with queue growth and watchdog reconnect; requires pump-level counters to distinguish CoreBluetooth backpressure vs wakeup/state desync.
- POST_RECONNECT_UNVERIFIABLE_PACKETS — two packets rejected near reconnect/rekey; security rejection works, but stale-frame/session-context race remains plausible.
- IPAD_NARROW_REGULAR_LAYOUT — TabletLayout uses a fixed 330 pt sidebar and only horizontalSizeClass branching. Narrow regular-width Stage Manager/Split View configurations need direct screenshot/simulator verification before marking as confirmed clipping.

## Explicitly removed / not bugs
- Auto-save Photos toggle oscillation — user confirmed this was deliberate rapid tapping.
- Thermal critical during extreme stress — expected stress-test stop condition by itself.
- Build 52 high GPU / peak memory — historical data, not sufficient to convict Build 53.

## Repair order
1. Face ID privacy crash.
2. Keychain OSStatus semantics + protected-data startup handling.
3. iPhone 7 legacy ScrollView/background regression and lock-screen landscape layout.
4. BLE PHY → GATT → SECURE state machine observability and secure-ready churn.
5. Main-thread stall detector + UI screen attribution + screenshot artifact export.
6. Reduce black-box observer effect.
7. LAN/Relay/Mesh telemetry and A9 multi-transport health model.
8. Theme architecture: dark/system/light policy + migrate system Form/List sheets into Veil visual tokens.
9. Typography/Dynamic Type and iPad narrow-layout sweep.

## Game / online / invitation audit — added 2026-09-26

### P1 — confirmed structural defects in current main
- GAME_CROSS_DEVICE_WALL_CLOCK_ORDERING — `MiniGameSessionBuilder` orders lifecycle events by `ChatMessage.sentAt` / packet `createdAt`, and inbound messages preserve the remote sender's timestamp. Two devices with clock skew can sort an `accept`/`decline` before the original invite and filter it out, leaving one side permanently at “waiting for acceptance”. The same ordering also decides accept-vs-cancel races.
- GAME_FAILED_PACKET_IS_AUTHORITATIVE — session reconstruction decodes all game messages without considering `deliveryState`. A locally queued move/accept/resign immediately mutates local game state; if the message later becomes `.failed`, reconstruction still treats it as authoritative.
  - failed invite: sender keeps a live “waiting for acceptance” session that the peer never saw;
  - failed accept: guest shows an active game while host still waits for acceptance;
  - failed move: sender advances the board while receiver never does, so both sides can end up “waiting for opponent” on different board states;
  - failed resign/cancel: one side ends/cancels while the other remains active/invited.
- GAME_FAILED_PACKET_NO_RECOVERY_UI — game packets are hidden from normal chat bubbles; `MiniGameDeliveryBadge` only displays state and exposes no retry. `SessionCoordinator.retryMessage()` exists for failed text messages, but game UI does not surface a path to invoke it. A failed game packet can therefore strand the session.
- INVITE_CANCEL_OVERLOADS_RESIGN — the same `.resign` command represents both “withdraw invitation before start” and “resign after start”. If a guest accept and host withdrawal cross in flight, the meaning of the host packet depends on reconstructed ordering: it can become cancellation or an actual resignation/loss. This is a protocol/state semantic race, not just a label issue.
- SIMULTANEOUS_CROSS_INVITES_NOT_ARBITRATED — sessions are grouped only by random `sessionID`. If both peers invite each other to the same game at nearly the same time, two live sessions can coexist; there is no deterministic game+peer collision/supersession rule. `liveSession(for:)` merely picks one local `first` session for the game picker while session lists can contain both.
- GAME_MAIN_THREAD_FULL_HISTORY_RELOAD — `MiniGameHubView.reload()` and `MiniGameSessionView.reload()` call `database.fetchMessages(conversationID:)` and rebuild full game history synchronously from SwiftUI callbacks. Every global `messagesRevision` can trigger another full-conversation decrypt/rebuild. This bypasses the bounded/background chat-render path specifically added for iPhone 7-class performance.
- GAME_TELEMETRY_BLIND_SPOT — the supplied 29,508-event DeepTelemetry export contains 0 game-specific semantic events for invite/send/accept/decline/move/resign/session reconstruction. Mini-game screens/actions are therefore effectively invisible to the current black box; controller/tap traces cannot identify which game transition failed.

### P1/P2 — chat/game integration defects
- CHAT_GAME_EVENT_BURIED_AT_INVITE_POSITION — normal chat hides all game packets except the original `.invite`; the persistent game card stays at the old invite position. Later accept/move/resign events update the card state but do not create a new visible chat event, do not move the card to the bottom, and do not change `visibleMessages.last?.id`, so an active turn can be buried far above the current conversation viewport.
- GAME_CHAT_WINDOW_CAN_LOSE_SESSION_CARD — ChatView expands its recent-message window only until it finds each session's invite, but device budgets cap history (720 SE1 / 1200 iPhone 7 / 2000+ modern). If the invite is older than the retained window, later game packets are hidden and the session has no card in chat. Additionally `fetchRecentMessages()` hard-caps at 2,000 while iPhone 13 Pro / iPad profiles advertise a 3,000 maximum, causing repeated identical 2,000-row fetches without ever reaching older invites.
- GAME_LINK_STATUS_BLE_ONLY_IN_CURRENT_MAIN — `MiniGameLinkStatusView` derives readiness from BLE snapshot + SessionCoordinator secure-session state only. It does not represent LAN Turbo / Relay / Mesh route readiness. Because Build 53 source provenance is split from current main, exact 26.9 behavior remains to be verified against the formal carrier, but this is a confirmed current-main architecture mismatch with the multi-transport direction.

### P2 — invitation/chat UX defects
- INVITE_CARD_FALSE_SENT_STATE — immediately after `queueContent`, the sender's card says “已邀请对方 · 等待接受” / session page says “邀请已发送” even when the underlying message is only `.queued`, offline, or later `.failed`. Delivery state is not represented on the chat invitation card itself.
- INCOMING_INVITE_LOW_ATTENTION — `MiniGameSessionRow` has an explicit `needsAttention` highlight, but `MiniGameConversationCard` does not. Incoming invitations are not `isLocalTurn`, so their chat card gets the neutral border/text treatment and the footer action is merely “查看” rather than “回应邀请”.
- OUTGOING_INVITE_PREVIEW_WRONG_DIRECTION — `MiniGameCodec.previewText(.invite)` always returns “[小游戏] 邀请你玩…”. The same preview is used when saving the sender's own outgoing message, so the sender's conversation list can read as if somebody invited the sender instead of “已发送邀请”.
- INVITE_WITHDRAW_PREVIEW_WRONG — cancellation is encoded as `.resign`, while `previewText(.resign)` always says “对局结束”; withdrawing an unstarted invitation can therefore update conversation preview with the wrong semantic text.
- STALE_INVITE_HAS_NO_EXPIRY — `.invited` remains a live session indefinitely unless a decline/accept/withdraw packet exists. A delivered-but-unanswered or failed invitation can keep `liveSession(for:)` occupied and prevent the picker from offering a clean new invitation for that game.

### Concrete divergence scenarios to reproduce
1. Host sends invite offline until the outbound item expires: host still sees a live invitation, receiver sees nothing; game picker is blocked by the ghost live session.
2. Guest accepts while link is unavailable and the accept later fails: guest UI becomes `.active` immediately, host remains `.invited`.
3. Host makes a move that eventually fails: host board advances to guest turn; guest board remains on host turn; both UIs can say they are waiting for the other side.
4. Device clocks differ materially: guest `accept.createdAt` can sort before host invite time and be discarded by `valid = !eventOrder(event, invite)`.
5. Both sides send same-game invitations at nearly the same time: two independent session IDs survive with no collision arbitration.

### Game repair order
1. Stop treating failed game packets as authoritative; define provisional/confirmed event semantics and rollback/retry behavior.
2. Add first-class retry/recover controls for invite/accept/move/resign packets and surface delivery state directly on chat game cards.
3. Replace cross-device wall-clock lifecycle ordering with causal/logical ordering scoped to session protocol.
4. Split `cancelInvite` from `resign` and specify deterministic accept-vs-cancel arbitration.
5. Add same-peer/same-game simultaneous-invite convergence/supersession.
6. Move full-history game reconstruction off MainActor and use indexed/session-scoped DB queries rather than decrypting entire conversations on every revision.
7. Redesign chat game surfacing: inline respond actions, turn/invite activity resurfacing, and a visible active-game banner instead of burying one card at the original invite position.
8. Add game semantic telemetry (`invite.queued/sent/delivered/failed`, `accept`, `decline`, `cancel`, `move`, `resign`, reconstruction result, session divergence hash) and route-aware transport diagnostics.

## User-reproduced game failures + source correlation — 2026-09-26 late audit

### P0 — runtime-confirmed by user on target device
- IPHONE7_GAME_STEP_CRASH — On the iPhone 7 target, a linked game is not practically playable: a local move can be followed by an app termination, reopening and taking the next step can terminate again, and an opponent move can also cause the local iPhone 7 side to terminate. This is a reproducible core-flow failure on a declared target device, even though the supplied DeepTelemetry package does not include the iPhone 7 MetricKit crash payload needed to name the exact exception/termination class.

### P1 — high-confidence source-correlated causes
- GAME_R11_MAINACTOR_RELOAD_REGRESSION — Commit `a5d20c6ad3` (R11-GH / Tactical V0.2.8 B04D) changed both `MiniGameHubView.reload()` and `MiniGameSessionView.reload()` from background `DispatchQueue.global` fetch/rebuild back to synchronous `model.database.fetchMessages(...)` + session reconstruction on the SwiftUI/MainActor path. Every game packet revision now risks decrypting/rebuilding the entire conversation on the main thread. This is a direct regression from the preceding V0.6/V0.9.7 implementation.
- GAME_LOCAL_MOVE_DOUBLE_REBUILD — `MiniGameSessionView.send()` immediately calls `reload(notify:false)` after queueing a game packet, while `queueContent()` also invokes `onMessagesChanged`, which later increments `messagesRevision`; the view then reloads again through `.onChange(of: model.messagesRevision)`. A single local move can therefore perform two full synchronous history/session rebuilds. Remote moves perform at least the revision-triggered rebuild. This matches the user's “my move crashes / opponent move also crashes here” trigger pattern.
- GAME_MAINACTOR_POLICY_RANKING_HOTPATH — every successful game reload calls `model.updateAgentGameContext(...)`; `AgentGameContextBroker` is `@MainActor` and synchronously builds observations, enumerates legal actions and runs `TrainedGamePolicyRuntime.rankedLegalActions(...)`. For Gomoku the legal set may approach 225 moves; Xiangqi legal enumeration is significantly more expensive.
- GAME_ADAPTER_VALIDATE_REENUMERATION_EXPLOSION — all three trained-game adapters implement `validate()` by calling `enumerateLegalActions()` again and searching the result. `rankedLegalActions()` first enumerates candidates and then calls `candidates.filter(adapter.validate)`, so it re-enumerates the complete legal action set once per candidate. On Gomoku this is quadratic candidate generation; on Xiangqi each re-enumeration itself performs legal-move simulation/check logic. This work currently sits in the MainActor game update path.
- GAME_AUTOMATIC_STABLE_STILL_ENABLES_MALECNS — `AgentGameDecisionMode.automaticStable` is the default, but `usesMaleCNSRerank` is true for every mode except `baselineOnly`. Consequently the nominal “automatic stable” path can still schedule MaleCNS Lite candidate reranking when the reconstructed state says it is the local turn, adding compute/memory pressure on A10/2 GB devices.
- GAME_IOS15_RENDER_REBUILD_COMPOUNDING — the same game views use `VeilAmbientBackground().ignoresSafeArea()` in paths that already bypass the project's iOS 15 legacy compositor safety rule. Re-rendering these views on every move compounds the known iPhone 7 invalidation risk; this is a secondary crash/flicker suspect, not yet the sole proven cause.

### P1/P2 — interaction and invitation regressions
- GAME_BOARD_INPUT_GATED_BY_RECONSTRUCTED_TURN — game interaction is gated by `session.isLocalTurn && !isSending`. Gomoku does not install the board touch layer unless this is true; Xiangqi installs the gesture but immediately returns when `enabled` is false; Ludo similarly gates legal controls. Any stale/mis-reconstructed session state (failed packet, clock-ordering race, delayed rebuild, divergent history) therefore presents to the user as “the piece/board cannot be clicked” with no explicit explanation or recovery action.
- CHAT_DIRECT_GAME_INVITE_ENTRY_MISSING — the current chat composer `+` menu exposes Photos, Files and one generic `双人小游戏` entry that opens `MiniGameHubView`; there is no direct “invite this contact to Gomoku/Xiangqi/Ludo/Tactical” action in the conversation itself. The user confirms a direct invitation option existed in the previously used build and is now gone, so this is a user-visible feature regression regardless of the exact unpublished/local commit where it disappeared.
- CHAT_INVITE_FLOW_EXTRA_HOP — because the direct action is absent, inviting a specific contact requires chat → `+` → Game Hub → game row → create invite. Combined with current Game Hub/reload instability, the only invitation path forces the user through the least stable screen instead of allowing a small reliable inline invite action.
- INCOMING_INVITE_LACKS_INLINE_ACCEPT_DECLINE — the chat card opens the hub/session but does not provide direct accept/decline controls in the chat timeline. In a degraded Game Hub state, an invitation can therefore be visible but not practically actionable from the conversation where it arrived.

### Telemetry gap
- IPHONE7_GAME_CRASH_NOT_CAPTURED_IN_CURRENT_EXPORT — the supplied MetricKit diagnostics only identify `iPhone14,2` (iPhone 13 Pro) and capture the Face ID privacy crash. They do not include the iPhone 7 game-step crash. Therefore the reproducible iPhone 7 failure is accepted as a real runtime defect from user testing, while the exact termination mechanism remains pending an iPhone 7 crash payload. The current black box also has no game semantic events, so it cannot correlate a termination to `invite/accept/move/reload` without additional instrumentation.

### Updated game repair priority
1. Restore background/session-scoped game reconstruction immediately; remove full-history synchronous reloads from MainActor and eliminate the local-move double rebuild.
2. Remove policy enumeration/ranking/MaleCNS work from the UI transaction path; on iPhone 7 default game decision support must be baseline-off or asynchronous with strict compute budget.
3. Make board enabled/disabled state explicit and recoverable instead of silently swallowing taps when reconstructed turn state is stale.
4. Restore a direct per-contact game invitation action in ChatView and add inline Accept / Decline / Retry on the invitation card.
5. Then fix packet authority, logical ordering, retry, cancel-vs-resign semantics and simultaneous-invite convergence described above.
6. Add iPhone 7 game-step crash capture and semantic telemetry before calling the linked-game path stable again.
