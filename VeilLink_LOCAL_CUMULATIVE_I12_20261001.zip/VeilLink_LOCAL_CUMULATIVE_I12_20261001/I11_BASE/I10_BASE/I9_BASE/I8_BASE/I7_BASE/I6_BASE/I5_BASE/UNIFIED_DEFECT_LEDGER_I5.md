# VeilLink 26.9 统一缺陷账本 · I5

基线：`main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`。此表记录本地累计补丁的静态修复状态；没有 Xcode/真机证据的条目不标记为“真机闭环”。

## 已进入累计补丁

- **P0 Face ID privacy crash** — I1：补 `NSFaceIDUsageDescription`。待正式 Xcode 构建/真机复核。
- **P0 Keychain 暂不可读误判永久丢钥匙** — I2：区分 missing 与 protected-data/unavailable。待锁屏/解锁真机复核。
- **P0 iPhone 7 联机游戏每步卡死/闪退高可信链** — I1：后台重建、去双 reload、降低 legacy AI 热路径。异常类型仍需 iPhone 7 crash stack。
- **P1 游戏时序/生命周期** — I2：取消邀请独立命令、减少跨设备墙钟依赖、邀请过期/冲突治理。
- **P1 BLE peripheral TX backpressure 卡死** — I3：补 ready-to-update 回调与 central safety drain。
- **P1 双角色 BLE 单边断开误杀 secure session** — I3：角色感知断线与 transport stage。
- **P1 stale fragment / reconnect epoch** — I3：重连清理 assembler source。
- **P1 A9 幽灵 BLE 节点** — I4：被动扫描节点过期；A9 只采 operationally relevant/GATT-ready 质量。
- **P1 A9 persistence 回调次数失真** — I4：改为 `systemUptime` 连续异常秒数，30s threshold。
- **P1/P2 telemetry observer effect / false stall** — I4：active-state + resume grace；UI snapshot/flush 降频。
- **P1 UI iOS15 unsafe safe-area 回归** — I1 + I5：游戏主页面以及规则/回放/Game Lobby 剩余路径全部移除危险背景调用。
- **P1 UI 横屏锁屏溢出** — I5：响应式左右布局 + 动态键位 + ScrollView 兜底。
- **P2 UI iPad 窄 regular-width 错位** — I5：720pt 双栏阈值，250–330pt 自适应侧栏。
- **P2 UI 系统 Sheet/Form 白块 / 主题混搭** — I5：26.9 明确 Dark 契约，UIKit Form/List/Sheet 与 Info.plist 统一深色。
- **P2 UI 5–9pt 微型字体** — I5：主 UI 的极小固定字号抬升，极端 minimumScaleFactor 收紧。
- **P2 telemetry screen 标签滞后** — I5：迟到 onDisappear 不再覆盖新导航 screen。

## 仍开放

- Build 53 正式载体与 GitHub main 源码分裂：必须在正式发布链重新统一事实源。
- iPhone 7 的实际游戏 crash stack 尚缺；I1 修复链为高可信根因修复，不是假装 MetricKit 已定责。
- LAN Turbo / Internet Relay / Mesh 在当前 main 中没有正式实现源码，无法在本地累计包里凭空补出真实健康遥测。
- 真正浅色主题未开放；需单独完成全仓语义颜色迁移后再进入稳定版。
- iPad Air 4 全屏/Stage Manager/Split View 仍需真机视觉验收。
- BLE secure-ready churn/rekey 的 I3 修复仍需 iPhone 7 ↔ iPhone 13 burn-in。
