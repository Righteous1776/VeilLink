# VeilLink 统一缺陷账本 — 累计 I2 状态

Base authority: `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`

## 已进入累计修复

- **P0 Face ID privacy crash** — I1：补 `NSFaceIDUsageDescription`。
- **P0 iPhone 7 游戏每步卡死/闪退高可信路径** — I1：恢复后台 rebuild、去掉本地双 rebuild、A9/A10 compact-safe、去 O(N²) 合法动作重复枚举、游戏失败操作可重试。
- **P0 Keychain protected-data 误判永久丢钥匙** — I2：`errSecItemNotFound` 与 transient/unexpected Keychain failure 分流；数据库密钥暂不可读时只安全停止，绝不生成新 key。
- **P1 游戏跨设备墙钟排序** — I2：accept/move 因果不再通过两台设备 `Date()` 比大小；accept 存在后由 turn + 游戏规则重建。
- **P1 撤回邀请 / 认输混用** — I2：新增 `.cancelInvite`；旧 pending `.resign` 仅作向后兼容。
- **P1 接受后立即认输被误判取消** — I2：accept 后 turn 0 `.resign` 明确认输。
- **P1 并发双邀请** — I2：8 秒碰撞窗内同游戏邀请确定性合并。
- **P2 幽灵邀请永久占位** — I2：30 分钟未响应退出活动队列并显示过期。
- **P2 聊天列表邀请文案方向错误** — I2：发送端使用 outgoing preview。
- **P1/P2 聊天框直接游戏邀请入口回归** — I1：恢复“发送游戏邀请”，支持聊天卡内接受/拒绝/重试。

## 尚未关闭

- BLE Secure Ready churn / TX pump backpressure / reconnect-rekey unverifiable frames。
- A9 ghost BLE snapshots、persistence 按回调次数、BLE-centric health。
- LAN Turbo / Relay / Mesh telemetry 缺口与游戏 transport 状态统一。
- 黑匣子 stall false-positive / UI hierarchy observer effect 的工程化降采样。
- 主题：真正 light/system 主题、系统 Form/List Sheet 统一、锁屏横屏、小字号/Dynamic Type。
- iPhone 7 真机 crash stack：I1/I2 仍需实际构建后 MetricKit 验收，不能仅凭静态修复宣称闭环。

## I2 证据边界

I2 是**本地累计源码修复包**，未写入 GitHub main；GitHub App 对仓库写 refs 返回 403。当前环境不是 macOS/Xcode，已完成补丁器 Python 编译、自身 Swift 注入块 parser 检查与包结构校验，但不能冒充真机/XCTest/iphoneos build 已通过。
