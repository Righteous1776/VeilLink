from pathlib import Path
import hashlib
import shutil
import sys

BASE_HEAD = "152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f"
BASE_BLOBS_UNCHANGED_THROUGH_I3 = {
    "VeilLink/Health/VeilA9HealthMonitor.swift": "8ec5c88b399b900eda18034da44ff8adfc95a659",
    "VeilLink/Health/VeilA9Lattice.swift": "d8fe113180360b551676feb098a1654a9df54fa7",
    "VeilLink/App/AppModel.swift": "4eb9f3bff55f14415449db11af13f4e5b20ba809",
    "VeilLink/Diagnostics/DeepTelemetry.swift": "199d5c23e4d789d86604d916f5e0bee8257e0433",
    "VeilLink/Diagnostics/DiagnosticLogStore.swift": "99d293953b56fdb2918e8eae18affa6ad2cacfea",
    "VeilLinkTests/A9HealthLatticeTests.swift": "a8a69d0f24916d32406f8611b1d90244aa1e8282",
    "VeilLinkTests/DiagnosticLogStoreTests.swift": "d8ef2bc9db90c4347c9de825be8f8fd7cfc4df72",
}

I3_REQUIRED_MARKERS = {
    "VeilLink/Transport/BLETransport.swift": [
        "peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)",
        "private func reconcileConnectionEvent(_ id: UUID)",
        "assembler.reset(source: id)",
    ],
    "VeilLink/Transport/BLELinkSnapshot.swift": [
        "enum BLETransportStage",
        "let transportStage: BLETransportStage",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        '"transport_stage": snapshot.transportStage.rawValue',
    ],
}

I4_MARKERS = {
    "VeilLink/Transport/BLETransport.swift": [
        "private let passiveDiscoveryRetention: TimeInterval = 15",
        "private func pruneStaleDiscoveryState(now: TimeInterval)",
    ],
    "VeilLink/Health/VeilA9HealthMonitor.swift": [
        "private var nonGreenSinceUptime: TimeInterval?",
        "Persistence: \\(decision.persistenceSeconds) s",
    ],
    "VeilLink/Health/VeilA9Lattice.swift": [
        "enum VeilA9TransportCoverage",
        "persistentDurationThresholdSeconds = 30",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "enum DeepTelemetryStallPolicy",
        "postInteractionSnapshotTask",
    ],
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def insert_before_final_brace(text: str, insertion: str, label: str) -> str:
    index = text.rfind("\n}")
    if index < 0:
        raise RuntimeError(f"{label}: final brace not found")
    return text[:index] + "\n" + insertion.rstrip() + "\n" + text[index:]


def patch_ble_transport(text: str) -> str:
    old = '''    private var lastRSSIPublishAt: [UUID: TimeInterval] = [:]\n    private var lastQueueProgressAt: [UUID: TimeInterval] = [:]'''
    new = '''    private var lastRSSIPublishAt: [UUID: TimeInterval] = [:]\n    private var lastSeenAt: [UUID: TimeInterval] = [:]\n    private var lastQueueProgressAt: [UUID: TimeInterval] = [:]'''
    text = replace_once(text, old, new, "BLE last-seen tracking")

    old = '''    private let maxFragmentsPerMessage = 16_384\n    private let performanceProfile: DevicePerformanceProfile'''
    new = '''    private let maxFragmentsPerMessage = 16_384\n    private let passiveDiscoveryRetention: TimeInterval = 15\n    private let performanceProfile: DevicePerformanceProfile'''
    text = replace_once(text, old, new, "BLE passive discovery retention")

    old = '''        assembler.resetAll()\n\n        connectionEvents.drainConnectedIDs().forEach { onDisconnected?($0) }'''
    new = '''        assembler.resetAll()\n        remotePeripherals.removeAll(keepingCapacity: false)\n        subscribedCentrals.removeAll(keepingCapacity: false)\n        discoveredRSSI.removeAll(keepingCapacity: false)\n        smoothedRSSI.removeAll(keepingCapacity: false)\n        lastRSSIPublishAt.removeAll(keepingCapacity: false)\n        lastSeenAt.removeAll(keepingCapacity: false)\n\n        connectionEvents.drainConnectedIDs().forEach { onDisconnected?($0) }'''
    text = replace_once(text, old, new, "BLE stop clears passive discovery state")

    old = '''    private func knownLinkIDs() -> Set<UUID> {\n        Set(remotePeripherals.keys)\n            .union(subscribedCentrals.keys)\n            .union(wantedConnections)\n            .union(centralOutboundQueues.keys)\n            .union(peripheralOutboundQueues.keys)\n            .union(discoveredRSSI.keys)\n    }'''
    new = '''    private func knownLinkIDs() -> Set<UUID> {\n        let now = Date().timeIntervalSinceReferenceDate\n        pruneStaleDiscoveryState(now: now)\n\n        let recentDiscovered = Set(lastSeenAt.compactMap { entry in\n            now - entry.value <= passiveDiscoveryRetention ? entry.key : nil\n        })\n        let liveRemote = Set(remotePeripherals.compactMap { entry -> UUID? in\n            let state = entry.value.state\n            if state == .connected || state == .connecting || wantedConnections.contains(entry.key) {\n                return entry.key\n            }\n            return recentDiscovered.contains(entry.key) ? entry.key : nil\n        })\n\n        return liveRemote\n            .union(subscribedCentrals.keys)\n            .union(wantedConnections)\n            .union(centralOutboundQueues.keys)\n            .union(peripheralOutboundQueues.keys)\n            .union(recentDiscovered)\n    }\n\n    private func pruneStaleDiscoveryState(now: TimeInterval) {\n        let protectedIDs = Set(subscribedCentrals.keys)\n            .union(wantedConnections)\n            .union(centralOutboundQueues.keys)\n            .union(peripheralOutboundQueues.keys)\n\n        let staleIDs = lastSeenAt.compactMap { entry -> UUID? in\n            guard now - entry.value > passiveDiscoveryRetention,\n                  !protectedIDs.contains(entry.key) else { return nil }\n            if let peripheral = remotePeripherals[entry.key],\n               peripheral.state == .connected || peripheral.state == .connecting {\n                return nil\n            }\n            return entry.key\n        }\n\n        for id in staleIDs {\n            lastSeenAt.removeValue(forKey: id)\n            discoveredRSSI.removeValue(forKey: id)\n            smoothedRSSI.removeValue(forKey: id)\n            lastRSSIPublishAt.removeValue(forKey: id)\n            reconnectAttempts.removeValue(forKey: id)\n            if remotePeripherals[id]?.state == .disconnected {\n                remotePeripherals.removeValue(forKey: id)\n            }\n        }\n    }'''
    text = replace_once(text, old, new, "BLE ghost-link expiry")

    old = '''        let rounded = Int(next.rounded())\n        let now = Date().timeIntervalSinceReferenceDate\n        let previousPublished = discoveredRSSI[id]'''
    new = '''        let rounded = Int(next.rounded())\n        let now = Date().timeIntervalSinceReferenceDate\n        lastSeenAt[id] = now\n        let previousPublished = discoveredRSSI[id]'''
    text = replace_once(text, old, new, "BLE observe last seen")
    return text


def patch_link_snapshot(text: str) -> str:
    old = '''    var isRecovering: Bool { isWanted && !isConnected }\n\n    var qualityTitle: String {'''
    new = '''    var isRecovering: Bool { isWanted && !isConnected }\n\n    /// Passive scan-only peers must not lower A9 health or compute budgets. A peer becomes\n    /// operationally relevant when it is connected, explicitly wanted, or owns queued traffic.\n    var isA9Relevant: Bool {\n        isConnected || isWanted || pendingPackets > 0 || controlPendingPackets > 0\n    }\n\n    /// RSSI/health scoring is meaningful only for a live GATT data channel. Reconnecting peers\n    /// are represented by reconnect/stall signals instead of a stale RSSI health penalty.\n    var contributesLinkQualityToA9: Bool {\n        isConnected && transportStage == .gattReady\n    }\n\n    var qualityTitle: String {'''
    return replace_once(text, old, new, "A9 BLE relevance semantics")


def patch_a9_lattice(text: str) -> str:
    old = '''enum VeilA9ThermalLevel: Int, Codable, Sendable {\n    case nominal = 0\n    case fair = 1\n    case serious = 2\n    case critical = 3\n}\n\nstruct VeilA9Input: Equatable, Sendable {\n    var bluetoothRunning = false'''
    new = '''enum VeilA9ThermalLevel: Int, Codable, Sendable {\n    case nominal = 0\n    case fair = 1\n    case serious = 2\n    case critical = 3\n}\n\nenum VeilA9TransportCoverage: String, Codable, Sendable {\n    case none = "NONE"\n    case bluetoothOnly = "BLE_ONLY"\n    case multiTransport = "MULTI_TRANSPORT"\n\n    var title: String {\n        switch self {\n        case .none: return "未上报传输健康"\n        case .bluetoothOnly: return "仅 BLE（当前 main 未上报 LAN / Relay / Mesh）"\n        case .multiTransport: return "多传输"\n        }\n    }\n}\n\nstruct VeilA9Input: Equatable, Sendable {\n    var transportCoverage: VeilA9TransportCoverage = .bluetoothOnly\n    var bluetoothRunning = false'''
    text = replace_once(text, old, new, "A9 transport coverage")

    old = '''struct VeilA9Packet: Equatable, Sendable {\n    let light: VeilA9Light\n    let p0: Int\n    let p1: Int\n    let p2: Int\n    let p3: Int\n    let riskBP: Int\n    let persistenceRuns: Int\n    let blocker: Bool\n    let healthBP: Int\n    let issues: [VeilA9Issue]\n}'''
    new = '''struct VeilA9Packet: Equatable, Sendable {\n    let light: VeilA9Light\n    let p0: Int\n    let p1: Int\n    let p2: Int\n    let p3: Int\n    let riskBP: Int\n    /// Legacy field name retained for source compatibility; I4 stores elapsed non-green seconds.\n    let persistenceRuns: Int\n    let blocker: Bool\n    let healthBP: Int\n    let issues: [VeilA9Issue]\n\n    var persistenceSeconds: Int { persistenceRuns }\n}'''
    text = replace_once(text, old, new, "A9 packet persistence seconds")

    old = '''struct VeilA9Decision: Equatable, Sendable {\n    let light: VeilA9Light\n    let level: VeilA9Level\n    let reasonCode: String\n    let healthScore: Int\n    let riskPoints: Double\n    let persistenceRuns: Int\n    let issues: [VeilA9Issue]\n    let latticeIndex: Int\n\n    static let initial = VeilA9Decision('''
    new = '''struct VeilA9Decision: Equatable, Sendable {\n    let light: VeilA9Light\n    let level: VeilA9Level\n    let reasonCode: String\n    let healthScore: Int\n    let riskPoints: Double\n    /// Legacy field name retained for source compatibility; I4 stores elapsed non-green seconds.\n    let persistenceRuns: Int\n    let issues: [VeilA9Issue]\n    let latticeIndex: Int\n\n    var persistenceSeconds: Int { persistenceRuns }\n\n    static let initial = VeilA9Decision('''
    text = replace_once(text, old, new, "A9 decision persistence seconds")

    old = '''enum VeilA9Lattice {\n    static let persistentRunThreshold = 3\n    static let redRiskThresholdBP = 2_800'''
    new = '''enum VeilA9Lattice {\n    static let persistentDurationThresholdSeconds = 30\n    // Legacy symbol retained so old call sites/tests still compile; the value is now seconds.\n    static let persistentRunThreshold = persistentDurationThresholdSeconds\n    static let redRiskThresholdBP = 2_800'''
    text = replace_once(text, old, new, "A9 duration threshold")

    old = '''            persistent: packet.persistenceRuns >= persistentRunThreshold,'''
    new = '''            persistent: packet.persistenceSeconds >= persistentDurationThresholdSeconds,'''
    text = replace_once(text, old, new, "A9 lattice duration axis")
    return text


def patch_a9_monitor(text: str) -> str:
    old = '''    private var persistenceRuns = 0\n    private var lastInput = VeilA9Input()\n\n    func setDatabaseIntegrity(_ value: VeilA9DatabaseIntegrity) {'''
    new = '''    // `persistenceRuns` is kept as an internal compatibility name; since I4 it stores\n    // elapsed continuous non-green seconds, never callback count.\n    private var persistenceRuns = 0\n    private var nonGreenSinceUptime: TimeInterval?\n    private var lastInput = VeilA9Input()\n\n    var transportCoverage: VeilA9TransportCoverage { lastInput.transportCoverage }\n\n    func setDatabaseIntegrity(_ value: VeilA9DatabaseIntegrity) {'''
    text = replace_once(text, old, new, "A9 monitor duration state")

    old = '''    func evaluate(_ rawInput: VeilA9Input) {\n        var input = rawInput\n        input.databaseIntegrity = databaseIntegrity\n        lastInput = input\n\n        let preliminary = VeilA9Classifier.makePacket(input: input, persistenceRuns: persistenceRuns)\n        if preliminary.light == .green {\n            persistenceRuns = 0\n        } else {\n            persistenceRuns = min(9_999, persistenceRuns + 1)\n        }\n        let packet = VeilA9Classifier.makePacket(input: input, persistenceRuns: persistenceRuns)\n        decision = VeilA9Lattice.decide(packet)\n        lastEvaluatedAt = Date()\n    }\n\n    func reevaluate() {\n        evaluate(lastInput)\n    }'''
    new = '''    func evaluate(\n        _ rawInput: VeilA9Input,\n        now: Date = Date(),\n        uptime: TimeInterval = ProcessInfo.processInfo.systemUptime\n    ) {\n        var input = rawInput\n        input.databaseIntegrity = databaseIntegrity\n        lastInput = input\n\n        // Classification color does not depend on persistence. Measure elapsed non-green time\n        // with monotonic system uptime so callback bursts and wall-clock changes cannot fake it.\n        let preliminary = VeilA9Classifier.makePacket(input: input, persistenceRuns: 0)\n        if preliminary.light == .green {\n            nonGreenSinceUptime = nil\n            persistenceRuns = 0\n        } else if let since = nonGreenSinceUptime, uptime >= since {\n            persistenceRuns = min(9_999, Int(uptime - since))\n        } else {\n            nonGreenSinceUptime = uptime\n            persistenceRuns = 0\n        }\n\n        let packet = VeilA9Classifier.makePacket(input: input, persistenceRuns: persistenceRuns)\n        decision = VeilA9Lattice.decide(packet)\n        lastEvaluatedAt = now\n    }\n\n    func reevaluate(\n        now: Date = Date(),\n        uptime: TimeInterval = ProcessInfo.processInfo.systemUptime\n    ) {\n        evaluate(lastInput, now: now, uptime: uptime)\n    }'''
    text = replace_once(text, old, new, "A9 elapsed persistence evaluation")

    old = '''            "Risk points: \\(String(format: \"%.2f\", decision.riskPoints))",\n            "Persistence runs: \\(decision.persistenceRuns)",\n            "Lattice cell: \\(decision.latticeIndex)/143",'''
    new = '''            "Risk points: \\(String(format: \"%.2f\", decision.riskPoints))",\n            "Persistence: \\(decision.persistenceSeconds) s",\n            "Transport coverage: \\(transportCoverage.title)",\n            "Lattice cell: \\(decision.latticeIndex)/143",'''
    text = replace_once(text, old, new, "A9 report truthful persistence/coverage")
    return text

def patch_app_model(text: str) -> str:
    old = '''    func refreshA9Health() {\n        let snapshots = Array(bluetooth.linkSnapshots.values)\n        let input = VeilA9Input(\n            bluetoothRunning: bluetooth.isRunning,\n            connectedPeerCount: snapshots.filter(\\.isConnected).count,\n            trackedPeerCount: snapshots.count,\n            recoveringPeerCount: snapshots.filter(\\.isRecovering).count,\n            weakPeerCount: snapshots.filter { $0.quality == .weak }.count,\n            marginalPeerCount: snapshots.filter { $0.quality == .marginal }.count,\n            minimumLinkHealth: snapshots.map(\\.healthScore).min(),\n            maximumReconnectAttempt: snapshots.map(\\.reconnectAttempt).max() ?? 0,\n            pendingBytes: snapshots.reduce(0) { $0 + $1.pendingBytes },\n            controlPendingPackets: snapshots.reduce(0) { $0 + $1.controlPendingPackets },\n            maximumStallMilliseconds: Int((snapshots.compactMap(\\.stalledFor).max() ?? 0) * 1_000),\n            agentUnavailable: agent.runtimeState == .unavailable,\n            agentCooling: agent.runtimeState == .cooling,\n            agentHasFailure: agent.diagnostics.lastFailure != nil,\n            thermalLevel: currentA9ThermalLevel(),\n            lowPowerMode: currentA9LowPowerMode(),\n            databaseIntegrity: a9Health.databaseIntegrity\n        )\n        a9Health.evaluate(input)\n    }'''
    new = '''    func refreshA9Health() {\n        // A9 must reason about operational links, not every UUID passively observed by scanning.\n        let snapshots = bluetooth.linkSnapshots.values.filter(\\.isA9Relevant)\n        let liveQualitySnapshots = snapshots.filter(\\.contributesLinkQualityToA9)\n        let input = VeilA9Input(\n            transportCoverage: .bluetoothOnly,\n            bluetoothRunning: bluetooth.isRunning,\n            connectedPeerCount: snapshots.filter(\\.isConnected).count,\n            trackedPeerCount: snapshots.count,\n            recoveringPeerCount: snapshots.filter(\\.isRecovering).count,\n            weakPeerCount: liveQualitySnapshots.filter { $0.quality == .weak }.count,\n            marginalPeerCount: liveQualitySnapshots.filter { $0.quality == .marginal }.count,\n            minimumLinkHealth: liveQualitySnapshots.map(\\.healthScore).min(),\n            maximumReconnectAttempt: snapshots.map(\\.reconnectAttempt).max() ?? 0,\n            pendingBytes: snapshots.reduce(0) { $0 + $1.pendingBytes },\n            controlPendingPackets: snapshots.reduce(0) { $0 + $1.controlPendingPackets },\n            maximumStallMilliseconds: Int((snapshots.compactMap(\\.stalledFor).max() ?? 0) * 1_000),\n            agentUnavailable: agent.runtimeState == .unavailable,\n            agentCooling: agent.runtimeState == .cooling,\n            agentHasFailure: agent.diagnostics.lastFailure != nil,\n            thermalLevel: currentA9ThermalLevel(),\n            lowPowerMode: currentA9LowPowerMode(),\n            databaseIntegrity: a9Health.databaseIntegrity\n        )\n        a9Health.evaluate(input)\n    }'''
    text = replace_once(text, old, new, "A9 operational BLE filtering")

    old = '''    private func makeAgentLocalContext() -> AgentLocalContext {\n        let snapshots = Array(bluetooth.linkSnapshots.values)'''
    new = '''    private func makeAgentLocalContext() -> AgentLocalContext {\n        let snapshots = bluetooth.linkSnapshots.values.filter(\\.isA9Relevant)'''
    text = replace_once(text, old, new, "Agent context ignores ghost BLE scan nodes")
    return text


def patch_deep_telemetry(text: str) -> str:
    old = '''import ObjectiveC.runtime\n\n@MainActor\nfinal class DeepTelemetry: ObservableObject {'''
    new = '''import ObjectiveC.runtime\n\nenum DeepTelemetryStallPolicy {\n    static func shouldReport(\n        delta: TimeInterval,\n        applicationActive: Bool,\n        nowUptime: TimeInterval,\n        resumeGraceUntilUptime: TimeInterval\n    ) -> Bool {\n        applicationActive && nowUptime >= resumeGraceUntilUptime && delta > 1.35\n    }\n}\n\n@MainActor\nfinal class DeepTelemetry: ObservableObject {'''
    text = replace_once(text, old, new, "Telemetry stall policy")

    old = '''    private var heartbeatTimer: Timer?\n    private var lastHeartbeatAt = Date()\n    private var heartbeatCounter = 0\n    private var lastSnapshotAt = Date.distantPast'''
    new = '''    private var heartbeatTimer: Timer?\n    private var lastHeartbeatUptime = ProcessInfo.processInfo.systemUptime\n    private var heartbeatResumeGraceUntilUptime = ProcessInfo.processInfo.systemUptime + 2\n    private var applicationActive = UIApplication.shared.applicationState == .active\n    private var heartbeatCounter = 0\n    private var lastSnapshotUptime: TimeInterval = 0\n    private var postInteractionSnapshotTask: Task<Void, Never>?'''
    text = replace_once(text, old, new, "Telemetry active heartbeat state")

    old = '''        let now = Date()\n        if !force, now.timeIntervalSince(lastSnapshotAt) < 0.25 { return }\n        lastSnapshotAt = now'''
    new = '''        let nowUptime = ProcessInfo.processInfo.systemUptime\n        let minimumInterval: TimeInterval = VeilDevicePerformance.current.transferVisualComplexity == .full ? 0.75 : 1.5\n        if !force, nowUptime - lastSnapshotUptime < minimumInterval { return }\n        lastSnapshotUptime = nowUptime'''
    text = replace_once(text, old, new, "Telemetry snapshot throttle")

    old = '''        let hierarchy = Self.viewControllerHierarchy(root: window.rootViewController)\n        let visibleViewCount = Self.visibleViewCount(in: window, limit: 2_500)'''
    new = '''        let hierarchy = Self.viewControllerHierarchy(root: window.rootViewController)\n        let viewLimit = VeilDevicePerformance.current.transferVisualComplexity == .full ? 1_200 : 700\n        let visibleViewCount = Self.visibleViewCount(in: window, limit: viewLimit)'''
    text = replace_once(text, old, new, "Telemetry bounded hierarchy traversal")

    old = '''    private func schedulePostInteractionSnapshot() {\n        guard postInteractionSnapshotsEnabled else { return }\n        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { [weak self] in\n            self?.captureUIHierarchy(reason: "post-interaction")\n        }\n    }'''
    new = '''    private func schedulePostInteractionSnapshot() {\n        guard postInteractionSnapshotsEnabled else { return }\n        postInteractionSnapshotTask?.cancel()\n        let delay: UInt64 = VeilDevicePerformance.current.transferVisualComplexity == .full\n            ? 250_000_000\n            : 450_000_000\n        postInteractionSnapshotTask = Task { @MainActor [weak self] in\n            try? await Task.sleep(nanoseconds: delay)\n            guard !Task.isCancelled, let self else { return }\n            self.postInteractionSnapshotTask = nil\n            self.captureUIHierarchy(reason: "post-interaction")\n        }\n    }'''
    text = replace_once(text, old, new, "Telemetry post-interaction coalescing")

    old = '''    private func installNotificationObservers() {\n        let center = NotificationCenter.default\n\n        observers.append(center.addObserver(forName: UIApplication.userDidTakeScreenshotNotification, object: nil, queue: .main) { _ in'''
    new = '''    private func installNotificationObservers() {\n        let center = NotificationCenter.default\n\n        observers.append(center.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { _ in\n            Task { @MainActor in DeepTelemetry.shared.setApplicationActive(true) }\n        })\n        observers.append(center.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: .main) { _ in\n            Task { @MainActor in DeepTelemetry.shared.setApplicationActive(false) }\n        })\n        observers.append(center.addObserver(forName: UIApplication.userDidTakeScreenshotNotification, object: nil, queue: .main) { _ in'''
    text = replace_once(text, old, new, "Telemetry lifecycle observers")

    old = '''    private func startHeartbeat() {\n        heartbeatTimer?.invalidate()\n        lastHeartbeatAt = Date()\n        heartbeatCounter = 0\n        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in\n            Task { @MainActor in\n                let telemetry = DeepTelemetry.shared\n                let now = Date()\n                let delta = now.timeIntervalSince(telemetry.lastHeartbeatAt)\n                telemetry.lastHeartbeatAt = now\n                telemetry.heartbeatCounter += 1\n\n                if telemetry.performanceWatchEnabled, delta > 1.35 {\n                    telemetry.store.log(\n                        .warning,\n                        .performance,\n                        event: "performance.main_thread_stall",\n                        screen: telemetry.currentScreen,\n                        metadata: ["delay_ms": String(Int((delta - 1.0) * 1_000))]\n                    )\n                }\n\n                if telemetry.heartbeatCounter % 30 == 0 {\n                    telemetry.captureSystemSnapshot(reason: "periodic-30s")\n                }\n            }\n        }\n        if let heartbeatTimer {\n            RunLoop.main.add(heartbeatTimer, forMode: .common)\n        }\n    }'''
    new = '''    private func setApplicationActive(_ active: Bool) {\n        applicationActive = active\n        let uptime = ProcessInfo.processInfo.systemUptime\n        lastHeartbeatUptime = uptime\n        heartbeatResumeGraceUntilUptime = active ? uptime + 2 : uptime\n    }\n\n    private func startHeartbeat() {\n        heartbeatTimer?.invalidate()\n        lastHeartbeatUptime = ProcessInfo.processInfo.systemUptime\n        heartbeatCounter = 0\n        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in\n            Task { @MainActor in\n                let telemetry = DeepTelemetry.shared\n                let nowUptime = ProcessInfo.processInfo.systemUptime\n                let delta = max(0, nowUptime - telemetry.lastHeartbeatUptime)\n                telemetry.lastHeartbeatUptime = nowUptime\n                telemetry.heartbeatCounter += 1\n\n                let active = telemetry.applicationActive && UIApplication.shared.applicationState == .active\n                if telemetry.performanceWatchEnabled,\n                   DeepTelemetryStallPolicy.shouldReport(\n                       delta: delta,\n                       applicationActive: active,\n                       nowUptime: nowUptime,\n                       resumeGraceUntilUptime: telemetry.heartbeatResumeGraceUntilUptime\n                   ) {\n                    telemetry.store.log(\n                        .warning,\n                        .performance,\n                        event: "performance.main_thread_stall",\n                        screen: telemetry.currentScreen,\n                        metadata: ["delay_ms": String(Int((delta - 1.0) * 1_000))]\n                    )\n                }\n\n                if active, telemetry.heartbeatCounter % 30 == 0 {\n                    telemetry.captureSystemSnapshot(reason: "periodic-30s")\n                }\n            }\n        }\n        if let heartbeatTimer {\n            RunLoop.main.add(heartbeatTimer, forMode: .common)\n        }\n    }'''
    text = replace_once(text, old, new, "Telemetry suspension-safe heartbeat")

    old = '''        DeepTelemetry.shared.captureUIHierarchy(reason: "controller.appear", force: true)'''
    new = '''        DeepTelemetry.shared.captureUIHierarchy(reason: "controller.appear", force: false)'''
    text = replace_once(text, old, new, "Telemetry controller snapshot no longer forced")
    return text


def patch_diagnostic_store(text: str) -> str:
    old = '''    private let flushThresholdBytes = 64 * 1_024'''
    new = '''    private let flushThresholdBytes = 256 * 1_024'''
    text = replace_once(text, old, new, "Diagnostics larger write batch")

    old = '''    private var pendingBuffer = Data()\n    private var flushTask: Task<Void, Never>?'''
    new = '''    private var pendingBuffer = Data()\n    private var flushTask: Task<Void, Never>?\n    private var flushesSinceDiskUsageRefresh = 0'''
    text = replace_once(text, old, new, "Diagnostics disk-scan cadence state")

    old = '''        pendingBuffer.removeAll(keepingCapacity: false)'''
    new = '''        pendingBuffer.removeAll(keepingCapacity: false)\n        flushesSinceDiskUsageRefresh = 0'''
    text = replace_once(text, old, new, "Diagnostics clear flush counter")

    old = '''            try? await Task.sleep(nanoseconds: 600_000_000)'''
    new = '''            try? await Task.sleep(nanoseconds: 1_500_000_000)'''
    text = replace_once(text, old, new, "Diagnostics delayed coalesced flush")

    old = '''        guard !pendingBuffer.isEmpty else {\n            refreshDiskUsage()\n            return\n        }\n\n        let data = pendingBuffer\n        pendingBuffer.removeAll(keepingCapacity: true)\n        rotateIfNeeded(incomingBytes: data.count)\n        append(data)\n        refreshDiskUsage()'''
    new = '''        guard !pendingBuffer.isEmpty else { return }\n\n        let data = pendingBuffer\n        pendingBuffer.removeAll(keepingCapacity: true)\n        let rotated = rotateIfNeeded(incomingBytes: data.count)\n        append(data)\n        flushesSinceDiskUsageRefresh += 1\n        if rotated || flushesSinceDiskUsageRefresh >= 8 {\n            refreshDiskUsage()\n            flushesSinceDiskUsageRefresh = 0\n        } else {\n            diskUsageBytes = min(retentionBytes, max(0, diskUsageBytes + data.count))\n            lastRefreshAt = Date()\n        }'''
    text = replace_once(text, old, new, "Diagnostics avoid per-flush disk scan")

    old = '''    private func rotateIfNeeded(incomingBytes: Int) {\n        let currentBytes = fileSize(currentLogURL)\n        guard currentBytes + incomingBytes > maxFileBytes else { return }\n\n        let oldest = rotatedURL(rotatedFileCount)\n        try? fileManager.removeItem(at: oldest)\n\n        if rotatedFileCount > 1 {\n            for index in stride(from: rotatedFileCount - 1, through: 1, by: -1) {\n                let source = rotatedURL(index)\n                let destination = rotatedURL(index + 1)\n                if fileManager.fileExists(atPath: source.path) {\n                    try? fileManager.removeItem(at: destination)\n                    try? fileManager.moveItem(at: source, to: destination)\n                }\n            }\n        }\n\n        if fileManager.fileExists(atPath: currentLogURL.path) {\n            let destination = rotatedURL(1)\n            try? fileManager.removeItem(at: destination)\n            try? fileManager.moveItem(at: currentLogURL, to: destination)\n        }\n    }'''
    new = '''    @discardableResult\n    private func rotateIfNeeded(incomingBytes: Int) -> Bool {\n        let currentBytes = fileSize(currentLogURL)\n        guard currentBytes + incomingBytes > maxFileBytes else { return false }\n\n        let oldest = rotatedURL(rotatedFileCount)\n        try? fileManager.removeItem(at: oldest)\n\n        if rotatedFileCount > 1 {\n            for index in stride(from: rotatedFileCount - 1, through: 1, by: -1) {\n                let source = rotatedURL(index)\n                let destination = rotatedURL(index + 1)\n                if fileManager.fileExists(atPath: source.path) {\n                    try? fileManager.removeItem(at: destination)\n                    try? fileManager.moveItem(at: source, to: destination)\n                }\n            }\n        }\n\n        if fileManager.fileExists(atPath: currentLogURL.path) {\n            let destination = rotatedURL(1)\n            try? fileManager.removeItem(at: destination)\n            try? fileManager.moveItem(at: currentLogURL, to: destination)\n        }\n        return true\n    }'''
    text = replace_once(text, old, new, "Diagnostics rotation result")
    return text


def patch_runtime_diagnostics(text: str) -> str:
    old = '''                            "risk": String(format: "%.2f", decision.riskPoints),\n                            "reason": decision.reasonCode,\n                            "cell": String(decision.latticeIndex),\n                            "issues": String(decision.issues.count)'''
    new = '''                            "risk": String(format: "%.2f", decision.riskPoints),\n                            "persistence_seconds": String(decision.persistenceSeconds),\n                            "transport_coverage": model.a9Health.transportCoverage.rawValue,\n                            "reason": decision.reasonCode,\n                            "cell": String(decision.latticeIndex),\n                            "issues": String(decision.issues.count)'''
    return replace_once(text, old, new, "A9 diagnostics duration/coverage")


def patch_a9_tests(text: str) -> str:
    insertion = r'''    @MainActor
    func testPersistenceUsesElapsedTimeNotCallbackVolume() {
        let monitor = VeilA9HealthMonitor()
        let base = Date(timeIntervalSince1970: 1_000)
        let yellow = VeilA9Input(weakPeerCount: 1)

        monitor.evaluate(yellow, now: base, uptime: 100)
        for _ in 0..<100 {
            monitor.evaluate(yellow, now: base.addingTimeInterval(1), uptime: 101)
        }
        XCTAssertEqual(monitor.decision.persistenceSeconds, 1)
        XCTAssertEqual(monitor.decision.level, .l1Advisory)

        monitor.evaluate(yellow, now: base.addingTimeInterval(31), uptime: 131)
        XCTAssertEqual(monitor.decision.persistenceSeconds, 31)
        XCTAssertEqual(monitor.decision.level, .l2Review)

        monitor.evaluate(VeilA9Input(), now: base.addingTimeInterval(32), uptime: 132)
        XCTAssertEqual(monitor.decision.persistenceSeconds, 0)
        XCTAssertEqual(monitor.decision.level, .l0Observe)
    }

    func testPersistentThresholdRepresentsSeconds() {
        XCTAssertEqual(VeilA9Lattice.persistentDurationThresholdSeconds, 30)
        XCTAssertEqual(VeilA9Lattice.persistentRunThreshold, 30)
    }
'''
    return insert_before_final_brace(text, insertion, "A9 duration tests")


def patch_diagnostic_tests(text: str) -> str:
    insertion = r'''    func testStallPolicyRejectsSuspensionAndResumeGrace() {
        XCTAssertFalse(DeepTelemetryStallPolicy.shouldReport(
            delta: 3_600,
            applicationActive: false,
            nowUptime: 10_000,
            resumeGraceUntilUptime: 0
        ))
        XCTAssertFalse(DeepTelemetryStallPolicy.shouldReport(
            delta: 3_600,
            applicationActive: true,
            nowUptime: 10_000,
            resumeGraceUntilUptime: 10_001
        ))
        XCTAssertTrue(DeepTelemetryStallPolicy.shouldReport(
            delta: 1.6,
            applicationActive: true,
            nowUptime: 10_000,
            resumeGraceUntilUptime: 9_000
        ))
    }
'''
    return insert_before_final_brace(text, insertion, "Telemetry stall policy tests")


def patch_ble_snapshot_tests(text: str) -> str:
    insertion = r'''    func testPassiveDiscoveryDoesNotContributeToA9Health() {
        let passive = BLEPeerLinkSnapshot(
            id: UUID(), isConnected: false, isWanted: false, reconnectAttempt: 0,
            rssi: -98, quality: .weak, pendingPackets: 0, pendingBytes: 0,
            controlPendingPackets: 0, maximumPacketSize: nil, role: .unavailable,
            transportStage: .discovered, stalledFor: nil
        )
        let live = BLEPeerLinkSnapshot(
            id: UUID(), isConnected: true, isWanted: true, reconnectAttempt: 0,
            rssi: -72, quality: .good, pendingPackets: 0, pendingBytes: 0,
            controlPendingPackets: 0, maximumPacketSize: 185, role: .central,
            transportStage: .gattReady, stalledFor: nil
        )
        XCTAssertFalse(passive.isA9Relevant)
        XCTAssertFalse(passive.contributesLinkQualityToA9)
        XCTAssertTrue(live.isA9Relevant)
        XCTAssertTrue(live.contributesLinkQualityToA9)
    }
'''
    return insert_before_final_brace(text, insertion, "BLE ghost A9 tests")


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I4_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink/Resources/Info.plist").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    # Idempotent: detect a complete I4 tree before validating pre-I4 blob SHAs.
    already_i4 = True
    for rel, markers in I4_MARKERS.items():
        p = root / rel
        if not p.exists():
            already_i4 = False
            break
        source = p.read_text(encoding="utf-8")
        if not all(marker.replace("\\\\", "\\") in source for marker in markers):
            already_i4 = False
            break
    if already_i4:
        print("I4 markers already present; no source rewrite needed.")
        return 0

    # I4 must layer on I3; never silently patch an older transport tree.
    for rel, markers in I3_REQUIRED_MARKERS.items():
        source = (root / rel).read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{rel}: missing required I3 marker {marker!r}")

    # Files untouched by I1-I3 must still be exact main-base blobs.
    for rel, expected in BASE_BLOBS_UNCHANGED_THROUGH_I3.items():
        p = root / rel
        actual = git_blob_sha(p.read_bytes())
        if actual != expected:
            raise RuntimeError(f"{rel}: baseline drift (expected {expected}, got {actual})")

    paths = {
        "VeilLink/Transport/BLETransport.swift": patch_ble_transport,
        "VeilLink/Transport/BLELinkSnapshot.swift": patch_link_snapshot,
        "VeilLink/Health/VeilA9Lattice.swift": patch_a9_lattice,
        "VeilLink/Health/VeilA9HealthMonitor.swift": patch_a9_monitor,
        "VeilLink/App/AppModel.swift": patch_app_model,
        "VeilLink/Diagnostics/DeepTelemetry.swift": patch_deep_telemetry,
        "VeilLink/Diagnostics/DiagnosticLogStore.swift": patch_diagnostic_store,
        "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": patch_runtime_diagnostics,
        "VeilLinkTests/A9HealthLatticeTests.swift": patch_a9_tests,
        "VeilLinkTests/DiagnosticLogStoreTests.swift": patch_diagnostic_tests,
        "VeilLinkTests/BLELinkSnapshotTests.swift": patch_ble_snapshot_tests,
    }

    original = {}
    patched = {}
    # Validate all transforms in memory before writing any file.
    for rel, transform in paths.items():
        p = root / rel
        source = p.read_text(encoding="utf-8")
        original[rel] = source
        patched[rel] = transform(source)
        if patched[rel] == source:
            raise RuntimeError(f"{rel}: transform produced no change")

    backup = root / ".veillink-local-iter/I4-backup"
    for rel, source in original.items():
        destination = backup / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(source, encoding="utf-8")

    for rel, source in patched.items():
        (root / rel).write_text(source, encoding="utf-8")

    print(f"Applied VeilLink cumulative I4 over I3; backup: {backup}")
    print("Base authority:", BASE_HEAD)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
