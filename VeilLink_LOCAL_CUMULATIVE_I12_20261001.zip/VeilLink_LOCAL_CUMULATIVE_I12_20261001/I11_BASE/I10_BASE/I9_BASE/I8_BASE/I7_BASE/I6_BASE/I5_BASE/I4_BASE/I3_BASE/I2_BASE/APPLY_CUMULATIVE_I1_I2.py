from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    info = root / "VeilLink/Resources/Info.plist"
    if not info.exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    # Fresh 152c3ab base -> apply I1. Already-I1 source -> verify and continue.
    if "NSFaceIDUsageDescription" not in info.read_text(encoding="utf-8"):
        run([sys.executable, HERE / "I1_BASE/I1_APPLY.py", root])
    run([sys.executable, HERE / "I1_BASE/I1_VERIFY.py", root])

    # Idempotent guard: an already-I2 tree is verified, never patched twice.
    core = (root / "VeilLink/Core/MiniGames.swift").read_text(encoding="utf-8")
    keychain = (root / "VeilLink/Security/KeychainStore.swift").read_text(encoding="utf-8")
    already_i2 = "case cancelInvite" in core and "func readData(for key: String) throws -> Data?" in keychain
    if not already_i2:
        run([sys.executable, HERE / "I2_APPLY.py", root])
    run([sys.executable, HERE / "I2_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
