# VeilLink Unified Defect / Integration Ledger — I6

## Local phase
**A10_INTEGRATION_READY — A10 对接准备 / 个性化适配阶段**

## Architecture decision
A9 remains the authoritative compatibility baseline. I6 does not claim A10 exists in VeilLink; it creates the host boundary required to accept the future Universal Lattice Kernel without coupling VeilLink business objects directly to the kernel.

## I6 closures
- A9 health input gains a versioned Signal Bus mirror.
- A9 decision gains a stable compatibility fingerprint for dual-run comparison.
- Existing A9 Compute Governor output gains a generic Budget Envelope mirror.
- Host-specific fault domains are declared: storage, transport, system, agent, game, lifecycle.
- A10 candidate runtime is restricted to sanitized Signal Frames and advisory Decision Snapshots.
- Shadow validation state is available; active profile remains `veillink.a9.compat.v1`.
- No direct mutation authority is granted to the kernel.
- No cloud scheduling or peer compute offload is permitted.

## Future cutover gate
1. A10 adapter implements `VeilLatticeKernelRuntimeAdapter`.
2. Compiled `veillink.a10.profile.v1` is loaded.
3. Enter shadow validation while A9 remains active.
4. Same Signal Frame is evaluated by A9 compatibility and A10 compatibility profile.
5. Unexpected decision diff must remain 0.
6. XcodeGen / XCTest / iPhone 7 + iPhone 13 burn-in passes.
7. External release/cutover process may then switch active profile. Kernel cannot self-promote.
