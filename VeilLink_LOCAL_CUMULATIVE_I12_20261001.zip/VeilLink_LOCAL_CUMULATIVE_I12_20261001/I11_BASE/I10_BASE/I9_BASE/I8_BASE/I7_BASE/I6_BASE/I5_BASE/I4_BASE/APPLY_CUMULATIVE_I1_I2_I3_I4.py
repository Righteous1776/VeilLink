from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink/Resources/Info.plist").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    # I3 cumulative runner is already idempotent and carries I1 + I2 internally.
    run([sys.executable, HERE / "I3_BASE/APPLY_CUMULATIVE_I1_I2_I3.py", root])

    monitor = (root / "VeilLink/Health/VeilA9HealthMonitor.swift").read_text(encoding="utf-8")
    telemetry = (root / "VeilLink/Diagnostics/DeepTelemetry.swift").read_text(encoding="utf-8")
    already_i4 = "private var nonGreenSinceUptime: TimeInterval?" in monitor and "enum DeepTelemetryStallPolicy" in telemetry
    if not already_i4:
        run([sys.executable, HERE / "I4_APPLY.py", root])
    run([sys.executable, HERE / "I4_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 -> I4 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
