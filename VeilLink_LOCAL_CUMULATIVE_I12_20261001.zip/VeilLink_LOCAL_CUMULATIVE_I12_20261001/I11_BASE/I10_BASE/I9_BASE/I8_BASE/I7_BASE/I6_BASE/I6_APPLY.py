from pathlib import Path
import shutil
import sys

I5_REQUIRED = {
    "VeilLink/Core/AppTheme.swift": ["enum VeilUILayoutPolicy"],
    "VeilLink/Resources/Info.plist": ["<key>UIUserInterfaceStyle</key>", "<string>Dark</string>"],
    "VeilLink/Health/VeilA9HealthMonitor.swift": ["private var nonGreenSinceUptime: TimeInterval?", "Persistence: \\(decision.persistenceSeconds) s"],
    "VeilLink/Health/VeilA9Lattice.swift": ["enum VeilA9TransportCoverage", "persistentDurationThresholdSeconds = 30"],
    "VeilLink/Transport/BLETransport.swift": ["peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)"],
}

I6_MARKERS = {
    "VeilLink/Health/VeilLatticeKernelBridge.swift": [
        "A10_INTEGRATION_READY",
        "protocol VeilLatticeKernelRuntimeAdapter",
        "func beginA10ShadowValidation",
        "Cutover gate: external release process only",
    ],
    "VeilLink/App/AppModel.swift": [
        "let latticeKernel: VeilLatticeKernelBridge",
        "latticeKernel = VeilLatticeKernelBridge()",
        "latticeKernel.recordA9Compatibility",
        "latticeKernel.recordComputePlan",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": ["kernel.integration_state"],
}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_app_model(text: str) -> str:
    text = replace_once(
        text,
        "    let a9Health: VeilA9HealthMonitor\n    let computeGovernor: VeilA9ComputeGovernor\n",
        "    let a9Health: VeilA9HealthMonitor\n    let computeGovernor: VeilA9ComputeGovernor\n    let latticeKernel: VeilLatticeKernelBridge\n",
        "kernel property"
    )
    text = replace_once(
        text,
        "        computeGovernor = VeilA9ComputeGovernor(profile: agentProfile)\n        agentControls = AgentControlCenterSettings()\n",
        "        computeGovernor = VeilA9ComputeGovernor(profile: agentProfile)\n        latticeKernel = VeilLatticeKernelBridge()\n        agentControls = AgentControlCenterSettings()\n",
        "kernel initialization"
    )
    text = replace_once(
        text,
        '''        a9Health.$decision
            .sink { [weak self] decision in
                Task { @MainActor [weak self] in self?.computeGovernor.update(decision: decision) }
            }
            .store(in: &a9Cancellables)''',
        '''        a9Health.$decision
            .sink { [weak self] decision in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.computeGovernor.update(decision: decision)
                    self.latticeKernel.recordComputePlan(self.computeGovernor.plan)
                }
            }
            .store(in: &a9Cancellables)''',
        "kernel compute-envelope binding"
    )
    text = replace_once(
        text,
        "        a9Health.evaluate(input)\n",
        "        a9Health.evaluate(input)\n        latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)\n",
        "kernel A9 compatibility record"
    )
    text = replace_once(
        text,
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report() + "\\n\\n" + computeGovernor.report()
    }''',
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report() + "\\n\\n" + latticeKernel.report() + "\\n\\n" + computeGovernor.report()
    }''',
        "kernel diagnostics report"
    )
    return text


def patch_runtime_diagnostics(text: str) -> str:
    anchor = "\n        model.maleCNS.$state\n"
    if text.count(anchor) != 1:
        raise RuntimeError(f"kernel diagnostics insertion: expected 1 anchor, found {text.count(anchor)}")
    insertion = '''
        model.latticeKernel.$snapshot
            .removeDuplicates()
            .sink { snapshot in
                Task { @MainActor in
                    self.store.log(
                        snapshot.unexpectedDecisionDiffs > 0 ? .warning : .info,
                        .a9,
                        event: "kernel.integration_state",
                        screen: DeepTelemetry.shared.currentScreen,
                        metadata: [
                            "stage": snapshot.stage.rawValue,
                            "active_profile": snapshot.activeProfileID,
                            "candidate_profile": snapshot.candidateProfileID ?? "none",
                            "authority": snapshot.authority.rawValue,
                            "signal_bus": String(snapshot.signalBusVersion),
                            "unexpected_diffs": String(snapshot.unexpectedDecisionDiffs),
                            "compute_mode": snapshot.computeMode ?? "none"
                        ]
                    )
                }
            }
            .store(in: &cancellables)
'''
    return text.replace(anchor, insertion + anchor, 1)


def copy_payload(here: Path, root: Path) -> None:
    mapping = {
        here / "Payload/VeilLink/Health/VeilLatticeKernelBridge.swift": root / "VeilLink/Health/VeilLatticeKernelBridge.swift",
        here / "Payload/VeilLinkTests/VeilLatticeKernelBridgeTests.swift": root / "VeilLinkTests/VeilLatticeKernelBridgeTests.swift",
        here / "Payload/docs/A10_INTEGRATION_READINESS.md": root / "docs/A10_INTEGRATION_READINESS.md",
    }
    for src, dst in mapping.items():
        if not src.exists():
            raise RuntimeError(f"missing I6 payload: {src}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I6_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    require_markers(root, I5_REQUIRED, "I5 prerequisite")

    bridge_path = root / "VeilLink/Health/VeilLatticeKernelBridge.swift"
    if bridge_path.exists() and "A10_INTEGRATION_READY" in bridge_path.read_text(encoding="utf-8"):
        require_markers(root, I6_MARKERS, "existing I6")
        print("I6 already present; no duplicate mutation performed")
        return 0

    backup = root / ".veillink-local-iter/I6-backup"
    backup.mkdir(parents=True, exist_ok=True)
    for rel in ["VeilLink/App/AppModel.swift", "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"]:
        src = root / rel
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    app = root / "VeilLink/App/AppModel.swift"
    app.write_text(patch_app_model(app.read_text(encoding="utf-8")), encoding="utf-8")

    diag = root / "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"
    diag.write_text(patch_runtime_diagnostics(diag.read_text(encoding="utf-8")), encoding="utf-8")

    copy_payload(here, root)
    require_markers(root, I6_MARKERS, "I6 post-apply")
    print("I6 A10 integration readiness applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
