from pathlib import Path
import hashlib
import re
import shutil
import sys

BASE_HEAD = "152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f"

# These files are untouched by I1-I4 and can still be guarded against the authoritative main blob.
UNCHANGED_BLOBS_THROUGH_I4 = {
    "VeilLink/Core/AppTheme.swift": "85420de39f4924829532087cc23e7ad9dc2d5969",
    "VeilLink/App/VeilLinkApp.swift": "5472f44aef099259e42fdab6913eab007d285389",
    "VeilLink/UI/LockScreenView.swift": "66eec019b68d25514a7b7d82cb842b976c949e63",
    "VeilLink/UI/AdaptiveRootView.swift": "2148ea8e8ddc86f75fb7d056b28e583d0e8d921b",
    "VeilLink/UI/SettingsView.swift": "463ac35078d7a69ff8fbc8a9f9dde85e267a300e",
    "VeilLink/UI/GameLobbyView.swift": "0f16990150750e54b02a9e197c9e7f0130ce4605",
    "VeilLink/UI/TacticalGameViews.swift": "668d2bd57ac70768ca58fe08b6d3404807d66d40",
    "VeilLink/UI/NearbyView.swift": "cb7783507942f477bd5815883189490ece5f104a",
}

I4_REQUIRED_MARKERS = {
    "VeilLink/Health/VeilA9HealthMonitor.swift": [
        "private var nonGreenSinceUptime: TimeInterval?",
        "Persistence: \\(decision.persistenceSeconds) s",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "enum DeepTelemetryStallPolicy",
        "postInteractionSnapshotTask",
    ],
    "VeilLink/Transport/BLETransport.swift": [
        "private let passiveDiscoveryRetention: TimeInterval = 15",
        "peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)",
    ],
}

I5_MARKERS = {
    "VeilLink/Core/AppTheme.swift": [
        "enum VeilUILayoutPolicy",
        "minimumTabletTwoPaneWidth",
    ],
    "VeilLink/UI/LockScreenView.swift": [
        "VeilUILayoutPolicy.lockUsesHorizontalLayout",
        "private func keypad(keySize: CGFloat, spacing: CGFloat)",
    ],
    "VeilLink/UI/AdaptiveRootView.swift": [
        "VeilUILayoutPolicy.usesTabletTwoPane",
        "let sidebarWidth: CGFloat",
    ],
    "VeilLink/App/VeilLinkApp.swift": [
        "UITableView.appearance().backgroundColor",
        "UITextField.appearance().keyboardAppearance = .dark",
    ],
    "VeilLink/Resources/Info.plist": [
        "<key>UIUserInterfaceStyle</key>",
        "<string>Dark</string>",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "if currentScreen == normalized",
        "screenStack.append(normalized)",
    ],
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping: dict[str, list[str]], label: str) -> None:
    for rel, markers in mapping.items():
        source = (root / rel).read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing marker {marker!r}")


def raise_micro_fonts(text: str) -> tuple[str, int]:
    # Remove the most extreme 5.3-9 pt fixed UI labels. 9.5pt+ remains available for compact
    # telemetry/board metadata, but no key user-facing target should drop below 10pt before scaling.
    pattern = re.compile(r"(?<=size:\s)(5\.3|6\.5|7\.5|7|8\.5|8|9)(?=[,)])")
    text, count = pattern.subn("10", text)
    # Prevent long Chinese labels from collapsing into 6pt-like output on narrow screens.
    text = text.replace(".minimumScaleFactor(0.6)", ".minimumScaleFactor(0.78)")
    text = text.replace(".minimumScaleFactor(0.62)", ".minimumScaleFactor(0.78)")
    text = text.replace(".minimumScaleFactor(0.68)", ".minimumScaleFactor(0.78)")
    return text, count


def patch_app_theme(text: str) -> str:
    marker = '''}\n\n\n/// Hardware/OS render capability gate.'''
    insertion = '''}\n\n/// Centralized geometry policy for the two device families that repeatedly exposed layout bugs:\n/// iPhone 7 / iOS 15 and iPad split-window layouts. Keeping the thresholds here makes them unit\n/// testable and prevents individual screens from reintroducing ad-hoc fixed widths.\nenum VeilUILayoutPolicy {\n    static let minimumTabletTwoPaneWidth: CGFloat = 720\n\n    static func usesTabletTwoPane(horizontalSizeClassRegular: Bool, viewportWidth: CGFloat) -> Bool {\n        horizontalSizeClassRegular && viewportWidth >= minimumTabletTwoPaneWidth\n    }\n\n    static func sidebarWidth(viewportWidth: CGFloat) -> CGFloat {\n        min(330, max(250, viewportWidth * 0.30))\n    }\n\n    static func lockUsesHorizontalLayout(size: CGSize) -> Bool {\n        size.width > size.height && size.height < 560\n    }\n\n    static func lockKeySize(size: CGSize) -> CGFloat {\n        if lockUsesHorizontalLayout(size: size) { return 50 }\n        return size.height < 700 ? 60 : 68\n    }\n}\n\n\n/// Hardware/OS render capability gate.'''
    return replace_once(text, marker, insertion, "UI layout policy insertion")


def patch_app_entry(text: str) -> str:
    old = '''    static func configure() {\n        let navigation = UINavigationBarAppearance()\n        navigation.configureWithOpaqueBackground()\n        navigation.backgroundColor = UIColor(red: 0.012, green: 0.013, blue: 0.017, alpha: 0.96)'''
    new = '''    static func configure() {\n        // VeilLink 26.9 has one production appearance contract: black/gold dark UI. Native\n        // SwiftUI Form/List/Sheet surfaces must use the same contract instead of briefly falling\n        // back to a light UIKit surface during presentation on iOS 15.\n        let background = UIColor(red: 0.012, green: 0.013, blue: 0.017, alpha: 1)\n        let elevated = UIColor(red: 0.045, green: 0.046, blue: 0.056, alpha: 1)\n\n        let navigation = UINavigationBarAppearance()\n        navigation.configureWithOpaqueBackground()\n        navigation.backgroundColor = background.withAlphaComponent(0.96)'''
    text = replace_once(text, old, new, "dark chrome background")

    old = '''        let tabBar = UITabBar.appearance()\n        tabBar.standardAppearance = tab\n        tabBar.scrollEdgeAppearance = tab\n    }'''
    new = '''        let tabBar = UITabBar.appearance()\n        tabBar.standardAppearance = tab\n        tabBar.scrollEdgeAppearance = tab\n\n        UITableView.appearance().backgroundColor = background\n        UITableView.appearance().separatorColor = UIColor.white.withAlphaComponent(0.06)\n        UITableViewCell.appearance().backgroundColor = .clear\n        UICollectionView.appearance().backgroundColor = background\n        UITextField.appearance().keyboardAppearance = .dark\n        UITextView.appearance().keyboardAppearance = .dark\n        UISearchBar.appearance().keyboardAppearance = .dark\n        UISearchBar.appearance().barTintColor = elevated\n    }'''
    return replace_once(text, old, new, "native dark Form/List/Sheet chrome")


LOCK_SCREEN_SOURCE = r'''import SwiftUI

struct LockScreenView: View {
    @ObservedObject var controller: AppLockController
    @ObservedObject var haptics: HapticEngine
    @State private var pin = ""

    var body: some View {
        GeometryReader { proxy in
            let horizontal = VeilUILayoutPolicy.lockUsesHorizontalLayout(size: proxy.size)
            let keySize = VeilUILayoutPolicy.lockKeySize(size: proxy.size)
            let gridSpacing: CGFloat = horizontal ? 9 : 16

            ZStack {
                VeilAmbientBackground()
                ScrollView(.vertical, showsIndicators: false) {
                    Group {
                        if horizontal {
                            HStack(spacing: 24) {
                                identityBlock(compact: true)
                                    .frame(maxWidth: .infinity)
                                keypad(keySize: keySize, spacing: gridSpacing)
                                    .frame(width: min(228, proxy.size.width * 0.48))
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 12)
                        } else {
                            VStack(spacing: 20) {
                                Spacer(minLength: 8)
                                identityBlock(compact: false)
                                keypad(keySize: keySize, spacing: gridSpacing)
                                Spacer(minLength: 8)
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 18)
                        }
                    }
                    .frame(minHeight: max(1, proxy.size.height - 1))
                    .frame(maxWidth: .infinity)
                }
            }
        }
    }

    @ViewBuilder
    private func identityBlock(compact: Bool) -> some View {
        VStack(spacing: compact ? 11 : 18) {
            VeilIdentityGlyph(seed: "VeilLink/Locked/Local", size: compact ? 58 : 78, active: true)
            VStack(spacing: 4) {
                Text("VEIL // LOCKED")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.5)
                    .foregroundColor(VeilTheme.mutedGold)
                Text("输入 VeilLink 密码")
                    .font(.system(compact ? .headline : .title3, design: .rounded).weight(.semibold))
            }
            HStack(spacing: compact ? 11 : 16) {
                ForEach(0..<6, id: \.self) { index in
                    Circle()
                        .fill(index < pin.count ? VeilTheme.goldBright : Color.clear)
                        .overlay(Circle().stroke(index < pin.count ? VeilTheme.gold.opacity(0.52) : VeilTheme.hairline, lineWidth: 1.2))
                        .frame(width: 12, height: 12)
                        .shadow(color: index < pin.count ? VeilTheme.gold.opacity(0.32) : .clear, radius: 5)
                }
            }
            .frame(height: 22)

            if let error = controller.errorMessage {
                Text(error)
                    .font(.footnote)
                    .foregroundColor(VeilTheme.danger)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func keypad(keySize: CGFloat, spacing: CGFloat) -> some View {
        let columns = Array(repeating: GridItem(.flexible(), spacing: spacing), count: 3)
        return LazyVGrid(columns: columns, spacing: spacing) {
            ForEach([1,2,3,4,5,6,7,8,9], id: \.self) { digit in
                key(String(digit), size: keySize)
            }
            Button {
                Task {
                    if await controller.unlockWithBiometrics() {
                        haptics.resolved()
                    } else {
                        haptics.error()
                    }
                }
            } label: {
                VeilIconDisc(systemName: "touchid", size: max(42, keySize - 10), highlighted: true)
            }
            .buttonStyle(VeilPressStyle())
            .frame(width: keySize, height: keySize)

            key("0", size: keySize)

            Button {
                if !pin.isEmpty {
                    pin.removeLast()
                    haptics.selection()
                }
            } label: {
                VeilIconDisc(systemName: "delete.left", size: max(42, keySize - 10))
            }
            .buttonStyle(VeilPressStyle())
            .frame(width: keySize, height: keySize)
        }
        .foregroundColor(VeilTheme.text)
        .frame(maxWidth: 270)
    }

    private func key(_ value: String, size: CGFloat) -> some View {
        Button {
            guard pin.count < 6 else { return }
            pin.append(value)
            haptics.selection()
            if pin.count == 6 {
                if controller.unlock(pin: pin) {
                    haptics.resolved()
                } else {
                    haptics.error()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { pin = "" }
                }
            }
        } label: {
            Text(value)
                .font(.system(size: size >= 60 ? 27 : 22, weight: .regular, design: .rounded))
                .frame(width: size, height: size)
                .background(VeilTheme.elevated.opacity(0.78))
                .clipShape(VeilPanelShape(cut: 11, radius: 7))
                .overlay(
                    VeilPanelShape(cut: 11, radius: 7)
                        .stroke(VeilTheme.hairline, lineWidth: 1)
                )
                .overlay(alignment: .topLeading) {
                    Rectangle()
                        .fill(VeilTheme.gold.opacity(0.22))
                        .frame(width: 13, height: 1)
                        .padding(.leading, 7)
                }
        }
        .buttonStyle(VeilPressStyle())
    }
}
'''


def patch_lock_screen(_text: str) -> str:
    # Blob guard proves we are replacing the exact audited version.
    return LOCK_SCREEN_SOURCE


def patch_adaptive_root(text: str) -> str:
    old = '''    var body: some View {\n        Group {\n            if horizontalSizeClass == .regular {\n                TabletLayout(model: model)\n            } else {\n                PhoneLayout(model: model)\n            }\n        }\n        .background(VeilAmbientBackground())\n    }'''
    new = '''    var body: some View {\n        GeometryReader { proxy in\n            Group {\n                if VeilUILayoutPolicy.usesTabletTwoPane(\n                    horizontalSizeClassRegular: horizontalSizeClass == .regular,\n                    viewportWidth: proxy.size.width\n                ) {\n                    TabletLayout(\n                        model: model,\n                        sidebarWidth: VeilUILayoutPolicy.sidebarWidth(viewportWidth: proxy.size.width)\n                    )\n                } else {\n                    PhoneLayout(model: model)\n                }\n            }\n            .frame(width: proxy.size.width, height: proxy.size.height)\n        }\n        .background(VeilAmbientBackground())\n    }'''
    text = replace_once(text, old, new, "adaptive root narrow regular-width fallback")

    old = '''private struct TabletLayout: View {\n    @ObservedObject var model: AppModel\n\n    var body: some View {'''
    new = '''private struct TabletLayout: View {\n    @ObservedObject var model: AppModel\n    let sidebarWidth: CGFloat\n\n    var body: some View {'''
    text = replace_once(text, old, new, "tablet layout sidebar input")
    text = replace_once(text, ".frame(width: 330)", ".frame(width: sidebarWidth)", "tablet sidebar fixed width")
    return text


def patch_info_plist(text: str) -> str:
    if "<key>UIUserInterfaceStyle</key>" in text:
        return text
    old = '''\t<key>UIApplicationSceneManifest</key>'''
    new = '''\t<key>UIUserInterfaceStyle</key>\n\t<string>Dark</string>\n\t<key>UIApplicationSceneManifest</key>'''
    return replace_once(text, old, new, "dark interface style plist contract")


def patch_safe_area(text: str, expected: int, label: str) -> str:
    old = "VeilAmbientBackground().ignoresSafeArea()"
    count = text.count(old)
    if count != expected:
        raise RuntimeError(f"{label}: expected {expected} remaining unsafe ambient backgrounds, found {count}")
    return text.replace(old, "VeilAmbientBackground()")


def patch_telemetry_screen_state(text: str) -> str:
    old = '''    func screenDisappear(_ name: String, metadata: [String: String] = [:]) {\n        let normalized = DiagnosticPrivacyFilter.sanitizeValue(name, limit: 128)\n        store.log(.info, .ui, event: "ui.screen.disappear", screen: normalized, metadata: metadata)\n        if let index = screenStack.lastIndex(of: normalized) {\n            screenStack.remove(at: index)\n        }\n        currentScreen = screenStack.last ?? "unknown"\n    }'''
    new = '''    func screenDisappear(_ name: String, metadata: [String: String] = [:]) {\n        let normalized = DiagnosticPrivacyFilter.sanitizeValue(name, limit: 128)\n        store.log(.info, .ui, event: "ui.screen.disappear", screen: normalized, metadata: metadata)\n        if let index = screenStack.lastIndex(of: normalized) {\n            screenStack.remove(at: index)\n        }\n        // SwiftUI can deliver the previous view's onDisappear after the next tab/navigation\n        // screen has already become current. Never let that late callback rewind diagnostics.\n        if currentScreen == normalized {\n            currentScreen = screenStack.last ?? "unknown"\n        }\n    }'''
    text = replace_once(text, old, new, "telemetry late disappear guard")

    old = '''    func setNavigationScreen(_ name: String, metadata: [String: String] = [:]) {\n        currentScreen = DiagnosticPrivacyFilter.sanitizeValue(name, limit: 128)\n        store.log(.info, .navigation, event: "ui.navigation", screen: currentScreen, metadata: metadata)\n        captureUIHierarchy(reason: "navigation", force: true)\n    }'''
    new = '''    func setNavigationScreen(_ name: String, metadata: [String: String] = [:]) {\n        let normalized = DiagnosticPrivacyFilter.sanitizeValue(name, limit: 128)\n        screenStack.removeAll { $0 == normalized }\n        screenStack.append(normalized)\n        currentScreen = normalized\n        store.log(.info, .navigation, event: "ui.navigation", screen: currentScreen, metadata: metadata)\n        captureUIHierarchy(reason: "navigation", force: false)\n    }'''
    return replace_once(text, old, new, "telemetry navigation stack synchronization")


def patch_typography_file(text: str, rel: str) -> str:
    patched, count = raise_micro_fonts(text)
    if count == 0:
        raise RuntimeError(f"{rel}: expected at least one <9.5pt fixed micro-font target")
    return patched


def add_layout_tests(root: Path) -> None:
    target = root / "VeilLinkTests/UILayoutPolicyTests.swift"
    if target.exists() and "testRegularButNarrowViewportFallsBackToPhone" in target.read_text(encoding="utf-8"):
        return
    target.write_text(r'''import XCTest
@testable import VeilLink

final class UILayoutPolicyTests: XCTestCase {
    func testRegularButNarrowViewportFallsBackToPhone() {
        XCTAssertFalse(VeilUILayoutPolicy.usesTabletTwoPane(horizontalSizeClassRegular: true, viewportWidth: 650))
        XCTAssertTrue(VeilUILayoutPolicy.usesTabletTwoPane(horizontalSizeClassRegular: true, viewportWidth: 834))
        XCTAssertFalse(VeilUILayoutPolicy.usesTabletTwoPane(horizontalSizeClassRegular: false, viewportWidth: 900))
    }

    func testTabletSidebarRemainsBounded() {
        XCTAssertEqual(VeilUILayoutPolicy.sidebarWidth(viewportWidth: 1_200), 330, accuracy: 0.001)
        XCTAssertGreaterThanOrEqual(VeilUILayoutPolicy.sidebarWidth(viewportWidth: 720), 250)
        XCTAssertLessThanOrEqual(VeilUILayoutPolicy.sidebarWidth(viewportWidth: 720), 330)
    }

    func testLandscapeLockUsesCompactKeypad() {
        let landscape = CGSize(width: 844, height: 390)
        let portrait = CGSize(width: 390, height: 844)
        XCTAssertTrue(VeilUILayoutPolicy.lockUsesHorizontalLayout(size: landscape))
        XCTAssertFalse(VeilUILayoutPolicy.lockUsesHorizontalLayout(size: portrait))
        XCTAssertEqual(VeilUILayoutPolicy.lockKeySize(size: landscape), 50, accuracy: 0.001)
        XCTAssertEqual(VeilUILayoutPolicy.lockKeySize(size: portrait), 68, accuracy: 0.001)
    }
}
''', encoding="utf-8")


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I5_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink/Resources/Info.plist").exists():
        raise RuntimeError(f"Not a VeilLink repo root: {root}")

    # I5 is only valid on top of cumulative I4. The cumulative runner supplies that automatically.
    require_markers(root, I4_REQUIRED_MARKERS, "I4 prerequisite")

    # Idempotent: if all I5 markers are present, do not rewrite a tested source tree.
    try:
        require_markers(root, I5_MARKERS, "I5")
        print("I5 markers already present; skipping mutation")
        return 0
    except RuntimeError:
        pass

    for rel, expected in UNCHANGED_BLOBS_THROUGH_I4.items():
        p = root / rel
        actual = git_blob_sha(p.read_bytes())
        if actual != expected:
            raise RuntimeError(f"{rel}: source drift before I5 (expected {expected}, got {actual})")

    backup = root / ".veillink-local-iter/I5-backup"
    backup.mkdir(parents=True, exist_ok=True)

    targets = [
        "VeilLink/Core/AppTheme.swift",
        "VeilLink/App/VeilLinkApp.swift",
        "VeilLink/UI/LockScreenView.swift",
        "VeilLink/UI/AdaptiveRootView.swift",
        "VeilLink/UI/SettingsView.swift",
        "VeilLink/UI/GameLobbyView.swift",
        "VeilLink/UI/TacticalGameViews.swift",
        "VeilLink/UI/NearbyView.swift",
        "VeilLink/UI/ConversationViews.swift",
        "VeilLink/UI/MiniGameViews.swift",
        "VeilLink/Resources/Info.plist",
        "VeilLink/Diagnostics/DeepTelemetry.swift",
    ]
    for rel in targets:
        src = root / rel
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    def mutate(rel: str, fn) -> None:
        p = root / rel
        old = p.read_text(encoding="utf-8")
        new = fn(old)
        if new == old:
            raise RuntimeError(f"{rel}: I5 patch made no change")
        p.write_text(new, encoding="utf-8")

    mutate("VeilLink/Core/AppTheme.swift", patch_app_theme)
    mutate("VeilLink/App/VeilLinkApp.swift", patch_app_entry)
    mutate("VeilLink/UI/LockScreenView.swift", patch_lock_screen)
    mutate("VeilLink/UI/AdaptiveRootView.swift", patch_adaptive_root)
    mutate("VeilLink/Resources/Info.plist", patch_info_plist)

    # I1 already removed three unsafe game backgrounds. Two replay/rules paths remain by design
    # in the main snapshot and are removed here. GameLobby has one additional regression.
    mutate("VeilLink/UI/MiniGameViews.swift", lambda s: patch_safe_area(s, 2, "MiniGame remaining safe-area regression"))
    mutate("VeilLink/UI/GameLobbyView.swift", lambda s: patch_safe_area(s, 1, "GameLobby safe-area regression"))
    mutate("VeilLink/Diagnostics/DeepTelemetry.swift", patch_telemetry_screen_state)

    # Raise only the most extreme fixed micro-fonts. This intentionally does not blanket-rewrite
    # all .caption/.caption2 semantics, preserving density while removing 5-9pt unreadable labels.
    typography_targets = [
        "VeilLink/UI/SettingsView.swift",
        "VeilLink/UI/AdaptiveRootView.swift",
        "VeilLink/UI/MiniGameViews.swift",
        "VeilLink/UI/TacticalGameViews.swift",
        "VeilLink/UI/ConversationViews.swift",
        "VeilLink/UI/NearbyView.swift",
        "VeilLink/UI/GameLobbyView.swift",
    ]
    for rel in typography_targets:
        p = root / rel
        before = p.read_text(encoding="utf-8")
        after = patch_typography_file(before, rel)
        p.write_text(after, encoding="utf-8")

    add_layout_tests(root)
    print("APPLIED VeilLink local cumulative I5 UI hardening")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
