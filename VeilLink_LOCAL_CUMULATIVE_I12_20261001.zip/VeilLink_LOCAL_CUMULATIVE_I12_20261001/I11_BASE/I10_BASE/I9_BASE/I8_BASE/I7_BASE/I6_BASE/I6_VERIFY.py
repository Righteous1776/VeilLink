from pathlib import Path
import subprocess
import sys

REQUIRED = {
    "VeilLink/Health/VeilLatticeKernelBridge.swift": [
        "enum VeilKernelIntegrationStage",
        "A10_INTEGRATION_READY",
        "protocol VeilLatticeKernelRuntimeAdapter",
        "static let veilLink = VeilKernelHostProfile",
        "canMutateTransport: false",
        "canMutateStorage: false",
        "canMutateGameState: false",
        "canReadSecrets: false",
        "allowsCloudScheduling: false",
        "allowsPeerComputeOffload: false",
        "func beginA10ShadowValidation",
        "func recordA10ShadowDecision",
        "Cutover gate: external release process only",
    ],
    "VeilLink/App/AppModel.swift": [
        "let latticeKernel: VeilLatticeKernelBridge",
        "latticeKernel = VeilLatticeKernelBridge()",
        "latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)",
        "latticeKernel.recordComputePlan(self.computeGovernor.plan)",
        "latticeKernel.report()",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        "model.latticeKernel.$snapshot",
        'event: "kernel.integration_state"',
        '"unexpected_diffs": String(snapshot.unexpectedDecisionDiffs)',
    ],
    "VeilLinkTests/VeilLatticeKernelBridgeTests.swift": [
        "testHostProfileKeepsKernelAdvisoryAndNonMutating",
        "testShadowComparisonCountsOnlyUnexpectedDecisionDrift",
    ],
    "docs/A10_INTEGRATION_READINESS.md": [
        "A10_INTEGRATION_READY",
        "0 unexpected decision diffs",
    ],
}

FORBIDDEN = {
    "VeilLink/Health/VeilLatticeKernelBridge.swift": [
        "func activateA10",
        "canMutateTransport: true",
        "canMutateStorage: true",
        "canMutateGameState: true",
        "canReadSecrets: true",
        "allowsCloudScheduling: true",
        "allowsPeerComputeOffload: true",
    ]
}


def fail(message: str):
    print("FAIL:", message)
    raise SystemExit(1)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I6_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    for rel, markers in REQUIRED.items():
        path = root / rel
        if not path.exists():
            fail(f"missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                fail(f"{rel}: missing {marker!r}")
    for rel, markers in FORBIDDEN.items():
        source = (root / rel).read_text(encoding="utf-8")
        for marker in markers:
            if marker in source:
                fail(f"{rel}: forbidden premature authority/cutover path: {marker!r}")

    swift_files = [
        "VeilLink/Health/VeilLatticeKernelBridge.swift",
        "VeilLink/App/AppModel.swift",
        "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift",
        "VeilLinkTests/VeilLatticeKernelBridgeTests.swift",
    ]
    for rel in swift_files:
        p = subprocess.run(["swiftc", "-parse", str(root / rel)], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout)
            print(p.stderr)
            fail(f"swiftc -parse failed: {rel}")
    print("PASS I6 Swift parse")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I6 A10 integration-readiness verification")
    print("STATE: A10_INTEGRATION_READY; active kernel remains veillink.a9.compat.v1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
