from pathlib import Path
import subprocess
import sys

REQUIRED = {
    "VeilLink/Transport/BLEFramer.swift": [
        "func reset(source: UUID)",
        "func resetAll()",
        "reconnect/rekey must not",
    ],
    "VeilLink/Transport/BLELinkSnapshot.swift": [
        "enum BLETransportStage",
        "case phyConnected = \"PHY_CONNECTED\"",
        "case gattReady = \"GATT_READY\"",
        "let transportStage: BLETransportStage",
    ],
    "VeilLink/Transport/BLETransport.swift": [
        "func transportStage(for id: UUID) -> BLETransportStage",
        "private func hasReadyDataChannel(_ id: UUID) -> Bool",
        "private func reconcileConnectionEvent(_ id: UUID)",
        "remoteCharacteristics[id]?.isNotifying == true",
        "peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager)",
        "max(0.15, tuning.interBurstDelay)",
        "蓝牙物理链路已连接，正在发现数据通道",
        "蓝牙数据通道已就绪",
        "assembler.reset(source: id)",
        "assembler.resetAll()",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        '"transport_stage": snapshot.transportStage.rawValue',
        ":secure=\\(secureReady)",
    ],
    "VeilLink/UI/MiniGameViews.swift": [
        "SECURE_SESSION_READY · 对手链路已就绪",
        "GATT_READY · 正在建立安全会话",
        "PHY_CONNECTED · 正在建立数据通道",
    ],
    "VeilLinkTests/BLETransportSafetyTests.swift": [
        "testAssemblerResetDropsPreviousTransportEpochFragments",
    ],
    "VeilLinkTests/BLELinkSnapshotTests.swift": [
        "testTransportStageDistinguishesPhysicalFromGATTReadiness",
        "transportStage: .gattReady",
        "transportStage: .phyConnected",
    ],
}

FORBIDDEN = {
    "VeilLink/Transport/BLETransport.swift": [
        'statusText = "加密蓝牙链路已就绪"',
        'statusText = "已建立蓝牙链路"',
        "remotePeripherals[id]?.state == .connected && remoteCharacteristics[id] != nil",
    ],
    "VeilLink/UI/MiniGameViews.swift": [
        'if snapshot?.isConnected == true { return "蓝牙已连接 · 安全会话恢复中" }',
    ],
}


def fail(message: str):
    print("FAIL:", message)
    raise SystemExit(1)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I3_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()

    for rel, needles in REQUIRED.items():
        p = root / rel
        if not p.exists():
            fail(f"missing {rel}")
        text = p.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in text:
                fail(f"{rel}: missing {needle!r}")

    for rel, needles in FORBIDDEN.items():
        text = (root / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle in text:
                fail(f"{rel}: forbidden pre-I3 path remains: {needle!r}")

    # The central-side resume fallback must no longer be conditional on CoreBluetooth already
    # reporting canSendWriteWithoutResponse=true; the callback remains primary, bounded timer fallback secondary.
    transport = (root / "VeilLink/Transport/BLETransport.swift").read_text(encoding="utf-8")
    old_gate = """if peripheral.canSendWriteWithoutResponse {\n                scheduleCentralDrain(for: id, after: tuning.interBurstDelay)\n            }"""
    if old_gate in transport:
        fail("central TX pump can still become callback-only stranded")

    # Make sure dual-role disconnects now reconcile instead of always killing the secure session.
    if transport.count("reconcileConnectionEvent(id)") < 3:
        fail("role-aware disconnect reconciliation is incomplete")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I3 static verification")
    print("NEXT: XcodeGen + XCTest + unsigned iphoneos build; then two-device BLE backpressure/dual-role/reconnect matrix on iPhone 7 + iPhone 13.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
