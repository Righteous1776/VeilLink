# VeilLink 本地累计迭代 I4

**基线权威：** `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`

I4 继续累计 I1 + I2 + I3；没有重新建立 R1/R2 版本线。包内完整携带 `I3_BASE/`，所以可以从原始 main 一键累计到 I4。

## 一键累计应用

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4.py /path/to/VeilLink
```

行为：

1. fresh `152c3ab...`：自动执行 I1 -> I2 -> I3 -> I4；
2. 已到 I3：只应用 I4；
3. 已到 I4：不重复写入，只运行静态验证；
4. 任何基础 blob 漂移、I3 marker 缺失或替换点不是唯一命中：I4 整层拒绝写入；
5. I4 写入前自动备份到 `.veillink-local-iter/I4-backup/`。

## I4 修复重点

- BLE 被动扫描节点 15 秒过期；断开、未 wanted、无队列的旧 UUID 不再永久留在 `linkSnapshots`；
- A9 只统计 operational BLE：被动扫描节点不再降低健康分；RSSI/最低 link health 只对真正 GATT-ready 的连接生效；
- A9 persistence 从“evaluate 回调次数”改为 **systemUptime 连续非绿秒数**；L2 persistence 阈值改为 30 秒；
- A9 报告明确标记 transport coverage。当前 main 只有 `BLE_ONLY`，不会再暗示已经覆盖 LAN / Relay / Mesh；
- 黑匣子主线程 stall 改为 active-only + 2 秒 resume grace，后台挂起/恢复不再伪造数小时 stall；
- UI hierarchy snapshot 改为交互合并触发，并按设备档位 0.75 / 1.5 秒节流，遍历上限降为 1200 / 700；
- controller appear 不再强制绕过节流；
- DiagnosticLogStore 写盘批量从 64 KB 提到 256 KB，普通 flush 从 0.6 秒改为 1.5 秒，并把磁盘目录统计降到每 8 次 flush / rotation 才全量刷新；
- 黑匣子 A9 事件新增 `persistence_seconds` 与 `transport_coverage`；
- 增加 persistence、stall policy、BLE ghost-node 语义单测。

## 重要边界

当前 GitHub `main` 源树没有 26.9 正式载体中的 LAN Turbo / Internet Relay / Mesh 实现。因此 I4 **没有伪造多传输健康数据**：A9 明确报告 `BLE_ONLY`。等正式载体源码回灌后，应把真实 route-health 接到 `VeilA9TransportCoverage.multiTransport` 以及后续 transport health 输入。

此前账本中“A9 会自动调用 `ble.refresh` / 直接改通信链路”的表述在当前 main 上没有源码证据，I4 已纠正：这里 A9 直接影响的是 Compute Governor 的预算，不直接 mutate BLE。

## 验收边界

当前环境不是 macOS/Xcode。I4 完成的是补丁器、自审、替换点验证和 Linux `swiftc -parse` 验证入口；**没有宣称 XcodeGen、XCTest、iphoneos build 或 iPhone 7 / iPhone 13 真机 burn-in 已通过。**

真实门槛：XcodeGen -> XCTest -> unsigned iphoneos build -> iPhone 7 + iPhone 13 至少 30 分钟 A9/黑匣子 burn-in，并比较 ghost link 数量、persistence_seconds、stall 数量、UI snapshot 数量和诊断自身 CPU/热状态。
