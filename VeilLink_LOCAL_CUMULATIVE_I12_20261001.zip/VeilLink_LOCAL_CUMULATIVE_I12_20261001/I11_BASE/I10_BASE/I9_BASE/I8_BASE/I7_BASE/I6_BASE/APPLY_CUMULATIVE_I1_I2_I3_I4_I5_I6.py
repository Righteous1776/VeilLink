from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    run([sys.executable, HERE / "I5_BASE/APPLY_CUMULATIVE_I1_I2_I3_I4_I5.py", root])
    bridge = root / "VeilLink/Health/VeilLatticeKernelBridge.swift"
    if not bridge.exists() or "A10_INTEGRATION_READY" not in bridge.read_text(encoding="utf-8"):
        run([sys.executable, HERE / "I6_APPLY.py", root])
    run([sys.executable, HERE / "I6_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 -> I4 -> I5 -> I6 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
