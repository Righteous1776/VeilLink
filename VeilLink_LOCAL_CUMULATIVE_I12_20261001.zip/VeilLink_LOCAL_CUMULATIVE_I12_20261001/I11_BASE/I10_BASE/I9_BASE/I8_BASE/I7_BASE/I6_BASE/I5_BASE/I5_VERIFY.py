from pathlib import Path
import re
import subprocess
import sys

REQUIRED = {
    "VeilLink/Core/AppTheme.swift": [
        "enum VeilUILayoutPolicy",
        "minimumTabletTwoPaneWidth: CGFloat = 720",
        "lockUsesHorizontalLayout",
    ],
    "VeilLink/App/VeilLinkApp.swift": [
        "UITableView.appearance().backgroundColor = background",
        "UITableViewCell.appearance().backgroundColor = .clear",
        "UICollectionView.appearance().backgroundColor = background",
        "UITextField.appearance().keyboardAppearance = .dark",
    ],
    "VeilLink/UI/LockScreenView.swift": [
        "VeilUILayoutPolicy.lockUsesHorizontalLayout",
        "ScrollView(.vertical, showsIndicators: false)",
        "private func keypad(keySize: CGFloat, spacing: CGFloat)",
    ],
    "VeilLink/UI/AdaptiveRootView.swift": [
        "VeilUILayoutPolicy.usesTabletTwoPane",
        "let sidebarWidth: CGFloat",
        ".frame(width: sidebarWidth)",
    ],
    "VeilLink/Resources/Info.plist": [
        "<key>UIUserInterfaceStyle</key>",
        "<string>Dark</string>",
        "<key>NSFaceIDUsageDescription</key>",
    ],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        "if currentScreen == normalized",
        "screenStack.append(normalized)",
        'captureUIHierarchy(reason: "navigation", force: false)',
        "enum DeepTelemetryStallPolicy",
    ],
    "VeilLinkTests/UILayoutPolicyTests.swift": [
        "testRegularButNarrowViewportFallsBackToPhone",
        "testLandscapeLockUsesCompactKeypad",
    ],
}

FORBIDDEN = {
    "VeilLink/UI/MiniGameViews.swift": ["VeilAmbientBackground().ignoresSafeArea()"],
    "VeilLink/UI/GameLobbyView.swift": ["VeilAmbientBackground().ignoresSafeArea()"],
    "VeilLink/UI/AdaptiveRootView.swift": [".frame(width: 330)"],
    "VeilLink/UI/LockScreenView.swift": ["GridItem(.fixed(72)"],
    "VeilLink/Diagnostics/DeepTelemetry.swift": [
        'currentScreen = screenStack.last ?? "unknown"\n    }\n\n    func setNavigationScreen',
        'captureUIHierarchy(reason: "navigation", force: true)',
    ],
}

TYPOGRAPHY_FILES = [
    "VeilLink/UI/SettingsView.swift",
    "VeilLink/UI/AdaptiveRootView.swift",
    "VeilLink/UI/MiniGameViews.swift",
    "VeilLink/UI/TacticalGameViews.swift",
    "VeilLink/UI/ConversationViews.swift",
    "VeilLink/UI/NearbyView.swift",
    "VeilLink/UI/GameLobbyView.swift",
]
MICRO_PATTERN = re.compile(r"\.font\(\.system\(size:\s*(5\.3|6\.5|7\.5|7|8\.5|8|9)(?=[,)])")


def fail(message: str):
    print("FAIL:", message)
    raise SystemExit(1)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I5_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()

    for rel, needles in REQUIRED.items():
        p = root / rel
        if not p.exists():
            fail(f"missing {rel}")
        source = p.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in source:
                fail(f"{rel}: missing {needle!r}")

    for rel, needles in FORBIDDEN.items():
        source = (root / rel).read_text(encoding="utf-8")
        for needle in needles:
            if needle in source:
                fail(f"{rel}: forbidden pre-I5 path remains: {needle!r}")

    for rel in TYPOGRAPHY_FILES:
        source = (root / rel).read_text(encoding="utf-8")
        match = MICRO_PATTERN.search(source)
        if match:
            fail(f"{rel}: unreadable fixed micro-font remains: {match.group(0)!r}")

    swift_files = [rel for rel in REQUIRED if rel.endswith(".swift")]
    swift_files += [rel for rel in TYPOGRAPHY_FILES if rel not in swift_files]
    for rel in sorted(set(swift_files)):
        p = subprocess.run(["swiftc", "-parse", str(root / rel)], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout)
            print(p.stderr)
            fail(f"swiftc -parse failed: {rel}")
    print(f"PASS swiftc -parse ({len(set(swift_files))} I5 Swift files)")

    if (root / ".git").exists():
        p = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if p.returncode != 0:
            print(p.stdout, p.stderr)
            fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I5 UI static verification")
    print("NEXT: XcodeGen + XCTest + iPhone 7 portrait/landscape + iPad split-window visual burn-in.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
