from pathlib import Path
import hashlib
import shutil
import sys

BASE_HEAD = "152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f"
BASE_BLOBS_UNCHANGED_BY_I1_I2 = {
    "VeilLink/Transport/BLETransport.swift": "cec390a6223c851df6a4b8a62c7850c4925c7cc6",
    "VeilLink/Transport/BLEFramer.swift": "a17489fb1f9a56916a4f43846359bfb742b493db",
    "VeilLink/Transport/BLELinkSnapshot.swift": "055080631832dff5d2bf68947ad33346ed6f13f9",
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": "50deed16f19fda9d48093423fe2f8f7b26319d32",
    "VeilLinkTests/BLETransportSafetyTests.swift": "1bf6d9148c9440ab025ae4afd475471f684bc4b3",
    "VeilLinkTests/BLELinkSnapshotTests.swift": "f27c546ab5346a893adc699ac7b2e85416e6e51d",
}

I2_MARKERS = {
    "VeilLink/UI/MiniGameViews.swift": [
        "重新发送上一条游戏操作",
        "send(command: .cancelInvite",
        "DispatchQueue.global(qos: .userInitiated).async",
    ],
    "VeilLink/Security/KeychainStore.swift": ["func readData(for key: String) throws -> Data?"],
    "VeilLink/Core/MiniGames.swift": ["case cancelInvite", "cross-device wall clocks are never used"],
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def patch_ble_framer(text: str) -> str:
    old = '''    private func pruneIfNeeded() {
        let now = Date().timeIntervalSinceReferenceDate'''
    new = '''    /// Drops incomplete transport frames for one physical peer. A reconnect/rekey must not
    /// inherit fragments assembled under the previous BLE transport epoch.
    func reset(source: UUID) {
        let keys = partials.keys.filter { $0.source == source }
        keys.forEach { removePartial(forKey: $0) }
    }

    func resetAll() {
        partials.removeAll(keepingCapacity: false)
        partialCountBySource.removeAll(keepingCapacity: false)
        totalBufferedBytes = 0
        nextPruneAt = 0
    }

    private func pruneIfNeeded() {
        let now = Date().timeIntervalSinceReferenceDate'''
    return replace_once(text, old, new, "BLE assembler reconnect reset API")


def patch_link_snapshot(text: str) -> str:
    old = '''enum BLEPeerLinkRole: String, Equatable {
    case central = "CENTRAL"
    case peripheral = "PERIPHERAL"
    case dual = "DUAL"
    case unavailable = "—"
}

struct BLEPeerLinkSnapshot: Identifiable, Equatable {'''
    new = '''enum BLEPeerLinkRole: String, Equatable {
    case central = "CENTRAL"
    case peripheral = "PERIPHERAL"
    case dual = "DUAL"
    case unavailable = "—"
}

enum BLETransportStage: String, Equatable {
    case discovered = "DISCOVERED"
    case phyConnected = "PHY_CONNECTED"
    case gattReady = "GATT_READY"
    case unavailable = "UNAVAILABLE"
}

struct BLEPeerLinkSnapshot: Identifiable, Equatable {'''
    text = replace_once(text, old, new, "BLE transport stage enum")

    old = '''    let maximumPacketSize: Int?
    let role: BLEPeerLinkRole
    let stalledFor: TimeInterval?'''
    new = '''    let maximumPacketSize: Int?
    let role: BLEPeerLinkRole
    let transportStage: BLETransportStage
    let stalledFor: TimeInterval?'''
    text = replace_once(text, old, new, "BLE snapshot transportStage")

    old = '''    var statusTitle: String {
        if isConnected { return "链路已就绪" }
        if isRecovering { return reconnectAttempt > 0 ? "自动重连中" : "等待恢复" }
        return "未连接"
    }'''
    new = '''    var statusTitle: String {
        switch transportStage {
        case .gattReady: return "GATT_READY · 数据通道已就绪"
        case .phyConnected: return "PHY_CONNECTED · 正在建立数据通道"
        case .discovered:
            if isRecovering { return reconnectAttempt > 0 ? "DISCOVERED · 自动重连中" : "DISCOVERED · 等待恢复" }
            return "DISCOVERED"
        case .unavailable: return "未连接"
        }
    }'''
    text = replace_once(text, old, new, "BLE stage-aware status")

    old = r'''    var compactDetail: String {
        var parts: [String] = []
        if let rssi { parts.append("\(rssi) dBm") }'''
    new = r'''    var compactDetail: String {
        var parts: [String] = [transportStage.rawValue]
        if let rssi { parts.append("\(rssi) dBm") }'''
    text = replace_once(text, old, new, "BLE compact detail stage")

    old = r'''- \(shortID) state=\(snapshot.statusTitle) role=\(snapshot.role.rawValue) quality=\(snapshot.quality.rawValue) health=\(snapshot.healthScore) rssi=\(rssi) mtu=\(mtu) pendingPackets=\(snapshot.pendingPackets) pendingBytes=\(snapshot.pendingBytes) controlPending=\(snapshot.controlPendingPackets) reconnectAttempt=\(snapshot.reconnectAttempt) stalled=\(stalled)'''
    new = r'''- \(shortID) stage=\(snapshot.transportStage.rawValue) state=\(snapshot.statusTitle) role=\(snapshot.role.rawValue) quality=\(snapshot.quality.rawValue) health=\(snapshot.healthScore) rssi=\(rssi) mtu=\(mtu) pendingPackets=\(snapshot.pendingPackets) pendingBytes=\(snapshot.pendingBytes) controlPending=\(snapshot.controlPendingPackets) reconnectAttempt=\(snapshot.reconnectAttempt) stalled=\(stalled)'''
    return replace_once(text, old, new, "BLE diagnostics stage")


def patch_ble_transport(text: str) -> str:
    old = '''        peripheralDrainWorkItems.removeAll()
        rssiPollTask?.cancel()
        rssiPollTask = nil

        connectionEvents.drainConnectedIDs().forEach { onDisconnected?($0) }'''
    new = '''        peripheralDrainWorkItems.removeAll()
        rssiPollTask?.cancel()
        rssiPollTask = nil
        assembler.resetAll()

        connectionEvents.drainConnectedIDs().forEach { onDisconnected?($0) }'''
    text = replace_once(text, old, new, "Reset assembler on transport stop")

    old = '''        remoteCharacteristics.removeValue(forKey: id)
        lastQueueProgressAt.removeValue(forKey: id)
    }'''
    new = '''        remoteCharacteristics.removeValue(forKey: id)
        lastQueueProgressAt.removeValue(forKey: id)
        assembler.reset(source: id)
    }'''
    text = replace_once(text, old, new, "Reset assembler on explicit transport teardown")

    old = '''    func linkSnapshot(for id: UUID) -> BLEPeerLinkSnapshot? {
        guard knownLinkIDs().contains(id) else { return nil }
        return makeLinkSnapshot(for: id)
    }

    func diagnosticsReport() -> String {'''
    new = '''    func linkSnapshot(for id: UUID) -> BLEPeerLinkSnapshot? {
        guard knownLinkIDs().contains(id) else { return nil }
        return makeLinkSnapshot(for: id)
    }

    func transportStage(for id: UUID) -> BLETransportStage {
        makeLinkSnapshot(for: id).transportStage
    }

    func diagnosticsReport() -> String {'''
    text = replace_once(text, old, new, "Expose BLE transport stage")

    old = '''        } else {
            centralOutboundQueues[id] = queue
            if peripheral.canSendWriteWithoutResponse {
                scheduleCentralDrain(for: id, after: tuning.interBurstDelay)
            }
        }'''
    new = '''        } else {
            centralOutboundQueues[id] = queue
            // `peripheralIsReady` is the primary CoreBluetooth resume signal. Keep one bounded
            // safety probe as well so a missed callback cannot strand the queue forever.
            let retryDelay = peripheral.canSendWriteWithoutResponse
                ? tuning.interBurstDelay
                : max(0.15, tuning.interBurstDelay)
            scheduleCentralDrain(for: id, after: retryDelay)
        }'''
    text = replace_once(text, old, new, "Central TX pump safety resume")

    old = '''    private func publishConnected(_ id: UUID) {
        let firstConnectionEvent = connectionEvents.markConnected(id)
        connectedPeerCount = connectionEvents.count
        statusText = "加密蓝牙链路已就绪"
        publishLinkSnapshots(force: true)
        if firstConnectionEvent { onConnected?(id) }
    }

    private func publishDisconnected(_ id: UUID) {'''
    new = '''    private func hasReadyDataChannel(_ id: UUID) -> Bool {
        let centralReady = isRunning
            && remotePeripherals[id]?.state == .connected
            && remoteCharacteristics[id]?.isNotifying == true
        let peripheralReady = isRunning && subscribedCentrals[id] != nil
        return centralReady || peripheralReady
    }

    private func reconcileConnectionEvent(_ id: UUID) {
        if hasReadyDataChannel(id) { publishConnected(id) }
        else { publishDisconnected(id) }
    }

    private func publishConnected(_ id: UUID) {
        let firstConnectionEvent = connectionEvents.markConnected(id)
        connectedPeerCount = connectionEvents.count
        statusText = "蓝牙数据通道已就绪"
        publishLinkSnapshots(force: true)
        if firstConnectionEvent { onConnected?(id) }
    }

    private func publishDisconnected(_ id: UUID) {'''
    text = replace_once(text, old, new, "Role-aware connection reconciliation")

    old = '''    private func makeLinkSnapshot(for id: UUID) -> BLEPeerLinkSnapshot {
        let centralReady = isRunning && remotePeripherals[id]?.state == .connected && remoteCharacteristics[id] != nil
        let peripheralReady = isRunning && subscribedCentrals[id] != nil
        let role: BLEPeerLinkRole'''
    new = '''    private func makeLinkSnapshot(for id: UUID) -> BLEPeerLinkSnapshot {
        let physicalCentralConnected = isRunning && remotePeripherals[id]?.state == .connected
        let centralReady = physicalCentralConnected && remoteCharacteristics[id]?.isNotifying == true
        let peripheralReady = isRunning && subscribedCentrals[id] != nil
        let transportStage: BLETransportStage
        if centralReady || peripheralReady { transportStage = .gattReady }
        else if physicalCentralConnected { transportStage = .phyConnected }
        else if knownLinkIDs().contains(id) { transportStage = .discovered }
        else { transportStage = .unavailable }
        let role: BLEPeerLinkRole'''
    text = replace_once(text, old, new, "Compute PHY/GATT transport stage")

    old = '''            maximumPacketSize: packetSizes.max(),
            role: role,
            stalledFor: stalledFor'''
    new = '''            maximumPacketSize: packetSizes.max(),
            role: role,
            transportStage: transportStage,
            stalledFor: stalledFor'''
    text = replace_once(text, old, new, "Snapshot stage initializer")

    old = '''    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        reconnectWorkItems.removeValue(forKey: peripheral.identifier)?.cancel()
        peripheral.delegate = self
        peripheral.discoverServices([Self.serviceUUID])
        peripheral.readRSSI()
        statusText = "已建立蓝牙链路"
    }'''
    new = '''    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        reconnectWorkItems.removeValue(forKey: peripheral.identifier)?.cancel()
        peripheral.delegate = self
        peripheral.discoverServices([Self.serviceUUID])
        peripheral.readRSSI()
        statusText = "蓝牙物理链路已连接，正在发现数据通道"
        publishLinkSnapshots(force: true)
    }'''
    text = replace_once(text, old, new, "PHY_CONNECTED wording")

    old = '''    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        centralDrainWorkItems.removeValue(forKey: peripheral.identifier)?.cancel()
        remoteCharacteristics.removeValue(forKey: peripheral.identifier)
        centralOutboundQueues.removeValue(forKey: peripheral.identifier)
        publishDisconnected(peripheral.identifier)
        statusText = "连接失败，准备重试"
        scheduleReconnect(peripheral)
    }'''
    new = '''    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        let id = peripheral.identifier
        centralDrainWorkItems.removeValue(forKey: id)?.cancel()
        remoteCharacteristics.removeValue(forKey: id)
        centralOutboundQueues.removeValue(forKey: id)
        if peripheralOutboundQueues[id]?.isEmpty != false {
            lastQueueProgressAt.removeValue(forKey: id)
        }
        reconcileConnectionEvent(id)
        if !hasReadyDataChannel(id) {
            assembler.reset(source: id)
            statusText = "连接失败，准备重试"
        } else {
            statusText = "中央角色连接失败，备用数据通道仍可用"
        }
        scheduleReconnect(peripheral)
    }'''
    text = replace_once(text, old, new, "Role-aware didFailToConnect")

    old = '''    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        centralDrainWorkItems.removeValue(forKey: peripheral.identifier)?.cancel()
        remoteCharacteristics.removeValue(forKey: peripheral.identifier)
        centralOutboundQueues.removeValue(forKey: peripheral.identifier)
        publishDisconnected(peripheral.identifier)
        statusText = "连接已断开，等待重连"
        scheduleReconnect(peripheral)
    }'''
    new = '''    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        let id = peripheral.identifier
        centralDrainWorkItems.removeValue(forKey: id)?.cancel()
        remoteCharacteristics.removeValue(forKey: id)
        centralOutboundQueues.removeValue(forKey: id)
        if peripheralOutboundQueues[id]?.isEmpty != false {
            lastQueueProgressAt.removeValue(forKey: id)
        }
        reconcileConnectionEvent(id)
        if !hasReadyDataChannel(id) {
            assembler.reset(source: id)
            statusText = "连接已断开，等待重连"
        } else {
            statusText = "中央角色已断开，备用数据通道仍可用"
        }
        scheduleReconnect(peripheral)
    }'''
    text = replace_once(text, old, new, "Role-aware didDisconnect")

    old = '''        remoteCharacteristics[peripheral.identifier] = characteristic
        peripheral.setNotifyValue(true, for: characteristic)
    }'''
    new = '''        remoteCharacteristics[peripheral.identifier] = characteristic
        statusText = "蓝牙数据通道已发现，正在订阅通知"
        publishLinkSnapshots(force: true)
        peripheral.setNotifyValue(true, for: characteristic)
    }'''
    text = replace_once(text, old, new, "GATT discovery stage")

    old = '''        reconnectAttempts[peripheral.identifier] = 0
        persistWantedConnectionIntent()
        publishConnected(peripheral.identifier)
    }'''
    new = '''        reconnectAttempts[peripheral.identifier] = 0
        persistWantedConnectionIntent()
        reconcileConnectionEvent(peripheral.identifier)
    }'''
    text = replace_once(text, old, new, "Reconcile central GATT ready")

    old = '''        guard characteristic.uuid == Self.dataUUID else { return }
        subscribedCentrals[central.identifier] = central
        publishConnected(central.identifier)
        if let localCharacteristic { drainPeripheralQueue(for: central.identifier, characteristic: localCharacteristic) }
    }'''
    new = '''        guard characteristic.uuid == Self.dataUUID else { return }
        subscribedCentrals[central.identifier] = central
        reconcileConnectionEvent(central.identifier)
        if let localCharacteristic { drainPeripheralQueue(for: central.identifier, characteristic: localCharacteristic) }
    }'''
    text = replace_once(text, old, new, "Reconcile peripheral GATT ready")

    old = '''        subscribedCentrals.removeValue(forKey: central.identifier)
        peripheralOutboundQueues.removeValue(forKey: central.identifier)
        publishDisconnected(central.identifier)
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {'''
    new = '''        let id = central.identifier
        subscribedCentrals.removeValue(forKey: id)
        peripheralOutboundQueues.removeValue(forKey: id)
        if centralOutboundQueues[id]?.isEmpty != false {
            lastQueueProgressAt.removeValue(forKey: id)
        }
        reconcileConnectionEvent(id)
        if !hasReadyDataChannel(id) {
            assembler.reset(source: id)
            statusText = "外围角色已断开，等待数据通道恢复"
        } else {
            statusText = "外围角色已断开，中央数据通道仍可用"
        }
    }

    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
        // Apple calls this after updateValue(...) returned false because its TX queue was full.
        // Resume every subscribed peer with pending data instead of leaving the queue stranded.
        guard isRunning, let characteristic = localCharacteristic else { return }
        for id in Array(peripheralOutboundQueues.keys) where subscribedCentrals[id] != nil {
            drainPeripheralQueue(for: id, characteristic: characteristic)
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {'''
    return replace_once(text, old, new, "Peripheral TX backpressure resume callback")


def patch_runtime_diagnostics(text: str) -> str:
    old = '''                String(snapshot.reconnectAttempt),
                snapshot.queueSummary,
                snapshot.compactDetail'''
    new = '''                String(snapshot.reconnectAttempt),
                snapshot.transportStage.rawValue,
                snapshot.queueSummary,
                snapshot.compactDetail'''
    text = replace_once(text, old, new, "Diagnostics fingerprint stage")

    old = '''                    "connected": String(snapshot.isConnected),
                    "recovering": String(snapshot.isRecovering),
                    "status": snapshot.statusTitle,'''
    new = '''                    "connected": String(snapshot.isConnected),
                    "recovering": String(snapshot.isRecovering),
                    "transport_stage": snapshot.transportStage.rawValue,
                    "status": snapshot.statusTitle,'''
    text = replace_once(text, old, new, "Diagnostics transport_stage metadata")

    old = r'''                            "peers": peers.prefix(32).map {
                                "\($0.transportID.uuidString):\($0.id):\($0.rssi):\(String(describing: $0.trustState))"
                            }.joined(separator: "|")'''
    new = r'''                            "peers": peers.prefix(32).map {
                                let secureReady = model.sessions.hasSecureSession(for: $0.id)
                                return "\($0.transportID.uuidString):\($0.id):\($0.rssi):\(String(describing: $0.trustState)):secure=\(secureReady)"
                            }.joined(separator: "|")'''
    return replace_once(text, old, new, "Diagnostics secure-ready metadata")


def patch_minigame_views(text: str) -> str:
    old = '''    private var secureReady: Bool { sessions.hasSecureSession(for: peerIdentityID) }
    private var linkReady: Bool { snapshot?.isConnected == true && secureReady }

    private var primaryText: String {
        if linkReady { return "对手链路已就绪" }
        if snapshot?.isConnected == true { return "蓝牙已连接 · 安全会话恢复中" }
        if snapshot?.isRecovering == true { return "正在自动恢复对手链路" }
        if transportID != nil { return "对手暂时离线" }
        return "等待发现对手设备"
    }'''
    new = '''    private var secureReady: Bool { sessions.hasSecureSession(for: peerIdentityID) }
    private var linkReady: Bool { snapshot?.transportStage == .gattReady && secureReady }

    private var primaryText: String {
        if linkReady { return "SECURE_SESSION_READY · 对手链路已就绪" }
        if snapshot?.transportStage == .gattReady { return "GATT_READY · 正在建立安全会话" }
        if snapshot?.transportStage == .phyConnected { return "PHY_CONNECTED · 正在建立数据通道" }
        if snapshot?.isRecovering == true { return "正在自动恢复对手链路" }
        if transportID != nil { return "DISCOVERED · 等待连接对手" }
        return "等待发现对手设备"
    }'''
    return replace_once(text, old, new, "Game link true readiness UI")


def patch_ble_transport_tests(text: str) -> str:
    insert = '''
    func testAssemblerResetDropsPreviousTransportEpochFragments() {
        let source = UUID()
        let firstMessage = Data(repeating: 0x51, count: 120)
        let secondMessage = Data(repeating: 0x61, count: 120)
        let first = BLEFragment.split(firstMessage, maximumPacketSize: 64)
        let second = BLEFragment.split(secondMessage, maximumPacketSize: 64)
        let assembler = BLEFragmentAssembler(
            maxConcurrentMessages: 4,
            maxConcurrentMessagesPerSource: 2,
            maxFragmentsPerMessage: 16,
            maxAssembledBytes: 256,
            maxPacketBytes: 64,
            maxTotalBufferedBytes: 512
        )

        XCTAssertNil(assembler.ingest(source: source, packet: first[0].encoded))
        assembler.reset(source: source)
        var oldRecovered: Data?
        for fragment in first.dropFirst() {
            oldRecovered = assembler.ingest(source: source, packet: fragment.encoded) ?? oldRecovered
        }
        XCTAssertNil(oldRecovered)

        var newRecovered: Data?
        for fragment in second {
            newRecovered = assembler.ingest(source: source, packet: fragment.encoded) ?? newRecovered
        }
        XCTAssertEqual(newRecovered, secondMessage)
    }
'''
    old = '''    func testConnectionEventGateDeduplicatesCallbacksAndAllowsReconnect() {'''
    new = insert + '''
    func testConnectionEventGateDeduplicatesCallbacksAndAllowsReconnect() {'''
    return replace_once(text, old, new, "BLE assembler epoch test")


def patch_link_snapshot_tests(text: str) -> str:
    text = replace_once(
        text,
        '''controlPendingPackets: 0, maximumPacketSize: 185, role: .central, stalledFor: nil''',
        '''controlPendingPackets: 0, maximumPacketSize: 185, role: .central, transportStage: .gattReady, stalledFor: nil''',
        "Snapshot strong initializer"
    )
    text = replace_once(
        text,
        '''controlPendingPackets: 12, maximumPacketSize: 20, role: .unavailable, stalledFor: 8''',
        '''controlPendingPackets: 12, maximumPacketSize: 20, role: .unavailable, transportStage: .discovered, stalledFor: 8''',
        "Snapshot weak initializer"
    )
    text = replace_once(
        text,
        '''controlPendingPackets: 4, maximumPacketSize: 185, role: .dual, stalledFor: nil''',
        '''controlPendingPackets: 4, maximumPacketSize: 185, role: .dual, transportStage: .gattReady, stalledFor: nil''',
        "Snapshot queue initializer"
    )
    text = replace_once(text, 'XCTAssertEqual(strong.statusTitle, "链路已就绪")', 'XCTAssertTrue(strong.statusTitle.contains("GATT_READY"))', "Snapshot strong stage assertion")
    text = replace_once(text, 'XCTAssertEqual(weak.statusTitle, "自动重连中")', 'XCTAssertTrue(weak.statusTitle.contains("DISCOVERED"))', "Snapshot weak stage assertion")
    old = '''    func testQueueSummaryCallsOutControlTraffic() {'''
    new = '''    func testTransportStageDistinguishesPhysicalFromGATTReadiness() {
        let snapshot = BLEPeerLinkSnapshot(
            id: UUID(), isConnected: false, isWanted: true, reconnectAttempt: 0,
            rssi: -58, quality: .strong, pendingPackets: 0, pendingBytes: 0,
            controlPendingPackets: 0, maximumPacketSize: 185, role: .unavailable,
            transportStage: .phyConnected, stalledFor: nil
        )
        XCTAssertEqual(snapshot.transportStage, .phyConnected)
        XCTAssertTrue(snapshot.statusTitle.contains("PHY_CONNECTED"))
        XCTAssertFalse(snapshot.isConnected)
    }

    func testQueueSummaryCallsOutControlTraffic() {'''
    return replace_once(text, old, new, "BLE transport stage unit test")


PATCHERS = {
    "VeilLink/Transport/BLEFramer.swift": patch_ble_framer,
    "VeilLink/Transport/BLELinkSnapshot.swift": patch_link_snapshot,
    "VeilLink/Transport/BLETransport.swift": patch_ble_transport,
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": patch_runtime_diagnostics,
    "VeilLink/UI/MiniGameViews.swift": patch_minigame_views,
    "VeilLinkTests/BLETransportSafetyTests.swift": patch_ble_transport_tests,
    "VeilLinkTests/BLELinkSnapshotTests.swift": patch_link_snapshot_tests,
}


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I3_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    if not (root / "VeilLink").is_dir():
        raise RuntimeError(f"Not a VeilLink repository root: {root}")

    # I3 must be layered on I2. Validate prior semantic gates first.
    for rel, markers in I2_MARKERS.items():
        p = root / rel
        if not p.exists(): raise RuntimeError(f"Missing I2 prerequisite file: {rel}")
        text = p.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in text:
                raise RuntimeError(f"I2 prerequisite missing in {rel}: {marker!r}")

    # Files untouched by I1/I2 must still be exactly the audited base revision.
    for rel, expected in BASE_BLOBS_UNCHANGED_BY_I1_I2.items():
        p = root / rel
        if not p.exists(): raise RuntimeError(f"Missing source file: {rel}")
        actual = git_blob_sha(p.read_bytes())
        if actual != expected:
            raise RuntimeError(f"{rel}: source drift; expected blob {expected}, got {actual}")

    originals = {}
    patched = {}
    # Validate all replacements in memory before any write.
    for rel, patcher in PATCHERS.items():
        p = root / rel
        if not p.exists(): raise RuntimeError(f"Missing source file: {rel}")
        original = p.read_text(encoding="utf-8")
        originals[rel] = original
        patched[rel] = patcher(original)

    backup = root / ".veillink-local-iter/I3-backup"
    backup.mkdir(parents=True, exist_ok=True)
    for rel, original in originals.items():
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(original, encoding="utf-8")

    for rel, value in patched.items():
        (root / rel).write_text(value, encoding="utf-8")
        print("PATCHED", rel)

    print("I3 APPLIED")
    print("Backup:", backup)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
