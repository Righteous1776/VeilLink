# VeilLink 本地累计迭代 I5

**事实源**：GitHub `Righteous1776/VeilLink` `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`。

这是累计包，不是新的 R1/R2：`I1 → I2 → I3 → I4 → I5`。直接运行：

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5.py /path/to/VeilLink
```

应用器会先执行内置 I4 累计链，再应用 I5；若源码已经到 I5，则只验证不重复修改。每层仍保留自己的防漂移/标记校验。

## I5 解决什么

1. **iPhone 7 / iOS 15 safe-area 回归**：清掉 Game Hub、棋谱回放、规则页剩余的 `VeilAmbientBackground().ignoresSafeArea()` 危险路径。
2. **横屏锁屏溢出**：锁屏不再固定 72pt × 4 行键盘；横屏切换左右布局、50pt 键位，并保留滚动兜底。
3. **iPad / Stage Manager / Split View 错位**：`.regular` 不再自动等价于 330pt 双栏；视口不足 720pt 时回退 PhoneLayout，侧栏宽度限制在 250–330pt。
4. **黑夜/白天混搭**：26.9 明确保持黑金深色正式主题；Info.plist 与 UIKit Form/List/Sheet/键盘统一 Dark，防止系统 Sheet 突然白块。
5. **微型字体**：选定主 UI 文件中的 5.3–9pt 固定字体统一抬到 10pt；0.6/0.62/0.68 的极端压缩底线抬到 0.78。
6. **黑匣子页面标签滞后**：旧页面迟到的 `onDisappear` 不再把 `currentScreen` 从新页面倒退回旧页面；导航事件同步 screen stack。

## 为什么没有直接开放浅色主题

当前聊天/游戏层仍有大量为黑金视觉设计的 `Color.white/black` 材质细节。现在暴露 Light 开关会把“偶发白块”变成稳定的混色 UI。I5 先闭合正式 Dark 主题；真正 Light 应作为独立主题工程逐文件语义化，不在稳定性修复里硬塞。

## 验证

```bash
python3 I5_VERIFY.py /path/to/VeilLink
```

这里能完成的是静态/语法验收。仍需 macOS/Xcode 执行 XcodeGen + XCTest + iphoneos build，并在 iPhone 7 真机测试：竖屏锁屏、横屏锁屏、Game Hub、规则/回放页；iPad 需测试全屏与窄 Split View。
