from pathlib import Path
import json
import subprocess
import sys

REQUIRED = {
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        'static let chipName = "A10 Ultra Ω"',
        'static let architecture = "OMEGA 96"',
        'static let architectureVersion = "V0.2"',
        'static let releaseStatus = "SHADOW_ACCELERATED"',
        'static let productionCutover = "DENIED"',
        'static let nativeIOSARM64Available = false',
        'case stage0 = "STAGE_0_A9_PRIMARY_ULTRA_SHADOW"',
        'case d4 = "D4_CRITICAL_FALSE_NEGATIVE"',
        'private enum A10UltraOmegaCompatibilityNormalizer',
        'private enum A10UltraOmegaDecisionCore',
        'final class A10UltraOmegaShadowCoordinator',
        'PRODUCTION_CUTOVER: DENIED',
    ],
    "VeilLink/App/AppModel.swift": [
        "let a10Ultra: A10UltraOmegaShadowCoordinator",
        "a10Ultra = A10UltraOmegaShadowCoordinator()",
        "let ultraSample = a10Ultra.makeSharedSample",
        "a10Ultra.recordA9Primary",
        "a10Ultra.evaluateA10UltraShadow(sample: ultraSample)",
        "a10Ultra.report()",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        "model.a10Ultra.$lastComparison",
        'event: "a10_ultra.shadow_sample"',
        '"sample_id": record.sampleID',
        '"signal_digest": record.signalDigest',
        '"divergence_class": record.divergence.rawValue',
        '"a9_latency_us"',
        '"ultra_latency_us"',
        '"guardian_status"',
        '"production_cutover": "DENIED"',
    ],
    "VeilLinkTests/A10UltraOmegaShadowTests.swift": [
        "testReleaseIdentityAndAuthorityWallAreLocked",
        "testSharedSampleHasEpochDigestAndRawInput",
        "testStage0NeverPromotesUltra",
    ],
    "docs/A10UltraOmega/VEILLINK_A9_TO_A10_ULTRA_CUTOVER_V1.md": [
        "A10 Ultra Ω",
        "A9 PRIMARY / A10 Ultra Ω SHADOW",
        "PRODUCTION_CUTOVER = DENIED",
    ],
}

FORBIDDEN = {
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        "func activateA10Ultra",
        "func promoteToStage1",
        'static let productionCutover = "ALLOWED"',
        "transportMutationAuthority = 1",
        "storageMutationAuthority = 1",
        "gameMutationAuthority = 1",
        "agentMutationAuthority = 1",
    ]
}

def fail(msg):
    print("FAIL:", msg)
    raise SystemExit(1)

def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I7_VERIFY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    for rel, markers in REQUIRED.items():
        p = root / rel
        if not p.exists(): fail(f"missing {rel}")
        s = p.read_text(encoding="utf-8")
        for m in markers:
            if m not in s: fail(f"{rel}: missing {m!r}")
    for rel, markers in FORBIDDEN.items():
        s = (root / rel).read_text(encoding="utf-8")
        for m in markers:
            if m in s: fail(f"{rel}: forbidden premature cutover/mutation path {m!r}")

    for rel in [
        "VeilLink/Health/A10UltraOmegaShadow.swift",
        "VeilLink/Health/VeilLatticeKernelBridge.swift",
        "VeilLink/App/AppModel.swift",
        "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift",
        "VeilLinkTests/A10UltraOmegaShadowTests.swift",
    ]:
        q = subprocess.run(["swiftc", "-parse", str(root / rel)], text=True, capture_output=True)
        if q.returncode:
            print(q.stdout); print(q.stderr); fail(f"swiftc -parse failed: {rel}")
    print("PASS I7 Swift parse")

    contract = json.loads((root / "docs/A10UltraOmega/OMEGA96_RELEASE_IDENTITY_V0_2.json").read_text())
    if contract.get("component_id") != "A10-ULTRA-OMEGA-96": fail("release identity component mismatch")
    if contract.get("status") != "SHADOW_ACCELERATED": fail("release state mismatch")
    if not str(contract.get("production_cutover", "")).startswith("DENY"): fail("release cutover is not denied")
    for key in ["transport_mutation_authority","storage_mutation_authority","game_mutation_authority","agent_mutation_authority"]:
        if contract.get(key) != 0: fail(f"authority wall broken: {key}")
    print("PASS A10 Ultra Ω release identity / authority wall")

    if (root / ".git").exists():
        q = subprocess.run(["git", "-C", str(root), "diff", "--check"], text=True, capture_output=True)
        if q.returncode:
            print(q.stdout, q.stderr); fail("git diff --check failed")
        print("PASS git diff --check")

    print("PASS I7 A9 PRIMARY + A10 Ultra Ω SHADOW verification")
    print("PRODUCTION_CUTOVER = DENIED")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
