from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent

def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)

def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    run([sys.executable, HERE / "I6_BASE/APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6.py", root])
    shadow = root / "VeilLink/Health/A10UltraOmegaShadow.swift"
    if not shadow.exists() or 'static let chipName = "A10 Ultra Ω"' not in shadow.read_text(encoding="utf-8"):
        run([sys.executable, HERE / "I7_APPLY.py", root])
    run([sys.executable, HERE / "I7_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 -> I4 -> I5 -> I6 -> I7 READY")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
