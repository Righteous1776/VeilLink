# VeilLink Local Cumulative I7 — A10 Ultra Ω loaded in Shadow Stage 0

I7 extends I1–I6. It does **not** replace A9.

Current runtime contract:

- **A9 Health Lattice / A9 Compute Governor = PRIMARY**
- **A10 Ultra Ω = SHADOW_ACCELERATOR**
- Execution architecture: **OMEGA 96 V0.2**
- Release state: **SHADOW_ACCELERATED**
- `PRODUCTION_CUTOVER = DENIED`
- `A9_RUNTIME_REMOVAL = DENIED`

## What “loaded” means in I7

The uploaded A10 Ultra Ω release was integrity-checked with its own release guard. Its contracts/profiles are copied under `docs/A10UltraOmega/` and the exact source ZIP is preserved under `A10_ULTRA_SOURCE_EVIDENCE/`.

The supplied native `.so` is **not iOS-loadable** (CPython 3.13 x86_64 Linux, `-march=native`), so I7 does not place it in the app bundle. Instead, VeilLink gets an independent Swift reference Shadow Runner implementing the A10 Ultra Ω A9-compat decision semantics directly from raw host signals. This lets Stage 0 begin on iOS without pretending the Linux native backend is running.

The Host Adapter was checked against the supplied OMEGA native Zero-Copy Frame engine with **250,000 randomized cases / 0 mismatch**.

## Apply

From an original/current compatible VeilLink repo:

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7.py /path/to/VeilLink
```

Or, if I6 is already applied:

```bash
python3 I7_APPLY.py /path/to/VeilLink
python3 I7_VERIFY.py /path/to/VeilLink
```

I7 is idempotent: if the A10 Ultra Ω Shadow layer is already present, it verifies instead of duplicating it.

## Evidence boundary

This package has local/static parser and differential evidence. It does not claim Xcode/XCTest/iPhoneOS or real-device Cutover gates have passed.
