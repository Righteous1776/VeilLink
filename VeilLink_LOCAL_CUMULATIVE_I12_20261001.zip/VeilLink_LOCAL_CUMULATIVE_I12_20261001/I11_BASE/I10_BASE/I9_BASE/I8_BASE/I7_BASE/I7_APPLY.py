from pathlib import Path
import shutil
import sys

I6_REQUIRED = {
    "VeilLink/Health/VeilLatticeKernelBridge.swift": ["A10_INTEGRATION_READY", "protocol VeilLatticeKernelRuntimeAdapter"],
    "VeilLink/App/AppModel.swift": ["let latticeKernel: VeilLatticeKernelBridge", "latticeKernel.recordA9Compatibility"],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": ["kernel.integration_state"],
}

I7_MARKERS = {
    "VeilLink/Health/A10UltraOmegaShadow.swift": [
        'static let chipName = "A10 Ultra Ω"',
        'static let architecture = "OMEGA 96"',
        'static let releaseStatus = "SHADOW_ACCELERATED"',
        'static let productionCutover = "DENIED"',
        'case d4 = "D4_CRITICAL_FALSE_NEGATIVE"',
        'final class A10UltraOmegaShadowCoordinator',
        'private enum A10UltraOmegaCompatibilityNormalizer',
        'private enum A10UltraOmegaDecisionCore',
        'A10UltraOmegaRelease.nativeIOSARM64Available',
    ],
    "VeilLink/App/AppModel.swift": [
        "let a10Ultra: A10UltraOmegaShadowCoordinator",
        "a10Ultra = A10UltraOmegaShadowCoordinator()",
        "a10Ultra.makeSharedSample",
        "a10Ultra.recordA9Primary",
        "a10Ultra.evaluateA10UltraShadow(sample: ultraSample)",
        "a10Ultra.report()",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "a10_ultra.shadow_sample"',
        '"divergence_class": record.divergence.rawValue',
        '"production_cutover": "DENIED"',
    ],
    "VeilLinkTests/A10UltraOmegaShadowTests.swift": [
        "testReleaseIdentityAndAuthorityWallAreLocked",
        "testSharedSampleHasEpochDigestAndRawInput",
        "testStage0NeverPromotesUltra",
    ],
    "docs/A10UltraOmega/VEILLINK_A9_TO_A10_ULTRA_CUTOVER_V1.md": [
        "A10 Ultra Ω",
        "A9 PRIMARY / A10 Ultra Ω SHADOW",
        "PRODUCTION_CUTOVER = DENIED",
    ],
}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_app_model(text: str) -> str:
    text = replace_once(
        text,
        "    let computeGovernor: VeilA9ComputeGovernor\n    let latticeKernel: VeilLatticeKernelBridge\n    let agentControls: AgentControlCenterSettings\n",
        "    let computeGovernor: VeilA9ComputeGovernor\n    let latticeKernel: VeilLatticeKernelBridge\n    let a10Ultra: A10UltraOmegaShadowCoordinator\n    let agentControls: AgentControlCenterSettings\n",
        "A10 Ultra property",
    )
    text = replace_once(
        text,
        "        computeGovernor = VeilA9ComputeGovernor(profile: agentProfile)\n        latticeKernel = VeilLatticeKernelBridge()\n        agentControls = AgentControlCenterSettings()\n",
        "        computeGovernor = VeilA9ComputeGovernor(profile: agentProfile)\n        latticeKernel = VeilLatticeKernelBridge()\n        a10Ultra = A10UltraOmegaShadowCoordinator()\n        agentControls = AgentControlCenterSettings()\n",
        "A10 Ultra initialization",
    )
    old = '''        a9Health.evaluate(input)
        latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)'''
    new = '''        // I7 Stage 0: create one raw-host sample before either decision rail consumes it.
        // A9 stays production-authoritative. A10 Ultra Ω receives the same raw VeilA9Input copy
        // through its Host Adapter and never consumes an A9 Decision as input.
        let ultraContext = A10UltraOmegaHostContext(
            foregroundActive: computeGovernor.foregroundActive,
            computeMode: computeGovernor.plan.mode.rawValue,
            totalComputeUnits: computeGovernor.plan.totalComputeUnits,
            transportReserveUnits: computeGovernor.plan.transportReserveUnits,
            systemAvailable: true,
            gameRuntimeState: "HOST_MANAGED"
        )
        let ultraSample = a10Ultra.makeSharedSample(input: input, hostContext: ultraContext)
        let a9Timing = A10UltraOmegaShadowCoordinator.timingStart()
        a9Health.evaluate(input)
        // Ensure the baseline budget recorded for this exact sample is current. The existing
        // Combine observer may recompute the same plan again; this explicit update is idempotent.
        computeGovernor.update(decision: a9Health.decision)
        latticeKernel.recordComputePlan(computeGovernor.plan)
        let a9Elapsed = A10UltraOmegaShadowCoordinator.timingElapsed(from: a9Timing)
        latticeKernel.recordA9Compatibility(input: input, decision: a9Health.decision)
        a10Ultra.recordA9Primary(
            sample: ultraSample,
            decision: a9Health.decision,
            budget: computeGovernor.plan,
            latencyNanos: a9Elapsed.wall,
            cpuNanos: a9Elapsed.cpu
        )
        a10Ultra.evaluateA10UltraShadow(sample: ultraSample)'''
    text = replace_once(text, old, new, "dual-rail raw sample flow")
    text = replace_once(
        text,
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report() + "\\n\\n" + latticeKernel.report() + "\\n\\n" + computeGovernor.report()
    }''',
        '''    func a9DiagnosticsReport() -> String {
        a9Health.report()
            + "\\n\\n" + latticeKernel.report()
            + "\\n\\n" + a10Ultra.report()
            + "\\n\\n" + computeGovernor.report()
    }''',
        "A10 Ultra diagnostics report",
    )
    return text


def patch_runtime_diagnostics(text: str) -> str:
    anchor = "\n        model.maleCNS.$state\n"
    if text.count(anchor) != 1:
        raise RuntimeError(f"A10 telemetry insertion: expected 1 anchor, found {text.count(anchor)}")
    insertion = r'''
        model.a10Ultra.$lastComparison
            .compactMap { $0 }
            .sink { record in
                Task { @MainActor in
                    self.store.log(
                        record.divergence == .d4 || record.divergence == .d5 ? .warning : .debug,
                        .a9,
                        event: "a10_ultra.shadow_sample",
                        screen: DeepTelemetry.shared.currentScreen,
                        metadata: [
                            "chip": A10UltraOmegaRelease.chipName,
                            "architecture": "\(A10UltraOmegaRelease.architecture) \(A10UltraOmegaRelease.architectureVersion)",
                            "sample_id": record.sampleID,
                            "epoch": String(record.epoch),
                            "timestamp": ISO8601DateFormatter().string(from: record.timestamp),
                            "source_domain": record.sourceDomains.joined(separator: ","),
                            "signal_digest": record.signalDigest,
                            "a9_light": record.a9.light,
                            "a9_level": String(record.a9.level),
                            "a9_risk_bp": String(record.a9.riskBasisPoints),
                            "a9_budget": record.a9Budget.mode,
                            "ultra_light": record.ultra?.light ?? "failure",
                            "ultra_level": record.ultra.map { String($0.level) } ?? "failure",
                            "ultra_risk_bp": record.ultra.map { String($0.riskBasisPoints) } ?? "failure",
                            "ultra_budget": record.ultraBudget?.mode ?? "failure",
                            "decision_match": String(record.decisionMatch),
                            "divergence_class": record.divergence.rawValue,
                            "a9_latency_us": String(record.a9LatencyNanos / 1_000),
                            "ultra_latency_us": String(record.ultraLatencyNanos / 1_000),
                            "a9_cpu_us": String(record.a9CPUNanos / 1_000),
                            "ultra_cpu_us": String(record.ultraCPUNanos / 1_000),
                            "ultra_physical_slot_count": String(record.ultraPhysicalSlotCount),
                            "rss_bytes": String(record.rssBytes),
                            "thermal_state": String(record.thermalState),
                            "battery_permille": String(record.batteryPermille),
                            "energy_proxy": String(record.energyProxy),
                            "ble_state": record.bleState,
                            "queue_depth": String(record.queueDepth),
                            "dropped_event_count": String(record.droppedEventCount),
                            "ultra_restart_count": String(record.ultraRestartCount),
                            "fallback_event": String(record.fallbackEvent),
                            "guardian_status": record.guardianStatus,
                            "rage_status": record.rageStatus,
                            "vault_status": record.vaultStatus,
                            "runtime_backend": record.runtimeBackend,
                            "native_ios_arm64": String(record.nativeIOSARM64Available),
                            "production_cutover": "DENIED"
                        ]
                    )
                }
            }
            .store(in: &cancellables)

        model.a10Ultra.$state
            .removeDuplicates()
            .sink { state in
                Task { @MainActor in
                    self.store.log(
                        state.d4Count > 0 || state.d5Count > 0 ? .warning : .info,
                        .a9,
                        event: "a10_ultra.shadow_state",
                        screen: DeepTelemetry.shared.currentScreen,
                        metadata: [
                            "cutover_stage": state.cutoverStage.rawValue,
                            "test_phase": state.testPhase.rawValue,
                            "valid_samples": String(state.validSharedSamples),
                            "d0": String(state.exactMatches),
                            "d1": String(state.d1Count),
                            "d2": String(state.d2Count),
                            "d3": String(state.d3Count),
                            "d4": String(state.d4Count),
                            "d5": String(state.d5Count),
                            "dropped": String(state.droppedEventCount),
                            "fallbacks": String(state.fallbackEventCount),
                            "production_cutover": "DENIED"
                        ]
                    )
                }
            }
            .store(in: &cancellables)
'''
    return text.replace(anchor, insertion + anchor, 1)


def copy_payload(here: Path, root: Path) -> None:
    mapping = {
        here / "Payload/VeilLink/Health/A10UltraOmegaShadow.swift": root / "VeilLink/Health/A10UltraOmegaShadow.swift",
        here / "Payload/VeilLinkTests/A10UltraOmegaShadowTests.swift": root / "VeilLinkTests/A10UltraOmegaShadowTests.swift",
    }
    for src, dst in mapping.items():
        if not src.exists():
            raise RuntimeError(f"missing I7 payload: {src}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    src_docs = here / "Payload/docs/A10UltraOmega"
    dst_docs = root / "docs/A10UltraOmega"
    dst_docs.mkdir(parents=True, exist_ok=True)
    for src in src_docs.iterdir():
        if src.is_file():
            shutil.copy2(src, dst_docs / src.name)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 I7_APPLY.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    require_markers(root, I6_REQUIRED, "I6 prerequisite")

    shadow = root / "VeilLink/Health/A10UltraOmegaShadow.swift"
    if shadow.exists() and 'static let chipName = "A10 Ultra Ω"' in shadow.read_text(encoding="utf-8"):
        require_markers(root, I7_MARKERS, "existing I7")
        print("I7 already present; no duplicate mutation performed")
        return 0

    backup = root / ".veillink-local-iter/I7-backup"
    backup.mkdir(parents=True, exist_ok=True)
    for rel in ["VeilLink/App/AppModel.swift", "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"]:
        src = root / rel
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    app = root / "VeilLink/App/AppModel.swift"
    app.write_text(patch_app_model(app.read_text(encoding="utf-8")), encoding="utf-8")
    diag = root / "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"
    diag.write_text(patch_runtime_diagnostics(diag.read_text(encoding="utf-8")), encoding="utf-8")
    copy_payload(here, root)
    require_markers(root, I7_MARKERS, "I7 post-apply")
    print("I7 A9 PRIMARY + A10 Ultra Ω SHADOW loaded")
    print("PRODUCTION_CUTOVER = DENIED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
