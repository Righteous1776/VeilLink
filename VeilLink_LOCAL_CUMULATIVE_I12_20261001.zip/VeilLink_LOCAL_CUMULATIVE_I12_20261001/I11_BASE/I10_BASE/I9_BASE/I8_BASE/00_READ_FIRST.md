# VeilLink 本地累计迭代 I8

## 当前状态

I8 在 I7 的 **A9 PRIMARY + A10 Ultra Ω SHADOW_ACCELERATOR** 基础上增加手动 Kernel Runtime Selector，用于收集可以直接比较的三组黑匣子数据。

默认仍为：

`A9_PLUS_A10_ULTRA_SHADOW`

并继续满足：

`PRODUCTION_CUTOVER = DENIED`

## 三种模式

### 1. A9_ONLY
只运行 A9 健康裁决与 Compute Governor。A10 Ultra Ω Shadow 不运行。

用途：得到没有 A10 Shadow 开销的真实基线。

### 2. A9_PLUS_A10_ULTRA_SHADOW
A9 与 A10 Ultra Ω 对同一原始宿主 Sample 双轨计算；A9 仍是生产主控。

用途：测 D0-D5 一致性以及双轨本身带来的 CPU/RSS/thermal/battery 额外成本。

### 3. A10_ULTRA_ONLY_LAB
只运行 A10 Ultra Ω 的健康裁决路径；A9 不进行本轮 health decision 计算。

为了遵守 Cutover V1.0，这不是生产 A10 Primary：宿主会冻结进入 LAB 前最后一份已提交 A9 安全 Compute Plan，A10 仍然 `mutation_authority=0`。进入 LAB 后 A9 Compute Governor 不会因 focus / foreground 等变化重新计算。

LAB 不跨进程保存。App 重启或 Ultra 内部失败时自动进入 `A9_ONLY`。

## 黑匣子

I8 用统一 `kernel.runtime_sample` 取代 I7 两条重复的逐样本 Shadow 日志。每条样本包含：

- kernel_mode / mode_epoch / mode_session_id / mode_sample_ordinal
- production_authority / fallback_policy / a9_enabled / ultra_enabled / a9_plan_frozen
- sample_id / epoch / timestamp / source_domain / signal_digest
- A9 / Ultra light, level, risk, budget（未运行的一路明确写 disabled）
- decision_match / divergence_class
- A9 / Ultra latency 与 CPU time
- Ultra physical slot count
- RSS / thermal / battery proxy / BLE state / queue depth
- dropped event / restart / fallback
- Guardian / RAGE / Vault status
- device/render profile、foreground、compute focus

因此黑匣子本身就知道“这条数据是在什么模式、什么设备/负载环境下产生的”。

## 应用

从原始受支持 main 一路累计到 I8：

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8.py /path/to/VeilLink
```

已经在 I7：

```bash
python3 I8_APPLY.py /path/to/VeilLink
python3 I8_VERIFY.py /path/to/VeilLink
```

补丁器会备份 I8 修改的原文件到 `.veillink-local-iter/I8-backup/`。

## 仍需 Apple 环境验证

本包做的是源码/ABI/静态自审，不冒充 Xcode 真机构建。需要后续在 Apple 工具链运行 XcodeGen、XCTest、iphoneos build，并在 iPhone 7 / iPhone 13 上分别采集三种模式的长时间黑匣子数据。
