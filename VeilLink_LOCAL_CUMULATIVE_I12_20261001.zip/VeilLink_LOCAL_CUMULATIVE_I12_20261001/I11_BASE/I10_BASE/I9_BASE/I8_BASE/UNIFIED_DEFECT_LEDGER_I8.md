# VeilLink Unified Defect / Migration Ledger — I8

## Runtime experimentation state

**CURRENT:** I8 Kernel Runtime Selector

**A9 removal:** DENIED  
**A10 Ultra Ω production cutover:** DENIED  
**Default:** A9 PRIMARY + A10 Ultra Ω SHADOW_ACCELERATOR

## I8 resolved / added

### KERNEL_MODE_COMPARISON_MISSING — RESOLVED
Previously VeilLink could only gather the Dual Shadow environment. I8 adds three explicitly tagged environments: `A9_ONLY`, `A9_PLUS_A10_ULTRA_SHADOW`, and `A10_ULTRA_ONLY_LAB`.

### BLACKBOX_ENVIRONMENT_AMBIGUOUS — RESOLVED
Every runtime sample now records mode epoch/session/ordinal, authority, enabled rails, fallback policy, device/render profile, foreground/focus, and A9 plan freeze state.

### SHADOW_TELEMETRY_DUPLICATION — RESOLVED
I7 emitted both per-sample comparison and per-sample shadow-state events. I8 supersedes them with one `kernel.runtime_sample` event, reducing diagnostics observer effect while retaining required evidence.

### A10_ONLY_NOT_ACTUALLY_ISOLATED — RESOLVED BY LAB CONTRACT
A10-only LAB disables A9 health evaluation and freezes the last committed A9 compute plan. The A9 governor no longer recomputes on focus/foreground changes until LAB exits. This isolates per-sample A9 compute overhead without granting Ultra production mutation authority.

### LAB_RESTART_RECOVERY — RESOLVED
A10-only LAB is intentionally ephemeral. A persisted one-bit sentinel causes the next process launch to enter A9_ONLY and record `LAB_MODE_RESTART_FALLBACK` rather than silently resuming the experiment.

### ULTRA_FAILURE_RECOVERY — GUARDED
The isolated Ultra runner has a throwable backend contract. An internal Ultra failure records a fallback event, unfreezes the A9 plan, changes runtime mode to A9_ONLY and schedules A9 re-evaluation.

## Cutover interpretation

Data from the three modes can now answer separate questions:

- **A9_ONLY vs DUAL:** real Shadow overhead.
- **A9_ONLY vs A10_ONLY_LAB:** A9 vs Ultra evaluation cost/stability with the inactive rail removed.
- **DUAL:** safety equivalence and D0-D5 evidence.

A10_ONLY_LAB is **not** Stage 1 `PRIMARY_CANARY`; its production authority is `HOST_FROZEN_BASELINE`, mutation authority remains zero, and it cannot be cited as proof that production Cutover has already occurred.

## Remaining gates

The original V1.0 hard gates remain unchanged: no D4, unexplained D3 must be zero, long-run/soak and fault injection must pass, native iOS ARM64 OMEGA backend remains unavailable in the supplied V0.2 binary, and A9 must remain until staged Cutover is separately authorized.
