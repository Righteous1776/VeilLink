from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def run(args):
    print("+", " ".join(map(str, args)))
    subprocess.run(list(map(str, args)), check=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8.py /path/to/VeilLink/repo")
        return 2
    root = Path(sys.argv[1]).resolve()
    run([sys.executable, HERE / "I7_BASE/APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7.py", root])
    selector = root / "VeilLink/Health/VeilKernelRuntimeSelector.swift"
    if not selector.exists() or 'case a10OnlyLab = "A10_ULTRA_ONLY_LAB"' not in selector.read_text(encoding="utf-8"):
        run([sys.executable, HERE / "I8_APPLY.py", root])
    run([sys.executable, HERE / "I8_VERIFY.py", root])
    print("CUMULATIVE I1 -> I2 -> I3 -> I4 -> I5 -> I6 -> I7 -> I8 READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
