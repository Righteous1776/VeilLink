# VeilLink Unified Defect Ledger — I9

## I9 repaired

### P1 — `A10_RAW_SIGNAL_CONTAMINATED_BY_A9_BUDGET`
I7/I8 built A10 HostContext using `computeGovernor.plan.mode`, `totalComputeUnits`, and `transportReserveUnits`. Those are A9 Compute Governor outputs. I9 removes them from A10 HostContext and `signal_digest`, restoring pre-decision raw-host separation.

### P1 — `ULTRA_PERSISTENCE_CROSSES_RUNTIME_MODE_EPOCH`
`ultraNonGreenSinceUptime` survived A9-only / Dual / A10-only changes. Time spent with Ultra disabled could be counted as Ultra persistence after re-entry. I9 resets persistence and pending A9 pairing at every runtime-mode boundary.

### P1 — `LAB_EXIT_REPLAYS_STALE_A9_PLAN`
Unfreezing A9 immediately recomputed from the last pre-LAB Decision before a fresh sample existed. I9 adds no-recompute unfreeze; the next fresh A9 sample becomes authoritative.

### P1 — `LAB_ULTRA_FAILURE_FALLBACK_DEBOUNCED`
Ultra internal failure previously waited for the ordinary health debounce before A9 recovered. I9 schedules A9 recovery on the next MainActor turn.

### P1 — `LAB_HOST_CRITICAL_SAFETY_FLOOR_MISSING`
A10-only LAB freezes the prior host compute plan. SQLite P0 or thermal critical must not leave a stale high-compute budget active. I9 records the Ultra sample, then exits LAB to A9 for these host-critical states.

### P2 — `DUAL_ENERGY_PROXY_UNDERCOUNTS_TOTAL_COST`
Dual mode previously used only Ultra CPU time for the energy proxy. I9 uses combined A9+Ultra CPU time and labels its scope in black-box telemetry.

### P2 — `A10_GAME_CONTEXT_HARDCODED_HOST_MANAGED`
A10 context always reported `HOST_MANAGED`. I9 derives `IDLE`/`ACTIVE` from the actual local game context.

## Still open / Apple-runtime dependent
- Xcode/XCTest and real iOS build acceptance.
- iPhone 7 / iPhone 13 three-mode comparison.
- RSS is still whole-process memory, not per-kernel attribution.
- Native iOS arm64 A10 Ultra Ω / OMEGA 96 backend is not yet supplied.
- Phase A–D Cutover gates are not yet satisfied.
