from pathlib import Path
import subprocess, sys
if len(sys.argv) != 2:
    raise SystemExit("usage: APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9.py <VeilLink repo root>")
here = Path(__file__).resolve().parent
root = Path(sys.argv[1]).resolve()
subprocess.run([sys.executable, str(here/"I8_BASE/APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8.py"), str(root)], check=True)
subprocess.run([sys.executable, str(here/"I9_APPLY.py"), str(root)], check=True)
subprocess.run([sys.executable, str(here/"I9_VERIFY.py"), str(root)], check=True)
print("CUMULATIVE I1 -> I9 PASS")
