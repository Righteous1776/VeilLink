from pathlib import Path
import sys

def need(text, marker, label):
    if marker not in text: raise RuntimeError(f"{label}: missing {marker!r}")

def main():
    if len(sys.argv) != 2: raise SystemExit("usage: I9_VERIFY.py <repo root>")
    root = Path(sys.argv[1])
    shadow = (root/"VeilLink/Health/A10UltraOmegaShadow.swift").read_text()
    app = (root/"VeilLink/App/AppModel.swift").read_text()
    gov = (root/"VeilLink/Agent/Compute/A9ComputeGovernor.swift").read_text()
    diag = (root/"VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift").read_text()
    safety = (root/"VeilLink/Health/VeilKernelHostSafetyPolicy.swift").read_text()
    for marker in ["func resetRuntimeEpoch(reason: String)", "activeProcessorCount: Int", "physicalMemoryBytes: UInt64", "let combinedCPU = baseline.cpu &+ ultraCPU"]:
        need(shadow, marker, "shadow")
    host_block = shadow.split("struct A10UltraOmegaHostContext", 1)[1].split("struct A10UltraOmegaSharedSample", 1)[0]
    for forbidden in ["computeMode:", "totalComputeUnits:", "transportReserveUnits:"]:
        if forbidden in host_block: raise RuntimeError(f"A10 HostContext still contains A9 output: {forbidden}")
    context_block = app.split("let ultraContext = A10UltraOmegaHostContext(", 1)[1].split("let ultraSample", 1)[0]
    if "computeGovernor.plan" in context_block: raise RuntimeError("A10 HostContext still reads A9 Compute Plan")
    for marker in ["hostForegroundActive", 'gameIntelligence.context == nil ? "IDLE" : "ACTIVE"', "VeilKernelHostSafetyPolicy.fallbackReason(for: input)", "recomputeOnUnfreeze: false"]:
        need(app, marker, "AppModel")
    need(gov, "recomputeOnUnfreeze: Bool = true", "governor")
    need(diag, '"signal_provenance": "RAW_HOST_PRE_DECISION"', "diagnostics")
    need(diag, '"combined_cpu_us": String((record.a9CPUNanos &+ record.ultraCPUNanos) / 1_000)', "diagnostics")
    need(safety, "HOST_STORAGE_P0_FALLBACK", "safety")
    need(safety, "HOST_THERMAL_CRITICAL_FALLBACK", "safety")
    print("I9 VERIFY PASS")

if __name__ == "__main__": main()
