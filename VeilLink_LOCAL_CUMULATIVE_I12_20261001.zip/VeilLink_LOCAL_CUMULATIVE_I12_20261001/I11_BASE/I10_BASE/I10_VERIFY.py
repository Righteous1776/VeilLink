from pathlib import Path
import sys

CHECKS = {
    "VeilLink/Agent/Compute/A10UltraComputeCore.swift": [
        "protocol A10UltraComputeRuntime",
        "A10UltraLanguageRuntimeAdapter",
        "candidateRanking",
        "gamePlanning",
        "visionAnalysis",
        "Mutation authority is deliberately absent",
    ],
    "VeilLink/Agent/Integration/VeilThreeCorePlan.swift": [
        "THREE_CORE_INSERTION_READY",
        "VEILLINK_HOST_ACTION_LAYER",
        "RETAINED_COMPATIBILITY_HARNESS",
    ],
    "VeilLink/Agent/Language/LocalTextModelRuntime.swift": [
        "var backendName: String { get }",
    ],
    "VeilLink/Agent/Language/LocalTextModelCoordinator.swift": [
        "private let baseRuntime",
        "activateOverride",
        "restoreBaseRuntime",
    ],
    "VeilLink/Agent/Core/AgentCoordinator.swift": [
        "threeCoreSnapshot",
        "attachA10UltraComputeRuntime",
        "runA10UltraComputeTask",
        "fallbackFromA10Compute",
        "A10UltraComputeBudget",
    ],
    "VeilLink/Agent/Core/AgentDiagnostics.swift": [
        "a10AttachCount",
        "a10FallbackCount",
        "realLocalInferenceActive",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "agent.three_core_state"',
        '"a10_runtime_id"',
        '"mutation_authority"',
    ],
    "VeilLinkTests/ThreeCoreIntegrationTests.swift": [
        "TestA10UltraComputeRuntime",
        "testCoordinatorCanOverrideAndRestoreBaseLanguageRuntime",
    ],
    "docs/ThreeCore/VEILLINK_THREE_CORE_PLAN_V1.md": [
        "A9 Governance Core",
        "A10 Ultra Ω Compute Core",
        "LingCore Orchestration Core",
        "not the new compute core",
    ],
}

FORBIDDEN = {
    "VeilLink/Agent/Compute/A10UltraComputeCore.swift": [
        "BLETransport",
        "DatabaseStore",
        "KeychainStore",
        "SessionCoordinator",
        "executeAppControl",
    ]
}

def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 I10_VERIFY.py /path/to/VeilLink")
    root = Path(sys.argv[1]).resolve()
    errors=[]
    for rel, markers in CHECKS.items():
        p=root/rel
        if not p.exists():
            errors.append(f"missing {rel}")
            continue
        t=p.read_text(encoding="utf-8")
        for m in markers:
            if m not in t:
                errors.append(f"{rel}: missing {m!r}")
    for rel, words in FORBIDDEN.items():
        p=root/rel
        if not p.exists(): continue
        t=p.read_text(encoding="utf-8")
        for w in words:
            if w in t:
                errors.append(f"{rel}: forbidden authority coupling {w!r}")
    if errors:
        print("I10 VERIFY FAIL")
        for e in errors: print("-",e)
        raise SystemExit(1)
    print("I10 VERIFY PASS — THREE_CORE_INSERTION_READY")

if __name__ == "__main__":
    main()
