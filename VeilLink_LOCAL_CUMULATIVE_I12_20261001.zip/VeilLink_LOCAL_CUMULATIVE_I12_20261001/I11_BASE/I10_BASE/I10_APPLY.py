from pathlib import Path
import shutil
import sys

I9_REQUIRED = {
    "VeilLink/Health/VeilKernelHostSafetyPolicy.swift": [
        "enum VeilKernelHostSafetyPolicy",
        "HOST_STORAGE_P0_FALLBACK",
    ],
    "VeilLink/App/AppModel.swift": [
        "private var hostForegroundActive = true",
        "a10Ultra.resetRuntimeEpoch(reason:",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        '"signal_provenance": "RAW_HOST_PRE_DECISION"',
        'event: "kernel.runtime_sample"',
    ],
}

I10_MARKERS = {
    "VeilLink/Agent/Compute/A10UltraComputeCore.swift": [
        "protocol A10UltraComputeRuntime",
        "final class A10UltraLanguageRuntimeAdapter",
    ],
    "VeilLink/Agent/Integration/VeilThreeCorePlan.swift": [
        "THREE_CORE_INSERTION_READY",
        "RETAINED_COMPATIBILITY_HARNESS",
    ],
    "VeilLink/Agent/Language/LocalTextModelRuntime.swift": [
        "var backendName: String { get }",
        "extension LocalTextModelRuntime",
    ],
    "VeilLink/Agent/Language/LocalTextModelCoordinator.swift": [
        "private let baseRuntime: LocalTextModelRuntime",
        "func activateOverride",
        "func restoreBaseRuntime",
    ],
    "VeilLink/Agent/Core/AgentCoordinator.swift": [
        "var threeCoreSnapshot",
        "func attachA10UltraComputeRuntime",
        "func runA10UltraComputeTask",
        "fallbackFromA10Compute",
    ],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": [
        'event: "agent.three_core_state"',
    ],
}

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_local_runtime(text: str) -> str:
    text = replace_once(
        text,
        "    var manifest: LocalTextModelManifest? { get }\n\n    func prepare() async throws",
        "    var manifest: LocalTextModelManifest? { get }\n    var backendName: String { get }\n\n    func prepare() async throws",
        "runtime backend name requirement",
    )
    text += '''\n\nextension LocalTextModelRuntime {\n    var backendName: String {\n        manifest?.displayName ?? String(reflecting: type(of: self))\n    }\n}\n'''
    return text


def patch_diagnostics(text: str) -> str:
    text = replace_once(
        text,
        "    var toolExecutionCount = 0\n    var lastToolCommand: String?",
        "    var toolExecutionCount = 0\n    var a10AttachCount = 0\n    var a10FallbackCount = 0\n    var lastA10FallbackReason: String?\n    var lastToolCommand: String?",
        "agent diagnostics a10 counters",
    )
    text = replace_once(
        text,
        '''    func report(\n        runtimeState: AgentRuntimeState,\n        runtimeID: String,\n        profile: AgentCapabilityProfile,\n        sessionMessageCount: Int\n    ) -> String {''',
        '''    func report(\n        runtimeState: AgentRuntimeState,\n        runtimeID: String,\n        backendName: String,\n        realLocalInferenceActive: Bool,\n        profile: AgentCapabilityProfile,\n        sessionMessageCount: Int\n    ) -> String {''',
        "agent diagnostics signature",
    )
    text = replace_once(
        text,
        '''            "Backend: \\(LocalTextModelRuntimeFactory.backendName)",\n            "Real local inference compiled: \\(LocalTextModelRuntimeFactory.isRealLocalInferenceCompiled)",''',
        '''            "Backend: \\(backendName)",\n            "Real local inference active: \\(realLocalInferenceActive)",''',
        "dynamic backend diagnostics",
    )
    text = replace_once(
        text,
        '''            "Tool executions: \\(toolExecutionCount)",\n            "Last tool: \\(lastToolCommand ?? \"-\")",''',
        '''            "Tool executions: \\(toolExecutionCount)",\n            "A10 Ultra Ω attaches: \\(a10AttachCount)",\n            "A10 Ultra Ω fallbacks: \\(a10FallbackCount)",\n            "Last A10 fallback: \\(lastA10FallbackReason ?? \"-\")",\n            "Last tool: \\(lastToolCommand ?? \"-\")",''',
        "a10 diagnostics report",
    )
    return text


def patch_agent_coordinator(text: str) -> str:
    text = replace_once(
        text,
        "    @Published private(set) var computePlan: VeilA9ComputePlan\n\n    let capabilityProfile: AgentCapabilityProfile",
        "    @Published private(set) var computePlan: VeilA9ComputePlan\n    @Published private(set) var threeCoreSnapshot: VeilThreeCoreSnapshot\n\n    let capabilityProfile: AgentCapabilityProfile",
        "three-core published snapshot",
    )
    text = replace_once(
        text,
        "    private var localContextProvider: (() -> AgentLocalContext?)?\n    private var toolExecutor: ((String) -> AgentToolExecution?)?",
        "    private var localContextProvider: (() -> AgentLocalContext?)?\n    private var toolExecutor: ((String) -> AgentToolExecution?)?\n    private var a10ComputeRuntime: (any A10UltraComputeRuntime)?",
        "a10 compute runtime slot",
    )
    text = replace_once(
        text,
        '''        self.computeGovernor = governor\n        computePlan = governor.plan\n        language = LocalTextModelCoordinator(runtime: selectedRuntime)\n        runtimeState = selectedRuntime.state\n        session = Self.makeFreshSession()''',
        '''        self.computeGovernor = governor\n        computePlan = governor.plan\n        threeCoreSnapshot = VeilThreeCoreSnapshot.initial(\n            languageBackend: selectedRuntime.backendName,\n            budgetMode: governor.plan.mode.rawValue\n        )\n        language = LocalTextModelCoordinator(runtime: selectedRuntime)\n        runtimeState = selectedRuntime.state\n        session = Self.makeFreshSession()''',
        "three-core initialization",
    )
    text = replace_once(
        text,
        '''        governor.onPlanChanged = { [weak self] plan in\n            self?.computePlan = plan\n        }''',
        '''        governor.onPlanChanged = { [weak self] plan in\n            guard let self else { return }\n            self.computePlan = plan\n            self.a10ComputeRuntime?.applyBudget(A10UltraComputeBudget.fromA9(plan))\n            self.refreshThreeCoreSnapshot()\n        }''',
        "budget relay to A10",
    )

    anchor = "    var isMaleCNSRuntimeBound: Bool { computeGovernor.hasBoundMaleCNSConsumer }\n\n"
    insertion = '''    var isMaleCNSRuntimeBound: Bool { computeGovernor.hasBoundMaleCNSConsumer }\n\n    /// Installs the future A10 Ultra Ω compute runtime into the LingCore compute slot.\n    /// LingCore keeps session/personality/tool orchestration; the host Action Layer keeps all\n    /// mutation authority. No request is replayed automatically across runtime swaps.\n    func attachA10UltraComputeRuntime(_ runtime: any A10UltraComputeRuntime) {\n        stopGeneration()\n        a10ComputeRuntime?.cancel()\n        a10ComputeRuntime?.unload()\n        a10ComputeRuntime = runtime\n        runtime.applyBudget(A10UltraComputeBudget.fromA9(computePlan))\n        language.activateOverride(A10UltraLanguageRuntimeAdapter(runtime: runtime))\n        diagnostics.a10AttachCount += 1\n        lastError = nil\n        refreshThreeCoreSnapshot()\n        syncRuntimeState()\n    }\n\n    func detachA10UltraComputeRuntime() {\n        stopGeneration()\n        a10ComputeRuntime?.cancel()\n        a10ComputeRuntime?.unload()\n        a10ComputeRuntime = nil\n        language.restoreBaseRuntime()\n        refreshThreeCoreSnapshot()\n        syncRuntimeState()\n    }\n\n    /// Generic non-mutating compute lane for future structured reasoning/ranking/game/vision use.\n    /// Callers receive data only; they must route any real app action through the host control layer.\n    func runA10UltraComputeTask(_ request: A10UltraComputeRequest) async throws -> A10UltraComputeResponse {\n        guard let runtime = a10ComputeRuntime else {\n            throw A10UltraComputeError.unavailable("A10 Ultra Ω 计算核尚未正式插入。")\n        }\n        return try await runtime.execute(request)\n    }\n\n'''
    text = replace_once(text, anchor, insertion, "a10 runtime management API")

    old_catch = '''            } catch {\n                self.lastError = error.localizedDescription\n                self.diagnostics.lastFailure = error.localizedDescription\n                if stream.text.isEmpty {\n                    self.session.updateMessage(id: assistantID, text: "本地运行时暂时不可用：\\(error.localizedDescription)")\n                } else {\n                    self.session.updateMessage(id: assistantID, text: stream.text)\n                }\n            }'''
    new_catch = '''            } catch {\n                self.lastError = error.localizedDescription\n                self.diagnostics.lastFailure = error.localizedDescription\n                if self.a10ComputeRuntime != nil {\n                    self.fallbackFromA10Compute(reason: error.localizedDescription)\n                }\n                if stream.text.isEmpty {\n                    self.session.updateMessage(id: assistantID, text: "本地运行时暂时不可用：\\(error.localizedDescription)")\n                } else {\n                    self.session.updateMessage(id: assistantID, text: stream.text)\n                }\n            }'''
    text = replace_once(text, old_catch, new_catch, "a10 generation fallback")

    text = replace_once(
        text,
        '''        diagnostics.report(\n            runtimeState: runtimeState,\n            runtimeID: runtimeManifest?.id ?? "none",\n            profile: capabilityProfile,\n            sessionMessageCount: session.messages.count\n        ) + "\\n\\n" + computeGovernor.report()''',
        '''        diagnostics.report(\n            runtimeState: runtimeState,\n            runtimeID: runtimeManifest?.id ?? "none",\n            backendName: language.backendName,\n            realLocalInferenceActive: language.isUsingOverride || LocalTextModelRuntimeFactory.isRealLocalInferenceCompiled,\n            profile: capabilityProfile,\n            sessionMessageCount: session.messages.count\n        ) + "\\n\\n" + computeGovernor.report() + "\\n\\n" + threeCoreSnapshot.report''',
        "three-core diagnostics report",
    )

    text = replace_once(
        text,
        '''    private func syncRuntimeState() {\n        runtimeState = language.state\n    }''',
        '''    private func syncRuntimeState() {\n        runtimeState = language.state\n        refreshThreeCoreSnapshot()\n    }\n\n    private func fallbackFromA10Compute(reason: String) {\n        a10ComputeRuntime?.cancel()\n        a10ComputeRuntime?.unload()\n        a10ComputeRuntime = nil\n        language.restoreBaseRuntime()\n        diagnostics.a10FallbackCount += 1\n        diagnostics.lastA10FallbackReason = reason\n        refreshThreeCoreSnapshot(phaseOverride: .fallback, fallbackReason: reason)\n    }\n\n    private func refreshThreeCoreSnapshot(\n        phaseOverride: VeilThreeCorePhase? = nil,\n        fallbackReason: String? = nil\n    ) {\n        let runtime = a10ComputeRuntime\n        let phase: VeilThreeCorePhase\n        if let phaseOverride {\n            phase = phaseOverride\n        } else if runtime == nil {\n            phase = .insertionReady\n        } else if runtime?.state == .computing {\n            phase = .a10ComputeActive\n        } else {\n            phase = .a10ComputeAttached\n        }\n        threeCoreSnapshot = VeilThreeCoreSnapshot(\n            phase: phase,\n            a9Role: .governance,\n            a10Role: .compute,\n            lingCoreRole: .orchestration,\n            a10RuntimeID: runtime?.manifest.runtimeID,\n            a10RuntimeState: runtime?.state.rawValue ?? A10UltraComputeState.detached.rawValue,\n            languageBackend: language.backendName,\n            a9BudgetMode: computePlan.mode.rawValue,\n            mutationAuthorityOwner: "VEILLINK_HOST_ACTION_LAYER",\n            legacyGovernanceShadow: "RETAINED_COMPATIBILITY_HARNESS",\n            fallbackReason: fallbackReason\n        )\n    }''',
        "three-core state helpers",
    )
    return text


def patch_runtime_bridge(text: str) -> str:
    anchor = '''        model.agent.$runtimeState\n            .map { String(describing: $0) }\n            .removeDuplicates()'''
    insertion = '''        model.agent.$threeCoreSnapshot\n            .removeDuplicates()\n            .sink { snapshot in\n                Task { @MainActor in\n                    self.store.log(\n                        snapshot.phase == .fallback ? .warning : .info,\n                        .agent,\n                        event: "agent.three_core_state",\n                        screen: DeepTelemetry.shared.currentScreen,\n                        metadata: [\n                            "phase": snapshot.phase.rawValue,\n                            "a9_role": snapshot.a9Role.rawValue,\n                            "a10_role": snapshot.a10Role.rawValue,\n                            "ling_core_role": snapshot.lingCoreRole.rawValue,\n                            "a10_runtime_id": snapshot.a10RuntimeID ?? "EMPTY_READY",\n                            "a10_runtime_state": snapshot.a10RuntimeState,\n                            "language_backend": snapshot.languageBackend,\n                            "a9_budget_mode": snapshot.a9BudgetMode,\n                            "mutation_authority": snapshot.mutationAuthorityOwner,\n                            "legacy_shadow": snapshot.legacyGovernanceShadow,\n                            "fallback_reason": snapshot.fallbackReason ?? "none"\n                        ]\n                    )\n                }\n            }\n            .store(in: &cancellables)\n\n        model.agent.$runtimeState\n            .map { String(describing: $0) }\n            .removeDuplicates()'''
    return replace_once(text, anchor, insertion, "three-core live telemetry")


def copy_payload(root: Path, package_root: Path) -> None:
    payload = package_root / "Payload"
    for source in payload.rglob("*"):
        if not source.is_file():
            continue
        rel = source.relative_to(payload)
        if str(rel).startswith("docs/") or str(rel).startswith("VeilLinkTests/") or str(rel).startswith("VeilLink/"):
            destination = root / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)


def apply(root: Path, package_root: Path) -> None:
    try:
        require_markers(root, I10_MARKERS, "I10 already applied")
        print("I10 already present; verification only.")
        return
    except Exception:
        pass

    require_markers(root, I9_REQUIRED, "I9 prerequisite")

    target = root / "VeilLink/Agent/Language/LocalTextModelRuntime.swift"
    target.write_text(patch_local_runtime(target.read_text(encoding="utf-8")), encoding="utf-8")

    # Coordinator replacement is intentionally payload-based: this file is a small compute-backend
    # holder and I10 upgrades it atomically to an override + restore slot.
    coordinator = root / "VeilLink/Agent/Language/LocalTextModelCoordinator.swift"
    old = coordinator.read_text(encoding="utf-8")
    if "private let runtime: LocalTextModelRuntime" not in old or "func generate(" not in old:
        raise RuntimeError("LocalTextModelCoordinator is not the expected I9/base shape")

    diagnostics = root / "VeilLink/Agent/Core/AgentDiagnostics.swift"
    diagnostics.write_text(patch_diagnostics(diagnostics.read_text(encoding="utf-8")), encoding="utf-8")

    agent = root / "VeilLink/Agent/Core/AgentCoordinator.swift"
    agent.write_text(patch_agent_coordinator(agent.read_text(encoding="utf-8")), encoding="utf-8")

    bridge = root / "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"
    bridge.write_text(patch_runtime_bridge(bridge.read_text(encoding="utf-8")), encoding="utf-8")

    copy_payload(root, package_root)
    require_markers(root, I10_MARKERS, "I10 post-apply")


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 I10_APPLY.py /path/to/VeilLink")
    root = Path(sys.argv[1]).resolve()
    package_root = Path(__file__).resolve().parent
    apply(root, package_root)
    print("I10 THREE_CORE_INSERTION_READY applied.")

if __name__ == "__main__":
    main()
