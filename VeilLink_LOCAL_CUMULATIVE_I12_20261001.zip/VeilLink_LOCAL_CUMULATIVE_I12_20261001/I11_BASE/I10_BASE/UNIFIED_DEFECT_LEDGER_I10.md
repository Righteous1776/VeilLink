# VeilLink Unified Engineering Ledger — I10

## I10 purpose

Prepare VeilLink for the newly evolving **A10 Ultra Ω real compute runtime**, which is no longer the same concept as the historical OMEGA 96 governance-shadow implementation.

## Architecture correction

### THREE_CORE_CONCEPT_COLLISION — FIXED

Before I10, the name “A10 Ultra Ω” could refer both to the old governance-shadow/cutover experiment and to the newly trained general compute runtime. This creates a dangerous integration ambiguity.

I10 separates the roles:

- **A9 Governance Core**: safety, health, persistence, resource budget, transport reserve.
- **A10 Ultra Ω Compute Core**: future real local compute/inference backend.
- **LingCore Orchestration Core**: session/persona/context/tool routing and host control-plane integration.

The old OMEGA 96 governance shadow remains a compatibility harness and is not considered the new compute core.

### LINGCORE_EMPTY_BACKEND_NO_FORMAL_INSERTION_ABI — FIXED

The previous LingCore language path could use llama.cpp or a deterministic Mock runtime, but had no explicit ABI for a new non-llama compute core.

I10 adds `A10UltraComputeRuntime/v1` plus `A10UltraLanguageRuntimeAdapter`.

### LANGUAGE_RUNTIME_NOT_REPLACEABLE_AT_RUNTIME — FIXED

`LocalTextModelCoordinator` previously held one immutable runtime. I10 adds a base runtime plus override/restore slot so a future A10 runtime can be inserted without replacing LingCore itself.

### A10_COMPUTE_BUDGET_BRIDGE_MISSING — FIXED

A9 continues to own safety/resource governance. I10 maps `VeilA9ComputePlan` into `A10UltraComputeBudget` and relays changes to the attached A10 compute runtime.

### A10_COMPUTE_MUTATION_BOUNDARY — HARDENED

The new compute protocol intentionally exposes no BLE transport, SQLite store, keychain, session coordinator, game mutator, or host tool executor. A10 returns computation only. App mutations remain behind the VeilLink Host Action Layer.

### A10_FAILURE_DUPLICATE_ACTION_RISK — HARDENED

If the A10 language backend fails mid-generation, I10 does not automatically replay the current request on another backend. It restores the base backend for subsequent requests only, reducing duplicate output/tool-action risk.

### THREE_CORE_OBSERVABILITY_GAP — FIXED

Black-box telemetry gains `agent.three_core_state` with phase, A9/A10/LingCore roles, A10 runtime ID/state, active language backend, A9 budget mode, mutation authority owner, legacy-shadow marker and fallback reason.

## Current gate

`THREE_CORE_INSERTION_READY`

The A10 compute slot is still `EMPTY_READY`. Formal insertion requires a concrete runtime plus Apple build/device validation.
