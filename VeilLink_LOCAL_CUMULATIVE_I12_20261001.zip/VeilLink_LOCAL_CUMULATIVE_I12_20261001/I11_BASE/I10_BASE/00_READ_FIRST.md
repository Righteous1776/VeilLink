# VeilLink Local Cumulative I10 — Three-Core Insertion Ready

I10 continues directly from I9.

Current state:

- **A9** = Governance / Safety / Budget Core
- **A10 Ultra Ω (new generation)** = Compute Core slot, `EMPTY_READY`
- **LingCore** = Orchestration / Persona / Session / Context / Tool-Control Core
- Historical **A10 Ultra Ω / OMEGA 96 governance shadow** = retained compatibility harness only; it is **not** the new compute core.

Apply from the original supported base or any already-cumulative state with:

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9_I10.py /path/to/VeilLink
```

Then run the normal XcodeGen / XCTest / iphoneos build chain on macOS.

## What I10 adds

- `A10UltraComputeRuntime/v1`: insertion ABI for the future real A10 Ultra Ω compute runtime.
- Prepared task lanes: text generation, structured reasoning, candidate ranking, game planning, vision analysis and embedding.
- `A10UltraLanguageRuntimeAdapter`: lets A10 take over the currently empty LingCore language-compute slot without taking over LingCore orchestration.
- `LocalTextModelCoordinator` override/restore slot for hot insertion and fallback to the existing local runtime.
- A9 compute-plan → `A10UltraComputeBudget` relay.
- `VeilThreeCoreSnapshot` and live black-box event `agent.three_core_state`.
- A10 failure fallback: current request is never silently replayed; subsequent requests return to the original LingCore compute backend to avoid duplicate output/tool actions.
- Mutation authority remains in the VeilLink Host Action Layer only.

## Important boundary

I10 does **not** claim the new A10 Ultra Ω runtime is already installed. The slot is intentionally `EMPTY_READY` until a concrete trained runtime implements `A10UltraComputeRuntime` and passes build/device/thermal/memory/cancellation/fallback/privacy validation.
