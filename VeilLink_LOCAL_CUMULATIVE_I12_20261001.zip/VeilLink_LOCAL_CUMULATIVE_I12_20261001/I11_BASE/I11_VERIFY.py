from pathlib import Path
import sys

CHECKS = {
    "VeilLink/Diagnostics/CollaborativeStressProtocol.swift": ["CollaborativeStressCodec", "CollaborativeStressInboundBulkAccumulator", "syntheticVoiceWAV", "case bulkReady"],
    "VeilLink/Diagnostics/CollaborativeStressCoordinator.swift": ["CollaborativeStressCoordinator", "stress.collab.session.begin", "MiniGameCodec.encode", "droppedFrames", "bulkReadyTransfers", "stress.collab.bulk.remote_ready_timeout"],
    "VeilLink/Security/SessionCoordinator.swift": ["onCollaborativeStressFrame", "sendCollaborativeStressFrame", "sendCollaborativeStressBulkChunk", "CollaborativeStressCodec.decode", "collaborativeStressMessageIDs", "pruneCollaborativeStressMessageIDs"],
    "VeilLink/Diagnostics/DeviceStressTestController.swift": ["CollaborativeStressCoordinator.shared.attach", 'extraFiles["stress-collaborative.json"]'],
    "VeilLink/UI/DeviceStressTestView.swift": ["TEMP E2EE STRESS CHANNEL", "发送协同邀请", "接收邀请并开始", "语音级 WAV/PCM bulk"],
    "VeilLinkTests/CollaborativeStressProtocolTests.swift": ["testFrameRoundTripAndPrefixIsolation", "testBulkAccumulatorVerifiesDigestAndOrdering", "testBulkReadyRequiresMatchingTransferIdentityFields"],
}

FORBIDDEN = {
    "VeilLink/Diagnostics/CollaborativeStressCoordinator.swift": ["AVAudioRecorder", "SFSpeechRecognizer", "inputNode.installTap", "sendText(", "sendImage("],
    "VeilLink/Diagnostics/CollaborativeStressProtocol.swift": ["KeychainStore", "DatabaseStore"],
}


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 I11_VERIFY.py /path/to/VeilLink")
    root = Path(sys.argv[1]).resolve()
    errors = []
    for rel, markers in CHECKS.items():
        path = root / rel
        if not path.exists():
            errors.append(f"missing {rel}")
            continue
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in source:
                errors.append(f"{rel}: missing {marker!r}")
    for rel, markers in FORBIDDEN.items():
        path = root / rel
        if not path.exists():
            continue
        source = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker in source:
                errors.append(f"{rel}: forbidden coupling {marker!r}")
    if errors:
        print("I11 VERIFY FAIL")
        for error in errors: print("-", error)
        raise SystemExit(1)
    print("I11 VERIFY PASS — COLLABORATIVE_STRESS_LAB_READY")


if __name__ == "__main__":
    main()
