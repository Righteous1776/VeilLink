# VeilLink Local Cumulative I12 — A10 Ultra Ω M5 Trained Cognition Shadow

基线仍为 GitHub `main@152c3ab23fe5710e89578d2bea3f3e3ba00f8b2f`，本包继续累计 I1→I11。

## I12 的定位

A10 Ultra Ω V0.5-M5 已经拥有经过训练的微型语言/推理能力，因此本层不再把它只当健康裁决器。I12 将 pristine M5 模型真正转换为 iOS 工程可携带的 Runtime：

- LingCore **Cognition Shadow**：与当前可见灵核后端并行接收同一份经过宿主清洗的 `AgentTextRequest`，但不抢用户可见回复、不执行工具；
- VeilLink **Governance Advisor**：读取原始宿主数值状态，运行 M4 Predictor + M5 Reasoner/RNN，形成结构化治理 proposal；
- 两条 rail 使用独立 M5 runtime，互不 cancel/污染状态；
- `mutation_authority = 0`；真实 BLE/SQLite/消息/游戏/密钥动作仍归 Host Action Layer。

**这不是生产 Cutover。** 原 M5 合同仍明确 `SHADOW_ONLY / PRODUCTION_CUTOVER=DENY / real_world_validation=NOT_PERFORMED`。

## iOS 运行路径

不携带 Python，也不把 Linux `.so` 放进 App。Payload 包含：

- M5 训练权重、词表与 provenance manifest；
- VeilLink M4 Runtime Predictor（INT8）；
- SQLite M4 Anomaly Predictor（INT8）；
- portable C：M5 Reasoner、RNN step、M4 INT8 dynamic-activation；
- Swift：tokenizer/domain routing/state merge/renderer/provenance/Shadow adapter。

本机差分：

- Reasoner 10,000：0 mismatch；
- RNN 10,000：0 mismatch；
- VeilLink M4 INT8 10,000：0 mismatch；
- SQLite M4 INT8 10,000：0 mismatch；
- Spirit 端到端语义 2,000：0 mismatch。

这些只证明当前本机数学/语义对齐，**不等于 iPhone/ARM64/Xcode 真机验证**。

## 应用

已处于 I11 源码：

```bash
python3 I12_APPLY.py /path/to/VeilLink
python3 I12_VERIFY.py /path/to/VeilLink
```

从原始 main 一路累计：

```bash
python3 APPLY_CUMULATIVE_I1_I2_I3_I4_I5_I6_I7_I8_I9_I10_I11_I12.py /path/to/VeilLink
```

## 下一 Gate

必须进入 Apple 构建环境完成 XcodeGen → XCTest → iphoneos build，并在 iPhone 7 / iPhone 13 上测 RAM、thermal、battery、Shadow 一致性、LingCore latency 与治理 proposal 的真实误报/漏报；这些完成前不得开启 visible takeover 或业务 mutation。
