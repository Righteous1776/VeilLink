from pathlib import Path
import shutil
import sys

I11_REQUIRED = {
    "VeilLink/Agent/Compute/A10UltraComputeCore.swift": ["protocol A10UltraComputeRuntime"],
    "VeilLink/Agent/Core/AgentCoordinator.swift": ["func attachA10UltraComputeRuntime", "var threeCoreSnapshot"],
    "VeilLink/App/AppModel.swift": ["let kernelRuntime: VeilKernelRuntimeSelector", "private var hostForegroundActive = true"],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": ['event: "agent.three_core_state"', 'event: "kernel.runtime_sample"'],
    "VeilLink/Diagnostics/CollaborativeStressCoordinator.swift": ["final class CollaborativeStressCoordinator"],
}

I12_MARKERS = {
    "VeilLink/Native/VeilLink-Bridging-Header.h": ['#include "A10UltraM5Native.h"'],
    "VeilLink/Native/A10UltraM5Native.c": ["a10_ultra_m5_reasoner_f32", "a10_ultra_m5_host_predictor_f32"],
    "VeilLink/Agent/Compute/A10UltraM5Runtime.swift": ["final class A10UltraM5Runtime", "TRAINED_COGNITION_SHADOW", "VEILLINK_M4_PROXY_V1"],
    "VeilLink/Agent/Integration/A10UltraM5GovernanceAdvisor.swift": ["final class A10UltraM5GovernanceAdvisor", "SHADOW_ADVISORY_ONLY"],
    "VeilLink/Agent/Core/AgentCoordinator.swift": ["attachA10UltraShadowRuntime", "launchA10UltraM5Shadow", "a10M5ShadowCognition"],
    "VeilLink/App/AppModel.swift": ["let a10M5Governance: A10UltraM5GovernanceAdvisor", "a10M5Governance.evaluate"],
    "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift": ['event: "a10.m5.cognition_shadow"', 'event: "a10.m5.governance_shadow"'],
    "VeilLink/Resources/A10UltraM5/ios_integration_manifest.json": ["VEILLINK_A10_ULTRA_M5_IOS_ASSET_V1", "c5ba826dab1ebe1db02e90e8b4bfd2c060e99586413970fa3bd4d848e378a8b4"],
}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)


def require_markers(root: Path, mapping, label: str) -> None:
    for rel, markers in mapping.items():
        path = root / rel
        if not path.exists():
            raise RuntimeError(f"{label}: missing {rel}")
        source = path.read_text(encoding="utf-8", errors="replace")
        for marker in markers:
            if marker not in source:
                raise RuntimeError(f"{label}: {rel} missing {marker!r}")


def patch_bridging(text: str) -> str:
    return replace_once(
        text,
        '#include "VeilFlyKernel.h"\n',
        '#include "VeilFlyKernel.h"\n#include "A10UltraM5Native.h"\n',
        "A10 M5 native bridge",
    )


def patch_agent(text: str) -> str:
    text = replace_once(
        text,
        "    @Published private(set) var threeCoreSnapshot: VeilThreeCoreSnapshot\n\n    let capabilityProfile: AgentCapabilityProfile",
        "    @Published private(set) var threeCoreSnapshot: VeilThreeCoreSnapshot\n    @Published private(set) var a10M5ShadowCognition: A10UltraM5ShadowCognitionSnapshot = .idle\n\n    let capabilityProfile: AgentCapabilityProfile",
        "A10 M5 shadow cognition snapshot",
    )
    text = replace_once(
        text,
        "    private var a10ComputeRuntime: (any A10UltraComputeRuntime)?",
        "    private var a10ComputeRuntime: (any A10UltraComputeRuntime)?\n    private var a10ShadowRuntime: (any A10UltraComputeRuntime)?\n    private var a10ShadowTask: Task<Void, Never>?",
        "A10 M5 shadow runtime slot",
    )
    text = replace_once(
        text,
        "            self.a10ComputeRuntime?.applyBudget(A10UltraComputeBudget.fromA9(plan))\n            self.refreshThreeCoreSnapshot()",
        "            self.a10ComputeRuntime?.applyBudget(A10UltraComputeBudget.fromA9(plan))\n            self.a10ShadowRuntime?.applyBudget(A10UltraComputeBudget.fromA9(plan))\n            self.refreshThreeCoreSnapshot()",
        "A10 M5 shadow budget relay",
    )

    anchor = "    var isMaleCNSRuntimeBound: Bool { computeGovernor.hasBoundMaleCNSConsumer }\n\n    /// Installs the future A10 Ultra Ω compute runtime into the LingCore compute slot."
    insertion = '''    var isMaleCNSRuntimeBound: Bool { computeGovernor.hasBoundMaleCNSConsumer }\n\n    /// Attaches A10 Ultra Ω M5 as a non-authoritative LingCore cognition shadow.\n    /// It receives the sanitized AgentTextRequest but never replaces the visible answer or executes tools.\n    func attachA10UltraShadowRuntime(_ runtime: any A10UltraComputeRuntime) {\n        a10ShadowTask?.cancel()\n        a10ShadowRuntime?.cancel()\n        a10ShadowRuntime?.unload()\n        a10ShadowRuntime = runtime\n        runtime.applyBudget(A10UltraComputeBudget.fromA9(computePlan))\n        a10M5ShadowCognition = .idle\n        refreshThreeCoreSnapshot()\n    }\n\n    func detachA10UltraShadowRuntime() {\n        a10ShadowTask?.cancel()\n        a10ShadowTask = nil\n        a10ShadowRuntime?.cancel()\n        a10ShadowRuntime?.unload()\n        a10ShadowRuntime = nil\n        a10M5ShadowCognition = .idle\n        refreshThreeCoreSnapshot()\n    }\n\n    /// Installs the future A10 Ultra Ω compute runtime into the LingCore compute slot.'''
    text = replace_once(text, anchor, insertion, "A10 M5 shadow attach API")

    text = replace_once(
        text,
        "            computeBudget: computePlan.language\n        )\n        let assistantID = UUID().uuidString",
        "            computeBudget: computePlan.language\n        )\n        launchA10UltraM5Shadow(request)\n        let assistantID = UUID().uuidString",
        "A10 M5 shadow request fork",
    )

    text = replace_once(
        text,
        "    func stopGeneration() {\n        guard generationTask != nil || runtimeState == .generating || runtimeState == .loading else { return }\n        generationTask?.cancel()",
        "    func stopGeneration() {\n        guard generationTask != nil || a10ShadowTask != nil || runtimeState == .generating || runtimeState == .loading else { return }\n        a10ShadowTask?.cancel()\n        a10ShadowTask = nil\n        a10ShadowRuntime?.cancel()\n        generationTask?.cancel()",
        "stop shadow with visible generation",
    )

    text = replace_once(
        text,
        "    func handleMemoryPressure() {\n        stopGeneration()\n        language.trimMemory()",
        "    func handleMemoryPressure() {\n        stopGeneration()\n        a10ShadowRuntime?.trimMemory()\n        language.trimMemory()",
        "A10 M5 shadow memory pressure",
    )
    text = replace_once(
        text,
        "    func handleBackground() {\n        stopGeneration()",
        "    func handleBackground() {\n        stopGeneration()\n        a10ShadowRuntime?.trimMemory()",
        "A10 M5 shadow background trim",
    )

    text = replace_once(
        text,
        '''        ) + "\\n\\n" + computeGovernor.report() + "\\n\\n" + threeCoreSnapshot.report''',
        '''        ) + "\\n\\n" + computeGovernor.report() + "\\n\\n" + threeCoreSnapshot.report\n            + "\\n\\nA10 Ultra Ω M5 Shadow Cognition"\n            + "\\nResult: \\(a10M5ShadowCognition.result)"\n            + "\\nRuntime: \\(a10M5ShadowCognition.runtimeID)"\n            + "\\nOutput digest: \\(a10M5ShadowCognition.outputDigest)"\n            + "\\nLatency ms: \\(a10M5ShadowCognition.latencyMilliseconds)"\n            + "\\nMutation authority: 0"''',
        "A10 M5 shadow diagnostics",
    )

    text = replace_once(
        text,
        "        let runtime = a10ComputeRuntime\n        let phase: VeilThreeCorePhase",
        "        let runtime = a10ComputeRuntime ?? a10ShadowRuntime\n        let phase: VeilThreeCorePhase",
        "three-core recognizes shadow attachment",
    )

    anchor = '''    private func syncRuntimeState() {\n        runtimeState = language.state\n        refreshThreeCoreSnapshot()\n    }'''
    helper = '''    private func launchA10UltraM5Shadow(_ request: AgentTextRequest) {\n        guard a10ComputeRuntime == nil, let runtime = a10ShadowRuntime else { return }\n        a10ShadowTask?.cancel()\n        a10ShadowTask = Task { @MainActor [weak self] in\n            guard let self else { return }\n            let started = ProcessInfo.processInfo.systemUptime\n            do {\n                let result = try await runtime.generateText(request: request) { _ in }\n                guard !Task.isCancelled else { return }\n                let elapsed = max(0, Int((ProcessInfo.processInfo.systemUptime - started) * 1_000))\n                self.a10M5ShadowCognition = A10UltraM5ShadowCognitionSnapshot(\n                    evaluatedAt: Date(),\n                    runtimeID: runtime.manifest.runtimeID,\n                    outputDigest: A10UltraM5Digest.sha256(result.text),\n                    estimatedTokenCount: result.estimatedTokenCount,\n                    latencyMilliseconds: elapsed,\n                    mutationAuthority: 0,\n                    result: "PASS",\n                    failure: nil\n                )\n            } catch is CancellationError {\n                return\n            } catch A10UltraComputeError.cancelled {\n                return\n            } catch {\n                guard !Task.isCancelled else { return }\n                self.a10M5ShadowCognition = A10UltraM5ShadowCognitionSnapshot(\n                    evaluatedAt: Date(),\n                    runtimeID: runtime.manifest.runtimeID,\n                    outputDigest: "-",\n                    estimatedTokenCount: 0,\n                    latencyMilliseconds: max(0, Int((ProcessInfo.processInfo.systemUptime - started) * 1_000)),\n                    mutationAuthority: 0,\n                    result: "FAILED",\n                    failure: error.localizedDescription\n                )\n            }\n            self.a10ShadowTask = nil\n        }\n    }\n\n    private func syncRuntimeState() {\n        runtimeState = language.state\n        refreshThreeCoreSnapshot()\n    }'''
    text = replace_once(text, anchor, helper, "A10 M5 shadow evaluation helper")
    return text


def patch_app_model(text: str) -> str:
    text = replace_once(
        text,
        "    let latticeKernel: VeilLatticeKernelBridge\n    let a10Ultra: A10UltraOmegaShadowCoordinator\n    let kernelRuntime: VeilKernelRuntimeSelector\n    let agentControls: AgentControlCenterSettings\n",
        "    let latticeKernel: VeilLatticeKernelBridge\n    let a10Ultra: A10UltraOmegaShadowCoordinator\n    let kernelRuntime: VeilKernelRuntimeSelector\n    let a10M5CognitionRuntime: A10UltraM5Runtime\n    let a10M5GovernanceRuntime: A10UltraM5Runtime\n    let a10M5Governance: A10UltraM5GovernanceAdvisor\n    let agentControls: AgentControlCenterSettings\n",
        "A10 M5 app properties",
    )
    text = replace_once(
        text,
        "        latticeKernel = VeilLatticeKernelBridge()\n        a10Ultra = A10UltraOmegaShadowCoordinator()\n        kernelRuntime = VeilKernelRuntimeSelector()\n        agentControls = AgentControlCenterSettings()",
        "        latticeKernel = VeilLatticeKernelBridge()\n        a10Ultra = A10UltraOmegaShadowCoordinator()\n        kernelRuntime = VeilKernelRuntimeSelector()\n        let m5CognitionRuntime = A10UltraM5Runtime()\n        let m5GovernanceRuntime = A10UltraM5Runtime()\n        a10M5CognitionRuntime = m5CognitionRuntime\n        a10M5GovernanceRuntime = m5GovernanceRuntime\n        a10M5Governance = A10UltraM5GovernanceAdvisor(runtime: m5GovernanceRuntime)\n        agentControls = AgentControlCenterSettings()",
        "A10 M5 app initialization",
    )
    text = replace_once(
        text,
        '''        agent = AgentCoordinator(\n            runtime: LocalTextModelRuntimeFactory.make(profile: agentProfile),\n            capabilityProfile: agentProfile,\n            computeGovernor: computeGovernor\n        )\n        performanceOverrides.onChange = { [weak self] in''',
        '''        agent = AgentCoordinator(\n            runtime: LocalTextModelRuntimeFactory.make(profile: agentProfile),\n            capabilityProfile: agentProfile,\n            computeGovernor: computeGovernor\n        )\n        agent.attachA10UltraShadowRuntime(m5CognitionRuntime)\n        performanceOverrides.onChange = { [weak self] in''',
        "attach A10 M5 LingCore shadow",
    )

    text = replace_once(
        text,
        "        let ultraContext = A10UltraOmegaHostContext(\n",
        "        a10M5GovernanceRuntime.applyBudget(A10UltraComputeBudget.fromA9(computeGovernor.plan))\n        a10M5Governance.evaluate(\n            input: input,\n            foregroundActive: hostForegroundActive,\n            agentGenerating: agent.isGenerating,\n            gameActive: gameIntelligence.context != nil\n        )\n\n        let ultraContext = A10UltraOmegaHostContext(\n",
        "A10 M5 governance sample fork",
    )

    text = replace_once(
        text,
        "            + \"\\n\\n\" + a10Ultra.report()\n            + \"\\n\\n\" + computeGovernor.report()",
        "            + \"\\n\\n\" + a10Ultra.report()\n            + \"\\n\\n\" + a10M5Governance.report()\n            + \"\\n\\n\" + computeGovernor.report()",
        "A10 M5 governance diagnostics",
    )

    text = replace_once(
        text,
        "    func handleMemoryPressure() {\n        database.clearTransientCaches()",
        "    func handleMemoryPressure() {\n        a10M5Governance.cancel()\n        a10M5GovernanceRuntime.trimMemory()\n        database.clearTransientCaches()",
        "A10 M5 governance memory pressure",
    )
    text = replace_once(
        text,
        "    func handleBackgroundTransition() {\n        hostForegroundActive = false",
        "    func handleBackgroundTransition() {\n        a10M5Governance.cancel()\n        a10M5GovernanceRuntime.trimMemory()\n        hostForegroundActive = false",
        "A10 M5 governance background",
    )
    return text


def patch_runtime_diagnostics(text: str) -> str:
    anchor = '''        model.agent.$runtimeState\n            .map { String(describing: $0) }\n            .removeDuplicates()'''
    insertion = '''        model.agent.$a10M5ShadowCognition\n            .removeDuplicates()\n            .sink { snapshot in\n                guard snapshot.result != "IDLE" else { return }\n                Task { @MainActor in\n                    self.store.log(\n                        snapshot.result == "FAILED" ? .warning : .debug,\n                        .agent,\n                        event: "a10.m5.cognition_shadow",\n                        screen: DeepTelemetry.shared.currentScreen,\n                        metadata: [\n                            "result": snapshot.result,\n                            "runtime_id": snapshot.runtimeID,\n                            "output_digest": snapshot.outputDigest,\n                            "estimated_tokens": String(snapshot.estimatedTokenCount),\n                            "latency_ms": String(snapshot.latencyMilliseconds),\n                            "mutation_authority": "0",\n                            "prompt_logged": "false",\n                            "output_text_logged": "false",\n                            "failure": snapshot.failure ?? "none"\n                        ]\n                    )\n                }\n            }\n            .store(in: &cancellables)\n\n        model.a10M5Governance.$snapshot\n            .removeDuplicates()\n            .sink { snapshot in\n                guard snapshot.evaluatedAt != .distantPast else { return }\n                Task { @MainActor in\n                    self.store.log(\n                        .debug,\n                        .a9,\n                        event: "a10.m5.governance_shadow",\n                        screen: DeepTelemetry.shared.currentScreen,\n                        metadata: [\n                            "states": snapshot.states.joined(separator: ","),\n                            "action_proposals": snapshot.actionProposals.joined(separator: ","),\n                            "output_digest": snapshot.outputDigest,\n                            "latency_us": String(snapshot.latencyNanoseconds / 1_000),\n                            "backend": snapshot.backend,\n                            "model_hash": snapshot.modelHash,\n                            "feature_adapter": snapshot.featureAdapter,\n                            "recommendation": snapshot.recommendation,\n                            "mutation_authority": "0",\n                            "user_plaintext_logged": "false"\n                        ]\n                    )\n                }\n            }\n            .store(in: &cancellables)\n\n        model.agent.$runtimeState\n            .map { String(describing: $0) }\n            .removeDuplicates()'''
    return replace_once(text, anchor, insertion, "A10 M5 blackbox telemetry")


def copy_payload(root: Path, package_root: Path) -> None:
    payload = package_root / "Payload"
    for source in payload.rglob("*"):
        if not source.is_file():
            continue
        rel = source.relative_to(payload)
        destination = root / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def apply(root: Path, package_root: Path) -> None:
    try:
        require_markers(root, I12_MARKERS, "I12 already applied")
        print("I12 already present; verification only.")
        return
    except Exception:
        pass

    require_markers(root, I11_REQUIRED, "I11 prerequisite")

    bridging = root / "VeilLink/Native/VeilLink-Bridging-Header.h"
    bridging.write_text(patch_bridging(bridging.read_text(encoding="utf-8")), encoding="utf-8")

    agent = root / "VeilLink/Agent/Core/AgentCoordinator.swift"
    agent.write_text(patch_agent(agent.read_text(encoding="utf-8")), encoding="utf-8")

    app = root / "VeilLink/App/AppModel.swift"
    app.write_text(patch_app_model(app.read_text(encoding="utf-8")), encoding="utf-8")

    diagnostics = root / "VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift"
    diagnostics.write_text(patch_runtime_diagnostics(diagnostics.read_text(encoding="utf-8")), encoding="utf-8")

    copy_payload(root, package_root)
    require_markers(root, I12_MARKERS, "I12 post-apply")


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 I12_APPLY.py /path/to/VeilLink")
    root = Path(sys.argv[1]).resolve()
    package_root = Path(__file__).resolve().parent
    apply(root, package_root)
    print("I12 A10 Ultra Ω M5 TRAINED_COGNITION_SHADOW applied.")


if __name__ == "__main__":
    main()
