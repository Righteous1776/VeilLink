from pathlib import Path
import hashlib
import json
import sys

EXPECTED_MODEL = "c5ba826dab1ebe1db02e90e8b4bfd2c060e99586413970fa3bd4d848e378a8b4"
EXPECTED_ARRAYS = "3228384ef72a809e5725a54f4288ba0457288cb695338966eb679b82221e3e26"
EXPECTED_VOCAB = "fbf7edf8ffe3e1ed5d7e79baa5b118b8fc38ed646dbb684f0615349d611dec50"
EXPECTED_VEIL_M4 = "74b1f91cb90c95823c882c284f4c369f3f815f90e8d6e87e06d5038a84684204"
EXPECTED_SQLITE_M4 = "549026ee043e99d11cc4e8110ac6167a084a166978761e98f6c6047929e4afb4"

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''): h.update(block)
    return h.hexdigest()

def need(path: Path, markers):
    if not path.exists(): raise RuntimeError(f"missing {path}")
    text=path.read_text(encoding='utf-8',errors='replace')
    for marker in markers:
        if marker not in text: raise RuntimeError(f"{path}: missing {marker!r}")

if len(sys.argv)!=2:
    raise SystemExit('usage: python3 I12_VERIFY.py /path/to/VeilLink')
root=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
need(root/'VeilLink/Native/VeilLink-Bridging-Header.h',['#include "A10UltraM5Native.h"'])
need(root/'VeilLink/Native/A10UltraM5Native.c',['a10_ultra_m5_reasoner_f32','a10_ultra_m5_rnn_step_f32','a10_ultra_m5_host_predictor_i8'])
need(root/'VeilLink/Agent/Compute/A10UltraM5Runtime.swift',['final class A10UltraM5Runtime','TRAINED_COGNITION_SHADOW','VEILLINK_M4_PROXY_V1','sqlitePredictor','budget.totalUnits <= 0'])
need(root/'VeilLink/Agent/Integration/A10UltraM5GovernanceAdvisor.swift',['final class A10UltraM5GovernanceAdvisor','SHADOW_ADVISORY_ONLY','mutationAuthority: 0'])
need(root/'VeilLink/Agent/Core/AgentCoordinator.swift',['attachA10UltraShadowRuntime','launchA10UltraM5Shadow','a10M5ShadowCognition'])
need(root/'VeilLink/App/AppModel.swift',['let a10M5Governance: A10UltraM5GovernanceAdvisor','a10M5GovernanceRuntime.applyBudget','a10M5Governance.evaluate'])
need(root/'VeilLink/Diagnostics/RuntimeDiagnosticsBridge.swift',['event: "a10.m5.cognition_shadow"','event: "a10.m5.governance_shadow"','"prompt_logged": "false"','"user_plaintext_logged": "false"'])
need(root/'VeilLinkTests/A10UltraM5IntegrationTests.swift',['testRuntimeIdentityIsM5ShadowOnly','testNativeABIIsPinned','testGovernanceStartsReadOnly'])

asset=root/'VeilLink/Resources/A10UltraM5'
manifest=json.loads((asset/'ios_integration_manifest.json').read_text())
assert manifest['chip_name']=='A10 Ultra Ω'
assert manifest['source_model_hash']==EXPECTED_MODEL
assert manifest['source_arrays_hash']==EXPECTED_ARRAYS
assert manifest['vocab_sha256']==EXPECTED_VOCAB
assert manifest['predictor_weights_sha256']==EXPECTED_VEIL_M4
assert manifest['sqlite_predictor_weights_sha256']==EXPECTED_SQLITE_M4
assert manifest['mutation_authority']==0
assert manifest['production_cutover']=='DENY'
assert manifest['real_world_validation']=='NOT_PERFORMED'
assert sha(asset/'language_weights.bin')==EXPECTED_ARRAYS
assert sha(asset/'vocab.json')==EXPECTED_VOCAB
assert sha(asset/'runtime_predictor_weights.bin')==EXPECTED_VEIL_M4
assert sha(asset/'sqlite_predictor_weights.bin')==EXPECTED_SQLITE_M4

for f in [root/'VeilLink/Agent/Compute/A10UltraM5Runtime.swift', root/'VeilLink/Agent/Integration/A10UltraM5GovernanceAdvisor.swift']:
    t=f.read_text()
    for forbidden in ['BLETransport','DatabaseStore','KeychainStore','SessionCoordinator','IdentityManager','BackupManager']:
        if forbidden in t: raise RuntimeError(f"mutation object leaked into M5 runtime: {forbidden}")

native=json.loads((here/'I12_NATIVE_DIFFERENTIAL.json').read_text())
semantic=json.loads((here/'I12_SPIRIT_SEMANTIC_DIFFERENTIAL.json').read_text())
patch=json.loads((here/'I12_PATCH_SELFTEST.json').read_text())
assert native['pass'] is True and semantic['pass'] is True and patch['pass'] is True
print('I12 VERIFY PASS: A10 Ultra Ω M5 cognition/governance shadow is provenance-locked, non-mutating, and differential-validated.')
