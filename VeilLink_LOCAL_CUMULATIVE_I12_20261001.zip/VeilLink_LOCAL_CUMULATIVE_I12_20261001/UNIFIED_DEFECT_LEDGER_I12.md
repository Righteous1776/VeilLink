# VeilLink I12 — A10 Ultra Ω M5 Integration Ledger

## 状态

`A10_ULTRA_M5_TRAINED_COGNITION_SHADOW`

- A9：`GOVERNANCE_PRIMARY`
- A10 Ultra Ω M5：`COGNITION_SHADOW + GOVERNANCE_ADVISOR`
- LingCore：`ORCHESTRATION_PRIMARY`
- Host Action Layer：唯一 mutation authority
- M5 mutation authority：`0`
- production cutover：`DENY`

## 本轮确认并修复

### I12-01 — Linux/Python Runtime 不可直接进入 iOS
原训练包的 Native/Python host 不能作为 iPhone Runtime。已重新实现 portable C 数学核 + Swift host glue；原 ZIP 仅作为 Source Evidence，不进入 App Payload。

### I12-02 — 训练权重 provenance 必须与 pristine 源保持一致
验收脚本会重新训练并覆盖工作副本，因此重新从上传 ZIP 提取 pristine 源。iOS 资产固定绑定：M5 model `c5ba826d...`、arrays `3228384e...`、vocab `fbf7edf8...`。

### I12-03 — 仅移植 VeilLink M4 会破坏 SQLite 域 Spirit 语义
首次端到端差分出现 572/2000 mismatch。根因是 pristine SpiritCore 在 SQLite 域额外调用 `SQLITEVAULT_MICRO_ANOMALY_M4_SYNTHETIC`。已将该模型与路由完整纳入 iOS Runtime。

### I12-04 — M4 FP32 reference 与真实 Spirit INT8 hot path 不同
加入 SQLite 模型后仍出现 10/2000 边界 mismatch。根因是 pristine `compute.infer()` 默认走 INT8 动态量化，而初版 iOS M4 使用 FP32 reference。已移植 source-compatible INT8 dynamic activation 路径。最终 VeilLink/SQLite M4 各 10k random differential 均为 0 mismatch，Spirit 2k semantic differential 为 0 mismatch。

### I12-05 — Governance Runtime 未受统一 Compute Budget Gate
初版 M5 Governance Runtime 没有显式接收 A9 Compute Plan；低电/thermal constrained 时可能继续 Shadow 推理。已在采样前应用 `A10UltraComputeBudget.fromA9(computeGovernor.plan)`，并在 Runtime 内对 `totalUnits <= 0` 做硬抑制。A9 budget 仅是资源许可，不参与 M5 reasoning signal。

### I12-06 — 认知与治理共用 Runtime 会产生 cancel/state contention
采用两个独立 `A10UltraM5Runtime`：一个 LingCore cognition shadow，一个 Governance Advisor。

### I12-07 — “能治理”不等于直接获得业务写权限
Runtime/Advisor 源码禁止持有 `BLETransport / DatabaseStore / KeychainStore / SessionCoordinator / IdentityManager / BackupManager`。输出只形成 proposal；Host 决定是否执行。

## 仍未关闭的 Gate

- Xcode/iOS 编译：未执行
- XCTest：未在 Apple toolchain 执行
- ARM64/iPhone Native：未执行
- iPhone 7 / iPhone 13 thermal/RAM/battery：未执行
- 真实用户/真实链路 Shadow precision/recall：未执行
- LingCore visible takeover：DENIED
- VeilLink management mutation：DENIED
